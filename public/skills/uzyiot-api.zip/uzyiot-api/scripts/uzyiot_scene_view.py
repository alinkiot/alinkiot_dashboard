#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
uzyiot_scene_view.py — 创建/更新场景自定义 HTML 视图 CLI

流程：1) 上传 HTML（POST /iotapi/upload）
      2) 查询该场景该视图类型是否已有记录（GET /iotapi/system/scene_view/list）
      3) 无记录 → 创建（POST /iotapi/system/scene_view）
         有记录 → 更新（PUT  /iotapi/system/scene_view，带 id）

请求体：{"scene":<场景ID>,"sceneType":"custom:3W","data":"{\"path\":\"/upload/x.html\",\"caption\":\"标题\"}"[,"id":<视图ID>]}

示例：
  python3 uzyiot_scene_view.py --scene 19 --scene-type custom:3W --file ./view.html --caption 三维视图
  # 已有路径，跳过上传
  python3 uzyiot_scene_view.py --scene 19 --scene-type custom:3W --path /upload/x.html --caption 三维视图
  # 仅预览请求体
  python3 uzyiot_scene_view.py --scene 19 --scene-type custom:3W --file ./view.html --dry-run

注意：sceneType 必须是该场景 viewType 中已有的类型（custom:<名称的 URL 编码>）。
输出：JSON（stdout）。退出码：0=成功，1=失败，2=鉴权失败。
"""
import argparse
import json
import os
import sys

import uzyiot_api as api
import uzyiot_upload as up

VIEW_PATH = "/iotapi/system/scene_view"


def _find_existing(base_url, token, scene, scene_type):
    """返回已有视图记录的 id；没有则返回 None。"""
    url = api._build_url(
        base_url, VIEW_PATH + "/list", {"scene": scene, "sceneType": scene_type}
    )
    status, resp = api._request("GET", url, headers={"token": token})
    if status in (401, 403):
        sys.stderr.write("鉴权失败\n")
        sys.exit(2)
    if status != 200 or not isinstance(resp, dict):
        raise RuntimeError(f"查询已有视图失败: HTTP {status}")
    rows = resp.get("rows") or resp.get("data") or []
    if isinstance(rows, dict):
        rows = rows.get("rows") or []
    for row in rows:
        if str(row.get("sceneType")) == scene_type and str(row.get("scene")) == str(scene):
            return row.get("id")
    return None


def main(argv=None):
    p = argparse.ArgumentParser(description="创建/更新场景自定义 HTML 视图")
    up.add_common_args(p)
    p.add_argument("--scene", required=True, type=int, help="场景 ID")
    p.add_argument("--scene-type", required=True, help="视图类型，如 custom:3W")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--file", help="本地 HTML 文件，先上传再创建/更新")
    src.add_argument("--path", help="已上传的服务器路径（如 /upload/xxx.html），跳过上传")
    p.add_argument("--caption", default="", help="视图标题（data.caption）")
    p.add_argument("--id", type=int, help="视图记录 ID；不传则自动按 scene+sceneType 查询")
    p.add_argument("--dry-run", action="store_true", help="只打印将发送的请求体（仍会上传 --file）")
    args = p.parse_args(argv)

    token = up.prepare(args)

    path = args.path
    if args.file:
        if not os.path.isfile(args.file):
            sys.stderr.write(f"文件不存在: {args.file}\n")
            sys.exit(1)
        try:
            status, resp = up.upload_file(args.base_url, token, args.file)
        except RuntimeError as e:
            sys.stderr.write(str(e) + "\n")
            sys.exit(1)
        sys.stderr.write("上传响应: " + json.dumps(resp, ensure_ascii=False) + "\n")
        if status in (401, 403):
            sys.exit(2)
        path = up.extract_path(resp)
        if path and not path.startswith(("/", "http")):
            path = "/" + path  # 接口返回 upload/xxx，视图需要 /upload/xxx
        if status != 200 or not path:
            sys.stderr.write("上传失败或响应中未找到文件路径；可用 --path 手动指定。\n")
            sys.exit(1)

    view_id = args.id
    try:
        if view_id is None:
            view_id = _find_existing(args.base_url, token, args.scene, args.scene_type)
    except RuntimeError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)

    body = {
        "scene": args.scene,
        "sceneType": args.scene_type,
        "data": json.dumps(
            {"path": path, "caption": args.caption},
            ensure_ascii=False, separators=(",", ":"),
        ),
    }
    method = "POST"
    if view_id is not None:
        body["id"] = view_id
        method = "PUT"

    if args.dry_run:
        print(json.dumps({"method": method, "body": body}, ensure_ascii=False, indent=2))
        return

    url = api._build_url(args.base_url, VIEW_PATH)
    try:
        status, resp = api._request(
            method, url, headers={"Authorization": f"Bearer {token}"}, body=body
        )
    except RuntimeError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)
    print(json.dumps(resp, ensure_ascii=False, indent=2))
    if status in (401, 403):
        sys.exit(2)
    code = resp.get("code") if isinstance(resp, dict) else None
    sys.exit(0 if status == 200 and code in (None, 200) else 1)


if __name__ == "__main__":
    main()
