#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
uzyiot_upload.py — 通用文件上传 CLI（POST /iotapi/upload，multipart/form-data）

示例：
  python3 uzyiot_upload.py --file ./panel.html
  python3 uzyiot_upload.py --file ./a.png --token xxx

鉴权、base-url 解析与 uzyiot_api.py 一致（--token / --app-id+--app-secret / 环境变量 / env.ini）。
输出：JSON（stdout）。退出码：0=成功，1=失败，2=鉴权失败。
"""
import argparse
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request
import uuid

import uzyiot_api as api

UPLOAD_PATH = "/iotapi/upload"


def _multipart(field, filename, content):
    boundary = "----PythonFormBoundary" + uuid.uuid4().hex
    ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    head = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'
        f"Content-Type: {ctype}\r\n\r\n"
    ).encode("utf-8")
    tail = f"\r\n--{boundary}--\r\n".encode("utf-8")
    return boundary, head + content + tail


def upload_file(base_url, token, file_path, field="file"):
    """上传文件，返回 (http_status, 解析后的响应)。网络错误抛 RuntimeError。"""
    with open(file_path, "rb") as f:
        content = f.read()
    boundary, body = _multipart(field, os.path.basename(file_path), content)
    req = urllib.request.Request(
        api._build_url(base_url, UPLOAD_PATH),
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Accept": "*/*",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=api.TIMEOUT, context=api.SSL_CONTEXT) as r:
            return r.status, api._try_json(r.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as e:
        return e.code, api._try_json(e.read().decode("utf-8", errors="replace"))
    except urllib.error.URLError as e:
        raise RuntimeError(f"网络错误: {e.reason}") from e


def extract_path(resp):
    """从上传响应里提取服务器文件路径（如 /upload/xxx.html）。找不到返回 None。"""
    if not isinstance(resp, dict):
        return None
    for src in (resp, resp.get("data")):
        if isinstance(src, str) and src:
            return src
        if isinstance(src, dict):
            for k in ("path", "fileName", "filePath", "url", "relativePath"):
                if src.get(k):
                    return src[k]
    return None


def add_common_args(parser):
    parser.add_argument("--base-url", default=None, help="平台地址；缺省按 env.ini host / 默认值")
    parser.add_argument("--insecure", action="store_true", help="不校验 HTTPS 证书（不安全）")
    parser.add_argument("--token", help="鉴权 token；缺省读 UZYIOT_TOKEN")
    parser.add_argument("--app-id", help="appId，自动登录换 token")
    parser.add_argument("--app-secret", help="appSecret")


def prepare(args):
    if args.insecure:
        api.enable_insecure()
    if not args.base_url:
        args.base_url = (
            os.environ.get("UZYIOT_BASE_URL") or api.host_from_env_ini() or api.DEFAULT_BASE_URL
        )
    args.project = None
    token, _ = api.resolve_token(args)
    return token


def main(argv=None):
    p = argparse.ArgumentParser(description="通用文件上传（POST /iotapi/upload）")
    add_common_args(p)
    p.add_argument("--file", required=True, help="要上传的本地文件路径")
    p.add_argument("--field", default="file", help="multipart 字段名，默认 file")
    args = p.parse_args(argv)

    if not os.path.isfile(args.file):
        sys.stderr.write(f"文件不存在: {args.file}\n")
        sys.exit(1)
    token = prepare(args)
    try:
        status, resp = upload_file(args.base_url, token, args.file, args.field)
    except RuntimeError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)
    print(json.dumps(resp, ensure_ascii=False, indent=2))
    if status in (401, 403):
        sys.exit(2)
    code = resp.get("code") if isinstance(resp, dict) else None
    sys.exit(0 if status == 200 and code in (None, 200) else 1)


if __name__ == "__main__":
    main()
