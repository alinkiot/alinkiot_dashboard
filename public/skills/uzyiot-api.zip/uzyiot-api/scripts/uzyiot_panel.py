#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
uzyiot_panel.py — 创建产品面板 CLI

流程：1) 上传 HTML 模板（POST /iotapi/upload）
      2) 创建面板（POST /iotapi/system/dict_data，dictType=iot_product_mgr）

示例：
  # 上传并创建
  python3 uzyiot_panel.py --file ./panel.html --label 大经 --value dji --remark 备注
  # 已有服务器路径，跳过上传
  python3 uzyiot_panel.py --path /upload/xxx.html --label 大经 --value dji
  # 仅预览请求体
  python3 uzyiot_panel.py --file ./panel.html --label 大经 --value dji --dry-run

dictValue 为 JSON 字符串：{"type":<--type>,"value":<--value>,"path":<上传得到的路径>}
输出：JSON（stdout）。退出码：0=成功，1=失败，2=鉴权失败。
"""
import argparse
import json
import os
import sys

import uzyiot_api as api
import uzyiot_upload as up

DICT_PATH = "/iotapi/system/dict_data"
DICT_TYPE = "iot_product_mgr"


def main(argv=None):
    p = argparse.ArgumentParser(description="创建产品面板（先上传 HTML 模板，再创建面板）")
    up.add_common_args(p)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--file", help="本地 HTML 模板文件，先上传再创建")
    src.add_argument("--path", help="已上传的服务器路径（如 /upload/xxx.html），跳过上传")
    p.add_argument("--label", required=True, help="面板名称（dictLabel）")
    p.add_argument("--value", required=True, help="面板标识（dictValue.value）")
    p.add_argument("--type", default="html", help="dictValue.type，默认 html；上传图片时用 image")
    p.add_argument("--remark", default="", help="备注")
    p.add_argument("--sort", type=int, default=0, help="排序 dictSort，默认 0")
    p.add_argument("--status", default="0", help="状态，默认 0（正常）")
    p.add_argument("--list-class", default="file", help="listClass，默认 file")
    p.add_argument("--dry-run", action="store_true", help="只打印将发送的请求体，不创建（仍会上传 --file）")
    args = p.parse_args(argv)

    token = up.prepare(args)

    path = args.path
    if args.file:
        if not os.path.isfile(args.file):
            sys.stderr.write(f"文件不存在: {args.file}\n")
            sys.exit(1)
        try:
            status, resp = up.upload_file(args.base_url, token, args.file)
        except RuntimeError as e:
            sys.stderr.write(str(e) + "\n")
            sys.exit(1)
        sys.stderr.write("上传响应: " + json.dumps(resp, ensure_ascii=False) + "\n")
        if status in (401, 403):
            sys.exit(2)
        path = up.extract_path(resp)
        if path and not path.startswith(("/", "http")):
            path = "/" + path  # 接口返回 upload/xxx，面板需要 /upload/xxx
        if status != 200 or not path:
            sys.stderr.write("上传失败或响应中未找到文件路径；可用 --path 手动指定。\n")
            sys.exit(1)

    body = {
        "dictType": DICT_TYPE,
        "dictLabel": args.label,
        "dictValue": json.dumps(
            {"type": args.type, "value": args.value, "path": path},
            ensure_ascii=False, separators=(",", ":"),
        ),
        "listClass": args.list_class,
        "dictSort": args.sort,
        "status": args.status,
        "remark": args.remark,
    }
    if args.dry_run:
        print(json.dumps(body, ensure_ascii=False, indent=2))
        return

    url = api._build_url(args.base_url, DICT_PATH)
    try:
        status, resp = api._request(
            "POST", url, headers={"Authorization": f"Bearer {token}"}, body=body
        )
    except RuntimeError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)
    print(json.dumps(resp, ensure_ascii=False, indent=2))
    if status in (401, 403):
        sys.exit(2)
    code = resp.get("code") if isinstance(resp, dict) else None
    sys.exit(0 if status == 200 and code in (None, 200) else 1)


if __name__ == "__main__":
    main()
