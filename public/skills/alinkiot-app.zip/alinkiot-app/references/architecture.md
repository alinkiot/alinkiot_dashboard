# 架构与数据模型

## 边界

MySQL 始终保存账户、授权、项目、设备档案、配置、任务、审计和报表元数据。时序数据通过 `TelemetryStore` 统一读写：设备规模较小时存 MySQL，不部署 TDengine；规模较大时增加 TDengine 专门存设备时序数据，业务数据仍存 MySQL。这是增加时序库，不是将 MySQL 业务库切换为 TDengine。根据设备数、测点数、采样/同步频率、保留期限和查询负载评估容量并记录选型依据，不使用未经验证的通用设备数阈值。外部数据库属于数据源，不等于应用业务库；源库账户默认只读。

```text
浏览器 → FastAPI → 授权服务 → 业务服务 → MySQL
                            ├─ TelemetryStore → 小规模：MySQL 时序表
                            │                  大规模：额外的 TDengine 时序库
独立调度进程 → 同步 worker ──┤
                  连接器 → 规范化 → 安全公式 → 幂等写入
浏览器聊天窗 → AI 服务 → 上下文构建与脱敏 → 模型提供商
```

新应用使用模块化单体，不预设微服务。调度器不得在每个 Web worker 的启动事件中重复启动。

## 固定三级权限

以下矩阵为固定开发规则，不提供自定义角色或向普通用户授予管理能力的开关。项目授权决定数据范围，操作能力只能在角色上限内收紧，不能突破角色边界；变更规则须由用户明确提出。

客户是隔离边界，项目是授权边界。非超管用户只属于一个客户。一个客户可有多个管理员；管理员只能管理自己有权访问的项目。

| 操作 | 超管 | 客户管理员 | 普通用户 |
|---|---|---|---|
| 创建客户、客户管理员 | 全部 | 否 | 否 |
| 创建普通用户 | 不参与日常管理 | 仅本客户 | 否 |
| 同步/新建项目、绑定外部项目 | 是 | 否 | 否 |
| 分配项目给客户及管理员 | 是 | 否 | 否 |
| 给普通用户分配项目 | 不参与日常管理 | 本客户且自己有权的项目 | 否 |
| 修改接入/治理/同步配置 | 全部 | 自己有权的项目，且获授对应能力 | 否 |
| 查询数据、大屏、曲线、报表 | 全部 | 自己有权的项目 | 自己有权的项目 |
| 保存共享曲线、报表定义、大屏编辑与发布 | 全部 | 自己有权的项目且获授对应能力 | 否 |
| 创建、修改、删除个人曲线 | 是 | 自己的视图，数据须获授权 | 自己的视图，数据须获授权 |
| 生成报表、导出数据、下载文件 | 全部 | 获授权项目且获授对应能力 | 获授权项目且获授对应能力，不可修改报表定义 |
| 手动执行、启停同步任务 | 全部 | 获授权项目且获授对应能力，不能操作统一任务 | 否 |
| 查看 AI 分析 | 全部 | 自己有权的数据 | 自己有权的数据 |
| 修改项目智能体接入/数字人选择、智能预警任务配置与启停 | 全部 | 获授权项目且获授对应管理能力 | 否 |
| 维护共享智能报表任务 | 全部 | 获授权项目且获授对应管理能力 | 否 |
| 手动生成/查看智能报表结果 | 全部 | 获授权项目且获授对应能力 | 获准生成/下载，不修改共享任务定义 |
| 查看告警、历史与处理记录 | 全部 | 自己有权的项目 | 自己有权的项目 |
| 配置告警规则、通知策略，确认与处理告警 | 全部 | 自己有权的项目且获授对应能力 | 否 |

超管不绑定客户，通过显式全局授权路径访问；不是用“缺少 customer_id 就不加过滤”的方式跳过权限。

- 项目属于一个客户；未分配的项目仅超管可见。跨客户共享必须另行设计，默认不支持。
- 每次请求计算 `ActorScope(user_id, role, customer_id, project_ids, capabilities)`；超级管理员使用独立分支。
- 资源查询同时约束资源 ID 与允许项目；关联设备、曲线系列、导出文件、AI 会话也必须逐级检查。
- 管理员给普通用户授权只能授予自己的项目子集。不能修改自己的角色、客户归属或权限上限。
- 普通用户的固定能力上限为业务查询、大屏查看、AI 使用、获准的导出/报表生成下载、个人曲线管理；保存个人曲线不等于允许修改设备档案、共享报表、大屏、公式或任务。服务端对能力授权也检查角色上限，不能通过手工 API 请求给普通用户加入管理能力。
- 超管负责开通客户管理员、分配客户项目，不承担客户内部用户的日常维护。管理员离职后的账号停用、凭证重置和管理员账号交接由企业自行处理，不应通过共享原管理员密码完成交接。
- 项目授权归客户持有，不是管理员个人的委托链。管理员停用或其个人项目授权收回，只影响本人访问，不级联撤销其他用户已有的合法授权。记录授权操作者用于审计，不将操作者账号有效性作为被授权用户持续访问的条件。
- 项目从客户收回时，撤销该客户下该项目的全部授权，并使相关查询、下载、大屏、同步与 AI 后续请求失效；与仅停用某个管理员账号明确区分。
- 统一任务的配置/执行仅限超管；客户管理员只可看其项目对应的执行片段，不能看到其他项目载荷。
- 收回授权后立即影响查询、后台生成、下载、大屏与 AI 后续请求；长任务分块执行前和发布结果前重新检查授权。
- 项目转移客户时用事务清理原客户授权、会话可见性和缓存；保留审计，不能让原客户继续访问。
- 敏感变更写入审计：操作者、对象、动作、时间、脱敏后的前后差异和请求 ID。

## 核心表

所有业务 ID 建议用应用生成的 UUID；迁移中统一 MySQL 存储类型。公共字段包括 `id`、`created_at`、`updated_at`；需要版本并发控制的配置增加 `version`。

| 表 | 核心字段 / 约束 |
|---|---|
| `customers` | name、status |
| `users` | customer_id、role、username、password_hash、status；用户名唯一 |
| `user_sessions` | user_id、refresh_token_hash、expires_at、revoked_at |
| `projects` | customer_id 可空、name、timezone、status |
| `project_grants` | project_id、user_id、capabilities；二元唯一 |
| `data_sources` | kind、endpoint、secret_ref、timeout、allowlisted_hosts |
| `project_bindings` | source_id、external_project_id、project_id；来源与外部 ID 唯一 |
| `device_types` | code、name、archive_table、telemetry_table、schema_version |
| `device_fields` | type_id、code、storage_type、unit、is_metric、nullable |
| `products` / `product_properties` | source_id、external_product_id、type_id、customer_id 可空、schema_version、synced_at；来源属性标识、type、unit、read/write、映射与约束，来源与外部标识唯一，后台只读 |
| `device_registry` | project_id、type_id、product_id、source_id、external_device_id、archive_id；来源与外部设备 ID 唯一 |
| `scenes` / `scene_devices` | project_id、name；scene_id 与 device_id 唯一，设备须同项目 |
| `display_panels` / `panel_versions` | kind、所属产品/场景/曲线/项目、owner_id、visibility、版本、入口/资源 key、基础配置、status |
| `curve_views` / `curve_series` | owner_id、project_id、visibility、设备/测点、轴与颜色；默认不跨项目 |
| `dashboard_versions` | project_id、version、layout_json、status；项目与版本唯一 |
| `report_definitions` / `report_runs` | project_id、filters、status、file_key、expires_at |
| `governance_rules` | project_id、type_id、metric_code、expression、version、status |
| `sync_jobs` / `sync_runs` | scope、project_id 可空、schedule、timezone、status、cursor、锁租约、运行统计 |
| `sync_job_products` / `sync_formula_bindings` | job_id、source_id、product_id、property_key、formula_id/version、变量/参数映射、output_unit、异常策略；同任务产品属性绑定唯一 |
| `sync_run_items` | run_id、project_id、cursor_before、cursor_after、status、错误摘要 |
| `alarm_rules` / `alarm_rule_versions` | project_id、设备/测点范围、条件、单位、等级、持续/恢复策略、通知策略、version、status |
| `alarm_states` | rule_id、device_id、metric_code 唯一；当前事件 ID、连续异常/恢复计数、最后已处理样本标识，支持并发控制 |
| `alarm_events` | project_id、source（device_rule / intelligent_warning）、rule_version 或 warning_run_id、device_id、metric_code、触发证据、检测/处理状态、首次/最近发生与恢复时间；活动事件幂等标识 |
| `alarm_actions` | event_id、actor_id、action、说明、时间；追加记录 |
| `notification_outbox` / `notification_deliveries` | event_id、消息类型、接收人、渠道、幂等键、status、重试次数、下次重试时间、错误摘要；凭证不入日志 |
| `ai_templates` | key、version、system_prompt、context_schema、allowed_roles、status |
| `ai_conversations` / `ai_messages` | owner_id、project_id、template_version、消息、保留期限 |
| `agent_connections` / `agent_connection_versions` | project_id 唯一有效配置、adapter_key、base_url、appid、secret_ref、version、status；Secret 不回显 |
| `agent_avatars` / `project_agent_selections` | connection_version、external_avatar_id、name、capabilities、status、fetched_at；项目默认数字人须来自对应平台 |
| `intelligent_report_tasks` / `intelligent_report_runs` | project_id、设备引用、范围、要求、任务版本；运行者、固定模板/数字人版本、status、证据/文件 key、错误与保留期限 |
| `intelligent_warning_tasks` / `warning_task_devices` | project_id、interval_minutes、window_minutes、分析/触发要求、level、version、enabled；设备关联同项目 |
| `intelligent_warning_runs` | task_id、task_version、scheduled_at 唯一、窗口、配置/数字人/模板版本、status、attempt、租约/fencing、数据质量、校验结论、错误与证据 |
| `audit_logs` | actor_id、project_id 可空、action、resource、request_id |

产品、场景及面板归属、SDK 与控制边界见 [面板契约](panels.md)。产品和面板元数据始终存 MySQL，上传资源存受控文件/对象存储，不写入 TDengine；不得将 HTML 资源当后台同源程序执行。

角色与客户关系、授权客户一致性须在服务层校验并测试；可用外键、唯一键和检查约束增强完整性，不能仅依赖 UI。

告警规则、检测状态、事件、处理记录及通知记录始终存 MySQL，不属于 TDengine 时序样本。启用 TDengine 时，告警评估只消费已确认持久化的样本，使用可重放批次与幂等状态保证跨库最终一致，不依赖跨库原子事务。

智能体配置、数字人元数据、智能报表/预警任务和执行记录同样存 MySQL；报表文件与较大证据存受控文件/对象存储。智能预警写入现有告警模型但以来源、任务执行和证据区分，不假冒设备阈值规则；事件检测生命周期与人工处理分开。任务只引用授权设备，不复制新的设备身份或绕过原时序权限。演示存储键/UUID/hash 路由不是生产 schema 或权限凭证。

## 按设备类型分表

`device_registry` 只是统一身份索引，不承载全部异构设备字段。水表、电表等各自有档案表和测点表：

```text
device_water_meter(id, project_id, serial_number, diameter_mm, location, ...)
telemetry_water_meter(project_id, device_id, event_time, source_key,
                      flow_m3h, total_m3, raw_json, rule_versions_json, quality, ingested_at)
device_power_meter(id, project_id, serial_number, rated_voltage, phase_count, ...)
telemetry_power_meter(project_id, device_id, event_time, source_key,
                      voltage_v, current_a, power_kw, energy_kwh, raw_json,
                      rule_versions_json, quality, ingested_at)
```

- 所有查询通过注册表解析设备类型与物理表映射；外部请求不能指定物理表。
- 类型编码使用严格白名单；表结构变更必须经 Alembic 或专用受审 schema 迁移，不在普通请求中执行任意 DDL。
- MySQL 时序索引至少包含 `(project_id, device_id, event_time)`；唯一键按来源事件标识设计。无事件 ID 时使用稳定的设备、时间、测点/序号组合，不假设同一秒只有一条数据。
- 新增字段明确单位、精度、空值、时间语义和历史兼容；大表变更考虑在线迁移及回滚。
- TDengine 可按设备类型建立超级表、按设备建立子表，项目/设备信息作为标签；字段名和类型根据实际部署版本验证。与 MySQL 档案保持一致，禁止宣称跨库原子事务。
- MySQL 元数据与 TDengine 写入通过持久化执行记录、幂等键和可重放批次保证最终一致；成功落库后才推进游标。

## API 契约

统一前缀 `/api/v1`，分页有上限，错误返回 `code`、`message`、`request_id`，不要泄漏 SQL 或凭证。

| 路由示意 | 功能 |
|---|---|
| `/auth/login`、`/auth/refresh`、`/auth/logout`、`/me` | 认证与当前有效权限 |
| `/customers`、`/users`、`/projects/{id}/grants` | 客户、用户及项目授权 |
| `/projects`、`/project-bindings` | 项目管理与外部绑定 |
| `/device-types`、`/devices`、`/devices/{id}` | 类型与档案查询 |
| `/products`、`/products/{id}/properties` | 同步产品物模型及兼容版本，只读查询；写入由受控同步服务完成 |
| `/projects/{id}/scenes`、`/scenes/{id}/devices` | 项目场景及设备关联 |
| `/display-panels`、`/display-panels/{id}/versions` | 面板资源、版本与受控预览 |
| `/panel-sessions`、`/device-commands` | 短期受限 SDK 会话与默认关闭的控制服务，逐请求授权 |
| `/telemetry/latest`、`/telemetry/history`、`/telemetry/aggregate` | 实时、历史、降采样 |
| `/curve-views` | 跨设备曲线配置 |
| `/projects/{id}/dashboards` | 大屏版本与发布 |
| `/reports`、`/report-runs/{id}/download` | 报表定义、执行和授权下载 |
| `/governance-rules`、`/governance-rules/preview` | 公式版本和预览 |
| `/sync-jobs`、`/sync-jobs/{id}/run`、`/sync-runs` | 任务与执行记录 |
| `/alarm-rules`、`/alarm-rules/preview` | 告警规则、版本与条件预览 |
| `/alarm-events`、`/alarm-events/{id}`、`/alarm-events/{id}/actions` | 当前/历史告警、证据与确认处理 |
| `/notification-policies`、`/notification-deliveries` | 项目通知策略与授权范围内的投递记录 |
| `/ai/conversations`、`/ai/messages/stream`、`/ai/analyses` | 聊天与固定模板分析 |
| `/projects/{id}/agent-connection`、`/projects/{id}/agent-avatars`、`/projects/{id}/agent-selection` | 项目接入配置、平台数字人列表/选择；请求由后端执行，响应不含 Secret |
| `/intelligent-report-tasks`、`/intelligent-report-tasks/{id}/runs`、`/intelligent-report-runs/{id}/download` | 智能报表配置、手动异步生成与授权结果下载 |
| `/intelligent-warning-tasks`、`/intelligent-warning-tasks/{id}/status`、`/intelligent-warning-runs` | 预警配置/启停、受权执行记录，触发结果在告警接口按来源查询 |

历史/聚合接口接收逻辑设备 ID、测点、时间范围、粒度和时区；返回系列、单位、质量及来源时间。服务端限制设备数、时间跨度和结果点数。流式 AI 可用 POST + fetch 读取 SSE，不把令牌放在 URL 中。
