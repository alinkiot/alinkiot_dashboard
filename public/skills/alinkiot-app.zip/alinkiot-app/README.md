# AlinkIoT App Skill

用于指导 AI 开发 **Python + MySQL 物联网应用** 的可复用技能。设备规模较小时，MySQL 同时存业务数据和时序数据，不需要 TDengine；规模较大时增加 TDengine 专门存设备时序数据，MySQL 仍保存账户、权限、项目、设备档案等业务数据，不被替代。是否增加时序库结合设备数、测点数、采样频率、保留期限及查询负载判断。这是开发技能及主题参考包，不是已经接入真实设备的业务系统。

## 使用

将本目录作为 `alinkiot-app` 技能目录添加到支持 `SKILL.md` 的工具中；或在开发仓库中让 AI 读取本目录的 `SKILL.md`，按其规范实施。

示例指令：

> 使用 alinkiot-app 创建物联网管理平台，Python + MySQL，先不启用 TDengine。选择 letu-smart 风格和 dark 配色，从 HTTP API 同步水表和电表，每类设备独立建表。实现项目管理、三级权限、产品属性与设备绑定、项目场景、实时/历史查询、卡片式曲线面板、项目多大屏、报表、告警、公式治理和定时同步。产品、场景、曲线支持上传 HTML，大屏支持 HTML/ZIP，提供隔离面板 SDK。右下角提供 AI 助手，历史查询页面提供 AI 分析；没有接口和 AI 凭证时使用明确标记的演示模式，真实控制默认关闭。

## 内容

完整平台模块包括：项目管理、固定三级权限、产品物模型、设备档案、现场场景、实时/历史查询、卡片式曲线面板、项目多大屏、报表中心、告警中心、数据治理、同步任务、项目智能体平台接入、智能诊断/分析/预警/报表与统一聊天。产品/场景/曲线支持上传 HTML，大屏支持 HTML/ZIP，统一通过隔离面板 SDK 使用受限设备数据；真实控制默认关闭。Letu 已提供本地参考，其他主题后续同步。告警规则独立页、通知记录放事件页；智能预警触发结果进入事件，标记来源，不将固定预警样本当已实现服务。

| 文件 | 用途 |
|---|---|
| [SKILL.md](SKILL.md) | 技能入口、默认技术栈、实施流程与约束 |
| [framework/](framework/README.md) | 可运行的 MySQL 安装、客户/项目/三级权限/日志、Letu 风格真实后台与声明式产品插件框架 |
| [references/architecture.md](references/architecture.md) | 架构、三级权限、项目隔离、设备分表与接口契约 |
| [references/modules.md](references/modules.md) | 全部业务模块的行为和验收要求 |
| [references/panels.md](references/panels.md) | 产品、场景、曲线/大屏卡片、上传面板与 SDK 边界 |
| [references/data-and-ai.md](references/data-and-ai.md) | 接入、治理、调度、项目智能体协议、智能报表生成与智能预警告警桥接 |
| [references/delivery.md](references/delivery.md) | 实施阶段、配置、测试及交付标准 |
| [themes/](themes/README.md) | 一目录一风格；澄明、星澜、路曜、秩序、微屿五套主题及各自配色 |

## 安装与插件框架

`framework/` 已提供独立 FastAPI 服务：网页 `/install` 使用一次性令牌连接 MySQL 8，默认库名 `alinkiot_app`，目标库不存在时正式安装自动建库，再初始化核心表、超管及产品插件表；已有库不清空，测试连接不写入，安装后入口锁定。AI 根据接口生成受审 `plugin.json`，部署到固定插件目录，安装时合并建表，后续由超管执行幂等更新，支持新增产品及可空字段。

```bash
cd framework
uv sync --locked
uv run alinkiot install-token
uv run alinkiot serve
```

访问 `http://127.0.0.1:58239/install`。安装后从 `/` 登录 Letu 风格真实后台，使用客户管理、项目管理、固定三级账号与项目授权、操作日志及产品插件。已安装环境无需重建数据库，重启服务即可使用新增基础模块。生成新应用时由 SKILL 先询问主题选择，业务 API 不绑定 Letu。

详细部署、密钥、插件契约和 MySQL 校验见 [框架说明](framework/README.md)。现在可通过标准本地 HTTP 模拟平台跑通“产品映射 → 设备/采样同步 → 公式入库 → 查询/报表/告警 → `agent` 智能体问答/预警”的真实后端闭环，并保存场景/曲线/大屏与限时分享。旧安装先执行 `uv run alinkiot upgrade`，Web、`alinkiot worker` 和 `alinkiot mock` 分别启动。模拟回答有明确标识；真实平台、ZIP/产品操作面板、完整通知/报表策略等仍待适配和扩展，详见框架说明的剩余范围。`themes/` 仍是独立离线参考，不与真实账号库混用。

## 主题样式

每套主题有独立样式名，目录名作为稳定的样式 ID；配色是样式内的选项，不另建风格目录。

| 样式名 | 样式 ID / 目录 | 视觉特点 | 可选配色 |
|---|---|---|---|
| **澄明 · Clear Console** | `themes/alink-console/` | 简洁卡片、清晰留白、轻量边框，适合通用管理与数据查询 | 清爽蓝白 `ocean-light`（默认）、午夜蓝 `midnight`、工业青绿 `industrial` |
| **星澜 · Stellar Glass** | `themes/letu-smart/` | 玻璃质感、渐变光晕、网格背景、高密度数据布局，适合工业监控与运营驾驶舱 | 科技蓝 `dark`（默认）、明亮白 `light` |
| **路曜 · Highway Command** | `themes/highway-command/` | 三栏态势、路线测点、分级预警，适合基础设施监测大屏 | 深蓝青光 `night-cyan`、明亮蓝白 `day-blue` |
| **秩序 · Order Workspace** | `themes/order-workspace/` | 中性浅底、靛蓝操作色、紧凑表格、筛选分页与详情，适合 B 端业务管理 | 中性靛蓝 `slate-indigo` |
| **微屿 · Soft Atelier** | `themes/soft-atelier/` | 圆角工作台、轻量侧栏、蜂窝和点阵分析，适合柔和轻盈的 B 端洞察界面 | 暖白柔彩 `warm-petal`、薄荷青 `mint-garden`、雾蓝 `mist-blue`、柔紫 `soft-lilac`、燕麦 `oat-latte` |

使用时可直接说明：“采用澄明样式，午夜蓝配色”或“采用星澜样式，科技蓝配色”。样式名用于选型，实际集成仍使用对应样式 ID 和配色 ID。

## 预览主题

直接用浏览器打开 `themes/alink-console/index.html`，不需要安装依赖，也不请求外部资源。可以切换配色、模块及项目，查看演示曲线，打开 AI 聊天窗和页面分析。所有数据与 AI 回复均为本地演示。其他风格使用各自目录中的 `index.html`，详见 [主题目录](themes/README.md)。

乐图智慧风格入口为 `themes/letu-smart/index.html`，提供科技蓝与明亮白配色；设计令牌、组件与迁移说明见 [Letu Smart 主题](themes/letu-smart/README.md)。

## Letu 当前实现与入口

以下是浏览器本地交互，不是 Python/MySQL 后端已完成的声明。配置使用当前浏览器本地存储，不能作为客户或账号权限边界。

| 模块 | 预览入口 | 当前能力 |
|---|---|---|
| 客户、项目、权限 | `#customers` / `#projects` / `#roles` | 档案维护、归属调整、固定三级角色授权模型；身份模拟仅作用于权限页 |
| 产品与设备 | `#products` / `#devices` | 同步属性只读展示、同类型产品绑定、设备定位、基础状态及上传 HTML 面板；真实来源尚未连接 |
| 项目场景 | `#scenes` | 项目—场景树、列表/地图/多个命名 HTML 标签、现场设备关联；地图为坐标示意 |
| 查询与曲线 | `#realtime` / `#history` / `#curves` | 固定历史样本、同源统计、曲线面板卡片→当前页详情/返回、设备属性及 HTML；实时自动刷新未闭环 |
| 项目大屏 | `#bigscreen` | 卡片→当前页详情/返回，抽屉选择所属项目；HTML/ZIP 与独立页分享（同浏览器存档），未正式发布 |
| 报表与告警 | `#reports` / `#alarms` | 本地报表模板/统计/CSV、告警处理/规则/模拟重试；无真实检测或通知投递 |
| 智能体接入 | `#agent-access` | 按项目保存 URL/示例 AppID，固定数字人列表与选择；Secret 禁用、无真实请求 |
| 智能报表 / 智能预警 | `#ai-report` / `#ai-warning` | 本地任务新建/保存/查看；预警周期/窗口/条件与启停；报表未生成、预警未运行/未触发 |
| 治理、同步、诊断/分析、日志 | 对应菜单 | 仍有展示样本及提示型操作，不代表任务、模型或真实审计已接通 |

自定义面板从 [SDK 说明](themes/letu-smart/sdk/README.md) 和 [HTML 示例](themes/letu-smart/sdk/example.html) 开始。业务关系、生产权限与上传契约见 [产品、场景与面板](references/panels.md)；逐步操作见 [Letu 使用流程](themes/letu-smart/README.md#产品与面板使用流程)。

后续重点：全局身份与项目权限贯通、公式实际试算/版本、同步执行闭环、统一 AI 上下文、实时刷新、真实操作日志。后端连接器、数据库、鉴权、正式文件发布及硬件指令服务均未在主题中实现。其他四套主题尚未同步产品、场景和新版面板功能。

SKILL 已将 Letu 确定的菜单顺序、面板交互与智能任务细化为实现/验收规范：生产应用需实现平台凭证保护、数字人 API、智能报表异步结果、智能预警可靠调度和来源告警闭环，不把主题的本地配置当后台服务。

高速公路监测参考风格入口为 `themes/highway-command/index.html`；地形为离线 SVG 示意，设计与集成说明见 [路曜主题](themes/highway-command/README.md)。

B 端业务管理风格入口为 `themes/order-workspace/index.html`，提供完整菜单、筛选分页与详情等交互，详见 [秩序主题](themes/order-workspace/README.md)。

图片参考的柔和分析后台入口为 `themes/soft-atelier/index.html`，详见 [微屿主题](themes/soft-atelier/README.md)。
