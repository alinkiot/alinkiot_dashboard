"use strict";

const $ = (id) => document.getElementById(id);
const STATUS = {
  ok: { label: "正常", color: "green" }, yellow: { label: "黄色", color: "yellow" },
  orange: { label: "橙色", color: "orange" }, red: { label: "红色", color: "red" },
  off: { label: "离线", color: "sub" }
};
const PROJECTS = {
  east: { name: "东线高速 K98—K135", start: 98, factor: 1, states: ["ok", "yellow", "orange", "ok", "off", "ok", "orange", "red", "ok", "yellow", "ok", "off"] },
  west: { name: "西线高速 K42—K68", start: 42, factor: .72, states: ["ok", "ok", "yellow", "ok", "ok", "off", "ok", "orange", "ok", "ok", "ok", "ok"] }
};
const TYPES = [
  { name: "GNSS 北斗接收机", group: "位移监测", table: "device_gnss", metric: "累计位移", unit: "mm", value: 38.6 },
  { name: "翻斗式雨量计", group: "环境监测", table: "device_rain_gauge", metric: "24h 累计雨量", unit: "mm", value: 128.6 },
  { name: "孔隙水压计", group: "水压监测", table: "device_piezometer", metric: "孔隙水压", unit: "kPa", value: 86.4 }
];
const SERIES = [
  { name: "累计位移", unit: "mm", color: "cyan", max: 50, day: [12, 14, 17, 18, 22, 27, 33, 38.6], week: [6, 11, 15, 20, 25, 30, 38.6] },
  { name: "小时雨量", unit: "mm", color: "yellow", max: 50, day: [0, 3, 12, 29, 42.3, 25, 12, 5], week: [0, 5, 2, 12, 28, 38, 9] },
  { name: "孔隙水压", unit: "kPa", color: "green", max: 100, day: [34, 36, 40, 48, 61, 75, 82, 86.4], week: [32, 38, 40, 53, 65, 78, 86.4] }
];
const PAGES = {
  overview: ["运行中心", "运行概览", "全线测点、预警与监测趋势。"],
  projects: ["资产与权限", "项目管理", "接口同步、手动新建、外部绑定与客户分配。"],
  permissions: ["资产与权限", "权限管理", "超管、客户管理员、普通用户三级授权边界。"],
  devices: ["资产与权限", "设备档案", "按设备类型管理档案，保留独立表结构。"],
  realtime: ["数据应用", "实时查询", "查看最新值、采样时间与质量；固定样本不轮询。"],
  history: ["数据应用", "历史查询", "按时间范围查看采样曲线与明细。"],
  curves: ["数据应用", "曲线管理", "组合不同设备系列，按单位独立数值轴展示。"],
  dashboard: ["可视化与报表", "项目大屏", "当前项目独立态势预览；未接入真实发布服务。"],
  reports: ["可视化与报表", "报表中心", "报表定义、生成记录、计算口径与导出状态。"],
  governance: ["治理与同步", "数据治理", "固定公式预览，保留原始值与规则版本。"],
  sync: ["治理与同步", "同步任务", "项目任务与统一任务的调度、游标和执行记录。"],
  assistant: ["AI 能力", "AI 在线助手", "右下角统一聊天窗，按项目隔离本地会话。"],
  analysis: ["AI 能力", "AI 分析", "页面上下文与固定模板分析入口。"],
  alarms: ["告警中心", "告警事件", "项目告警、物理恢复与确认处理。"],
  "alarm-rules": ["告警中心", "告警规则", "阈值、离线检测与恢复策略。"],
  "alarm-notifications": ["告警中心", "通知记录", "站内与外部渠道投递记录。"]
};
const state = { project: "east", view: "overview", filter: "all", selected: 0, range: "day", series: [true, true, true], syncEnabled: { east: true, west: true }, messages: { east: [], west: [] } };
const current = () => PROJECTS[state.project];
const escapeText = (value) => {
  const span = document.createElement("span");
  span.textContent = String(value);
  return span.innerHTML;
};
function points() {
  return current().states.map((status, i) => {
    const type = TYPES[i % TYPES.length];
    return { id: `${state.project}-${i + 1}`, code: `${["GNSS", "RAIN", "PORE"][i % 3]}-${String(i + 1).padStart(2, "0")}`,
      location: `K${current().start + i * 2}+500`, status, type,
      value: status === "off" ? null : Number((type.value * current().factor * (1 - i * .025)).toFixed(1)) };
  });
}
const statusTag = (status) => `<span class="status" style="--tone:var(--${STATUS[status].color})">${STATUS[status].label}</span>`;
function table(headers, rows) {
  return `<table><thead><tr>${headers.map((v) => `<th scope="col">${escapeText(v)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((v) => `<td>${escapeText(v)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
}
function renderKpis() {
  const data = points();
  const counts = [
    ["测点总数", data.length, "cyan"], ["在线运行", data.filter((p) => p.status !== "off").length, "green"],
    ...["yellow", "orange", "red", "off"].map((status) => [status === "off" ? "离线 / 维护" : `${STATUS[status].label}预警`, data.filter((p) => p.status === status).length, STATUS[status].color])
  ];
  $("kpis").innerHTML = counts.map(([label, count, color]) => `<article class="kpi" style="--tone:var(--${color})"><strong>${count}</strong><span>${label}</span></article>`).join("");
}
function visiblePoints() {
  return points().filter((p) => state.filter === "all" || (state.filter === "off" ? p.status === "off" : ["yellow", "orange", "red"].includes(p.status)));
}
function renderTerrain() {
  const visible = new Set(visiblePoints().map((p) => p.id));
  if (!visible.has(points()[state.selected].id)) {
    state.selected = points().findIndex((p) => visible.has(p.id));
  }
  const nodes = points().map((p, i) => {
    if (!visible.has(p.id)) return "";
    const x = 70 + i * 44, y = 266 - i * 10 + Math.sin(i * .8) * 25;
    return `<g class="point" role="button" tabindex="0" data-point="${i}" aria-label="${p.location} ${p.code} ${STATUS[p.status].label}" aria-pressed="${state.selected === i}" style="color:var(--${STATUS[p.status].color})">
      <circle class="halo" cx="${x}" cy="${y}" r="14" fill="none" stroke="currentColor" opacity=".45"/>
      <circle cx="${x}" cy="${y}" r="5" fill="currentColor" stroke="#fff" stroke-width="1"/>
      <text x="${x}" y="${y - 22}" text-anchor="middle">${i + 1}</text></g>`;
  }).join("");
  const lines = Array.from({ length: 10 }, (_, i) => {
    const offset = i * 13;
    return `<path d="M25 ${330 - offset} Q110 ${270 - offset} 190 ${300 - offset} T355 ${240 - offset} T610 ${230 - offset}" fill="none" stroke="var(--blue)" opacity="${.12 + i * .018}"/>`;
  }).join("");
  $("terrain").innerHTML = `<svg viewBox="0 0 640 410" role="group" aria-labelledby="terrain-title">
    <title id="terrain-title">路线测点示意图，非真实地理坐标；各测点可通过键盘选择</title>
    <defs><linearGradient id="terrain-fill" x2="0" y2="1"><stop stop-color="var(--terrain-top)" stop-opacity=".8"/><stop offset="1" stop-color="var(--terrain-bottom)" stop-opacity=".3"/></linearGradient></defs>
    <path d="M20 330 L80 220 L140 255 L220 108 L310 195 L400 80 L470 180 L535 125 L620 260 L620 355 L20 385Z" fill="url(#terrain-fill)" stroke="var(--panel-br)"/>
    ${lines}<path d="M60 270 Q145 305 230 240 T395 205 T565 155" fill="none" stroke="var(--blue)" stroke-width="16" opacity=".25"/>
    <path d="M60 270 Q145 305 230 240 T395 205 T565 155" fill="none" stroke="var(--cyan)" stroke-width="2" stroke-dasharray="7 5"/>
    <text x="35" y="370">起点 K${current().start}</text><text x="480" y="370">测点位置仅为示意</text>${nodes}</svg>`;
  renderPointDetail();
}
function renderPointDetail() {
  const p = points()[state.selected];
  $("point-detail").innerHTML = `<strong>${p.location} · ${p.code}</strong> ${statusTag(p.status)}
    <p>${p.type.name} / ${p.type.metric}：${p.value === null ? "无有效最新值（非零）" : `${p.value} ${p.type.unit}`}</p>
    <p>档案表：${p.type.table} · 样本时间：${p.status === "off" ? "2026-10-30 13:30（过期）" : "2026-10-30 14:30"}</p>`;
}
function spark(series, range, index) {
  const values = series[range].map((v) => Number((v * current().factor).toFixed(1)));
  const coords = values.map((v, i) => `${34 + i * 244 / (values.length - 1)},${80 - v / series.max * 65}`).join(" ");
  return `<div class="spark" style="--tone:var(--${series.color})"><div class="spark-caption"><span>${series.name} / ${series.unit}</span><strong>末点 ${values.at(-1)}</strong></div>
    <svg viewBox="0 0 310 110" role="img" aria-labelledby="spark-${index}"><title id="spark-${index}">${series.name}，${range === "day" ? "近24小时" : "近7天"}，单位${series.unit}，范围0至${series.max}，本地固定样本</title>
    <path d="M34 14H278 M34 47H278 M34 80H278" fill="none" stroke="var(--panel-br)" stroke-dasharray="3 4"/>
    <text x="2" y="18">${series.max}</text><text x="16" y="84">0</text>
    <polyline points="${coords}" fill="none" stroke="var(--${series.color})" stroke-width="2"/>
    <text x="34" y="102">${range === "day" ? "10/29 14:30" : "10/24"}</text><text x="278" y="102" text-anchor="end">${range === "day" ? "10/30 14:30" : "10/30"}</text></svg></div>`;
}
function renderHistory() {
  $("history-series").innerHTML = SERIES.map((s, i) => `<label><input type="checkbox" data-series="${i}" ${state.series[i] ? "checked" : ""}> ${s.name} / ${s.unit}</label>`).join("");
  $("history-trends").innerHTML = SERIES.map((s, i) => state.series[i] ? spark(s, state.range, `history-${i}`) : "").join("") || '<p class="hint">请选择至少一个系列。</p>';
  const selected = SERIES.filter((_, i) => state.series[i]);
  const size = SERIES[0][state.range].length;
  $("history-table").innerHTML = table(["采样时间", ...selected.map((s) => `${s.name} / ${s.unit}`)],
    Array.from({ length: size }, (_, i) => {
      const start = Date.UTC(2026, 9, state.range === "day" ? 29 : 24, 6, 30);
      const span = state.range === "day" ? 86400000 : 6 * 86400000;
      const date = new Date(start + span * i / (size - 1) + 8 * 3600000);
      return [date.toISOString().slice(0, 16).replace("T", " ") + " +08:00", ...selected.map((s) => (s[state.range][i] * current().factor).toFixed(1))];
    }));
}
function render() {
  const data = points();
  renderKpis();
  $("section-name").textContent = current().name;
  $("categories").innerHTML = TYPES.map((t) => `<p class="category-title">■ ${t.group}</p><div class="sensor-row"><span>${t.name}</span><strong>${data.filter((p) => p.type === t).length} 点</strong></div>`).join("");
  $("live-values").innerHTML = data.slice(0, 6).map((p) => `<div class="sensor-row"><span>${p.code}<br>${statusTag(p.status)}</span><strong>${p.value === null ? "—" : `${p.value} ${p.type.unit}`}</strong></div>`).join("");
  $("alarms").innerHTML = data.filter((p) => ["yellow", "orange", "red"].includes(p.status)).sort((a, b) => ["red", "orange", "yellow"].indexOf(a.status) - ["red", "orange", "yellow"].indexOf(b.status)).map((p) =>
    `<article class="alarm" style="--tone:var(--${STATUS[p.status].color})"><div class="alarm-title">${statusTag(p.status)}<strong>${p.location} · ${p.code}</strong></div><p>${p.type.metric} ${p.value} ${p.type.unit} · 固定示例分级，非自动计算阈值。</p><p>样本时间 14:30 · 未发送真实通知</p></article>`).join("");
  $("trends").innerHTML = SERIES.map((s, i) => spark(s, "day", `overview-${i}`)).join("");
  $("device-table").innerHTML = table(["设备编码", "项目测点", "设备类型", "独立档案表", "状态", "值 / 单位"], data.map((p) => [p.code, p.location, p.type.name, p.type.table, STATUS[p.status].label, p.value === null ? "无有效值" : `${p.value} ${p.type.unit}`]));
  $("footer-metrics").innerHTML = [
    ["在线率", (data.filter((p) => p.status !== "off").length / data.length * 100).toFixed(1), "%", "green"],
    ["最大累计位移", Math.max(...data.filter((p) => p.type === TYPES[0] && p.value !== null).map((p) => p.value)), "mm", "orange"],
    ["最高孔隙水压", Math.max(...data.filter((p) => p.type === TYPES[2] && p.value !== null).map((p) => p.value)), "kPa", "yellow"],
    ["当前预警测点", data.filter((p) => ["yellow", "orange", "red"].includes(p.status)).length, "点", "red"]
  ].map(([label, value, unit, color]) => `<article class="mini" style="--tone:var(--${color})"><span>${label}</span><strong>${value}<small> ${unit}</small></strong></article>`).join("");
  renderTerrain();
  renderHistory();
  renderModule();
}
function renderModule() {
  if (AlarmCenter.has(state.view)) {
    $("module").innerHTML = AlarmCenter.render(state.view, current().name);
    return;
  }
  const name = current().name;
  const frame = (title, body) => `<div class="panel-heading"><h2>${title}</h2><span class="demo">本地演示</span></div>${body}`;
  const grid = (headers, rows) => `<div class="panel-body table-wrap">${table(headers, rows)}</div>`;
  let html = "";
  switch (state.view) {
    case "projects":
      html = grid(["项目", "来源", "外部绑定", "客户", "授权"], [
        [name, "HTTP API / 数据库视图", `source-01 / ${state.project}`, `${name.slice(0, 2)}运维客户`, "客户管理员"],
        [`${name} · 扩建段`, "手动新建", "待绑定", "未分配", "仅超管"]
      ]) + '<p class="module-intro">正式应用提供新建、同步与绑定接口；重同步不覆盖本地授权。本页仅展示来源与授权样式，不执行项目写入。</p>';
      break;
    case "permissions":
      html = grid(["角色", "用户管理", "项目授权", "数据范围"], [
        ["超管", "创建客户管理员", "分配项目给客户与管理员", "显式全局授权"],
        ["客户管理员", "本客户普通用户", "仅自己获授项目的子集", `${name} / 本客户`],
        ["普通用户", "不可管理", "不可再授权", "获授项目 / 默认只读"]
      ]) + '<p class="module-intro">菜单用于展示组件风格，不模拟真实角色登录。每次请求须在后端检查权限，不能以隐藏菜单替代授权。</p>';
      break;
    case "realtime":
      html = grid(["设备", "测点", "最新值", "单位", "状态", "采样时间 +08:00"], points().map((p) => [
        p.code, p.type.metric, p.value === null ? "—（非零）" : p.value, p.type.unit,
        p.status === "off" ? "过期 / 无有效值" : "示例有效", p.status === "off" ? "2026-10-30 13:30" : "2026-10-30 14:30"
      ]));
      break;
    case "reports":
      html = grid(["报表", "项目", "周期", "状态", "口径"], [
        ["位移监测日报", name, "2026-10-29", "已完成 · 固定示例", "位移最大值 / 变化率"],
        ["雨量监测周报", name, "10/24—10/30", "待生成 · 固定示例", "区间雨量累计 / 缺测标记"],
        ["测点质量报表", name, "2026-10-30", "待生成 · 固定示例", "完整率 / 过期率"]
      ]) + '<div class="module-actions"><button type="button" data-demo-action="report">演示生成报表反馈</button></div><p class="module-intro">此按钮仅展示反馈，不生成文件。正式实现需异步生成、下载重新鉴权及到期清理。</p>';
      break;
    case "governance":
      html = '<p class="module-intro">仅演示固定换算 value * 0.001（毫米 → 米），不执行任意表达式，也不写入数据库。</p><form id="governance-form" class="governance-form"><label>原始位移 / mm<input id="raw-value" type="number" step="any" min="-1000000000" max="1000000000" required value="38.6"></label><button type="submit">预览治理结果</button></form><output id="governance-result" class="governance-result" aria-live="polite">原始值 38.6 mm → 处理值 0.0386 m · 规则 v1</output>' +
        grid(["规则", "输入 / 输出", "版本", "异常策略"], [["位移单位换算", "mm → m", "v1", "保留原始值并标记质量"]]);
      break;
    case "sync":
      html = grid(["任务", "作用域", "调度", "游标", "状态"], [
        ["设备与监测数据同步", name, "每 5 分钟 / Asia/Shanghai", "14:30 + event-012", state.syncEnabled[state.project] ? "已启用" : "已暂停"],
        ["全平台来源同步", "超管统一任务", "每小时 / Asia/Shanghai", "按项目维护", "仅展示当前项目片段"]
      ]) + `<div class="module-actions"><button type="button" data-demo-action="toggle-sync">${state.syncEnabled[state.project] ? "暂停" : "启用"}项目任务（本地）</button><button type="button" data-demo-action="run-sync">模拟立即执行反馈</button></div>` +
        grid(["运行", "项目", "读取 / 写入 / 跳过", "结果"], [["run-demo-1430", name, "12 / 11 / 1", "局部失败：1 条身份待映射"], ["run-demo-1425", name, "12 / 12 / 0", "成功 · 示例"]]);
      break;
    case "assistant":
      html = '<p class="module-intro">可收起、继续追问，切换项目后使用独立本地会话。所有回复为固定模拟，不连接模型或知识库。</p><div class="module-actions"><button type="button" data-demo-action="chat">打开 AI 聊天窗</button></div>' +
        grid(["上下文", "当前范围", "外部发送"], [["项目", name, "关闭"], ["数据", "固定样本 / 受控上下文示意", "关闭"]]);
      break;
    case "analysis":
      html = grid(["固定模板示例", "上下文", "限制"], [["monitoring_alert_summary_demo", "当前项目 / 预警样本", "非真实风险评估"], ["history_trend_demo", "当前项目 / 选中系列 / 时间范围", "非真实趋势结论"]]) +
        '<div class="module-actions"><button type="button" data-demo-action="analysis">分析当前项目样本</button></div><p class="module-intro">正式应用由服务端验证资源权限、获取数据并套用版本化模板，客户端不能覆写系统提示词。</p>';
      break;
  }
  $("module").innerHTML = html ? frame(PAGES[state.view][1], html) : "";
}
function showView(view, updateHash = true) {
  if (!Object.hasOwn(PAGES, view)) view = "overview";
  state.view = view;
  const surface = ["overview", "dashboard"].includes(view) ? "overview" : ["history", "curves"].includes(view) ? "history" : view === "devices" ? "devices" : "module";
  for (const id of ["overview", "devices", "history", "module"]) $(id).hidden = id !== surface;
  document.querySelectorAll("[data-page]").forEach((link) => {
    if (link.dataset.page === view) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  const [group, title, description] = PAGES[view];
  $("page-group").textContent = group;
  $("page-title").textContent = title;
  $("page-description").textContent = description;
  $("history-title").textContent = view === "curves" ? "曲线管理 · 跨设备系列组合" : "历史查询 · 采样趋势";
  $("module-status").textContent = "";
  document.title = `${title} · AlinkIoT 主题参考`;
  renderModule();
  if (updateHash) location.hash = view;
  window.scrollTo({ top: 0, behavior: "instant" });
}
$("navigation").addEventListener("click", (event) => {
  if (!event.target.closest('a[href^="#"]')) return;
  requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" }));
});
function renderMessages() {
  $("messages").replaceChildren();
  const messages = state.messages[state.project];
  for (const message of messages.length ? messages : [{ role: "assistant", text: `当前项目：${current().name}。本地模拟助手不连接模型，可从预警面板发起上下文分析演示。` }]) {
    const p = document.createElement("p");
    p.className = `message ${message.role}`;
    p.textContent = `${message.role === "user" ? "你" : "模拟助手"}：${message.text}`;
    $("messages").append(p);
  }
  $("messages").scrollTop = $("messages").scrollHeight;
}
function openChat() {
  $("chat").hidden = false;
  $("chat-launcher").setAttribute("aria-expanded", "true");
  renderMessages();
  $("question").focus();
}
function closeChat() {
  $("chat").hidden = true;
  $("chat-launcher").setAttribute("aria-expanded", "false");
  $("chat-launcher").focus();
}
$("project").addEventListener("change", (event) => {
  state.project = event.target.value;
  state.selected = 0;
  $("question").value = "";
  render();
  renderMessages();
});
$("status-filter").addEventListener("change", (event) => {
  state.filter = event.target.value;
  renderTerrain();
});
function selectPoint(event) {
  const node = event.target.closest("[data-point]");
  if (!node) return;
  if (event.type === "keydown" && !["Enter", " "].includes(event.key)) return;
  event.preventDefault();
  state.selected = Number(node.dataset.point);
  renderTerrain();
  $("terrain").querySelector(`[data-point="${state.selected}"]`).focus();
}
$("terrain").addEventListener("click", selectPoint);
$("terrain").addEventListener("keydown", selectPoint);
$("range").addEventListener("change", (event) => { state.range = event.target.value; renderHistory(); });
$("history-series").addEventListener("change", (event) => {
  if (event.target.dataset.series === undefined) return;
  state.series[Number(event.target.dataset.series)] = event.target.checked;
  renderHistory();
  $("history-series").querySelector(`[data-series="${event.target.dataset.series}"]`).focus();
});
$("fullscreen").addEventListener("click", async () => {
  try {
    if (!document.fullscreenEnabled) { $("fullscreen").textContent = "浏览器不支持全屏"; return; }
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  } catch { $("fullscreen").textContent = "全屏不可用"; }
});
document.addEventListener("fullscreenchange", () => { $("fullscreen").textContent = document.fullscreenElement ? "退出全屏" : "全屏预览"; });
function analyzePage(alertOnly = false) {
  const warnings = points().filter((p) => ["yellow", "orange", "red"].includes(p.status));
  const historyView = ["history", "curves"].includes(state.view) && !alertOnly;
  const title = alertOnly ? "预警样本" : PAGES[state.view][1];
  const scope = historyView ? `${state.range === "day" ? "近24小时" : "近7天"} / ${SERIES.filter((_, i) => state.series[i]).map((s) => `${s.name} ${s.unit}`).join("、") || "未选系列"}` : "2026-10-30 14:30 +08:00";
  const detail = historyView ? `当前范围：${scope}。所选系列使用各自单位与数值轴；固定样本不能推断因果或真实趋势。` : `固定样本共有 ${warnings.length} 个预警测点，其中红色 ${warnings.filter((p) => p.status === "red").length} 个。`;
  state.messages[state.project].push(
    { role: "user", text: `分析 ${current().name} / ${title}，范围：${scope}；模板：${historyView ? "history_trend_demo" : "monitoring_alert_summary_demo"}。` },
    { role: "assistant", text: `【模拟分析，非模型输出】\n项目：${current().name}\n${detail}\n状态为演示预设，不能由此推断失稳风险或采取现场处置。真实应用应结合阈值版本、数据质量及专业人员复核；本模板不发送告警或控制设备。` }
  );
  openChat();
}
$("analyze").addEventListener("click", () => analyzePage(true));
$("page-analyze").addEventListener("click", () => analyzePage());
$("module").addEventListener("click", (event) => {
  const button = event.target.closest("[data-demo-action]");
  if (!button) return;
  switch (button.dataset.demoAction) {
    case "chat": openChat(); break;
    case "analysis": analyzePage(); break;
    case "toggle-sync":
      state.syncEnabled[state.project] = !state.syncEnabled[state.project];
      renderModule();
      $("module").querySelector('[data-demo-action="toggle-sync"]').focus();
      $("module-status").textContent = "已更新本地项目任务状态，未调用调度服务。";
      break;
    case "report": $("module-status").textContent = "模拟反馈：报表生成请求。未提交真实任务，未创建文件。"; break;
    case "run-sync": $("module-status").textContent = "模拟反馈：立即执行请求。未启动真实同步。"; break;
  }
});
$("module").addEventListener("submit", (event) => {
  if (event.target.id !== "governance-form") return;
  event.preventDefault();
  const value = Number($("raw-value").value);
  $("governance-result").textContent = Number.isFinite(value) && Math.abs(value) <= 1e9
    ? `原始值 ${value} mm → 处理值 ${Number((value * .001).toFixed(8))} m · 规则 v1 / 未写入数据库`
    : "请输入范围内的有限数值。";
});
$("collapse-menu").addEventListener("click", () => {
  const collapsed = document.body.classList.toggle("menu-collapsed");
  $("collapse-menu").setAttribute("aria-expanded", String(!collapsed));
  $("collapse-menu").setAttribute("aria-label", collapsed ? "展开侧边菜单" : "收起侧边菜单");
});
window.addEventListener("hashchange", () => showView(location.hash.slice(1), false));
$("chat-launcher").addEventListener("click", () => $("chat").hidden ? openChat() : closeChat());
$("chat-close").addEventListener("click", closeChat);
document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !$("chat").hidden) closeChat(); });
$("chat-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const question = $("question").value.trim();
  if (!question) return;
  state.messages[state.project].push({ role: "user", text: question }, { role: "assistant", text: `【模拟回复】当前项目为 ${current().name}。没有真实模型连接，无法根据本地演示数据作出工程安全判断。正式应用需由服务端校验权限并构建受控上下文。` });
  $("question").value = "";
  renderMessages();
});
let previousGroup = "";
$("navigation").innerHTML = Object.entries(PAGES).map(([id, [group, title]], index) => {
  const heading = group !== previousGroup ? `<p class="nav-group">${group}</p>` : "";
  previousGroup = group;
  return `${heading}<a class="nav-link" href="#${id}" data-page="${id}" data-menu-tip="${title}" aria-label="${title}">${menuIcon(id)}<span class="nav-label">${title}</span></a>`;
}).join("");
render();
showView(location.hash.slice(1) || "overview", false);

function syncPaletteButtons() {
  const light = document.documentElement.dataset.theme === "day-blue";
  document.querySelectorAll("[data-palette-toggle]").forEach((button) => {
    const label = light ? "切换到深蓝青光" : "切换到明亮蓝白";
    button.textContent = light ? "☾" : "☀";
    button.setAttribute("aria-label", label);
    button.setAttribute("title", label);
    button.setAttribute("aria-pressed", String(light));
  });
}
function applyPalette(theme) {
  document.documentElement.dataset.theme = theme === "day-blue" ? "day-blue" : "night-cyan";
  syncPaletteButtons();
}
let savedPalette = "night-cyan";
try { savedPalette = localStorage.getItem("highway-command-theme") || savedPalette; } catch { /* Use the default without storage. */ }
applyPalette(savedPalette);
document.addEventListener("click", (event) => {
  if (!event.target.closest("[data-palette-toggle]")) return;
  applyPalette(document.documentElement.dataset.theme === "day-blue" ? "night-cyan" : "day-blue");
  try { localStorage.setItem("highway-command-theme", document.documentElement.dataset.theme); } catch { /* Switching still works without storage. */ }
});

{
  const tip = document.createElement("div");
  tip.id = "menu-tip";
  tip.className = "menu-tip";
  tip.setAttribute("role", "tooltip");
  tip.hidden = true;
  document.body.append(tip);
  let active;
  const hide = () => {
    active?.removeAttribute("aria-describedby");
    active = null;
    tip.hidden = true;
  };
  const show = (event) => {
    const item = event.target.closest("[data-menu-tip]");
    if (!item || !item.closest(".menu-collapsed, .collapsed")) return;
    hide();
    active = item;
    tip.textContent = item.dataset.menuTip;
    tip.hidden = false;
    item.setAttribute("aria-describedby", tip.id);
    const rect = item.getBoundingClientRect();
    tip.style.left = `${Math.max(8, Math.min(rect.right + 10, innerWidth - tip.offsetWidth - 8))}px`;
    tip.style.top = `${Math.max(8, Math.min(rect.top + (rect.height - tip.offsetHeight) / 2, innerHeight - tip.offsetHeight - 8))}px`;
  };
  document.addEventListener("pointerover", show);
  document.addEventListener("focusin", show);
  for (const type of ["pointerout", "focusout"]) document.addEventListener(type, (event) => {
    if (active && !active.contains(event.relatedTarget)) hide();
  });
  document.addEventListener("click", hide);
  document.addEventListener("scroll", hide, true);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hide(); });
  window.addEventListener("resize", hide);
}
