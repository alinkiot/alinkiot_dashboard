{
  const page = document.createElement("section");
  page.className = "login-page";
  page.setAttribute("aria-label", "路曜登录页");
  page.innerHTML = `
    <header class="login-top"><div class="login-brand">AlinkIoT <span>HIGHWAY COMMAND / 监测指挥工作台</span></div><button class="palette-toggle" type="button" data-palette-toggle aria-label="切换到明亮蓝白" title="切换到明亮蓝白" aria-pressed="false">☀</button></header>
    <div class="login-layout">
      <div class="login-story"><p class="login-eyebrow">INFRASTRUCTURE OBSERVABILITY</p><h1>感知每一处变化，<br>洞察全线运行态势。</h1><p>聚合道路测点与设备数据，以项目为中心连接实时监测、历史追溯与预警分析。</p><div class="login-features"><span>全线测点监测</span><span>分级预警视图</span><span>项目态势与报表</span></div></div>
      <form class="login-card"><p class="login-eyebrow">COMMAND ACCESS</p><h2>登录监测控制台</h2><p>路曜 · Highway Command</p>
        <label for="login-user">账号</label><input id="login-user" name="username" autocomplete="username" value="admin" required placeholder="请输入账号">
        <label for="login-password">密码</label><div class="login-password"><input id="login-password" name="password" type="password" autocomplete="current-password" value="demo123" required placeholder="请输入密码"><button type="button" class="login-eye" aria-label="显示密码" aria-pressed="false">显示</button></div>
        <p class="login-notice">本地演示 · 任意非空账号密码均可进入。不验证身份，不保存或发送输入内容。</p>
        <button class="login-submit" type="submit">进入演示控制台 →</button>
      </form>
    </div><footer class="login-footer">主题参考 / 无真实认证、数据库或 AI 连接</footer>`;
  document.body.append(page);
  document.getElementById("logout").addEventListener("click", () => {
    const url = new URL(location.href);
    url.hash = "";
    location.replace(url.href);
  });
  syncPaletteButtons();
  const enter = () => {
    document.body.classList.remove("login-pending");
    page.hidden = true;
    document.querySelector("main")?.focus({ preventScroll: true });
    window.dispatchEvent(new Event("resize"));
  };
  page.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    page.querySelector("form").reset();
    enter();
  });
  page.querySelector(".login-eye").addEventListener("click", (event) => {
    const input = page.querySelector("#login-password");
    const visible = input.type === "password";
    input.type = visible ? "text" : "password";
    event.currentTarget.textContent = visible ? "隐藏" : "显示";
    event.currentTarget.setAttribute("aria-label", visible ? "隐藏密码" : "显示密码");
    event.currentTarget.setAttribute("aria-pressed", String(visible));
  });
  if (location.hash && document.querySelector(`#navigation a[href="${CSS.escape(location.hash)}"]`)) enter();
}
