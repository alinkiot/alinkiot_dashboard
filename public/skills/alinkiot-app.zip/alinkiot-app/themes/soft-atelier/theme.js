"use strict";

const $ = (id) => document.getElementById(id);
const THEME_IDS = ["warm-petal", "mint-garden", "mist-blue", "soft-lilac", "oat-latte"];
function applyTheme(id) {
  if (!THEME_IDS.includes(id)) id = "warm-petal";
  document.documentElement.dataset.theme = id;
  $("theme-select").value = id;
  try { localStorage.setItem("soft-atelier-theme", id); } catch { /* Local file storage may be unavailable. */ }
}
const PAGES = {
  overview: ["工作空间", "数据洞察", "轻一点的界面，清晰一点的洞察。"],
  projects: ["资产与权限", "项目管理", "接口同步、手动新建与外部绑定。"],
  permissions: ["资产与权限", "权限管理", "三级角色授权，客户与项目范围隔离。"],
  devices: ["资产与权限", "设备档案", "按类型独立建档，快速筛选和查看设备详情。"],
  realtime: ["数据应用", "实时查询", "查看最新值与质量，区分过期、缺失和零值。"],
  history: ["数据应用", "历史查询", "按时间范围查询设备采样及聚合趋势。"],
  curves: ["数据应用", "曲线管理", "动态关联不同设备系列，使用各自单位与数值轴。"],
  dashboard: ["展示与报表", "项目大屏", "按项目维护独立布局、草稿和发布版本。"],
  reports: ["展示与报表", "报表中心", "管理计算口径、生成记录与授权下载。"],
  governance: ["治理与同步", "数据治理", "固定公式预览，保留原始值与版本。"],
  sync: ["治理与同步", "同步任务", "按项目或统一调度，追踪增量游标和运行结果。"],
  assistant: ["AI 能力", "AI 在线助手", "当前项目对话，使用统一右下角聊天窗。"],
  analysis: ["AI 能力", "AI 分析", "以受控页面上下文打开固定模板分析。"],
  alarms: ["告警中心", "告警事件", "项目告警、物理恢复与确认处理。"],
  "alarm-rules": ["告警中心", "告警规则", "阈值、离线检测与恢复策略。"],
  "alarm-notifications": ["告警中心", "通知记录", "站内与外部渠道投递记录。"]
};
const PROJECTS = {
  park: { name: "未来科技园", customer: "未来园区运营", factor: 1, total: 128, online: 124 },
  factory: { name: "滨江智造工厂", customer: "滨江制造集团", factor: 1.3, total: 86, online: 82 }
};
const state = { page: "overview", project: "park", query: "", status: "all", pageIndex: 0, selected: new Set(), range: "day", series: [true, true], overviewTab: "analysis", category: "all", sync: { park: true, factory: true }, conversations: { park: [], factory: [] } };
const current = () => PROJECTS[state.project];
const escapeText = (value) => {
  const span = document.createElement("span");
  span.textContent = String(value);
  return span.innerHTML;
};
function statusBadge(text, tone = "success") {
  return `<span class="status ${tone}">${escapeText(text)}</span>`;
}
function table(headers, rows) {
  return `<div class="table-wrap"><table><thead><tr>${headers.map((v) => `<th scope="col">${escapeText(v)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((v) => `<td>${escapeText(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
function panel(title, body, subtitle = "DEMO / 本地样本") {
  return `<section class="panel"><div class="section-heading"><h2>${escapeText(title)}</h2><small>${escapeText(subtitle)}</small></div>${body}</section>`;
}
function devices() {
  return Array.from({ length: 12 }, (_, i) => ({
    id: `${state.project}-${i + 1}`, code: `${i % 2 ? "E" : "W"}-${String(i + 1).padStart(3, "0")}`,
    name: `${["北区", "南区", "东区"][i % 3]}${i % 2 ? "配电计量" : "供水计量"}`,
    type: i % 2 ? "电表" : "水表", table: i % 2 ? "device_power_meter" : "device_water_meter",
    status: i === 4 ? "offline" : i === 8 ? "stale" : "online",
    value: i === 4 ? null : Number(((i % 2 ? 286 : 38.6) * current().factor + i).toFixed(1)), unit: i % 2 ? "kW" : "m³/h"
  }));
}
const statusNames = { online: "在线", offline: "离线", stale: "数据过期" };
function filteredDevices() {
  return devices().filter((d) => (state.status === "all" || d.status === state.status) && `${d.code} ${d.name} ${d.type}`.toLowerCase().includes(state.query.toLowerCase()));
}
function deviceList() {
  const list = filteredDevices();
  const rows = list.slice(state.pageIndex * 5, state.pageIndex * 5 + 5);
  return `<form id="filter-form" class="filter-bar">
    <label for="search">设备搜索</label><input id="search" value="${escapeText(state.query).replaceAll('"', "&quot;")}" placeholder="设备名称 / 编码 / 类型">
    <label for="status-filter">状态</label><select id="status-filter"><option value="all" ${state.status === "all" ? "selected" : ""}>全部状态</option>${Object.entries(statusNames).map(([id, label]) => `<option value="${id}" ${state.status === id ? "selected" : ""}>${label}</option>`).join("")}</select>
    <button class="primary" type="submit">查询</button><button type="button" data-action="reset">重置</button><span class="count">已选 ${state.selected.size} 项</span></form>
    <div class="table-wrap"><table><thead><tr><th scope="col">选择</th>${["设备编码", "设备名称", "类型 / 独立档案表", "状态", "最新值", "操作"].map((h) => `<th scope="col">${h}</th>`).join("")}</tr></thead>
    <tbody>${rows.length ? rows.map((d) => `<tr><td><input type="checkbox" data-select="${d.id}" aria-label="选择 ${d.code}" ${state.selected.has(d.id) ? "checked" : ""}></td><td><strong>${d.code}</strong></td><td>${d.name}<br><span class="muted">${current().name}</span></td><td>${d.type}<br><span class="muted">${d.table}</span></td><td>${statusBadge(statusNames[d.status], d.status === "online" ? "success" : "warning")}</td><td>${d.value === null ? "—（非零）" : `${d.value} ${d.unit}`}</td><td><button class="text-button" type="button" data-detail="${d.id}">查看详情</button></td></tr>`).join("") : '<tr><td colspan="7" class="empty">没有匹配设备，请调整筛选条件。</td></tr>'}</tbody></table></div>
    <div class="table-footer"><span>共 ${list.length} 条 / 每页 5 条</span><button type="button" data-action="previous" ${state.pageIndex === 0 ? "disabled" : ""}>上一页</button><span>${state.pageIndex + 1} / ${Math.max(1, Math.ceil(list.length / 5))}</span><button type="button" data-action="next" ${(state.pageIndex + 1) * 5 >= list.length ? "disabled" : ""}>下一页</button></div>`;
}
function trend(interactive = false) {
  const range = state.range;
  const labels = range === "day" ? ["00:00", "04:00", "08:00", "12:00", "16:00", "20:00"] : ["10/24", "10/25", "10/26", "10/27", "10/28", "10/29", "10/30"];
  const water = (range === "day" ? [16, 20, 35, 29, 42, 38] : [20, 31, 26, 39, 33, 42, 38]).map((v) => Number((v * current().factor).toFixed(1)));
  const power = (range === "day" ? [150, 210, 270, 230, 320, 286] : [160, 200, 260, 210, 330, 300, 286]).map((v) => Number((v * current().factor).toFixed(1)));
  const coords = (values, max) => values.map((v, i) => `${48 + i * 570 / (values.length - 1)},${210 - v / max * 170}`).join(" ");
  return `<div class="section-body"><div class="legend"><span><i></i>水表 W-001 · 左轴 m³/h</span><span><i class="secondary"></i>电表 E-002 · 右轴 kW</span><label>范围 <select id="range"><option value="day" ${range === "day" ? "selected" : ""}>2026-10-30 当日</option><option value="week" ${range === "week" ? "selected" : ""}>10/24 至 10/30</option></select></label></div>
    ${interactive ? `<div class="series-controls">${["水表流量", "电表功率"].map((label, i) => `<label><input type="checkbox" data-series="${i}" ${state.series[i] ? "checked" : ""}>${label}</label>`).join("")}</div>` : ""}
    <svg class="chart" viewBox="0 0 680 250" role="img" aria-labelledby="trend-title"><title id="trend-title">水电趋势固定样本，${range === "day" ? "当日" : "近7日"}，左轴流量0至60立方米每小时，右轴功率0至600千瓦；明细见下方采样表</title>
    ${[0, 1, 2, 3].map((i) => `<path d="M48 ${210 - i * 57} H618" stroke="var(--border)" fill="none" stroke-dasharray="3 4"/><text x="35" y="${214 - i * 57}" text-anchor="end">${i * 20}</text><text x="632" y="${214 - i * 57}">${i * 200}</text>`).join("")}
    ${(!interactive || state.series[0]) ? `<polyline points="${coords(water, 60)}" fill="none" stroke="var(--primary)" stroke-width="2.5"/>` : ""}
    ${(!interactive || state.series[1]) ? `<polyline points="${coords(power, 600)}" fill="none" stroke="var(--chart-secondary)" stroke-width="2.5"/>` : ""}
    ${labels.map((v, i) => `<text x="${48 + i * 570 / (labels.length - 1)}" y="239" text-anchor="middle">${v}</text>`).join("")}</svg>
    ${interactive && !state.series.some(Boolean) ? '<p class="muted">未选择系列，请勾选至少一项。</p>' : ""}
    <details><summary class="muted">查看采样明细（Asia/Shanghai）</summary>${table(["时间", ...(!interactive || state.series[0] ? ["流量 m³/h"] : []), ...(!interactive || state.series[1] ? ["功率 kW"] : [])],
      labels.map((label, i) => [label, ...(!interactive || state.series[0] ? [water[i]] : []), ...(!interactive || state.series[1] ? [power[i]] : [])]))}</details></div>`;
}
function categories() {
  const total = current().total;
  const counts = [Math.floor(total * .35), Math.floor(total * .28), Math.floor(total * .23)];
  counts.push(total - counts.reduce((sum, n) => sum + n, 0));
  return ["智能电表", "水务计量", "环境传感", "网关及其他"].map((name, i) => ({
    name, count: counts[i], color: ["chart-secondary", "apricot", "sky", "stone"][i]
  }));
}
function honeycomb() {
  const groups = categories();
  const total = current().total;
  const positions = Array.from({ length: 192 }, (_, i) => ({ index: i, row: Math.floor(i / 16), col: i % 16 }));
  const active = positions.toSorted((a, b) => ((a.col - 7.5) / 7) ** 2 + ((a.row - 5.5) / 5) ** 2 - ((b.col - 7.5) / 7) ** 2 - ((b.row - 5.5) / 5) ** 2).slice(0, total);
  const cells = new Map(), anchors = [[5, 3], [11, 5], [9, 9], [3, 8]];
  groups.forEach((g, group) => {
    const [x, y] = anchors[group];
    const available = active.filter((p) => !cells.has(p.index)).toSorted((a, b) => (a.col - x) ** 2 + (a.row - y) ** 2 - (b.col - x) ** 2 - (b.row - y) ** 2);
    available.slice(0, g.count).forEach((p) => cells.set(p.index, group));
  });
  const hexes = positions.map(({ index: i, row, col }) => {
    const x = 14 + col * 21 + (row % 2 ? 10.5 : 0), y = 14 + row * 18.2;
    const polygon = Array.from({ length: 6 }, (_, j) => {
      const angle = (j * 60 - 30) * Math.PI / 180;
      return `${(x + 12 * Math.cos(angle)).toFixed(2)},${(y + 12 * Math.sin(angle)).toFixed(2)}`;
    }).join(" ");
    const group = cells.get(i);
    const fill = group === undefined ? "chart-empty" : groups[group].color;
    const dim = state.category !== "all" && group !== Number(state.category);
    return `<polygon class="honey-cell" data-category-cell="${group === undefined ? "empty" : group}" points="${polygon}" fill="var(--${fill})" opacity="${dim ? .18 : 1}"/>`;
  }).join("");
  return `<div class="honey-summary"><span class="big-number">${total} 台</span>每格代表 1 台设备，浅灰格为未使用位置。</div>
    <svg class="honeycomb" viewBox="0 0 354 230" role="img" aria-labelledby="honey-title"><title id="honey-title">${current().name}设备分类分布：${groups.map((g) => `${g.name}${g.count}台`).join("、")}。图例可筛选高亮，不改变总数。</title>${hexes}</svg>
    <div class="category-list">${groups.map((g, i) => `<button class="category-row" type="button" data-category="${i}" aria-pressed="${state.category === String(i)}" style="--tone:var(--${g.color})"><i></i>${g.name}<small>${(g.count / total * 100).toFixed(0)}%</small><strong>${g.count} 台</strong></button>`).join("")}</div>
    <button class="honey-reset" type="button" data-category="all">显示全部分类</button>`;
}
function delayCounts() {
  return [21, 18, 12, 10, 15, 14, 9].map((n) => Math.round(n * current().factor));
}
function dotChart() {
  const counts = delayCounts();
  const max = 30;
  const dots = counts.map((count, i) => {
    const nodes = Array.from({ length: max }, (_, j) => {
      const x = 22 + i * 44 + j % 3 * 8, y = 160 - Math.floor(j / 3) * 13;
      return `<circle cx="${x}" cy="${y}" r="3.1" fill="var(--${j >= count ? "chart-empty" : i < 2 ? "chart-secondary" : "apricot"})"/>`;
    }).join("");
    return `${nodes}<text x="${30 + i * 44}" y="185" text-anchor="middle">${["周一", "周二", "周三", "周四", "周五", "周六", "周日"][i]}</text>`;
  }).join("");
  return `<div class="dot-summary"><span class="big-number">${(counts.reduce((sum, n) => sum + n, 0) / 7).toFixed(1)} 条</span>日均延迟样本 · 本周示例</div>
    <svg class="dot-chart" viewBox="0 0 334 198" role="img" aria-labelledby="dot-title"><title id="dot-title">每个有色圆点代表1条延迟记录，周一至周日分别为${counts.join("、")}条；蓝色表示周初，杏色表示其余日期，不代表严重等级。</title>${dots}</svg>
    <p class="chart-footnote">1 点 = 1 条延迟记录；空白点为余量，不代表采样缺失。</p>
    <details class="section-body"><summary class="muted">查看点阵明细</summary>${table(["日期（固定示例周）", "延迟条数"], counts.map((n, i) => [`10/${19 + i}（${["一", "二", "三", "四", "五", "六", "日"][i]}）`, n]))}</details>`;
}
function overviewContent() {
  const toolbar = `<div class="insight-toolbar"><span class="period-chip">▦ 10/19 — 10/25 · 固定示例周</span><div class="view-tabs" role="group" aria-label="洞察视图">${[["analysis", "分析概览"], ["trends", "趋势"], ["log", "日志"]].map(([id, label]) => `<button type="button" data-overview-tab="${id}" aria-pressed="${state.overviewTab === id}">${label}</button>`).join("")}</div><small>${current().name} / 演示数据</small></div>`;
  if (state.overviewTab === "trends") return toolbar + panel("项目用量趋势", trend());
  if (state.overviewTab === "log") return toolbar + panel("本地样本日志", table(["时间 +08:00", "事件", "项目", "状态"], [
    ["2026-10-30 10:30", "采样批次写入", current().name, "固定样本"],
    ["2026-10-30 10:20", "一条设备身份待映射", current().name, "待复核 · 示例"],
    ["2026-10-30 10:10", "设备采样过期", current().name, "待核对 · 示例"]
  ]));
  const counts = delayCounts(), sum = counts.reduce((a, b) => a + b, 0);
  return toolbar + `<div class="atelier-grid">${panel("◈ 设备分布", honeycomb(), "分类构成 / 每格 1 台")}
    <div class="atelier-right">${panel("✦ 微屿观察到", `<p class="insight-copy">示例周的延迟记录更多集中在周一和周二，占本周的 <strong>${((counts[0] + counts[1]) / sum * 100).toFixed(0)}%</strong>。这只是固定样本分布，不代表已定位故障原因。</p>
      <div class="insight-stats"><div class="insight-stat"><strong>${sum} 条</strong><small>本周示例延迟</small></div><div class="insight-stat"><strong>周一 / 周二</strong><small>较集中的时段</small></div><div class="insight-stat"><strong>${counts[0]} 条</strong><small>周一延迟记录</small></div></div>
      <div class="insight-actions"><button type="button" data-go="sync">查看任务</button><button type="button" class="soft-blue" data-insight-analyze>✦ 打开模拟分析</button></div>`, "规则摘要 · 非模型结果")}
      ${panel("▦ 每日延迟分布", dotChart(), "蓝：周初 / 杏：其他日期")}</div></div>`;
}
function content() {
  if (AlarmCenter.has(state.page)) return AlarmCenter.render(state.page, current().name);
  const p = current();
  switch (state.page) {
    case "overview":
      return overviewContent();
    case "devices": return panel("设备列表", deviceList(), "筛选、分页、勾选与详情 / 独立类型表");
    case "projects":
      return panel("项目来源与授权", table(["项目", "客户", "来源", "外部绑定", "管理员"], [[p.name, p.customer, "HTTP API", `source-01 / ${state.project}`, "本客户管理员"], [`${p.name} · 扩建区`, p.customer, "手动新建", "待绑定", "待超管分配"]])) +
        panel("接入规范", '<div class="section-body muted">重同步按来源与外部 ID 去重，不覆盖本地客户归属与授权。此主题不执行项目写入。</div>');
    case "permissions":
      return panel("三级角色与授权", table(["角色", "用户管理", "项目分配", "数据范围"], [["超管", "创建客户管理员", "分配客户与管理员", "显式全局授权"], ["客户管理员", "本客户普通用户", "自己授权项目的子集", `${p.customer} / 获授项目`], ["普通用户", "不可管理", "不可再授权", "获授项目 / 默认只读"]])) +
        panel("权限约束", '<div class="section-body muted">所有菜单仅为样式演示。真实应用每次请求都要检查客户、项目和操作能力，不能依赖前端隐藏按钮。</div>');
    case "realtime":
      return panel("最新采样", table(["设备", "测点类型", "最新值", "单位", "质量", "采样时间 +08:00"], devices().map((d) => [d.code, d.type, d.value === null ? "缺失（非零）" : d.value, d.unit, statusNames[d.status], d.status === "online" ? "2026-10-30 10:30" : "2026-10-30 10:10（过期）"])));
    case "history": return panel("历史聚合查询", trend());
    case "curves": return panel("跨设备曲线组合", trend(true), "临时组合演示 / 不保存共享视图");
    case "dashboard":
      return panel("项目独立大屏预览", `<div class="section-body"><div class="screen-preview"><h3>${p.name} · 项目态势</h3><div class="screen-tiles"><p>设备总数<strong>${p.total}</strong>台</p><p>在线设备<strong>${p.online}</strong>台</p><p>在线率<strong>${(p.online / p.total * 100).toFixed(1)}%</strong>固定样本</p></div></div><p class="muted">草稿 v3 / 已发布 v2 为示例状态。正式实现使用受保护的独立路由与真实版本服务。</p></div>`);
    case "reports":
      return panel("报表记录", table(["报表", "项目", "统计周期", "状态", "计算口径"], [["用水日报", p.name, "2026-10-29", "已完成 · 示例", "累计量差值 / 处理复位"], ["用电日报", p.name, "2026-10-29", "待生成 · 示例", "电量差值 / 缺测标记"], ["设备质量周报", p.name, "10/24—10/30", "待生成 · 示例", "完整率 / 过期率"]])) +
        panel("导出与下载", '<div class="section-body muted">未生成真实文件。正式实现需异步生成、下载重新鉴权、公式注入防护及到期清理。</div>');
    case "governance":
      return panel("公式治理预览", '<div class="section-body"><p class="muted">固定换算 value * 0.001，升 → 立方米；不执行任意表达式，不写入数据库。</p><form id="governance-form" class="governance-form"><label>原始读数 / L<input id="raw-value" type="number" step="any" min="-1000000000" max="1000000000" value="1250" required></label><button class="primary" type="submit">预览结果</button></form><p id="formula-result" class="result" aria-live="polite">原始值 1250 L → 处理值 1.25 m³ · 规则 v1</p></div>') +
        panel("规则版本", table(["规则", "版本", "输出单位", "异常策略"], [["水量单位换算", "v1", "m³", "保留原始值并标记质量"]]));
    case "sync":
      return panel("同步任务", table(["任务", "范围", "调度", "游标", "状态"], [["设备与采样同步", p.name, "每 5 分钟", "10:30 + event-012", state.sync[state.project] ? "已启用" : "已暂停"], ["全平台来源同步", "超管统一任务", "每小时", "按项目维护", "此处只展示当前项目片段"]])) +
        panel("最近执行", table(["运行", "项目", "读取 / 写入 / 跳过", "结果"], [["demo-run-1030", p.name, "12 / 11 / 1", "局部失败：身份待映射"], ["demo-run-1025", p.name, "12 / 12 / 0", "成功 · 示例"]]));
    case "assistant": return panel("当前项目助手", `<div class="section-body"><p class="muted">项目：${p.name}。本地模拟，不连接模型或知识库。切换项目后使用独立会话。</p><p class="result">点击右上方“打开助手”或右下角入口，打开统一聊天窗。</p></div>`);
    case "analysis": return panel("分析模板", table(["模板示例", "受控范围", "输出限制"], [["project_overview_demo", "当前项目关键指标", "固定样本 / 不推断真实状态"], ["history_trend_demo", "当前项目 / 时间范围 / 系列", "不把相关性解释为因果"], ["sync_failure_demo", "当前项目运行片段", "不查看其他项目日志"]])) +
      panel("页面联动", '<div class="section-body muted">每个页面均可通过“AI 分析”进入同一个聊天窗。正式接入须在服务端验证权限、重查数据并套用版本化提示词。</div>');
    default: return "";
  }
}
function primaryLabel() {
  if (state.page === "assistant") return "打开助手";
  if (state.page === "sync") return state.sync[state.project] ? "暂停任务（演示）" : "启用任务（演示）";
  if (["devices", "overview"].includes(state.page)) return state.page === "devices" ? "模拟批量操作" : "+ 查看同步任务";
  if (state.page === "reports") return "模拟生成报表";
  return "查看模块说明";
}
function renderContent() {
  $("content").innerHTML = content();
  $("primary-action").textContent = primaryLabel();
}
function render() {
  const [group, title, description] = PAGES[state.page];
  $("page-group").textContent = `${group} / SOFT ATELIER`;
  $("page-title").textContent = title;
  $("breadcrumb").textContent = title;
  $("page-description").textContent = description;
  $("chat-context").textContent = `${current().name} · 模拟模式`;
  $("feedback").textContent = "";
  document.title = `${title} · AlinkIoT 主题参考`;
  document.querySelectorAll("[data-page]").forEach((a) => {
    if (a.dataset.page === state.page) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
  $("metrics").innerHTML = [
    ["◈ 接入设备", current().total, "台", "项目全量示例 / 蜂窝每格 1 台"],
    ["在线设备", current().online, "台", `在线率 ${(current().online / current().total * 100).toFixed(1)}%`],
    ["离线占比", ((current().total - current().online) / current().total * 100).toFixed(1), "%", "项目全量示例 / 非目录子集"]
  ].map(([label, value, unit, foot]) => `<article class="metric"><p class="metric-label">${label}</p><strong>${value}<small>${unit}</small></strong><p class="metric-foot">${foot}</p></article>`).join("");
  renderContent();
}
function route() {
  const page = location.hash.slice(1);
  state.page = Object.hasOwn(PAGES, page) ? page : "overview";
  state.query = ""; state.status = "all"; state.pageIndex = 0; state.selected.clear();
  $("detail-dialog").close();
  render();
  $("main").scrollTo({ top: 0, behavior: "instant" });
}
$("navigation").addEventListener("click", (event) => {
  if (!event.target.closest('a[href^="#"]')) return;
  requestAnimationFrame(() => $("main").scrollTo({ top: 0, behavior: "instant" }));
});
function renderMessages() {
  $("messages").replaceChildren();
  const messages = state.conversations[state.project];
  for (const { role, text } of messages.length ? messages : [{ role: "assistant", text: `当前项目：${current().name}。这是本地演示助手，可查看页面分析上下文示例，不具备真实模型能力。` }]) {
    const node = document.createElement("p");
    node.className = `message ${role}`;
    node.textContent = `${role === "user" ? "你" : "模拟助手"}：${text}`;
    $("messages").append(node);
  }
  $("messages").scrollTop = $("messages").scrollHeight;
}
function openChat() {
  $("chat").hidden = false; $("chat-launcher").setAttribute("aria-expanded", "true");
  renderMessages(); $("question").focus();
}
function closeChat() {
  $("chat").hidden = true; $("chat-launcher").setAttribute("aria-expanded", "false"); $("chat-launcher").focus();
}
function analyze() {
  const isTrend = ["history", "curves"].includes(state.page) || (state.page === "overview" && state.overviewTab === "trends");
  const scope = isTrend ? `${state.range === "day" ? "2026-10-30 当日" : "2026-10-24 至 10-30"} / Asia/Shanghai；系列：${["水表流量", "电表功率"].filter((_, i) => state.page !== "curves" || state.series[i]).join("、") || "未选系列"}` : "2026-10-30 10:30 +08:00";
  const template = isTrend ? "history_trend_demo" : state.page === "sync" ? "sync_failure_demo" : "project_overview_demo";
  const selectedFilter = state.page === "devices" ? `；筛选：${state.query || "全部设备"} / ${state.status}；匹配 ${filteredDevices().length} 条` : state.page === "overview" ? `；洞察视图：${state.overviewTab}；分类高亮：${state.category === "all" ? "全部" : categories()[Number(state.category)].name}；固定点阵周：2026-10-19 至 10-25` : "";
  state.conversations[state.project].push(
    { role: "user", text: `分析 ${current().name} / ${PAGES[state.page][1]}\n范围：${scope}${selectedFilter}\n模板：${template}` },
    { role: "assistant", text: `【模拟分析，非模型输出】\n当前项目 ${current().name}：全量示例 ${current().total} 台，在线 ${current().online} 台。设备目录仅为12条子集示例。\n${state.page === "sync" ? "示例运行有1条设备身份待映射，应先核查项目绑定与设备标识。" : isTrend ? "不同单位使用独立数值轴；缺少真实连续数据，不能推断趋势原因。" : "建议核查过期采样与待处理任务；这里没有真实数据连接。"}\n未执行任何业务操作，也未向外部模型发送数据。` }
  );
  openChat();
}
function showDetail(device) {
  $("detail-title").textContent = `${device.code} · ${device.name}`;
  $("detail-body").replaceChildren();
  for (const text of [`项目：${current().name}`, `类型：${device.type}`, `独立档案表：${device.table}`, `状态：${statusNames[device.status]}`, `最新值：${device.value === null ? "缺失，不等于零" : `${device.value} ${device.unit}`}`, "来源：固定样本，无真实设备连接"]) {
    const node = document.createElement("p"); node.textContent = text; $("detail-body").append(node);
  }
  $("detail-dialog").showModal();
}
$("content").addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  if (button.dataset.overviewTab) {
    state.overviewTab = button.dataset.overviewTab; renderContent();
    $("content").querySelector(`[data-overview-tab="${state.overviewTab}"]`).focus(); return;
  }
  if (button.dataset.category !== undefined) {
    state.category = button.dataset.category; renderContent();
    $("content").querySelector(`[data-category="${state.category}"]`).focus(); return;
  }
  if (button.hasAttribute("data-insight-analyze")) { analyze(); return; }
  if (button.dataset.go) { location.hash = button.dataset.go; return; }
  if (button.dataset.detail) { showDetail(devices().find((d) => d.id === button.dataset.detail)); return; }
  switch (button.dataset.action) {
    case "previous": state.pageIndex = Math.max(0, state.pageIndex - 1); break;
    case "next": state.pageIndex = Math.min(Math.ceil(filteredDevices().length / 5) - 1, state.pageIndex + 1); break;
    case "reset": state.query = ""; state.status = "all"; state.pageIndex = 0; break;
    default: return;
  }
  renderContent();
});
$("content").addEventListener("submit", (event) => {
  event.preventDefault();
  if (event.target.id === "filter-form") {
    state.query = $("search").value.trim(); state.status = $("status-filter").value; state.pageIndex = 0; renderContent();
  }
  if (event.target.id === "governance-form") {
    const value = Number($("raw-value").value);
    $("formula-result").textContent = Number.isFinite(value) && Math.abs(value) <= 1e9 ? `原始值 ${value} L → 处理值 ${Number((value * .001).toFixed(8))} m³ · 规则 v1 / 未写入数据库` : "请输入范围内的有限数值。";
  }
});
$("content").addEventListener("change", (event) => {
  const target = event.target;
  if (target.dataset.select) {
    if (target.checked) state.selected.add(target.dataset.select); else state.selected.delete(target.dataset.select);
    $("content").querySelector(".count").textContent = `已选 ${state.selected.size} 项`;
  }
  if (target.id === "range") { state.range = target.value; renderContent(); $("range").focus(); }
  if (target.dataset.series !== undefined) {
    state.series[Number(target.dataset.series)] = target.checked; renderContent();
    $("content").querySelector(`[data-series="${target.dataset.series}"]`).focus();
  }
});
$("project").addEventListener("change", (event) => {
  state.project = event.target.value; state.pageIndex = 0; state.selected.clear(); $("question").value = "";
  $("detail-dialog").close(); render(); renderMessages();
});
$("primary-action").addEventListener("click", () => {
  switch (state.page) {
    case "overview": location.hash = "sync"; break;
    case "assistant": openChat(); break;
    case "sync":
      state.sync[state.project] = !state.sync[state.project]; render();
      $("feedback").textContent = "已更新本地项目任务状态，未调用调度服务。"; break;
    case "devices": $("feedback").textContent = state.selected.size ? `已选 ${state.selected.size} 项，仅演示批量操作反馈，未写入数据。` : "请先勾选设备。"; break;
    case "reports": $("feedback").textContent = "模拟生成请求：未提交真实任务，未创建文件。"; break;
    default: $("feedback").textContent = `${PAGES[state.page][1]}：${PAGES[state.page][2]} 当前仅为主题演示。`;
  }
});
$("detail-close").addEventListener("click", () => $("detail-dialog").close());
$("collapse").addEventListener("click", () => {
  const collapsed = document.body.classList.toggle("collapsed");
  $("collapse").setAttribute("aria-expanded", String(!collapsed));
  $("collapse").setAttribute("aria-label", collapsed ? "展开侧边菜单" : "收起侧边菜单");
});
$("analyze").addEventListener("click", analyze);
$("chat-launcher").addEventListener("click", () => $("chat").hidden ? openChat() : closeChat());
$("chat-close").addEventListener("click", closeChat);
document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !$("chat").hidden && !$("detail-dialog").open) closeChat(); });
$("chat-form").addEventListener("submit", (event) => {
  event.preventDefault(); const text = $("question").value.trim(); if (!text) return;
  state.conversations[state.project].push({ role: "user", text }, { role: "assistant", text: `【模拟回复】当前项目：${current().name}。没有连接真实模型，不能根据示例给出业务结论。正式应用需由服务端校验权限并获取受控数据。` });
  $("question").value = ""; renderMessages();
});
let previousGroup = "";
$("navigation").innerHTML = Object.entries(PAGES).map(([id, [group, title]], i) => {
    const heading = previousGroup === group ? "" : `<p class="nav-group">${group}</p>`; previousGroup = group;
    const paths = [
      "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
      "M3 7h7l2-3h9v16H3z", "M12 2l8 4v6c0 5-8 9-8 9s-8-4-8-9V6z",
      "M5 5h14v14H5z M9 9h6v6H9z M9 2v3 M15 2v3 M9 19v3 M15 19v3",
      "M2 12h5l3-7 4 14 3-7h5", "M12 3a9 9 0 1 0 9 9 M12 6v6l4 2",
      "M3 3v18h18 M6 16l4-6 4 3 6-7", "M3 4h18v13H3z M8 21h8 M12 17v4",
      "M6 3h9l4 4v14H6z M9 11h7 M9 15h7", "M4 5h16 M4 12h16 M4 19h16 M8 3v4 M16 10v4 M11 17v4",
      "M20 8A8 8 0 0 0 6 5L3 8 M3 3v5h5 M4 16a8 8 0 0 0 14 3l3-3 M21 21v-5h-5",
      "M4 4h16v13H9l-5 4z M8 9h8 M8 13h5", "M12 2l2 7 7 3-7 2-2 8-3-8-7-2 7-3z"
    ];
    const iconPath = AlarmCenter.has(id) ? "M12 3a6 6 0 0 0-6 6v5l-2 3h16l-2-3V9a6 6 0 0 0-6-6 M10 21h4" : paths[i];
    return `${heading}<a class="nav-link" href="#${id}" data-page="${id}" data-menu-tip="${title}" aria-label="${title}"><small><svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${iconPath}"/></svg></small><span>${title}</span></a>`;
}).join("");
window.addEventListener("hashchange", route);
function filterMenu() {
  const query = $("menu-search").value.trim().toLowerCase();
  const links = [...$("navigation").querySelectorAll("[data-page]")];
  links.forEach((link) => { link.hidden = !link.textContent.toLowerCase().includes(query); });
  $("navigation").querySelectorAll(".nav-group").forEach((heading) => {
    let node = heading.nextElementSibling, visible = false;
    while (node && !node.classList.contains("nav-group")) { if (!node.hidden) visible = true; node = node.nextElementSibling; }
    heading.hidden = !visible;
  });
  $("menu-empty").hidden = links.some((link) => !link.hidden);
}
$("menu-search").addEventListener("input", filterMenu);
$("theme-select").addEventListener("change", (event) => applyTheme(event.target.value));
document.addEventListener("keydown", (event) => {
  if (event.key !== "/" || event.ctrlKey || event.metaKey || event.altKey || event.target.closest("input, textarea, select, [contenteditable]")) return;
  if (!$("menu-search").getClientRects().length || $("detail-dialog").open) return;
  event.preventDefault();
  $("menu-search").focus();
});
let savedTheme = "warm-petal";
try { savedTheme = localStorage.getItem("soft-atelier-theme") || savedTheme; } catch { /* Keep the default without storage. */ }
applyTheme(savedTheme);
route();

{
  const tip = document.createElement("div");
  tip.id = "menu-tip";
  tip.className = "menu-tip";
  tip.setAttribute("role", "tooltip");
  tip.hidden = true;
  document.body.append(tip);
  let active;
  const hide = () => {
    active?.removeAttribute("aria-describedby");
    active = null;
    tip.hidden = true;
  };
  const show = (event) => {
    const item = event.target.closest("[data-menu-tip]");
    if (!item || !item.closest(".menu-collapsed, .collapsed")) return;
    hide();
    active = item;
    tip.textContent = item.dataset.menuTip;
    tip.hidden = false;
    item.setAttribute("aria-describedby", tip.id);
    const rect = item.getBoundingClientRect();
    tip.style.left = `${Math.max(8, Math.min(rect.right + 10, innerWidth - tip.offsetWidth - 8))}px`;
    tip.style.top = `${Math.max(8, Math.min(rect.top + (rect.height - tip.offsetHeight) / 2, innerHeight - tip.offsetHeight - 8))}px`;
  };
  document.addEventListener("pointerover", show);
  document.addEventListener("focusin", show);
  for (const type of ["pointerout", "focusout"]) document.addEventListener(type, (event) => {
    if (active && !active.contains(event.relatedTarget)) hide();
  });
  document.addEventListener("click", hide);
  document.addEventListener("scroll", hide, true);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hide(); });
  window.addEventListener("resize", hide);
}
