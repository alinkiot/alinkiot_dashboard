function openAIWarningTask() {
  const project = Workspace.project || PROJECTS[0]?.id;
  openDrawer('新建智能预警任务', `<form id="aiWarningTaskForm">
    <div class="form-field"><label>任务名称</label><input class="inp" name="name" required maxlength="80"/></div>
    <div class="form-field"><label>项目</label><select class="sel" name="project" required aria-label="预警任务项目">
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <p class="hint" data-warning-agent></p>
    <div class="form-row"><div class="form-field"><label>分析间隔（分钟）</label><input class="inp" name="interval" type="number" required min="1" max="1440" step="1" value="15"/></div>
      <div class="form-field"><label>每次分析最近（分钟）</label><input class="inp" name="window" type="number" required min="1" max="10080" step="1" value="60"/></div></div>
    <h4>关联设备</h4><div class="panel-device-picker" data-warning-devices></div>
    <div class="form-field"><label>AI 分析要求</label><textarea class="inp" name="prompt" rows="4" style="height:auto" required maxlength="2000" placeholder="例如：分析各设备最近一小时的数据趋势，识别持续上升、异常波动，并给出对应设备和数据证据。"></textarea></div>
    <div class="form-field"><label>预警触发条件</label><textarea class="inp" name="condition" rows="3" style="height:auto" required maxlength="1000" placeholder="例如：发现持续异常且有数据证据时触发；无数据或仅推测时不触发。"></textarea></div>
    <div class="form-field"><label>预警等级</label><select class="sel" name="level"><option>高</option><option selected>中</option><option>低</option></select></div>
    <label><input type="checkbox" name="enabled"/>保存为启用配置（不代表已运行）</label>
    <p class="hint">触发结果：进入告警事件，来源标记“智能预警”。当前只保存配置，不调度、不调用 AI、不触发告警；设备数据范围为所选设备，每次回看配置的时间窗口。数字人沿用项目接入配置，尚不能真实调用。</p>
    <p data-warning-error role="alert" hidden style="color:var(--danger)"></p></form>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" form="aiWarningTaskForm" type="submit">保存任务</button>');
  const form = document.getElementById('aiWarningTaskForm');
  const paint = () => {
    const project = form.elements.project.value, target = AgentAccess.target(project);
    form.querySelector('[data-warning-agent]').textContent = target ?
      '项目数字人：' + target.avatar.name + '（本地接入示例，未连接 AI）' : '项目尚未选择数字人，可先保存任务配置；真实执行需要接入智能体平台。';
    form.querySelector('[data-warning-devices]').innerHTML = DEVICES.filter(d => d.project === project).map(d =>
      `<label class="check-line"><input type="checkbox" name="device" value="${d.id}"/><i></i>${escapeHTML(d.name)} · ${escapeHTML(d.code)}</label>`).join('') || '<p class="hint">该项目暂无设备</p>';
  };
  form.elements.project.onchange = paint;
  form.onsubmit = event => {
    event.preventDefault();
    try {
      const result = AIWarningTasks.create({ name: form.elements.name.value, project: form.elements.project.value,
        devices: [...form.querySelectorAll('[name=device]:checked')].map(input => input.value),
        interval: Number(form.elements.interval.value), window: Number(form.elements.window.value),
        prompt: form.elements.prompt.value, condition: form.elements.condition.value,
        level: form.elements.level.value, enabled: form.elements.enabled.checked });
      Object.assign(Workspace.page('ai-warning'), { selected: result.id, opened: false });
      Workspace.save(); go('ai-warning');
      toast(result.persisted ? '任务配置已保存，未执行定时分析' : '任务仅内存保存，存储失败，刷新将丢失', result.persisted ? 'ok' : 'warn');
    } catch (e) {
      const error = form.querySelector('[data-warning-error]');
      error.textContent = e.message; error.hidden = false;
    }
  };
  paint();
}
VIEWS['ai-warning'] = {
  group: 'AI 能力', title: '智能预警',
  render() {
    const state = Workspace.page('ai-warning'), tasks = AIWarningTasks.list();
    const current = state.opened && AIWarningTasks.task(state.selected);
    const status = task => task.enabled ? '配置已启用 · 未运行' : '配置已停用';
    const target = current && AgentAccess.target(current.project);
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">智能预警</div>
      <div class="page-desc">按任务定时分析设备数据 · 满足条件进入告警事件（未接入执行服务）</div></div>
      <div class="page-actions">${current ? '<button class="btn btn-ghost" data-warning-back>返回列表</button>' :
        '<button class="btn btn-primary" data-warning-add>新建任务</button>'}</div></div>
      <p class="hint">本地配置演示：未调度、未调用 AI、未生成告警。启停仅改变配置；真实执行后的告警来源约定为“智能预警”。未接入统一账号权限。</p>
      ${AIWarningTasks.loadError ? '<p class="hint">预警任务存档无法读取，已回退空列表。</p>' : ''}
      ${current ? `<section class="card"><div class="card-head"><h3>${escapeHTML(current.name)}</h3>
        <button class="btn btn-ghost" data-warning-toggle="${current.id}">${current.enabled ? '停用配置' : '启用配置'}</button></div><div class="card-body">
        <p>项目：${escapeHTML(projName(current.project))}</p><p>状态：${status(current)}</p>
        <p>每 ${current.interval} 分钟分析一次，回看最近 ${current.window} 分钟数据。</p>
        <p>预警等级：${current.level} · 触发去向：告警事件 · 来源：智能预警（待接入）</p>
        <p>项目数字人：${target ? escapeHTML(target.avatar.name) + '（示例，未连接）' : '未配置'}</p>
        <p>创建：${escapeHTML(current.created)}</p><h4>AI 分析要求</h4>
        <p style="white-space:pre-wrap;overflow-wrap:anywhere">${escapeHTML(current.prompt)}</p><h4>预警触发条件</h4>
        <p style="white-space:pre-wrap;overflow-wrap:anywhere">${escapeHTML(current.condition)}</p>
        <h4>关联设备（${current.devices.length} 台）</h4><ul>${current.devices.map(id => {
          const device = DEVICES.find(d => d.id === id);
          return `<li>${escapeHTML(device?.name || id)} · ${escapeHTML(device?.code || '设备已移除')}</li>`;
        }).join('')}</ul>
        <div class="empty"><h4>暂无执行记录</h4><p>尚未执行定时分析，无 AI 结果、无触发告警。</p></div>
      </div></section>` : `<div class="panel-grid">${tasks.map(task => `<article class="card"><div class="card-body">
        <h3>${escapeHTML(task.name)}</h3><p class="hint">${escapeHTML(projName(task.project))} · ${task.devices.length} 台设备 · ${task.level}等级</p>
        <p class="hint">每 ${task.interval} 分钟 · 最近 ${task.window} 分钟数据</p><p>${status(task)}</p>
        <div class="panel-actions"><button class="btn btn-primary btn-sm" data-warning-open="${task.id}">查看任务</button>
          <button class="btn btn-ghost btn-sm" data-warning-toggle="${task.id}">${task.enabled ? '停用配置' : '启用配置'}</button></div>
      </div></article>`).join('')}</div>${tasks.length ? '' : '<div class="empty"><h4>暂无智能预警任务</h4><p>新建任务，配置设备范围、分析周期和触发条件。</p></div>'}`}</div>`;
  },
  mount(scope) {
    const state = Workspace.page('ai-warning');
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      if (button.hasAttribute('data-warning-add')) openAIWarningTask();
      if (button.dataset.warningOpen) {
        Object.assign(state, { selected: button.dataset.warningOpen, opened: true }); Workspace.save(); go('ai-warning');
      }
      if (button.hasAttribute('data-warning-back')) { state.opened = false; Workspace.save(); go('ai-warning'); }
      if (button.dataset.warningToggle) {
        try {
          const persisted = AIWarningTasks.toggle(button.dataset.warningToggle);
          go('ai-warning');
          toast('启停配置已更新，未执行定时分析' + (persisted ? '' : '；存储失败，刷新将丢失'), persisted ? 'info' : 'warn');
        } catch (e) { toast(e.message, 'warn'); }
      }
    });
  }
};
