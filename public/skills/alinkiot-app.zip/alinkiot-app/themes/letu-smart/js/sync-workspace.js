const SyncWorkspace = (() => {
  const key = 'letu-sync-workspace-v1';
  const formulas = [
    { id: 'demo-divide10', name: '十倍值还原', version: 1, expression: 'value / 10' },
    { id: 'demo-multiply1000', name: '千倍换算', version: 1, expression: 'value * 1000' }
  ];
  let tasks = [], loadError = false;
  const clone = value => JSON.parse(JSON.stringify(value));
  function source(input) {
    let url;
    try { url = new URL(String(input.url || '').trim()); } catch (e) { throw new Error('请输入有效 URL'); }
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash ||
        url.href.length > 500) throw new Error('URL 须为 HTTP/HTTPS，不含凭证、查询参数或片段');
    const appid = String(input.appid || '').trim();
    if (!appid || appid.length > 100) throw new Error('AppID 须为 1–100 字');
    return { url: url.href.replace(/\/$/, ''), appid };
  }
  function validate(input) {
    const name = String(input.name || '').trim();
    if (!name || name.length > 80) throw new Error('任务名称须为 1–80 字');
    if (input.project && !PROJECTS.some(p => p.id === input.project)) throw new Error('项目无效');
    if (!Number.isInteger(input.interval) || input.interval < 1 || input.interval > 1440 ||
        typeof input.enabled !== 'boolean') throw new Error('间隔须为 1–1440 分钟整数，启停状态须有效');
    if (!Array.isArray(input.products) || !input.products.length || input.products.length > 40) throw new Error('请选择产品');
    const seen = new Set();
    const products = input.products.map(item => {
      const product = PanelWorkspace.product(item.id);
      if (!product || seen.has(item.id) || !Array.isArray(item.bindings)) throw new Error('产品无效或重复');
      seen.add(item.id);
      const properties = new Set();
      const bindings = item.bindings.map(binding => {
        const property = product.properties.find(p => p.key === binding.property && p.type === 'number' && p.source === 'telemetry');
        const formula = formulas.find(f => f.id === binding.formulaId && f.version === binding.version);
        if (!property || !formula || properties.has(binding.property) || typeof binding.unit !== 'string' ||
            binding.unit.length > 20) throw new Error('公式绑定须指向产品采样数值属性、有效版本和输出单位');
        properties.add(binding.property);
        return { property: property.key, formulaId: formula.id, version: formula.version,
          expression: formula.expression, unit: binding.unit.trim() };
      });
      return { id: product.id, name: product.name, bindings };
    });
    return { name, ...source(input), project: input.project || '', interval: input.interval, enabled: input.enabled, products };
  }
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.version !== 1 || !Array.isArray(data.tasks) || data.tasks.length > 100) throw new Error('无效存档');
      tasks = data.tasks.map(task => {
        if (typeof task.id !== 'string' || !task.id || typeof task.created !== 'string') throw new Error('无效任务');
        return { ...validate(task), id: task.id, created: task.created };
      });
      if (new Set(tasks.map(t => t.id)).size !== tasks.length) throw new Error('重复任务');
    }
  } catch (e) { tasks = []; loadError = true; }
  const persist = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, tasks })); return true; }
    catch (e) { return false; }
  };
  return {
    get loadError() { return loadError; },
    list: () => clone(tasks),
    task: id => { const task = tasks.find(t => t.id === id); return task ? clone(task) : null; },
    formulas: () => clone(formulas),
    discover(input) { return { ...source(input), products: PanelWorkspace.products() }; },
    create(input) {
      if (tasks.length >= 100) throw new Error('最多保存 100 个同步任务');
      const task = { ...validate(input), id: crypto.randomUUID(), created: Telemetry.format(Date.now()) };
      tasks.push(task);
      return { id: task.id, persisted: persist() };
    },
    toggle(id) {
      const task = tasks.find(t => t.id === id);
      if (!task) throw new Error('任务不存在');
      if (!task.enabled) validate(task);
      task.enabled = !task.enabled;
      return persist();
    }
  };
})();
