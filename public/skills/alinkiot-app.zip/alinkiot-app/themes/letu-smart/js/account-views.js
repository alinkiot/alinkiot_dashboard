function finishAccountChange(persisted, message, reset = false) {
  if (reset) Object.assign(Workspace.page('roles'), { search: '', accountRole: '', accountStatus: '', page: 1 });
  go('roles');
  toast(persisted ? message + '（本地演示）' : message + '，但存储失败，刷新可能丢失', persisted ? 'ok' : 'warn');
}

function openAccountEditor(target) {
  const who = Accounts.actor();
  const role = target?.role || (who.role === 'superadmin' ? 'admin' : 'user');
  const customer = target?.customer || (who.role === 'admin' ? who.customer : CUSTOMERS[0]?.id || '');
  openModal(target ? '编辑账号与授权' : '新增' + Accounts.roles[role], `
    <form id="accountForm">
      <div class="form-row">
        <div class="form-field"><label>登录账号 <span class="req">*</span></label>
          <input class="inp" name="username" required minlength="3" maxlength="40" pattern="[A-Za-z][A-Za-z0-9_.\\-]{2,39}"
            value="${escapeHTML(target?.username || '')}" ${target ? 'readonly' : ''} placeholder="字母开头，3–40 位"/></div>
        <div class="form-field"><label>显示姓名 <span class="req">*</span></label>
          <input class="inp" name="name" required maxlength="40" value="${escapeHTML(target?.name || '')}"/></div>
      </div>
      <div class="form-field"><label>固定角色</label><input class="inp" value="${Accounts.roles[role]}" disabled/></div>
      <div class="form-field"><label>所属客户 <span class="req">*</span></label>
        <select class="sel" name="customer" required ${target || who.role !== 'superadmin' ? 'disabled' : ''}>${customerOptions(customer)}</select></div>
      <div style="font-size:13px;font-weight:600;margin:14px 0 8px">项目范围与可选能力</div>
      <div data-account-grants style="max-height:300px;overflow:auto"></div>
      <p class="hint">选中项目即允许查询、AI、查看大屏及管理自己的个人曲线；可选能力受固定角色上限约束。普通用户没有配置、用户管理或告警处理能力。</p>
      <p class="hint">未获授权的已有项目以只读形式保留，不能代替其他管理员修改。授权属于客户，不随原授权管理员停用而消失。</p>
      <p class="hint">本地样本不创建真实登录凭证，不收集密码；这里只演示账号档案及授权关系。</p>
      <p data-account-error role="alert" hidden style="color:var(--danger)"></p>
    </form>`, `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
      <button class="btn btn-primary" type="submit" form="accountForm">保存账号</button>`);
  const form = document.getElementById('accountForm');
  const customerSelect = form.elements.customer;
  const renderGrants = () => {
    const customerId = customerSelect.value;
    const projects = Accounts.grantable(customerId);
    const grants = target ? Accounts.effective(target.id) : [];
    const own = Accounts.effective(who.id);
    const editable = new Set(projects.map(p => p.id));
    form.querySelector('[data-account-grants]').innerHTML = projects.map(p => {
      const current = grants.find(g => g.project === p.id);
      return `<div class="card" data-grant="${p.id}" style="margin-bottom:8px;padding:8px">
        <label class="check-line"><input type="checkbox" name="project" value="${p.id}" ${current ? 'checked' : ''}/><i></i>${escapeHTML(p.name)}</label>
        <div style="display:flex;flex-wrap:wrap">
          ${Accounts.ceiling(role).map(cap => {
            const allowed = who.role === 'superadmin' || own.find(g => g.project === p.id)?.capabilities.includes(cap);
            return `<label class="check-line"><input type="checkbox" data-cap="${cap}"
              ${current?.capabilities.includes(cap) ? 'checked' : ''} ${allowed ? '' : 'disabled'}/><i></i>${Accounts.capabilities[cap]}${allowed ? '' : '（未获授）'}</label>`;
          }).join('')}
        </div>
      </div>`;
    }).join('') || '<p class="hint">当前没有可分配项目，可先创建零项目账号，后续再授权。</p>';
    for (const grant of grants.filter(g => !editable.has(g.project))) {
      const project = PROJECTS.find(p => p.id === grant.project);
      const locked = document.createElement('p');
      locked.className = 'hint';
      locked.textContent = '保留已有授权（只读）：' + (project?.name || grant.project) + ' · ' +
        (grant.capabilities.map(cap => Accounts.capabilities[cap]).join('、') || '仅基础查询与个人曲线');
      form.querySelector('[data-account-grants]').appendChild(locked);
    }
    form.querySelectorAll('[data-grant]').forEach(card => {
      const project = card.querySelector('[name="project"]');
      const sync = () => card.querySelectorAll('[data-cap]:not([data-unavailable])').forEach(input => {
        input.disabled = !project.checked;
      });
      card.querySelectorAll('[data-cap]:disabled').forEach(input => { input.dataset.unavailable = 'true'; });
      project.addEventListener('change', sync);
      sync();
    });
  };
  customerSelect.addEventListener('change', renderGrants);
  renderGrants();
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const grants = [...form.querySelectorAll('[name="project"]:checked')].map(input => ({
      project: input.value,
      capabilities: [...input.closest('[data-grant]').querySelectorAll('[data-cap]:checked:not(:disabled)')].map(el => el.dataset.cap)
    }));
    const input = {
      username: form.elements.username.value.trim(), name: form.elements.name.value.trim(),
      role, customer: customerSelect.value, grants
    };
    try {
      const persisted = target ? Accounts.update(target.id, input) : Accounts.create(input);
      finishAccountChange(persisted, target ? '账号与授权已保存' : '账号已创建', !target);
    } catch (e) {
      const error = form.querySelector('[data-account-error]');
      error.textContent = e.message;
      error.hidden = false;
    }
  });
}

function showAccountDetails(user) {
  const grants = Accounts.effective(user.id);
  openDrawer('账号详情 · ' + user.name, `
    <dl class="kv">
      <dt>登录账号</dt><dd>${escapeHTML(user.username)}</dd>
      <dt>固定角色</dt><dd>${Accounts.roles[user.role]}</dd>
      <dt>所属客户</dt><dd>${escapeHTML(custName(user.customer))}</dd>
      <dt>档案状态</dt><dd>${user.status === 'active' ? '正常' : '已停用'}</dd>
    </dl>
    <h4 style="margin:18px 0 8px">当前项目授权</h4>
    ${user.role === 'superadmin' ? '<p class="hint">演示超管使用全局范围，不绑定客户或个人项目授权。</p>' :
      grants.map(g => `<div class="list-row"><div class="lr-body"><b>${escapeHTML(projName(g.project))}</b>
        <small>${escapeHTML(g.capabilities.map(c => Accounts.capabilities[c]).join('、') || '基础查询与个人曲线')}</small></div></div>`).join('') ||
        '<p class="hint">未分配项目，业务数据范围为空。</p>'}
    <p class="hint">账号停用保留本人授权记录以便恢复，但不撤销其他用户授权。本页身份仅控制账号操作演示，不影响其他页面或真实登录。</p>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>');
}

VIEWS.roles = {
  group: '系统', title: '角色权限',
  render() {
    const who = Accounts.actor(), users = Accounts.visible();
    const matrix = [
      ['开通客户管理员', '是', '否', '否'],
      ['维护普通用户', '不参与日常管理', '仅本客户', '否'],
      ['分配客户及管理员项目', '是', '否', '否'],
      ['给普通用户授权项目', '不参与日常管理', '自己的授权子集', '否'],
      ['查询 / AI / 大屏查看 / 告警查看', '全部', '获授权项目', '获授权项目'],
      ['管理个人曲线', '本人视图', '本人获授权数据', '本人获授权数据'],
      ['导出 / 报表生成与下载', '全部', '按项目获授能力', '按项目获授能力'],
      ['治理 / 接入 / 共享配置', '全部', '按项目获授能力', '否'],
      ['项目同步 / 告警配置与处理', '全部', '按项目获授能力', '否'],
      ['统一同步任务', '是', '否', '否']
    ];
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">角色权限</div><div class="page-desc">固定三级角色 · 客户持有项目授权 · 本地账号与授权操作演示</div></div>
        <div class="page-actions">${who.role !== 'user' ? `<button class="btn btn-primary" data-act="add-account">${icon('plus')}新增${who.role === 'superadmin' ? '客户管理员' : '普通用户'}</button>` : ''}</div>
      </div>
      <div class="card" style="margin-bottom:16px"><div class="card-body">
        <label style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">操作身份（仅本页演示）
          <select class="sel" data-account-actor aria-label="操作身份">
            ${Accounts.identities().map(u => `<option value="${u.id}" ${u.id === who.id ? 'selected' : ''}>${escapeHTML(u.name)} · ${Accounts.roles[u.role]}${u.customer ? ' · ' + escapeHTML(custShort(u.customer)) : ''}</option>`).join('')}
          </select>
        </label>
        <p class="hint">此选择器不是登录，所有身份均为本地样本。仅本页按身份约束账号与授权操作；其他菜单、业务数据与悬浮 AI 尚未接入统一身份，不能用于验证全站隔离。</p>
        ${Accounts.loadError ? '<p class="hint" style="color:var(--warn)">账号存档无法读取，当前使用初始账号样本。</p>' : ''}
      </div></div>
      <div class="grid g3" style="margin-bottom:16px">
        ${Object.entries(Accounts.roles).map(([role, name]) => `<div class="card"><div class="card-body">
          <h3>${name}</h3><p class="hint">${role === 'superadmin' ? '开通客户管理员，分配客户及管理员的项目，不管理企业普通用户。' :
            role === 'admin' ? '仅管理本企业普通用户，分配自己已获授权的项目；本人角色与归属不可改。' :
              '只看获授权数据；允许个人曲线及获授的导出/报表能力，没有管理能力。'}</p>
          <span class="badge plain">当前列表 ${users.filter(u => u.role === role).length} 个</span>
        </div></div>`).join('')}
      </div>
      <div class="card">
        <div class="card-head" style="flex-wrap:wrap"><h3><span class="dot-mark"></span>账号列表</h3><div class="ch-right" style="flex-wrap:wrap">
          <div class="search-box" style="min-width:180px"><span class="ico-s"></span><input data-filter placeholder="搜索账号 / 姓名"/></div>
          <select class="sel" data-account-role aria-label="账号角色"><option value="">全部角色</option>
            ${Object.entries(Accounts.roles).map(([role, name]) => `<option value="${role}">${name}</option>`).join('')}</select>
          <select class="sel" data-account-status aria-label="账号状态"><option value="">全部状态</option><option value="active">正常</option><option value="disabled">已停用</option></select>
        </div></div>
        <div class="card-body flush"><div class="table-wrap"><table class="tbl">
          <thead><tr><th>账号</th><th>角色</th><th>所属客户</th><th>授权项目</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>${users.map(u => `<tr data-row data-account-id="${u.id}" data-account-role="${u.role}" data-account-status="${u.status}">
            <td><div class="cname">${escapeHTML(u.name)}${u.id === who.id ? '（当前）' : ''}</div><div class="csub">${escapeHTML(u.username)}</div></td>
            <td>${Accounts.roles[u.role]}</td><td>${escapeHTML(custShort(u.customer))}</td>
            <td>${u.role === 'superadmin' ? '全局' : Accounts.effective(u.id).length + ' 个'}</td>
            <td>${badge(u.status, u.status === 'active' ? '正常' : '已停用')}</td>
            <td><div class="actions">
              <button class="btn btn-sm btn-ghost" data-act="account-detail" data-id="${u.id}">详情</button>
              ${Accounts.canEdit(u.id) ? `<button class="btn btn-sm btn-ghost" data-act="edit-account" data-id="${u.id}">编辑授权</button>` : ''}
              ${Accounts.canToggle(u.id) ? `<button class="btn btn-sm btn-ghost" data-act="toggle-account" data-id="${u.id}">${u.status === 'active' ? '停用' : '恢复'}</button>` : ''}
            </div></td></tr>`).join('')}</tbody></table>
          <div data-empty class="empty" style="display:none">没有匹配账号</div>
        </div></div>${pager(users.length, 1, 10)}
      </div>
      <div class="card mt"><div class="card-head"><h3>固定权限上限（业务规范）</h3></div>
        <div class="card-body flush"><div class="table-wrap"><table class="tbl"><thead><tr><th>操作</th><th>超级管理员</th><th>客户管理员</th><th>普通用户</th></tr></thead>
        <tbody>${matrix.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>
      </div>
      <p class="hint">企业其他管理员可停用/恢复本企业账号，不可停用本人。管理员个人项目撤销不级联其他用户；项目转出客户则清理该客户下所有相关授权。密码重置、管理员交接、后端认证与审计仍未接入。</p>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-account-role]', 'accountRole');
    bindSelectFilter(scope, '[data-account-status]', 'accountStatus');
    scope.querySelector('[data-account-actor]').addEventListener('change', event => {
      try { finishAccountChange(Accounts.selectActor(event.target.value), '已切换本页操作身份', true); }
      catch (e) { toast(e.message, 'warn'); }
    });
    scope.addEventListener('click', event => {
      const button = event.target.closest('[data-act]');
      if (!button) return;
      const user = Accounts.visible().find(u => u.id === button.dataset.id);
      if (button.dataset.act === 'add-account') openAccountEditor();
      if (button.dataset.act === 'account-detail' && user) showAccountDetails(user);
      if (button.dataset.act === 'edit-account' && user && Accounts.canEdit(user.id)) openAccountEditor(user);
      if (button.dataset.act === 'toggle-account' && user && Accounts.canToggle(user.id)) {
        const action = user.status === 'active' ? '停用' : '恢复';
        openModal(action + '账号', `<p>${escapeHTML(user.name)} · ${escapeHTML(user.username)}</p>
          <p class="hint">仅改变本地账号状态，保留其授权记录。不撤销其他用户已有授权，不影响真实登录会话。</p>`,
          `<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" data-confirm-account>确认${action}</button>`);
        document.querySelector('[data-confirm-account]').addEventListener('click', () => {
          try { finishAccountChange(Accounts.toggle(user.id), '账号已' + action); }
          catch (e) { toast(e.message, 'warn'); }
        });
      }
    });
  }
};
