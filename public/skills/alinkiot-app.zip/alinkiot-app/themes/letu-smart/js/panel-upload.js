const PanelUpload = (() => {
  const decoder = new TextDecoder('utf-8', { fatal: true });
  const maxFile = 2000000;
  const fail = message => { throw new Error(message); };
  const path = value => {
    if (!value || value.includes('\\') || value.startsWith('/') || value.includes(':') || /[\u0000-\u001f]/.test(value)) fail('资源路径无效');
    const parts = value.split('/');
    if (parts.some(p => p === '..' || p === '.')) fail('资源路径不可包含 . 或 ..');
    return parts.filter(Boolean).join('/');
  };
  const crc32 = bytes => {
    let crc = 0xffffffff;
    for (const byte of bytes) {
      crc ^= byte;
      for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
    return (crc ^ 0xffffffff) >>> 0;
  };
  async function unzip(buffer) {
    const bytes = new Uint8Array(buffer), view = new DataView(buffer);
    if (bytes.length > 1000000) fail('ZIP 压缩包最多 1 MB');
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (view.getUint32(i, true) === 0x06054b50 && i + 22 + view.getUint16(i + 20, true) === bytes.length) { end = i; break; }
    }
    if (end < 0) fail('不是有效 ZIP 文件');
    const count = view.getUint16(end + 10, true), size = view.getUint32(end + 12, true), offset = view.getUint32(end + 16, true);
    if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true) ||
        view.getUint16(end + 8, true) !== count || !count || count > 80 || offset + size !== end) fail('ZIP 不支持分卷、ZIP64 或超过 80 个条目');
    const files = new Map();
    let pos = offset, expanded = 0;
    for (let i = 0; i < count; i++) {
      if (pos + 46 > end || view.getUint32(pos, true) !== 0x02014b50) fail('ZIP 目录损坏');
      const flags = view.getUint16(pos + 8, true), method = view.getUint16(pos + 10, true);
      const crc = view.getUint32(pos + 16, true), packed = view.getUint32(pos + 20, true), length = view.getUint32(pos + 24, true);
      const nameLength = view.getUint16(pos + 28, true), extra = view.getUint16(pos + 30, true), comment = view.getUint16(pos + 32, true);
      const local = view.getUint32(pos + 42, true), mode = view.getUint32(pos + 38, true) >>> 16;
      if (pos + 46 + nameLength + extra + comment > end || flags & 1 || ![0, 8].includes(method) ||
          (mode & 0xf000) === 0xa000 || view.getUint16(pos + 34, true)) fail('ZIP 不支持加密、符号链接或该压缩方式');
      const originalName = decoder.decode(bytes.subarray(pos + 46, pos + 46 + nameLength)), name = path(originalName);
      pos += 46 + nameLength + extra + comment;
      if (originalName.endsWith('/')) continue;
      if (files.has(name)) fail('ZIP 存在重复文件');
      expanded += length;
      if (expanded > maxFile || length > maxFile) fail('ZIP 解压后总大小最多 2 MB');
      if (local + 30 > offset || view.getUint32(local, true) !== 0x04034b50) fail('ZIP 文件头损坏');
      const localNameLength = view.getUint16(local + 26, true), localExtra = view.getUint16(local + 28, true);
      const start = local + 30 + localNameLength + localExtra;
      if (start + packed > offset || view.getUint16(local + 8, true) !== method ||
          view.getUint16(local + 6, true) !== flags ||
          decoder.decode(bytes.subarray(local + 30, local + 30 + localNameLength)) !== originalName) fail('ZIP 文件边界或名称不一致');
      let output;
      if (method === 0) output = bytes.slice(start, start + packed);
      else {
        if (typeof DecompressionStream === 'undefined') fail('当前浏览器不支持 ZIP 解压，请直接上传 HTML');
        const stream = new Blob([bytes.subarray(start, start + packed)]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        const reader = stream.getReader(), chunks = [];
        let total = 0;
        while (true) {
          const item = await reader.read();
          if (item.done) break;
          total += item.value.length;
          if (total > length || total > maxFile) { await reader.cancel(); fail('ZIP 解压大小超限'); }
          chunks.push(item.value);
        }
        output = new Uint8Array(total);
        let cursor = 0;
        chunks.forEach(chunk => { output.set(chunk, cursor); cursor += chunk.length; });
      }
      if (output.length !== length || crc32(output) !== crc) fail('ZIP 文件校验失败');
      files.set(name, output);
    }
    if (pos !== end || !files.has('index.html')) fail('ZIP 根目录必须包含 index.html');
    return files;
  }
  const mime = name => ({ png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
    webp: 'image/webp', svg: 'image/svg+xml', woff: 'font/woff', woff2: 'font/woff2' })[name.split('.').pop().toLowerCase()];
  function compile(files) {
    const read = name => {
      if (!files.has(name)) fail('缺少本地资源：' + name);
      return decoder.decode(files.get(name));
    };
    const resolve = (url, base = 'index.html') => {
      const raw = url.trim();
      if (/^(data:|#)/i.test(raw)) return raw;
      if (!raw || /[?#]/.test(raw)) fail('资源路径不支持查询参数或片段：' + raw);
      let decoded;
      try { decoded = decodeURIComponent(raw); } catch (e) { fail('资源路径编码无效'); }
      const folder = base.includes('/') ? base.slice(0, base.lastIndexOf('/') + 1) : '';
      return path(folder + decoded);
    };
    const asset = (url, base) => {
      const name = resolve(url, base);
      if (/^(data:|#)/i.test(name)) {
        if (name.length > 2800000) fail('嵌入资源过大');
        return name;
      }
      const type = mime(name), bytes = files.get(name);
      if (!type || !bytes) fail('图片/字体资源不存在或类型不支持：' + name);
      let binary = '';
      for (const byte of bytes) binary += String.fromCharCode(byte);
      return 'data:' + type + ';base64,' + btoa(binary);
    };
    const css = (value, base) => {
      if (/@import/i.test(value)) fail('CSS 不支持 @import，请合并到本地样式');
      return value.replace(/url\(\s*(['"]?)(.*?)\1\s*\)/gi, (_, quote, url) => 'url("' + asset(url, base).replace(/"/g, '%22') + '")');
    };
    const template = document.createElement('template');
    template.innerHTML = read('index.html');
    const root = template.content;
    root.querySelectorAll('base,meta,iframe,frame,frameset,object,embed,form').forEach(el => el.remove());
    for (const el of root.querySelectorAll('script')) {
      if (el.type && !['text/javascript', 'application/javascript'].includes(el.type)) fail('仅支持普通 JavaScript，不支持 ES Module');
      const src = el.getAttribute('src');
      if (src) {
        if (/(^|\/)alinkiot-panel\.js$/.test(src)) { el.remove(); continue; }
        el.textContent = read(resolve(src)).replace(/<\/script/gi, '<\\/script');
        el.removeAttribute('src');
      }
      el.removeAttribute('integrity');
      el.removeAttribute('crossorigin');
    }
    for (const el of root.querySelectorAll('link')) {
      if (el.rel !== 'stylesheet') { el.remove(); continue; }
      const name = resolve(el.getAttribute('href') || ''), style = document.createElement('style');
      style.textContent = css(read(name), name).replace(/<\/style/gi, '<\\/style');
      el.replaceWith(style);
    }
    for (const el of root.querySelectorAll('style')) el.textContent = css(el.textContent, 'index.html');
    for (const el of root.querySelectorAll('*')) {
      if (el.hasAttribute('style')) el.setAttribute('style', css(el.getAttribute('style'), 'index.html'));
      if (el.hasAttribute('srcset')) fail('暂不支持 srcset，请使用本地 src 图片');
      for (const attr of ['src', 'poster']) {
        if (el.hasAttribute(attr) && el.tagName !== 'SCRIPT') el.setAttribute(attr, asset(el.getAttribute(attr), 'index.html'));
      }
      if (el.hasAttribute('href') && !el.getAttribute('href').startsWith('#')) el.removeAttribute('href');
      el.removeAttribute('target');
      el.removeAttribute('action');
      el.removeAttribute('formaction');
    }
    const source = template.innerHTML;
    if (source.length > 2800000) fail('编译后面板超过 2.8 MB，请缩小资源');
    return source;
  }
  return {
    unzip, compile,
    async read(file) {
      if (!file || file.name.length > 160) fail('请选择有效文件');
      const zip = /\.zip$/i.test(file.name);
      if (!zip && !/\.html?$/i.test(file.name)) fail('只支持 HTML 或 ZIP');
      if (file.size > (zip ? 1000000 : 500000)) fail(zip ? 'ZIP 最多 1 MB' : 'HTML 最多 500 KB');
      const buffer = await file.arrayBuffer();
      const files = zip ? await unzip(buffer) : new Map([['index.html', new Uint8Array(buffer)]]);
      return { source: compile(files), filename: file.name };
    }
  };
})();
