const AgentAccess = (() => {
  const key = 'letu-agent-access-v1';
  const catalog = [
    { id: 'demo-diagnosis', name: '故障诊断数字人', description: '设备故障问答与诊断示例' },
    { id: 'demo-analysis', name: '数据分析数字人', description: '指标与趋势分析示例' },
    { id: 'demo-report', name: '报表数字人', description: '按任务要求生成报表示例' }
  ];
  let entries = [], loadError = false;
  const clone = value => JSON.parse(JSON.stringify(value));
  function validate(input) {
    if (!PROJECTS.some(p => p.id === input.project)) throw new Error('请选择有效项目');
    let url;
    try { url = new URL(String(input.url || '').trim()); } catch (e) { throw new Error('请输入有效的平台 URL'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
      throw new Error('URL 须为 HTTP/HTTPS 地址，不含凭证、查询参数或片段');
    }
    if (url.href.length > 500) throw new Error('URL 不能超过 500 字');
    const appid = String(input.appid || '').trim();
    if (!appid || appid.length > 100) throw new Error('AppID 须为 1–100 字');
    return { project: input.project, url: url.href.replace(/\/$/, ''), appid };
  }
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.version !== 1 || !Array.isArray(data.entries) || data.entries.length > PROJECTS.length) throw new Error('无效存档');
      entries = data.entries.map(entry => {
        const config = validate(entry);
        if (typeof entry.loaded !== 'boolean' || typeof entry.selected !== 'string' ||
            (entry.selected && (!entry.loaded || !catalog.some(a => a.id === entry.selected)))) throw new Error('无效数字人');
        const avatars = entry.avatars === undefined ? entry.loaded ? clone(catalog) : [] : entry.avatars;
        if (!Array.isArray(avatars) || avatars.length > 100 ||
            avatars.some(a => !catalog.some(sample => sample.id === a.id)) ||
            new Set(avatars.map(a => a.id)).size !== avatars.length ||
            (entry.selected && !avatars.some(a => a.id === entry.selected))) throw new Error('无效数字人存档');
        return { ...config, loaded: entry.loaded, selected: entry.selected,
          avatars: avatars.map(a => clone(catalog.find(sample => sample.id === a.id))),
          syncedAt: typeof entry.syncedAt === 'string' ? entry.syncedAt : '' };
      });
      if (new Set(entries.map(e => e.project)).size !== entries.length) throw new Error('重复项目');
    }
  } catch (e) { entries = []; loadError = true; }
  const persist = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, entries })); return true; }
    catch (e) { return false; }
  };
  const entry = project => {
    const config = entries.find(e => e.project === project);
    if (!config) throw new Error('请先新增本项目接入配置');
    return config;
  };
  return {
    get loadError() { return loadError; },
    list: () => clone(entries),
    config: project => { const config = entries.find(e => e.project === project); return config ? clone(config) : null; },
    save(input) {
      const config = validate(input), old = entries.find(e => e.project === config.project);
      const unchanged = old && old.url === config.url && old.appid === config.appid;
      const next = { ...config, loaded: true, selected: unchanged ? old.selected : '',
        avatars: unchanged ? old.avatars : clone(catalog),
        syncedAt: unchanged ? old.syncedAt : new Date().toISOString() };
      if (old) entries[entries.indexOf(old)] = next; else entries.push(next);
      return persist();
    },
    loadAvatars(project) {
      const config = entry(project);
      config.loaded = true;
      config.avatars = clone(catalog);
      config.syncedAt = new Date().toISOString();
      if (!config.avatars.some(a => a.id === config.selected)) config.selected = '';
      return persist();
    },
    avatars: project => clone(entries.find(e => e.project === project)?.avatars || []),
    select(project, id) {
      const config = entry(project);
      if (!config.loaded || !config.avatars.some(a => a.id === id)) throw new Error('请选择当前列表中的数字人');
      config.selected = id;
      return persist();
    },
    target(project) {
      const config = entries.find(e => e.project === project);
      if (!config?.loaded || !config.selected) return null;
      return { mode: 'local-demo', project, url: config.url, appid: config.appid,
        avatar: clone(config.avatars.find(a => a.id === config.selected)), callable: false };
    }
  };
})();
