/* ═══════════════════════════════════════════
   乐图智慧 · 页面视图（核心数据域）
   ═══════════════════════════════════════════ */
window.VIEWS = window.VIEWS || {};

const custName = id => (CUSTOMERS.find(c => c.id === id) || {}).name || '—';
const custShort = id => (CUSTOMERS.find(c => c.id === id) || {}).short || '—';
const projName = id => (PROJECTS.find(p => p.id === id) || {}).name || '—';
const projOf = id => PROJECTS.find(p => p.id === id) || {};
const totalDevices = () => PROJECTS.reduce((a, p) => a + p.devices, 0);
const totalOnline = () => PROJECTS.reduce((a, p) => a + p.online, 0);

/* 按采样比例还原全量设备类型分布 */
function typeTotals() {
  const total = totalDevices();
  const sampled = DEVICES.length || 1;
  const out = DEVICE_TYPES.map(t => ({
    key: t.key,
    name: t.name,
    value: Math.round(DEVICES.filter(d => d.type === t.key).length / sampled * total)
  }));
  const diff = total - out.reduce((a, b) => a + b.value, 0);
  out[0].value += diff;
  return out;
}

/* 搜索、下拉与类型按钮共享同一筛选结果，再对结果分页。 */
const TABLES = new WeakMap();
function tableState(scope) {
  if (TABLES.has(scope)) return TABLES.get(scope);
  const rows = [...scope.querySelectorAll('[data-row]')];
  const saved = Workspace.page(CURRENT);
  const filters = new Map();
  const pagerEl = scope.querySelector('.pager');
  const size = Number(pagerEl?.dataset.size) || rows.length || 1;
  let page = Number.isInteger(saved.page) && saved.page > 0 ? saved.page : 1;
  let empty = scope.querySelector('[data-empty]');
  if (!empty && rows.length) {
    empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = '没有匹配的数据，请调整筛选条件';
    rows[0].closest('.table-wrap').appendChild(empty);
  }
  const table = {
    matchingRows() { return rows.filter(r => [...filters.values()].every(test => test(r))); },
    apply() {
      const hits = this.matchingRows();
      page = Math.min(page, Math.max(1, Math.ceil(hits.length / size)));
      const visible = new Set(pagerEl ? hits.slice((page - 1) * size, page * size) : hits);
      rows.forEach(r => { r.style.display = visible.has(r) ? '' : 'none'; });
      if (empty) empty.style.display = hits.length ? 'none' : '';
      if (pagerEl) pagerEl.innerHTML = pager(hits.length, page, size).replace(/^<div[^>]*>|<\/div>$/g, '');
      saved.page = page;
      Workspace.save();
    },
    filter(key, value, test, reset = true) {
      saved[key] = value;
      filters.set(key, test);
      if (reset) page = 1;
      this.apply();
    }
  };
  scope.addEventListener('click', e => {
    const b = e.target.closest('[data-pg]');
    if (!b || b.disabled || !pagerEl?.contains(b)) return;
    page = Number(b.dataset.pg);
    table.apply();
  });
  TABLES.set(scope, table);
  return table;
}
function bindRowFilter(scope) {
  const inp = scope.querySelector('[data-filter]');
  if (!inp) return;
  const table = tableState(scope);
  inp.value = Workspace.page(CURRENT).search || '';
  const apply = reset => {
    const q = inp.value.trim().toLowerCase();
    table.filter('search', inp.value, r => !q || r.textContent.toLowerCase().includes(q), reset);
  };
  inp.addEventListener('input', () => apply(true));
  apply(false);
}
function bindSelectFilter(scope, sel, key) {
  const s = scope.querySelector(sel);
  if (!s) return;
  const saved = Workspace.page(CURRENT)[key];
  if ([...s.options].some(o => o.value === saved)) s.value = saved;
  const table = tableState(scope);
  const apply = reset => {
    const v = s.value;
    table.filter(key, v, r => !v || r.dataset[key] === v, reset);
  };
  s.addEventListener('change', () => apply(true));
  apply(false);
}
function bindProjectScope(scope) {
  const select = scope.querySelector('[data-project-scope]');
  const table = tableState(scope);
  const apply = reset => table.filter('project', Workspace.project,
    r => !Workspace.project || r.dataset.project === Workspace.project, reset);
  select.addEventListener('change', () => {
    Workspace.setProject(select.value);
    apply(true);
  });
  apply(false);
}

/* ═══════════ 工作台 ═══════════ */
VIEWS.dashboard = {
  group: '总览', title: '工作台',
  render() {
    const dev = totalDevices(), on = totalOnline();
    const rate = (on / dev * 100).toFixed(1);
    const hour = new Date().getHours();
    const greet = hour < 6 ? '凌晨好' : hour < 12 ? '上午好' : hour < 18 ? '下午好' : '晚上好';

    const kpis = [
      { label:'接入客户', val:CUSTOMERS.length, unit:'家', ico:'users', trend:'up', delta:'+1 本月', note:'全部正常运营', spark:genSeries(20, 8, 2) },
      { label:'项目总数', val:PROJECTS.length, unit:'个', ico:'folder', trend:'up', delta:'+2 本月', note:'17 个运行中', spark:genSeries(20, 15, 3) },
      { label:'设备总数', val:dev, unit:'台', ico:'cpu', trend:'up', delta:'+128 本周', note:'覆盖 6 类设备', spark:genSeries(20, 3800, 320) },
      { label:'设备在线率', val:rate, unit:'%', ico:'activity', trend:'down', delta:'-0.4pp', note:`离线 ${dev - on} 台`, spark:genSeries(20, 97, 2) }
    ];

    return `<div class="view-in">
      <div class="hero">
        <div class="hero-in">
          <div>
            <h2>${greet}，系统管理员</h2>
            <p>今日数据同步正常 · 有 <b style="color:var(--warn)">2</b> 项异常待处理 · 最近一次同步 00:25:03</p>
          </div>
          <div class="hero-side">
            <div class="metric-inline">
              <div><b>${nf(dev)}</b><span>设备总数</span></div>
              <div><b class="ok">${rate}%</b><span>在线率</span></div>
              <div><b>${nf(4286)}</b><span>今日采集点位</span></div>
            </div>
            <button class="btn btn-primary" data-act="sync-now">${icon('refresh')}立即同步</button>
          </div>
        </div>
      </div>

      <div class="grid g4">
        ${kpis.map(k => `
          <div class="kpi">
            <div class="kpi-top">
              <span class="kpi-label">${k.label}</span>
              <span class="kpi-ico">${icon(k.ico)}</span>
            </div>
            <div class="kpi-val">${k.val}<i>${k.unit}</i></div>
            <div class="kpi-foot">
              <span class="trend ${k.trend}">${k.trend === 'up' ? '▲' : '▼'} ${k.delta}</span>
              <span>${k.note}</span>
            </div>
            <div class="kpi-spark" data-spark='${JSON.stringify(k.spark)}'></div>
          </div>`).join('')}
      </div>

      <div class="grid g-2-1 mt">
        <div class="card">
          <div class="card-head">
            <h3><span class="dot-mark"></span>数据采集趋势</h3>
            <span class="sub">近 24 小时 · 单位：万条</span>
            <div class="ch-right">
              <div class="segmented" data-range>
                <button class="on" data-r="24">24 小时</button>
                <button data-r="7">7 天</button>
                <button data-r="30">30 天</button>
              </div>
            </div>
          </div>
          <div class="card-body"><div class="chart" id="dashTrend" style="height:290px"></div></div>
        </div>

        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>设备类型分布</h3>
            <div class="ch-right"><span class="badge accent plain">6 类</span></div>
          </div>
          <div class="card-body">
            <div class="chart" id="dashDonut" style="height:196px"></div>
            <div id="dashLegend" style="margin-top:14px"></div>
          </div>
        </div>
      </div>

      <div class="grid g-2-1 mt">
        <div class="card">
          <div class="card-head">
            <h3><span class="dot-mark"></span>重点项目运行状态</h3>
            <div class="ch-right"><button class="btn btn-sm btn-ghost" data-go="projects">全部项目${icon('chevron')}</button></div>
          </div>
          <div class="card-body flush">
            <div class="table-wrap">
              <table class="tbl">
                <thead><tr><th>项目</th><th>所属客户</th><th class="num">设备</th><th>在线率</th><th>状态</th></tr></thead>
                <tbody>
                  ${PROJECTS.filter(p => p.status === 'active').slice(0, 6).map(p => {
                    const r = p.devices ? (p.online / p.devices * 100) : 0;
                    return `<tr style="cursor:pointer" data-go="bigscreen">
                      <td><div class="cell-main"><span class="row-ico">${escapeHTML(p.code.slice(3,5))}</span>
                        <div><div class="cname">${escapeHTML(p.name)}</div><div class="csub">${escapeHTML(p.code)}</div></div></div></td>
                      <td style="color:var(--text-2)">${escapeHTML(custShort(p.customer))}</td>
                      <td class="num">${nf(p.devices)}</td>
                      <td><div style="display:flex;align-items:center;gap:8px">
                        <div class="progress" style="width:64px"><i style="width:${r}%"></i></div>
                        <span class="num" style="font-size:11.5px;color:var(--text-2)">${r.toFixed(1)}%</span></div></td>
                      <td>${badge(p.status)}</td>
                    </tr>`;
                  }).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>系统动态</h3>
            <div class="ch-right"><button class="btn btn-sm btn-ghost" data-go="logs">日志${icon('chevron')}</button></div>
          </div>
          <div class="card-body">
            <div class="timeline">
              <div class="tl-item done"><div class="tl-t">实时数据落库完成</div><div class="tl-d">处理 4,286 条记录，耗时 12.4s，无异常</div><div class="tl-time">00:25:03</div></div>
              <div class="tl-item warn"><div class="tl-t">报表自动生成失败</div><div class="tl-d">公式 F-004 除零异常，3 条记录保留原始值</div><div class="tl-time">06:30:00</div></div>
              <div class="tl-item"><div class="tl-t">AI 分析已生成结论</div><div class="tl-d">热网供温异常趋势分析 · 3 条结论</div><div class="tl-time">07:02:18</div></div>
              <div class="tl-item"><div class="tl-t">项目分配变更</div><div class="tl-d">高新区智慧排水 → 子账号 lizq</div><div class="tl-time">昨日 00:18</div></div>
              <div class="tl-item danger"><div class="tl-t">水质异常告警</div><div class="tl-d">进水氨氮 41.2 mg/L，超设计上限 32%</div><div class="tl-time">昨日 22:10</div></div>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    scope.querySelectorAll('[data-spark]').forEach((el, i) => {
      const d = JSON.parse(el.dataset.spark);
      const colors = ['var(--accent)', 'var(--accent-2)', 'var(--accent-3)', 'var(--ok)'];
      Charts.spark(el, d, getComputedStyle(document.documentElement).getPropertyValue(colors[i % 4].slice(4, -1)).trim() || '#3b82f6');
    });

    const drawTrend = (range) => {
      const n = range === '24' ? 24 : range === '7' ? 28 : 30;
      const span = range === '24' ? 86400000 : range === '7' ? 86400000 * 7 : 86400000 * 30;
      const labels = timeLabels(n, span);
      const main = genSeries(n, 42, 12, 0.18);
      const avg = genSeries(n, 38, 5, 0.05);
      Charts.line(document.getElementById('dashTrend'), {
        labels, height: 290, yDec: 0, unit: ' 万条',
        series: [
          { name: '采集量', data: main, color: '#3b82f6' },
          { name: '近 7 日同期', data: avg, color: '#22d3ee', width: 1.6, area: false }
        ],
        lastDot: true
      });
    };
    drawTrend('24');
    scope.querySelectorAll('[data-range] button').forEach(b => {
      b.addEventListener('click', () => {
        scope.querySelectorAll('[data-range] button').forEach(x => x.classList.remove('on'));
        b.classList.add('on');
        drawTrend(b.dataset.r);
      });
    });

    const typeDist = typeTotals().map((t, i) => ({
      name: t.name,
      value: t.value,
      color: ['#3b82f6', '#22d3ee', '#818cf8', '#fbbf24', '#34d399', '#38bdf8'][i]
    }));
    Charts.donut(document.getElementById('dashDonut'), {
      data: typeDist, height: 196, centerLabel: '设备类型', centerValue: typeDist.length + ' 类'
    });
    document.getElementById('dashLegend').innerHTML = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 14px">` +
      typeDist.map(d => `<div style="display:flex;align-items:center;gap:7px;font-size:11.5px">
        <i style="width:7px;height:7px;border-radius:2px;background:${d.color};flex:0 0 auto"></i>
        <span style="color:var(--text-2);flex:1">${d.name}</span>
        <span class="num" style="font-weight:600">${d.value}</span></div>`).join('') + `</div>`;
  }
};

/* ═══════════ 客户管理 ═══════════ */
VIEWS.customers = {
  group: '资产管理', title: '客户管理',
  render() {
    return `<div class="view-in">
      <div class="page-head">
        <div>
          <div class="page-title">客户管理</div>
          <div class="page-desc">客户档案与项目归属 · 本地演示，不创建登录账号或执行权限拦截</div>
        </div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="export">${icon('download')}导出筛选结果 CSV</button>
          <button class="btn btn-primary" data-act="add-customer">${icon('plus')}新增客户</button>
        </div>
      </div>

      <div class="grid g4" style="margin-bottom:16px">
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">客户总数</span><span class="kpi-ico">${icon('users')}</span></div>
          <div class="kpi-val">${CUSTOMERS.length}<i>家</i></div><div class="kpi-foot"><span>本地客户档案</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">正常运营</span><span class="kpi-ico" style="background:var(--ok-soft);color:var(--ok)">${icon('check')}</span></div>
          <div class="kpi-val">${CUSTOMERS.filter(c => c.status === 'active').length}<i>家</i></div><div class="kpi-foot"><span>占比 ${(CUSTOMERS.filter(c=>c.status==='active').length/CUSTOMERS.length*100).toFixed(0)}%</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">覆盖项目</span><span class="kpi-ico">${icon('folder')}</span></div>
          <div class="kpi-val">${PROJECTS.filter(p => p.customer).length}<i>个</i></div><div class="kpi-foot"><span>未分配 ${PROJECTS.filter(p => !p.customer).length} 个项目</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">接入设备</span><span class="kpi-ico">${icon('cpu')}</span></div>
          <div class="kpi-val">${nf(totalDevices())}<i>台</i></div><div class="kpi-foot"><span class="trend down">▼ -0.4pp</span><span>在线率</span></div></div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3><span class="dot-mark"></span>客户列表</h3>
          <div class="ch-right">
            <div class="search-box" style="min-width:220px">
              <span class="ico-s"></span>
              <input type="text" placeholder="搜索客户名称 / 联系人" data-filter/>
            </div>
            <select class="sel" data-status>
              <option value="">全部状态</option><option value="active">正常</option>
              <option value="paused">暂停</option><option value="disabled">停用</option>
            </select>
          </div>
        </div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr>
                <th>客户</th><th>联系人</th><th>联系电话</th><th class="num">项目数</th>
                <th class="num">设备数</th><th>状态</th><th>创建时间</th><th style="text-align:right">操作</th>
              </tr></thead>
              <tbody>
                ${CUSTOMERS.map(c => `<tr data-row data-id="${c.id}" data-status="${c.status}">
                  <td><div class="cell-main">
                    <span class="row-ico ${c.level === 'S' ? 'amber' : c.level === 'A' ? '' : 'teal'}">${escapeHTML(c.short.slice(0,2))}</span>
                    <div><div class="cname">${escapeHTML(c.name)}</div><div class="csub">${c.id} · ${escapeHTML(c.industry)}</div></div>
                  </div></td>
                  <td>${escapeHTML(c.contact)}</td>
                  <td class="num" style="font-family:var(--mono);font-size:11.5px;color:var(--text-2)">${escapeHTML(c.phone)}</td>
                  <td class="num">${c.projects}</td>
                  <td class="num">${nf(c.devices)}</td>
                  <td>${badge(c.status, c.status === 'active' ? '正常' : c.status === 'paused' ? '暂停' : '已停用')}</td>
                  <td style="color:var(--text-3);font-size:11.5px">${c.created}</td>
                  <td><div class="actions">
                    <button class="act-btn" data-act="view-customer" data-id="${c.id}" title="详情">${icon('eye')}</button>
                    <button class="act-btn" data-act="edit-customer" data-id="${c.id}" title="编辑">${icon('edit')}</button>
                    <button class="act-btn ${c.status === 'active' ? 'danger' : ''}" data-act="toggle-customer" data-id="${c.id}" title="${c.status === 'active' ? '停用' : '恢复'}">${icon(c.status === 'active' ? 'pause' : 'play')}</button>
                  </div></td>
                </tr>`).join('')}
              </tbody>
            </table>
            <div data-empty style="display:none" class="empty">
              <div class="empty-ico">${icon('users')}</div><h4>未找到匹配的客户</h4><p>请调整搜索关键字后重试</p>
            </div>
          </div>
        </div>
        ${pager(CUSTOMERS.length, 1, 10)}
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-status]', 'status');
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      const act = b.dataset.act;
      if (act === 'add-customer' || act === 'edit-customer') {
        editCustomer(CUSTOMERS.find(x => x.id === b.dataset.id));
      }
      if (act === 'view-customer') {
        const c = CUSTOMERS.find(x => x.id === b.dataset.id);
        const ps = PROJECTS.filter(p => p.customer === c.id);
        openDrawer('客户详情 · ' + c.short, `
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px">
            <span class="row-ico" style="width:52px;height:52px;border-radius:14px;font-size:15px">${escapeHTML(c.short.slice(0,2))}</span>
            <div><div style="font-size:16px;font-weight:700">${escapeHTML(c.name)}</div>
            <div style="font-size:12px;color:var(--text-3);margin-top:2px">${c.id} · ${escapeHTML(c.industry)} · 等级 ${c.level}</div></div>
            <div style="margin-left:auto">${badge(c.status, c.status==='active'?'正常':c.status==='paused'?'暂停':'已停用')}</div>
          </div>
          <div class="grid g2" style="gap:10px;margin-bottom:20px">
            <div class="card" style="padding:14px"><div style="font-size:11px;color:var(--text-3)">项目数</div><div class="num" style="font-size:22px;font-weight:700">${ps.length}</div></div>
            <div class="card" style="padding:14px"><div style="font-size:11px;color:var(--text-3)">设备数</div><div class="num" style="font-size:22px;font-weight:700">${nf(c.devices)}</div></div>
          </div>
          <div style="font-size:12px;font-weight:600;margin-bottom:10px">基础信息</div>
          <dl class="kv">
            <dt>联系人</dt><dd>${escapeHTML(c.contact)}</dd>
            <dt>联系电话</dt><dd>${escapeHTML(c.phone)}</dd>
            <dt>创建时间</dt><dd>${c.created}</dd>
            <dt>归属项目</dt><dd>本客户名下 ${ps.length} 个，个人访问范围另行授权</dd>
          </dl>
          <div style="font-size:12px;font-weight:600;margin:20px 0 10px">名下项目</div>
          ${ps.map(p => `<div class="list-row" style="padding:10px 0;border-color:var(--line)">
            <span class="row-ico teal" style="width:28px;height:28px;font-size:10px">${escapeHTML(p.code.slice(3,5))}</span>
            <div class="lr-body"><b>${escapeHTML(p.name)}</b><small>${escapeHTML(p.code)} · ${nf(p.devices)} 台设备</small></div>
            ${badge(p.status)}
          </div>`).join('')}`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>`);
      }
      if (act === 'toggle-customer') confirmCustomerStatus(CUSTOMERS.find(c => c.id === b.dataset.id));
      if (act === 'export') {
        const ids = new Set(tableState(scope).matchingRows().map(r => r.dataset.id));
        const rows = CUSTOMERS.filter(c => ids.has(c.id));
        downloadCSV('AlinkIoT-客户清单.csv', [
          ['客户名称', '客户简称', '联系人', '联系电话', '所属行业', '项目数', '设备数', '状态'],
          ...rows.map(c => [c.name, c.short, c.contact, c.phone, c.industry, c.projects, c.devices,
            c.status === 'active' ? '正常' : c.status === 'paused' ? '暂停' : '已停用'])
        ]);
        toast('已导出 ' + rows.length + ' 条本地客户记录', 'info');
      }
    });
  }
};

/* ═══════════ 项目管理 ═══════════ */
VIEWS.projects = {
  group: '资产管理', title: '项目管理',
  render() {
    const active = PROJECTS.filter(p => p.status === 'active').length;
    return `<div class="view-in">
      <div class="page-head">
        <div>
          <div class="page-title">项目管理</div>
          <div class="page-desc">本地项目档案、手工新建与客户归属；API 同步尚未连接服务</div>
        </div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="manual-project">${icon('plus')}手工新建</button>
          <button class="btn btn-primary" data-act="sync-now">${icon('refresh')}查看同步说明</button>
        </div>
      </div>

      <div class="grid g4" style="margin-bottom:16px">
        ${[
          ['项目总数', PROJECTS.length, '个', 'folder', '含 ' + PROJECTS.filter(p => p.status !== 'active').length + ' 个非运行项目'],
          ['运行中', active, '个', 'play', '项目档案状态，不代表设备在线'],
          ['已填写 API ID', PROJECTS.filter(p => p.apiId).length, '个', 'link', '仅本地映射，未校验外部接口'],
          ['待分配客户', PROJECTS.filter(p => !p.customer).length, '个', 'target', '未分配项目仅用于平台管理']
        ].map(([l, v, u, ic, note]) => `<div class="kpi">
          <div class="kpi-top"><span class="kpi-label">${l}</span><span class="kpi-ico">${icon(ic)}</span></div>
          <div class="kpi-val">${v}<i>${u}</i></div>
          <div class="kpi-foot"><span>${note}</span></div></div>`).join('')}
      </div>

      <div class="card">
        <div class="card-head">
          <h3><span class="dot-mark"></span>项目列表</h3>
          <div class="ch-right">
            <div class="search-box" style="min-width:210px"><span class="ico-s"></span>
              <input type="text" placeholder="搜索项目名称 / 编号" data-filter/></div>
            <select class="sel" data-cust>
              <option value="">全部客户</option>
              <option value="unassigned">未分配</option>
              ${CUSTOMERS.map(c => `<option value="${c.id}">${escapeHTML(c.short)}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th>项目</th><th>所属客户</th><th>API 项目 ID</th><th class="num">设备</th>
                <th>在线率</th><th>状态</th><th style="text-align:right">操作</th></tr></thead>
              <tbody>
                ${PROJECTS.map(p => {
                  const r = p.devices ? p.online / p.devices * 100 : 0;
                  return `<tr data-row data-id="${p.id}" data-cust="${p.customer || 'unassigned'}">
                    <td><div class="cell-main"><span class="row-ico">${escapeHTML(p.code.slice(3,5))}</span>
                      <div><div class="cname">${escapeHTML(p.name)}</div><div class="csub">${escapeHTML(p.code)}</div></div></div></td>
                    <td style="color:var(--text-2)">${p.customer ? escapeHTML(custShort(p.customer)) : '未分配'}</td>
                    <td style="font-family:var(--mono);font-size:11px;color:var(--text-3)">${escapeHTML(p.apiId) || '—'}</td>
                    <td class="num">${nf(p.devices)}</td>
                    <td><div style="display:flex;align-items:center;gap:8px">
                      <div class="progress" style="width:56px"><i style="width:${r}%"></i></div>
                      <span class="num" style="font-size:11.5px;color:var(--text-2)">${r.toFixed(1)}%</span></div></td>
                    <td>${badge(p.status, p.status==='active'?'运行中':p.status==='paused'?'已暂停':'已停用')}</td>
                    <td><div class="actions">
                      <button class="act-btn" data-act="view-project" data-id="${p.id}" title="详情">${icon('eye')}</button>
                      <button class="act-btn" data-act="assign" data-id="${p.id}" title="分配给客户">${icon('users')}</button>
                      <button class="act-btn" data-act="edit-project" data-id="${p.id}" title="编辑">${icon('edit')}</button>
                    </div></td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
            <div data-empty style="display:none" class="empty">
              <div class="empty-ico">${icon('folder')}</div><h4>未找到匹配的项目</h4><p>试试更换关键字或客户筛选条件</p></div>
          </div>
        </div>
        ${pager(PROJECTS.length, 1, 10)}
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-cust]', 'cust');
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      const p = PROJECTS.find(x => x.id === b.dataset.id);
      if (b.dataset.act === 'view-project') {
        openDrawer('项目详情 · ' + p.name, `
          <div style="font-size:16px;font-weight:700;margin-bottom:4px">${escapeHTML(p.name)}</div>
          <div style="font-size:12px;color:var(--text-3);margin-bottom:18px">${escapeHTML(p.code)} · ${p.customer ? escapeHTML(custName(p.customer)) : '未分配'}</div>
          <div class="grid g2" style="gap:10px;margin-bottom:20px">
            <div class="card" style="padding:14px"><div style="font-size:11px;color:var(--text-3)">设备总数</div><div class="num" style="font-size:22px;font-weight:700">${nf(p.devices)}</div></div>
            <div class="card" style="padding:14px"><div style="font-size:11px;color:var(--text-3)">在线设备</div><div class="num" style="font-size:22px;font-weight:700;color:var(--ok)">${nf(p.online)}</div></div>
          </div>
          <dl class="kv">
            <dt>项目描述</dt><dd>${escapeHTML(p.desc)}</dd>
            <dt>所属客户</dt><dd>${p.customer ? escapeHTML(custName(p.customer)) : '未分配'}</dd>
            <dt>API 项目 ID</dt><dd style="font-family:var(--mono);font-size:11.5px">${escapeHTML(p.apiId) || '—'}</dd>
            <dt>排序权重</dt><dd>${p.sort}</dd>
            <dt>创建时间</dt><dd>${p.created}</dd>
            <dt>状态</dt><dd>${badge(p.status)}</dd>
          </dl>
          <div style="font-size:12px;font-weight:600;margin:20px 0 10px">关联入口</div>
          <div class="grid g2" style="gap:10px">
            <button class="btn btn-ghost" data-go="bigscreen" data-project="${p.id}">${icon('monitor')}项目大屏</button>
            <button class="btn btn-ghost" data-go="realtime" data-project="${p.id}">${icon('activity')}实时查询</button>
            <button class="btn btn-ghost" data-go="history" data-project="${p.id}">${icon('clock')}历史查询</button>
            <button class="btn btn-ghost" data-go="reports" data-project="${p.id}">${icon('file')}项目报表</button>
          </div>
          <p class="hint">以上入口均携带当前项目范围。</p>`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>
           <button class="btn btn-primary" data-go="bigscreen" data-project="${p.id}">查看项目大屏</button>`);
      }
      if (b.dataset.act === 'assign') {
        assignProject(p);
      }
      if (b.dataset.act === 'edit-project') {
        editProject(p);
      }
      if (b.dataset.act === 'sync-now') toast('未连接 API，本次未提交同步任务；可先维护本地项目映射', 'info');
      if (b.dataset.act === 'manual-project') editProject();
    });
  }
};

/* ═══════════ 设备档案 ═══════════ */
VIEWS.devices = {
  group: '资产管理', title: '设备档案',
  render() {
    const list = DEVICES;
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">设备档案</div>
          <div class="page-desc">设备基础档案与测点映射，由 API 同步任务自动维护</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="export">${icon('download')}导出档案</button>
          <button class="btn btn-primary" data-go="realtime">${icon('activity')}实时数据</button>
        </div>
      </div>

      <div class="grid g6" style="margin-bottom:16px">
        ${DEVICE_TYPES.map((t, i) => {
          const n = typeTotals()[i].value;
          const colors = ['#3b82f6','#22d3ee','#818cf8','#fbbf24','#34d399','#38bdf8'];
          return `<div class="kpi">
            <div class="kpi-top"><span class="kpi-label">${t.name}</span>
              <span class="kpi-ico" style="background:${colors[i]}1f;color:${colors[i]}">${icon('cpu')}</span></div>
            <div class="kpi-val">${n}<i>台</i></div>
            <div class="kpi-foot"><span style="color:var(--text-3)">${t.unit}</span></div>
          </div>`;
        }).join('')}
      </div>

      <div class="card">
        <div class="card-head">
          <h3><span class="dot-mark"></span>设备列表</h3>
          <span class="sub">以下为 ${DEVICES.length} 条本地设备样本，统计卡为全量模拟概览</span>
          <div class="ch-right">
            ${Workspace.projectSelect()}
            <div class="search-box" style="min-width:210px"><span class="ico-s"></span>
              <input type="text" placeholder="搜索设备名称 / 编号" data-filter/></div>
            <select class="sel" data-type><option value="">全部类型</option>
              ${DEVICE_TYPES.map(t => `<option value="${t.key}">${t.name}</option>`).join('')}</select>
          </div>
        </div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th>设备名称</th><th>设备编号</th><th>类型</th><th>型号</th><th>所属项目</th>
                <th>公式</th><th>状态</th><th>产品面板</th></tr></thead>
              <tbody>
                ${list.map(d => `<tr data-row data-type="${d.type}" data-project="${d.project}">
                  <td><div class="cell-main"><span class="row-ico teal">${icon('cpu')}</span>
                    <div><div class="cname">${d.name}</div><div class="csub">${d.unit}</div></div></div></td>
                  <td style="font-family:var(--mono);font-size:11px;color:var(--text-3)">${d.code}</td>
                  <td><span class="tag">${d.typeName}</span></td>
                  <td style="font-family:var(--mono);font-size:11px;color:var(--text-2)">${d.model}</td>
                  <td style="color:var(--text-2);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHTML(projName(d.project))}</td>
                  <td>${d.formula ? '<span class="badge accent">已配置</span>' : '<span class="badge mute">原始值</span>'}</td>
                  <td>${badge(d.status)}</td>
                  <td><button class="btn btn-sm btn-ghost" data-device-product="${d.id}">查看面板</button>
                    <button class="btn btn-sm btn-ghost" data-device-binding="${d.id}">产品 / 定位</button></td>
                </tr>`).join('')}
              </tbody>
            </table>
            <div data-empty style="display:none" class="empty">
              <div class="empty-ico">${icon('cpu')}</div><h4>未找到匹配设备</h4><p>请调整搜索或类型筛选</p></div>
          </div>
        </div>
        ${pager(DEVICES.length, 1, 24)}
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-type]', 'type');
    bindProjectScope(scope);
    scope.addEventListener('click', event => {
      const binding = event.target.closest('[data-device-binding]');
      if (binding) { openDeviceBinding(binding.dataset.deviceBinding); return; }
      const button = event.target.closest('[data-device-product]');
      if (!button) return;
      const device = PanelWorkspace.device(button.dataset.deviceProduct);
      Object.assign(Workspace.page('products'), { selected: device.product, device: device.id, panel: '' });
      Workspace.save();
      go('products');
    });
  }
};

/* ═══════════ 实时查询 ═══════════ */
VIEWS.realtime = {
  group: '数据应用', title: '实时查询',
  render() {
    const list = DEVICES;
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">实时查询</div>
          <div class="page-desc">按设备类型查询全部设备当前值，数据每 30 秒自动刷新</div></div>
        <div class="page-actions">
          <div class="segmented" data-dtype>
            <button class="on" data-t="">全部</button>
            ${DEVICE_TYPES.map(t => `<button data-t="${t.key}">${t.name}</button>`).join('')}
          </div>
        </div>
      </div>

      <div class="grid g4" style="margin-bottom:16px">
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">在线设备</span><span class="kpi-ico" style="background:var(--ok-soft);color:var(--ok)">${icon('activity')}</span></div>
          <div class="kpi-val">${nf(totalOnline())}<i>/ ${nf(totalDevices())}</i></div>
          <div class="kpi-foot"><span class="trend up">▲ 96.8%</span><span>较昨日 +0.3pp</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">离线设备</span><span class="kpi-ico" style="background:var(--danger-soft);color:var(--danger)">${icon('alert')}</span></div>
          <div class="kpi-val">${nf(totalDevices() - totalOnline())}<i>台</i></div>
          <div class="kpi-foot"><span>含 1 个暂停项目</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">刷新间隔</span><span class="kpi-ico">${icon('refresh')}</span></div>
          <div class="kpi-val">30<i>秒</i></div>
          <div class="kpi-foot"><label class="switch" style="margin-right:6px"><input type="checkbox" checked id="autoRefresh"/><i></i></label><span>自动刷新已开启</span></div></div>
        <div class="kpi"><div class="kpi-top"><span class="kpi-label">最近更新</span><span class="kpi-ico">${icon('clock')}</span></div>
          <div class="kpi-val" style="font-size:20px">00:26:0<i>8</i></div>
          <div class="kpi-foot"><span class="dot-live" style="display:inline-block"></span><span>数据通道正常</span></div></div>
      </div>

      <div class="card">
        <div class="card-head">
          <h3><span class="dot-mark"></span>设备当前值</h3>
          <span class="sub">本地设备样本 · 非实时连接</span>
          <div class="ch-right">
            ${Workspace.projectSelect()}
            <div class="search-box" style="min-width:190px"><span class="ico-s"></span>
              <input type="text" placeholder="搜索设备" data-filter/></div>
            <select class="sel" data-status><option value="">全部状态</option>
              <option value="online">在线</option><option value="offline">离线</option></select>
            <button class="btn btn-sm btn-ghost" data-act="refresh">${icon('refresh')}刷新</button>
          </div>
        </div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th>设备名称</th><th>类型</th><th>所属项目</th><th class="num">当前值</th>
                <th>信号</th><th>状态</th><th>更新时间</th><th style="text-align:right">操作</th></tr></thead>
              <tbody>
                ${list.map(d => `<tr data-row data-status="${d.status}" data-type="${d.type}" data-project="${d.project}">
                  <td><div class="cell-main"><span class="row-ico ${d.status==='online'?'green':'rose'}" style="width:28px;height:28px">${icon('cpu')}</span>
                    <div><div class="cname">${d.name}</div><div class="csub">${d.code}</div></div></div></td>
                  <td><span class="tag">${d.typeName}</span></td>
                  <td style="color:var(--text-2);font-size:12px">${escapeHTML(projName(d.project))}</td>
                  <td class="num"><span style="font-size:14px;font-weight:650">${d.value ?? '—'}</span>
                    <span style="font-size:10.5px;color:var(--text-3);margin-left:3px">${d.unit}</span></td>
                  <td><div style="display:flex;align-items:center;gap:6px">
                    <div class="progress" style="width:40px;height:4px"><i style="width:${d.signal}%;background:${d.signal>80?'var(--ok)':d.signal>60?'var(--warn)':'var(--danger)'}"></i></div>
                    <span class="num" style="font-size:10.5px;color:var(--text-3)">${d.signal}%</span></div></td>
                  <td>${badge(d.status)}</td>
                  <td style="font-family:var(--mono);font-size:10.5px;color:var(--text-3)">${d.updated.slice(11)}</td>
                  <td><div class="actions">
                    <button class="act-btn" data-act="history" data-id="${d.id}" title="历史查询">${icon('clock')}</button>
                    <button class="act-btn" data-act="curve" data-id="${d.id}" title="加入曲线">${icon('chart')}</button>
                  </div></td>
                </tr>`).join('')}
              </tbody>
            </table>
            <div data-empty style="display:none" class="empty">
              <div class="empty-ico">${icon('activity')}</div><h4>无匹配设备</h4><p>调整筛选条件后重试</p></div>
          </div>
        </div>
        ${pager(DEVICES.length, 1, 20)}
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-status]', 'status');
    bindProjectScope(scope);
    const table = tableState(scope);
    const savedType = Workspace.page(CURRENT).dtype || '';
    table.filter('dtype', savedType, r => !savedType || r.dataset.type === savedType, false);
    scope.querySelectorAll('[data-dtype] button').forEach(b => {
      b.classList.toggle('on', b.dataset.t === savedType);
      b.addEventListener('click', () => {
        scope.querySelectorAll('[data-dtype] button').forEach(x => x.classList.remove('on'));
        b.classList.add('on');
        const t = b.dataset.t;
        table.filter('dtype', t, r => !t || r.dataset.type === t);
        toast(t ? '已切换至 ' + DEVICE_TYPES.find(x => x.key === t).name : '已显示全部设备', 'info');
      });
    });
    scope.querySelector('[data-act="refresh"]')?.addEventListener('click', () => toast('数据已刷新'));
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (b?.dataset.act === 'history') {
        const device = DEVICES.find(d => d.id === b.dataset.id);
        Workspace.setProject(device.project);
        Object.assign(Workspace.page('history'), { device: device.id, deviceSearch: '', page: 1 });
        Workspace.save();
        go('history');
      }
      if (b?.dataset.act === 'curve') {
        try {
          const device = DEVICES.find(d => d.id === b.dataset.id);
          const saved = PanelWorkspace.addDeviceCurve(device.id);
          Workspace.page('curves').selected = 'curve-default';
          Workspace.page('curves').opened = true;
          Workspace.save();
          go('curves');
          toast(saved ? '已加入基础曲线面板，重复设备属性不会再添加' : '已加入面板，但仅内存生效', saved ? 'ok' : 'warn');
        } catch (e) { toast(e.message, 'warn'); }
      }
    });
  }
};

/* ═══════════ 历史查询 ═══════════ */
VIEWS.history = {
  group: '数据应用', title: '历史查询',
  render() {
    const devs = DEVICES.filter(d => !Workspace.project || d.project === Workspace.project);
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">历史查询</div>
          <div class="page-desc">北京时间 UTC+8 · 固定小时样本：2026-10-01 00:00 至 2026-10-30 00:00 · 非真实采集</div></div>
        <div class="page-actions">
          ${Workspace.projectSelect()}
          <button class="btn btn-ghost" data-act="export">${icon('download')}导出 CSV</button>
        </div>
      </div>

      <div class="grid history-layout">
        <div class="card" style="align-self:start">
          <div class="card-head"><h3><span class="dot-mark"></span>选择设备</h3></div>
          <div class="card-body tight">
            <div class="search-box" style="width:100%;margin-bottom:8px"><span class="ico-s"></span>
              <input type="text" placeholder="搜索设备" id="histSearch"/></div>
            <div style="max-height:520px;overflow:auto" id="histList">
              ${devs.map((d, i) => `<button type="button" class="list-row hist-device" data-dev="${d.id}" style="padding:9px 10px;border-radius:8px;border:0;cursor:pointer;${i===0?'background:var(--accent-soft)':''}">
                <span class="row-ico ${i===0?'':'teal'}" style="width:26px;height:26px">${icon('cpu')}</span>
                <span class="lr-body"><b style="font-size:12px">${d.name}</b><small>${d.code} · ${escapeHTML(projName(d.project))}</small></span>
                ${d.status === 'online' ? '<span class="dot-live"></span>' : ''}
              </button>`).join('')}
              <p id="histEmptyDevices" class="hint" hidden>没有匹配设备，请调整项目或搜索条件</p>
            </div>
          </div>
        </div>

        <div>
          <div class="card" style="margin-bottom:16px">
            <div class="card-head">
              <h3><span class="dot-mark"></span><span id="histTitle">进水口流量计 · 瞬时流量</span></h3>
              <span class="sub" id="histSub"></span>
              <div class="ch-right">
                <div class="segmented" data-hrange>
                  <button data-r="today">样本当天</button>
                  <button class="on" data-r="7">近 7 天</button>
                  <button data-r="30">近 30 天</button>
                  <button data-r="custom">自定义</button>
                </div>
              </div>
            </div>
            <div class="card-body">
              <p class="hint" id="histQueryLabel"></p>
              <div class="chart" id="histChart" style="height:280px"></div>
              <div class="metric-inline" style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line)">
                <div><b id="hMax">—</b><span>最大值</span></div>
                <div><b id="hMin">—</b><span>最小值</span></div>
                <div><b id="hAvg">—</b><span>平均值</span></div>
                <div><b id="hCnt">—</b><span>结果点数</span></div>
                <div><b id="hSamples">—</b><span>原始样本数</span></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head">
              <h3><span class="dot-mark"></span>明细数据</h3>
              <div class="ch-right"><span class="badge accent plain">按时间倒序 · 图表为正序</span></div>
            </div>
            <div class="card-body flush">
              <div class="table-wrap">
                <table class="tbl">
                  <thead><tr><th>采集时间</th><th class="num">原始值</th><th class="num">计算值</th>
                    <th>单位</th><th>计算规则</th><th>样本数</th></tr></thead>
                  <tbody id="histBody"></tbody>
                </table>
                <p id="histEmpty" class="empty" hidden>当前设备和时间范围内没有样本</p>
              </div>
            </div>
            <div id="histPager">${pager(0, 1, 10)}</div>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    const saved = Workspace.page('history');
    const devices = DEVICES.filter(d => !Workspace.project || d.project === Workspace.project);
    let dev = devices.find(d => d.id === saved.device) || devices[0];
    let query = { ...Telemetry.defaults('7'), aggregation: 'raw', range: '7' };
    try {
      if (saved.query && dev) {
        Telemetry.query(dev.id, saved.query.from, saved.query.to, saved.query.aggregation);
        query = { ...saved.query };
      }
    } catch (e) {}
    let rows = [];
    let page = Number.isInteger(saved.page) && saved.page > 0 ? saved.page : 1;
    const size = 10;
    const persist = () => {
      Object.assign(saved, { device: dev?.id || '', page, query });
      Workspace.save();
    };
    const drawTable = () => {
      page = Math.min(page, Math.max(1, Math.ceil(rows.length / size)));
      const sorted = [...rows].reverse();
      scope.querySelector('#histBody').innerHTML = sorted.slice((page - 1) * size, page * size).map(r =>
        `<tr><td>${Telemetry.format(r.time)}</td><td class="num">${r.raw.toFixed(3)}</td>
          <td class="num">${r.value.toFixed(3)}</td><td>${dev.unit}</td>
          <td>${r.formula}</td><td class="num">${r.count}</td></tr>`).join('');
      scope.querySelector('#histEmpty').hidden = rows.length > 0;
      scope.querySelector('#histPager').innerHTML = pager(rows.length, page, size);
      persist();
    };
    const draw = () => {
      rows = dev ? Telemetry.query(dev.id, query.from, query.to, query.aggregation) : [];
      scope.querySelectorAll('[data-dev]').forEach(el => {
        const selected = el.dataset.dev === dev?.id;
        el.style.background = selected ? 'var(--accent-soft)' : '';
        el.setAttribute('aria-pressed', String(selected));
      });
      scope.querySelectorAll('[data-hrange] button').forEach(el => el.classList.toggle('on', el.dataset.r === query.range));
      scope.querySelector('#histTitle').textContent = dev?.name || '未选择设备';
      scope.querySelector('#histSub').textContent = dev ? `${dev.code} · ${dev.model} · ${projName(dev.project)}` : '';
      scope.querySelector('#histQueryLabel').textContent = `${query.from.replace('T', ' ')} 至 ${query.to.replace('T', ' ')}（含端点，北京时间） · ${query.aggregation === 'day' ? '按日均值，首尾可能为不完整日' : '原始小时样本'}`;
      const stats = Telemetry.stats(rows);
      for (const [id, value] of Object.entries({
        hMax: stats?.max.toFixed(3), hMin: stats?.min.toFixed(3), hAvg: stats?.average.toFixed(3),
        hCnt: stats ? nf(stats.count) : '0', hSamples: stats ? nf(stats.samples) : '0'
      })) scope.querySelector('#' + id).textContent = value ?? '—';
      const chart = scope.querySelector('#histChart');
      Charts.remove(chart);
      if (rows.length) {
        Charts.line(chart, {
          labels: rows.map(r => Telemetry.format(r.time).slice(5, 16)), height: 280, yDec: 3,
          unit: ' ' + dev.unit, dots: rows.length < 40, lastDot: true,
          series: [{ name: dev.name, data: rows.map(r => r.value), color: '#3b82f6' }]
        });
      } else {
        chart.innerHTML = '<div class="empty">当前范围没有模拟样本</div>';
      }
      scope.querySelector('[data-act="export"]').disabled = !dev;
      drawTable();
    };
    scope.querySelector('[data-project-scope]').addEventListener('change', event => {
      Workspace.setProject(event.target.value);
      saved.deviceSearch = '';
      saved.page = 1;
      go('history');
    });
    scope.querySelectorAll('[data-dev]').forEach(el => el.addEventListener('click', () => {
      dev = devices.find(d => d.id === el.dataset.dev);
      page = 1;
      draw();
    }));
    scope.querySelectorAll('[data-hrange] button').forEach(button => button.addEventListener('click', () => {
      if (button.dataset.r !== 'custom') {
        query = { ...Telemetry.defaults(button.dataset.r), aggregation: 'raw', range: button.dataset.r };
        page = 1;
        draw();
        return;
      }
      openModal('自定义时间范围（北京时间）', `
        <form id="historyQueryForm">
          <div class="form-row">
            <div class="form-field"><label>开始时间 <span class="req">*</span></label>
              <input class="inp" name="from" type="datetime-local" required value="${escapeHTML(query.from)}"/></div>
            <div class="form-field"><label>结束时间 <span class="req">*</span></label>
              <input class="inp" name="to" type="datetime-local" required value="${escapeHTML(query.to)}"/></div>
          </div>
          <div class="form-field"><label>聚合粒度</label><select class="sel" name="aggregation">
            <option value="raw">原始小时样本</option><option value="day" ${query.aggregation === 'day' ? 'selected' : ''}>按日均值</option>
          </select></div>
          <p class="hint">单次最多 90 天；仅固定样本期间有数据，不会补造分钟采样。统计基于查询结果点，不声明真实完整率。</p>
          <p data-history-error role="alert" hidden style="color:var(--danger)"></p>
        </form>`, `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
          <button class="btn btn-primary" type="submit" form="historyQueryForm">查询</button>`);
      const form = document.getElementById('historyQueryForm');
      form.addEventListener('submit', event => {
        event.preventDefault();
        try {
          const next = { ...Object.fromEntries(new FormData(form)), range: 'custom' };
          if (!dev) throw new Error('当前项目没有设备');
          Telemetry.query(dev.id, next.from, next.to, next.aggregation);
          query = next;
          page = 1;
          closeModal();
          draw();
        } catch (e) {
          const error = form.querySelector('[data-history-error]');
          error.hidden = false;
          error.textContent = e.message;
        }
      });
    }));
    scope.querySelector('#histPager').addEventListener('click', event => {
      const button = event.target.closest('[data-pg]');
      if (!button || button.disabled) return;
      page = Number(button.dataset.pg);
      drawTable();
    });
    const search = scope.querySelector('#histSearch');
    search.value = typeof saved.deviceSearch === 'string' ? saved.deviceSearch : '';
    const filterDevices = () => {
      const q = search.value.trim().toLowerCase();
      let matches = 0;
      scope.querySelectorAll('[data-dev]').forEach(el => {
        const hit = el.textContent.toLowerCase().includes(q);
        el.style.display = hit ? '' : 'none';
        matches += hit ? 1 : 0;
      });
      scope.querySelector('#histEmptyDevices').hidden = matches > 0;
      saved.deviceSearch = search.value;
      Workspace.save();
    };
    search.addEventListener('input', filterDevices);
    scope.querySelector('[data-act="export"]').addEventListener('click', () => {
      if (!dev) return;
      downloadCSV('AlinkIoT-' + dev.code + '-历史数据.csv', [
        ['设备编号', '设备名称', '项目', '北京时间 UTC+8', '原始值', '计算值', '单位', '计算规则', '样本数', '聚合粒度'],
        ...[...rows].reverse().map(r => [dev.code, dev.name, projName(dev.project), Telemetry.format(r.time),
          r.raw.toFixed(3), r.value.toFixed(3), dev.unit, r.formula, r.count, query.aggregation === 'day' ? '日均值' : '原始小时'])
      ]);
      toast('已导出当前查询的 ' + rows.length + ' 条本地结果（全部分页）', 'info');
    });
    filterDevices();
    draw();
    scope._cleanup = () => Charts.remove(scope.querySelector('#histChart'));
  }
};
