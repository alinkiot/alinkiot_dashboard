const PanelHost = (() => {
  function mount(container, options) {
    const { kind, owner, panelId, deviceId } = options;
    const item = PanelWorkspace.panel(panelId);
    if (!item?.html) throw new Error('面板没有上传内容');
    const ids = () => PanelWorkspace.contextDevices(kind, owner, panelId, deviceId);
    ids();
    const frame = document.createElement('iframe');
    frame.title = item.name + ' · 隔离面板';
    frame.setAttribute('sandbox', 'allow-scripts');
    frame.setAttribute('referrerpolicy', 'no-referrer');
    frame.setAttribute('allow', "camera 'none'; microphone 'none'; geolocation 'none'; clipboard-read 'none'; clipboard-write 'none'");
    frame.className = 'custom-panel-frame';
    const policy = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'; media-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none';";
    frame.srcdoc = '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="' + policy +
      '"><script>' + window.AlinkIoTPanelSDKSource.replace(/<\/script/gi, '<\\/script') + '</script></head><body>' + item.html.source + '</body></html>';
    let port, active = true, loaded = false, calls = 0, reset = Date.now();
    const snapshot = () => ids().map(id => PanelWorkspace.device(id));
    const unsubscribe = PanelWorkspace.subscribe(() => {
      if (active && port) {
        try { port.postMessage({ type: 'state', devices: snapshot() }); } catch (e) {}
      }
    });
    frame.addEventListener('load', () => {
      if (!active) return;
      if (loaded) {
        active = false;
        port?.close();
        unsubscribe();
        frame.remove();
        const notice = document.createElement('p');
        notice.textContent = '面板发生页面跳转，已关闭 SDK 通道。请重新打开面板。';
        container.append(notice);
        return;
      }
      loaded = true;
      const channel = new MessageChannel();
      port = channel.port1;
      port.onmessage = ({ data }) => {
        if (!active || !data || typeof data.id !== 'string' || data.id.length > 40) return;
        try {
          if (Date.now() - reset > 1000) { calls = 0; reset = Date.now(); }
          if (++calls > 30) throw new Error('SDK 请求过于频繁');
          const allowed = ids(), args = data.args || {};
          if (data.method !== 'devices' && !allowed.includes(args.device)) throw new Error('设备不在当前面板关联范围');
          let result;
          if (data.method === 'devices') result = snapshot();
          else if (data.method === 'state') result = PanelWorkspace.device(args.device);
          else if (data.method === 'history') {
            if (kind === 'curve' && !PanelWorkspace.panel(panelId).series.some(s => s.device === args.device && s.property === args.property)) throw new Error('属性不在曲线配置范围');
            result = PanelWorkspace.history(args.device, args.property, args.from, args.to);
          } else if (data.method === 'control') {
            if (!options.allowControl()) throw new Error('请先在宿主页面允许本次模拟控制');
            result = PanelWorkspace.control(args.device, args.property, args.value);
            options.onControl?.(args, result);
          } else throw new Error('不支持的 SDK 方法');
          port.postMessage({ id: data.id, result });
        } catch (e) { port.postMessage({ id: data.id, error: e.message }); }
      };
      port.start();
      frame.contentWindow.postMessage({ type: 'alinkiot:init' }, '*', [channel.port2]);
      port.postMessage({ type: 'ready', context: { version: 1, mode: 'local-demo', kind, owner, panelId,
        deviceIds: ids(), timezone: 'Asia/Shanghai' } });
    });
    container.append(frame);
    return () => { active = false; unsubscribe(); port?.close(); frame.remove(); };
  }
  return { mount };
})();
