function finishReportChange(saved, message) {
  go('reports');
  toast(saved ? message + '（本地演示）' : message + '，但存储失败，刷新将丢失', saved ? 'ok' : 'warn');
}

function openReportEditor(template) {
  openModal(template ? '编辑报表模板' : '新建报表模板', `
    <form id="reportForm">
      <div class="form-field"><label>模板名称 <span class="req">*</span></label>
        <input class="inp" name="name" required maxlength="80" value="${escapeHTML(template?.name || '')}"/></div>
      <div class="form-field"><label>统计字段（固定顺序）</label>
        ${Object.entries(Reports.fields).map(([field, label]) => `<label class="check-line">
          <input type="checkbox" name="fields" value="${field}" ${!template || template.fields.includes(field) ? 'checked' : ''}/><i></i>${label}</label>`).join('')}</div>
      <div class="form-field"><label>小数位</label><select class="sel" name="decimals">
        ${[0, 1, 2, 3].map(n => `<option value="${n}" ${n === (template?.decimals ?? 2) ? 'selected' : ''}>${n} 位</option>`).join('')}</select></div>
      <p class="hint">模板可复用于任意项目。设备名称、编号、指标与单位固定保留；不同单位不汇总。不支持跨指标推算或数据完整率。</p>
      <p data-report-error role="alert" hidden style="color:var(--danger)"></p>
    </form>`, '<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" type="submit" form="reportForm">保存模板</button>');
  const form = document.getElementById('reportForm');
  form.addEventListener('submit', event => {
    event.preventDefault();
    try {
      const saved = Reports.put(template?.id, { name: form.elements.name.value,
        fields: [...form.querySelectorAll('[name="fields"]:checked')].map(input => input.value),
        decimals: Number(form.elements.decimals.value) });
      Object.assign(Workspace.page('reports'), {
        template: Reports.list().find(t => t.name === form.elements.name.value.trim()).id, page: 1
      });
      Workspace.save();
      finishReportChange(saved, '模板已保存');
    } catch (e) {
      const error = form.querySelector('[data-report-error]');
      error.textContent = e.message;
      error.hidden = false;
    }
  });
}

VIEWS.reports = (() => {
  let preview;
  return {
    group: '数据应用', title: '报表中心',
    render() {
      const templates = Reports.list(), state = Workspace.page('reports');
      const selected = templates.find(t => t.id === state.template) || templates[0];
      let from = state.from, to = state.to;
      try {
        const begin = Telemetry.parse(from), end = Telemetry.parse(to);
        if (begin > end || end - begin > 90 * 86400000) throw new Error();
      } catch (e) { ({ from, to } = Telemetry.defaults('7')); }
      const project = Workspace.project || PROJECTS[0]?.id;
      preview = selected && project ? Reports.generate(selected.id, project, from, to) : null;
      return `<div class="view-in">
        <div class="page-head"><div><div class="page-title">报表中心</div>
          <div class="page-desc">本浏览器模板 · 固定小时历史样本 · 非自动调度或服务端报表</div></div>
          <div class="page-actions"><button class="btn btn-primary" data-report-act="add">${icon('plus')}新建模板</button></div></div>
        <p class="hint">样本窗口：2026-10-01 00:00 至 2026-10-30 00:00（UTC+8），含首尾端点。统计使用与历史查询相同的计算值。离线为当前设备快照，不代表历史缺失。权限页身份尚未作用于本模块。</p>
        ${Reports.loadError ? '<p class="hint" style="color:var(--warn)">模板存档无法读取，使用初始模板。</p>' : ''}
        <div class="card"><div class="card-body">
          ${templates.length && project ? `<form id="reportQuery" style="display:flex;flex-wrap:wrap;gap:12px;align-items:end">
            <label style="min-width:0;max-width:100%">报表模板<select class="sel" name="template" aria-label="报表模板" style="display:block;max-width:100%">
              ${templates.map(t => `<option value="${t.id}" ${selected.id === t.id ? 'selected' : ''}>${escapeHTML(t.name)}</option>`).join('')}</select></label>
            <label style="min-width:0;max-width:100%">项目<select class="sel" name="project" aria-label="报表项目" style="display:block;max-width:100%">
              ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></label>
            <label>开始（北京时间）<input class="inp" name="from" type="datetime-local" value="${from}" required style="display:block;width:220px;max-width:100%"/></label>
            <label>结束（北京时间）<input class="inp" name="to" type="datetime-local" value="${to}" required style="display:block;width:220px;max-width:100%"/></label>
            <button class="btn btn-primary" type="submit">生成预览</button>
            <button class="btn btn-ghost" type="button" data-report-act="range">近7天样本</button>
          </form><p data-report-query-error role="alert" hidden style="color:var(--danger)"></p>` :
          '<div class="empty"><h4>暂无可用模板或项目</h4><p>请新建模板或项目后生成报表</p></div>'}
        </div></div>
        ${preview ? `<div class="card" style="margin-top:16px"><div class="card-head" style="flex-wrap:wrap;gap:10px">
          <h3 style="overflow-wrap:anywhere;min-width:0">${escapeHTML(preview.template.name)}</h3>
          <div class="ch-right" style="flex-wrap:wrap">
            <button class="btn btn-sm btn-ghost" data-report-act="edit">编辑当前模板</button>
            <button class="btn btn-sm btn-ghost" data-report-act="delete">删除模板</button>
            <button class="btn btn-sm btn-primary" data-report-act="csv" ${preview.rows.length ? '' : 'disabled'}>${icon('download')}下载 CSV</button></div></div>
          <div class="card-body"><p class="hint" style="overflow-wrap:anywhere">预览：${escapeHTML(preview.project.name)} · ${from.replace('T', ' ')} — ${to.replace('T', ' ')}（UTC+8）。未提交的筛选不会改变预览或下载。</p>
            <div data-report-results></div>
            <p class="hint">每台设备统计各自的小时样本；不合计不同指标/单位。无样本显示“—”，样本数为 0；不伪造完整率、累计流量、生成耗时或成功次数。CSV 包含全部设备，不限当前页。</p>
          </div></div>` : ''}
      </div>`;
    },
    mount(scope) {
      const report = preview, state = Workspace.page('reports');
      let page = Number.isInteger(state.page) && state.page > 0 ? state.page : 1;
      const paint = () => {
        if (!report) return;
        const pages = Math.max(1, Math.ceil(report.rows.length / 10));
        page = Math.min(page, pages);
        scope.querySelector('[data-report-results]').innerHTML = report.rows.length ? `
          <div class="table-wrap"><table class="tbl"><thead><tr><th>设备名称</th><th>编号</th><th>指标</th><th>单位</th>
            ${report.template.fields.map(f => `<th class="num">${Reports.fields[f]}</th>`).join('')}</tr></thead><tbody>
            ${report.rows.slice((page - 1) * 10, page * 10).map(row => `<tr><td>${escapeHTML(row.name)}</td><td>${escapeHTML(row.code)}</td>
              <td>${escapeHTML(row.metric)}</td><td>${escapeHTML(row.unit)}</td>
              ${report.template.fields.map(f => `<td class="num">${Reports.value(report, row, f)}</td>`).join('')}</tr>`).join('')}
            </tbody></table></div>
          <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:12px">
            <span class="hint">共 ${report.rows.length} 台设备 · 第 ${page} / ${pages} 页</span>
            <button class="btn btn-sm btn-ghost" data-report-page="-1" ${page === 1 ? 'disabled' : ''}>上一页</button>
            <button class="btn btn-sm btn-ghost" data-report-page="1" ${page === pages ? 'disabled' : ''}>下一页</button></div>` :
          '<div class="empty"><h4>该项目暂无设备</h4><p>不生成虚构报表数据</p></div>';
      };
      paint();
      const form = scope.querySelector('#reportQuery');
      const apply = () => {
        try {
          Reports.generate(form.elements.template.value, form.elements.project.value, form.elements.from.value, form.elements.to.value);
          Object.assign(state, { template: form.elements.template.value, from: form.elements.from.value, to: form.elements.to.value, page: 1 });
          Workspace.setProject(form.elements.project.value);
          go('reports');
        } catch (e) {
          const error = scope.querySelector('[data-report-query-error]');
          error.textContent = e.message;
          error.hidden = false;
        }
      };
      form?.addEventListener('submit', event => { event.preventDefault(); apply(); });
      scope.addEventListener('click', event => {
        const pager = event.target.closest('[data-report-page]');
        if (pager) {
          page += Number(pager.dataset.reportPage);
          paint();
          state.page = page;
          Workspace.save();
          return;
        }
        const button = event.target.closest('[data-report-act]');
        if (!button) return;
        const act = button.dataset.reportAct;
        if (act === 'add') openReportEditor();
        if (act === 'edit') openReportEditor(report.template);
        if (act === 'range') {
          const time = Telemetry.defaults('7');
          form.elements.from.value = time.from;
          form.elements.to.value = time.to;
          apply();
        }
        if (act === 'csv' && report.rows.length) {
          downloadCSV('AlinkIoT-report-' + report.project.id + '.csv', Reports.csv(report));
          toast('已下载当前预览的全部设备统计（CSV）', 'ok');
        }
        if (act === 'delete') {
          openModal('删除报表模板', `<p style="overflow-wrap:anywhere">${escapeHTML(report.template.name)}</p><p class="hint">仅删除本地模板，不删除项目或遥测数据。</p>`,
            '<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" data-confirm-report-delete>确认删除</button>');
          document.querySelector('[data-confirm-report-delete]').addEventListener('click', () =>
            finishReportChange(Reports.remove(report.template.id), '模板已删除'));
        }
      });
    }
  };
})();
