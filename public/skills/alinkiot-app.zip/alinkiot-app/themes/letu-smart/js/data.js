/* ═══════════════════════════════════════════
   乐图智慧 · 模拟数据层
   ═══════════════════════════════════════════ */

let _seed = 20261029;
function rnd(){ _seed = (_seed * 9301 + 49297) % 233280; return _seed / 233280; }
function pick(a){ return a[Math.floor(rnd() * a.length)]; }
function ri(a, b){ return Math.floor(a + rnd() * (b - a + 1)); }
function rf(a, b, d = 2){ return +(a + rnd() * (b - a)).toFixed(d); }

/* ─── 客户 ─── */
const CUSTOMERS = [
  { id:'C001', name:'华东智慧水务集团', short:'华东水务', contact:'陈志远', phone:'138-0021-4478', projects:3, devices:642, status:'active', created:'2024-03-12', level:'A', industry:'水务' },
  { id:'C002', name:'滨江环境科技股份', short:'滨江环境', contact:'李婉宁', phone:'139-2288-0163', projects:2, devices:418, status:'active', created:'2024-05-28', level:'A', industry:'环保' },
  { id:'C003', name:'中鑫能源集团', short:'中鑫能源', contact:'王海涛', phone:'137-6612-9034', projects:4, devices:936, status:'active', created:'2024-01-09', level:'S', industry:'能源' },
  { id:'C004', name:'南方热力有限公司', short:'南方热力', contact:'周敏', phone:'136-5501-7720', projects:2, devices:287, status:'active', created:'2024-08-16', level:'B', industry:'供热' },
  { id:'C005', name:'西岭市政工程处', short:'西岭市政', contact:'赵国强', phone:'135-8890-2245', projects:1, devices:154, status:'paused', created:'2024-11-02', level:'B', industry:'市政' },
  { id:'C006', name:'蓝湾新城运营公司', short:'蓝湾新城', contact:'孙晓雅', phone:'188-2245-6611', projects:2, devices:321, status:'active', created:'2025-02-19', level:'A', industry:'园区' },
  { id:'C007', name:'东方精工制造', short:'东方精工', contact:'刘建平', phone:'150-3388-4412', projects:1, devices:96, status:'active', created:'2025-04-07', level:'C', industry:'制造' },
  { id:'C008', name:'恒源供水服务中心', short:'恒源供水', contact:'吴静', phone:'186-6620-1178', projects:2, devices:263, status:'active', created:'2025-06-23', level:'B', industry:'水务' },
  { id:'C009', name:'嘉禾生态农业园', short:'嘉禾生态', contact:'郑立', phone:'133-9911-5520', projects:1, devices:72, status:'disabled', created:'2025-08-11', level:'C', industry:'农业' },
  { id:'C010', name:'北岸能源服务中心', short:'北岸能源', contact:'黄伟', phone:'189-2277-3301', projects:1, devices:118, status:'active', created:'2025-10-15', level:'B', industry:'能源' }
];

/* ─── 项目 ─── */
const PROJECTS = [
  { id:'P1001', code:'LT-WS-2024-001', name:'滨江污水处理厂二期', customer:'C001', desc:'日处理能力 12 万吨，含预处理、生化、深度处理三段工艺', devices:286, online:281, status:'active', sort:100, apiId:'API-P-88213', created:'2024-03-20' },
  { id:'P1002', code:'LT-WS-2024-002', name:'城东供水调度中心', customer:'C001', desc:'覆盖 6 座加压泵站与 42 公里主干管网', devices:214, online:209, status:'active', sort:98, apiId:'API-P-88214', created:'2024-04-02' },
  { id:'P1003', code:'LT-WS-2025-003', name:'高新区智慧排水', customer:'C001', desc:'区域内 18 个易涝点在线监测与预警', devices:142, online:136, status:'active', sort:96, apiId:'API-P-90112', created:'2025-01-15' },
  { id:'P2001', code:'LT-EN-2024-001', name:'北岸污水资源化工程', customer:'C002', desc:'再生水回用规模 5 万吨/日', devices:238, online:231, status:'active', sort:95, apiId:'API-P-88420', created:'2024-06-01' },
  { id:'P2002', code:'LT-EN-2025-002', name:'临港工业废水站', customer:'C002', desc:'工业废水专项处理，含重金属在线监测', devices:180, online:172, status:'active', sort:93, apiId:'API-P-90341', created:'2025-03-08' },
  { id:'P3001', code:'LT-NY-2024-001', name:'中鑫热电机组监测', customer:'C003', desc:'2×350MW 机组全参数在线监测', devices:412, online:406, status:'active', sort:92, apiId:'API-P-87001', created:'2024-01-18' },
  { id:'P3002', code:'LT-NY-2024-002', name:'西区供热管网', customer:'C003', desc:'86 座换热站、214 公里热网', devices:324, online:311, status:'active', sort:90, apiId:'API-P-87002', created:'2024-02-22' },
  { id:'P3003', code:'LT-NY-2025-003', name:'光伏电站集控', customer:'C003', desc:'装机 120MW，含组串级监测', devices:128, online:126, status:'active', sort:88, apiId:'API-P-91005', created:'2025-05-11' },
  { id:'P3004', code:'LT-NY-2025-004', name:'储能调峰站', customer:'C003', desc:'50MWh 磷酸铁锂储能系统', devices:72, online:70, status:'active', sort:86, apiId:'API-P-91006', created:'2025-07-30' },
  { id:'P4001', code:'LT-HR-2024-001', name:'南城集中供热一期', customer:'C004', desc:'供热面积 480 万平米', devices:196, online:189, status:'active', sort:84, apiId:'API-P-88610', created:'2024-09-05' },
  { id:'P4002', code:'LT-HR-2025-002', name:'老城区管网改造监测', customer:'C004', desc:'改造段 32 公里，重点监测泄漏', devices:91, online:84, status:'active', sort:82, apiId:'API-P-91440', created:'2025-04-18' },
  { id:'P5001', code:'LT-SZ-2024-001', name:'西岭新区综合管廊', customer:'C005', desc:'管廊 8.6 公里，含环境与结构监测', devices:154, online:0, status:'paused', sort:80, apiId:'API-P-88790', created:'2024-11-10' },
  { id:'P6001', code:'LT-YQ-2025-001', name:'蓝湾新城智慧园区', customer:'C006', desc:'园区能耗、环境、安防一体化', devices:208, online:203, status:'active', sort:78, apiId:'API-P-91880', created:'2025-02-25' },
  { id:'P6002', code:'LT-YQ-2025-002', name:'蓝湾商业综合体', customer:'C006', desc:'冷站群控与分项计量', devices:113, online:108, status:'active', sort:76, apiId:'API-P-91881', created:'2025-06-14' },
  { id:'P7001', code:'LT-ZZ-2025-001', name:'东方精工产线能耗', customer:'C007', desc:'三条产线重点设备能耗监测', devices:96, online:94, status:'active', sort:74, apiId:'API-P-92210', created:'2025-04-12' },
  { id:'P8001', code:'LT-WS-2025-004', name:'恒源供水二厂', customer:'C008', desc:'供水能力 8 万吨/日', devices:171, online:167, status:'active', sort:72, apiId:'API-P-92500', created:'2025-06-30' },
  { id:'P8002', code:'LT-WS-2025-005', name:'恒源加压泵站群', customer:'C008', desc:'11 座泵站远程监控', devices:92, online:88, status:'active', sort:70, apiId:'API-P-92501', created:'2025-08-02' },
  { id:'P9001', code:'LT-NY-2025-005', name:'嘉禾生态灌溉', customer:'C009', desc:'智能灌溉与土壤墒情监测', devices:72, online:0, status:'disabled', sort:68, apiId:'API-P-92990', created:'2025-08-15' },
  { id:'P10001', code:'LT-NY-2025-006', name:'北岸能源计量改造', customer:'C010', desc:'区域能源计量与结算', devices:118, online:114, status:'active', sort:66, apiId:'API-P-93310', created:'2025-10-20' }
];

/* ─── 设备类型 ─── */
const DEVICE_TYPES = [
  { key:'flow',  name:'流量计',     unit:'m³/h', model:['LDG-DN200','LDG-DN300','UFM-100'],  range:[120, 980] },
  { key:'level', name:'液位计',     unit:'m',    model:['ULM-20','RDR-80','ULM-35'],        range:[0.4, 6.8] },
  { key:'press', name:'压力变送器', unit:'MPa',  model:['PTX-790','PTX-500','PTX-1200'],    range:[0.12, 1.6] },
  { key:'water', name:'水质分析仪', unit:'mg/L', model:['WQA-900','WQA-600','NH3N-200'],    range:[0.2, 42] },
  { key:'temp',  name:'温度传感器', unit:'℃',    model:['TSP-200','TSP-400'],               range:[8, 96] },
  { key:'power', name:'智能电表',   unit:'kWh',  model:['DTSD-341','DSSD-110'],             range:[1200, 9800] }
];

const DEV_PREFIX = ['1#','2#','3#','4#','5#','6#','7#','8#','9#','10#','11#','12#'];
const DEV_PLACE  = ['进水口','出水口','一级泵房','二级泵房','加药间','沉淀池','滤池','清水池','配电室','换热站','主管网','支线'];

/* ─── 设备生成 ─── */
const DEVICES = [];
(function buildDevices(){
  let seq = 1;
  PROJECTS.forEach(p => {
    const count = Math.min(p.devices, 26);
    for (let i = 0; i < count; i++) {
      const t = DEVICE_TYPES[ri(0, DEVICE_TYPES.length - 1)];
      const online = p.status === 'active' && rnd() > 0.055;
      DEVICES.push({
        id: 'D' + String(seq).padStart(5, '0'),
        name: pick(DEV_PLACE) + t.name,
        code: 'LT-' + t.key.toUpperCase() + '-' + String(10000 + seq),
        type: t.key,
        typeName: t.name,
        model: pick(t.model),
        unit: t.unit,
        project: p.id,
        customer: p.customer,
        status: online ? 'online' : 'offline',
        value: online ? rf(t.range[0], t.range[1], t.range[1] < 10 ? 2 : 1) : null,
        raw: online ? rf(t.range[0], t.range[1], 2) : null,
        updated: online ? `2026-10-30 00:${String(ri(10, 25)).padStart(2,'0')}:${String(ri(10,59)).padStart(2,'0')}` : '2026-10-29 18:42:07',
        signal: online ? ri(72, 99) : 0,
        formula: rnd() > 0.55
      });
      seq++;
    }
  });
})();

/* ─── 历史数据生成 ─── */
function genSeries(n, base, amp, noise = 0.12, trend = 0){
  const out = [];
  let v = base;
  for (let i = 0; i < n; i++) {
    v = base + Math.sin(i / n * Math.PI * 2.6) * amp * 0.55 + Math.sin(i / n * Math.PI * 7.2) * amp * 0.22
      + (rnd() - 0.5) * amp * noise * 2 + trend * i;
    out.push(+v.toFixed(2));
  }
  return out;
}
function timeLabels(n, span){
  const now = new Date('2026-10-30T00:26:00');
  const out = [];
  const stepMs = span / (n - 1);
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * stepMs);
    out.push(span <= 86400000 * 2
      ? `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
      : `${d.getMonth()+1}/${d.getDate()}`);
  }
  return out;
}

/* ─── 同步任务 ─── */
const SYNC_TASKS = [
  { id:'T1', name:'项目基础信息同步', cron:'0 */30 * * * ?', desc:'从第三方 API 拉取项目列表，按 API 项目 ID upsert', status:'running', last:'2026-10-30 00:00:12', next:'2026-10-30 00:30:00', result:'success', cost:'4.2s', rows:19, scope:'全量' },
  { id:'T2', name:'设备档案同步',     cron:'0 */15 * * * ?', desc:'同步设备基础档案与测点映射关系', status:'running', last:'2026-10-30 00:15:08', next:'2026-10-30 00:30:00', result:'success', cost:'8.7s', rows:4286, scope:'增量' },
  { id:'T3', name:'实时数据落库',     cron:'0 */5 * * * ?',  desc:'拉取设备实时值，经公式计算后写入本地库', status:'running', last:'2026-10-30 00:25:03', next:'2026-10-30 00:30:00', result:'success', cost:'12.4s', rows:4286, scope:'增量' },
  { id:'T4', name:'历史数据补采',     cron:'0 0 2 * * ?',    desc:'每日凌晨补采前一日历史数据并去重入库', status:'running', last:'2026-10-30 02:00:00', next:'2026-10-31 02:00:00', result:'success', cost:'184s', rows:614400, scope:'全量' },
  { id:'T5', name:'设备在线状态巡检', cron:'0 */10 * * * ?', desc:'刷新设备在线状态与信号强度', status:'paused', last:'2026-10-29 22:40:02', next:'—', result:'success', cost:'2.1s', rows:4286, scope:'增量' },
  { id:'T6', name:'报表自动生成',     cron:'0 30 6 * * ?',   desc:'按默认模板生成各项目日报', status:'running', last:'2026-10-30 06:30:00', next:'2026-10-31 06:30:00', result:'failed', cost:'31.6s', rows:19, scope:'按项目' }
];

const SYNC_LOGS = Array.from({ length: 14 }, (_, i) => {
  const t = SYNC_TASKS[i % 6];
  const ok = i !== 3 && i !== 9;
  return {
    time: `2026-10-30 ${String(23 - Math.floor(i / 2)).padStart(2,'0')}:${String(ri(10,59)).padStart(2,'0')}:${String(ri(10,59)).padStart(2,'0')}`,
    task: t.name,
    status: ok ? 'success' : 'failed',
    rows: ok ? ri(1200, 4286) : 0,
    cost: (rf(1.2, 24, 1)) + 's',
    msg: ok ? '同步完成，无异常' : (i === 3 ? '第三方 API 返回 429 限流，已进入重试队列（第 2 次）' : '公式 F-004 除零异常，3 条记录保留原始值并标记未计算')
  };
});

/* ─── 公式 ─── */
const FORMULAS = [
  { id:'F-001', name:'瞬时流量标况换算', target:'流量计 / LDG-DN200', expr:'Q_n = Q_w × (P × 293.15) / (0.101325 × (273.15 + T))', unit:'Nm³/h', priority:1, status:'active', version:'v3', updated:'2026-09-18', dec:2 },
  { id:'F-002', name:'液位高度温度补偿', target:'液位计 / ULM-20', expr:'H_c = H_raw × (1 + 0.0002 × (T - 20))', unit:'m', priority:2, status:'active', version:'v2', updated:'2026-08-04', dec:3 },
  { id:'F-003', name:'压力零点漂移修正', target:'压力变送器 / PTX-790', expr:'P_c = P_raw - 0.0086 × days_since_calib', unit:'MPa', priority:3, status:'active', version:'v1', updated:'2026-07-22', dec:3 },
  { id:'F-004', name:'氨氮浓度折算',     target:'水质分析仪 / WQA-900', expr:'NH3N = (A450 - blank) × 1.42 / sample_vol', unit:'mg/L', priority:4, status:'active', version:'v4', updated:'2026-10-11', dec:2 },
  { id:'F-005', name:'累计流量日增量',   target:'流量计 / 通用', expr:'Q_day = Q_total_today - Q_total_yesterday', unit:'m³', priority:5, status:'active', version:'v2', updated:'2026-06-30', dec:1 },
  { id:'F-006', name:'电表需量计算',     target:'智能电表 / DTSD-341', expr:'D_max = max(P_15min) × 4', unit:'kW', priority:6, status:'paused', version:'v1', updated:'2026-05-14', dec:1 },
  { id:'F-007', name:'温度传感器线性校准', target:'温度传感器 / TSP-200', expr:'T_c = T_raw × 1.0021 + 0.34', unit:'℃', priority:7, status:'draft', version:'v1', updated:'2026-10-28', dec:2 }
];

/* ─── 报表模板 ─── */
const REPORT_TPL = [
  { id:'R-01', name:'污水处理运行日报', project:'滨江污水处理厂二期', fields:12, scope:'全设备', freq:'每日 06:30', status:'active', updated:'2026-10-12' },
  { id:'R-02', name:'供水管网压力月报', project:'城东供水调度中心', fields:8, scope:'压力变送器', freq:'每月 1 日', status:'active', updated:'2026-09-28' },
  { id:'R-03', name:'换热站能耗周报',   project:'西区供热管网', fields:15, scope:'智能电表 + 温度', freq:'每周一 08:00', status:'active', updated:'2026-10-05' },
  { id:'R-04', name:'光伏组串发电日报', project:'光伏电站集控', fields:10, scope:'全部组串', freq:'每日 07:00', status:'active', updated:'2026-10-20' },
  { id:'R-05', name:'水质达标分析表',   project:'临港工业废水站', fields:18, scope:'水质分析仪', freq:'每日 09:00', status:'paused', updated:'2026-08-16' }
];

/* ─── 操作日志 ─── */
const LOGS = [
  { time:'2026-10-30 00:24:51', user:'系统管理员', role:'超管', module:'同步任务', action:'手动执行', target:'实时数据落库', detail:'手动触发同步任务，处理 4,286 条记录，耗时 12.4s', ip:'10.20.3.11', level:'info' },
  { time:'2026-10-30 00:18:07', user:'陈志远', role:'客户管理员', module:'项目管理', action:'分配项目', target:'高新区智慧排水 → 子账号 lizq', detail:'将项目分配给子账号李清泉', ip:'58.246.88.12', level:'info' },
  { time:'2026-10-29 23:41:33', user:'系统管理员', role:'超管', module:'公式配置', action:'修改公式', target:'F-004 氨氮浓度折算', detail:'版本 v3 → v4，调整系数 1.38 → 1.42，历史数据不重算', ip:'10.20.3.11', level:'warn' },
  { time:'2026-10-29 22:56:12', user:'李婉宁', role:'客户管理员', module:'大屏配置', action:'更新配置', target:'北岸污水资源化工程 大屏', detail:'新增 6 台水质分析仪，移除 2 台离线设备', ip:'116.228.4.90', level:'info' },
  { time:'2026-10-29 21:30:45', user:'系统管理员', role:'超管', module:'客户管理', action:'停用账号', target:'嘉禾生态农业园', detail:'停用客户账号，数据保留可恢复', ip:'10.20.3.11', level:'warn' },
  { time:'2026-10-29 20:12:08', user:'王海涛', role:'客户管理员', module:'数据导出', action:'导出数据', target:'中鑫热电机组监测 历史数据', detail:'导出 CSV，时间范围 2026-10-01 ~ 2026-10-29，共 86,400 行', ip:'202.101.7.55', level:'info' },
  { time:'2026-10-29 18:04:22', user:'lizq', role:'子账号', module:'实时查询', action:'查询', target:'滨江污水处理厂二期', detail:'按设备类型「流量计」查询当前值', ip:'58.246.88.31', level:'info' },
  { time:'2026-10-29 17:22:39', user:'系统管理员', role:'超管', module:'角色权限', action:'修改权限', target:'客户管理员', detail:'开放「报表模板编辑」菜单权限', ip:'10.20.3.11', level:'warn' },
  { time:'2026-10-29 16:48:15', user:'周敏', role:'客户管理员', module:'登录', action:'登录', target:'—', detail:'账号密码登录成功，IP 归属地：杭州', ip:'36.24.118.77', level:'info' },
  { time:'2026-10-29 15:33:51', user:'未知账号', role:'—', module:'登录', action:'登录失败', target:'—', detail:'连续 3 次密码错误，账号临时锁定 10 分钟', ip:'45.132.9.204', level:'danger' },
  { time:'2026-10-29 14:10:26', user:'系统管理员', role:'超管', module:'项目管理', action:'编辑项目', target:'储能调峰站', detail:'修改 API 项目映射关系', ip:'10.20.3.11', level:'info' },
  { time:'2026-10-29 11:05:44', user:'孙晓雅', role:'客户管理员', module:'曲线管理', action:'新建曲线', target:'蓝湾新城智慧园区', detail:'创建 4 条曲线：冷站供回水温度、瞬时流量', ip:'121.40.66.18', level:'info' }
];

/* ─── AI 分析任务 ─── */
const AI_TASKS = [
  { id:'A-01', name:'热网供温异常趋势分析', target:'西区供热管网 · 12 台温度传感器', freq:'每日 07:00', status:'active', last:'2026-10-30 07:00', next:'2026-10-31 07:00', result:'已生成 3 条结论', level:'warn' },
  { id:'A-02', name:'污水厂进水水质突变识别', target:'滨江污水处理厂二期 · 水质分析仪', freq:'每 6 小时', status:'active', last:'2026-10-30 00:00', next:'2026-10-30 06:00', result:'已生成 1 条结论', level:'danger' },
  { id:'A-03', name:'泵站能耗对比分析', target:'城东供水调度中心 · 智能电表', freq:'每周一 08:00', status:'active', last:'2026-10-28 08:00', next:'2026-11-04 08:00', result:'已生成 5 条结论', level:'ok' },
  { id:'A-04', name:'光伏组串发电效率衰减', target:'光伏电站集控 · 全部组串', freq:'每日 06:00', status:'paused', last:'2026-10-25 06:00', next:'—', result:'已生成 2 条结论', level:'ok' }
];

const AI_RESULTS = [
  {
    id:'AR-20261030-01', task:'热网供温异常趋势分析', time:'2026-10-30 07:02:18', project:'西区供热管网', level:'danger',
    summary:'检测到 3 号换热站二次侧供温连续 6 小时低于目标值 4.2~6.8℃，且回温同步下降，判断为换热器结垢导致的换热效率衰减，而非热源侧供给不足。',
    metrics:[{k:'平均供温',v:'58.4 ℃',s:'目标 62 ℃'},{k:'偏差幅度',v:'-5.8 %',s:'超阈值 2.8pp'},{k:'持续时长',v:'6.2 h',s:'近 7 天累计 19h'},{k:'置信度',v:'91 %',s:'高'}],
    points:['3 号换热站二次侧供温 01:00 起持续下探，最低 55.1℃','同站一次侧流量稳定，排除热源波动因素','回温差由 18.2℃ 收窄至 12.6℃，换热效率下降明显','相邻 4 号站运行正常，为单站问题'],
    suggest:['安排 3 号换热站换热器化学清洗，预计恢复效率 8~11%','清洗前临时提高一次侧流量 5% 以维持末端温度','将该站纳入周度结垢趋势跟踪清单']
  },
  {
    id:'AR-20261030-02', task:'污水厂进水水质突变识别', time:'2026-10-30 00:03:41', project:'滨江污水处理厂二期', level:'warn',
    summary:'进水氨氮在 22:10—23:40 区间由 18.6 mg/L 骤升至 41.2 mg/L，超出设计进水上限 32%，同期 COD 上升 46%，疑似上游工业废水偷排。',
    metrics:[{k:'氨氮峰值',v:'41.2 mg/L',s:'设计上限 31.0'},{k:'持续时长',v:'1.5 h',s:'已回落'},{k:'COD 增幅',v:'+46 %',s:'同步异常'},{k:'置信度',v:'87 %',s:'较高'}],
    points:['22:10 起氨氮斜率突变，1 小时内上升 122%','COD 与氨氮同向变化，排除仪表故障','23:40 后逐步回落至 21.4 mg/L','出水氨氮未超标，生化系统缓冲有效'],
    suggest:['调取上游 3 个监测点同期数据定位排放源','提前投加碳源并降低进水负荷 15%','向环保主管部门报送异常事件记录']
  },
  {
    id:'AR-20261028-03', task:'泵站能耗对比分析', time:'2026-10-28 08:04:52', project:'城东供水调度中心', level:'ok',
    summary:'6 座加压泵站单位电耗环比下降 4.3%，主要来自 2 号泵站变频改造后的调度优化；1 号泵站因夜间小流量工况偏离高效区，仍有 6~8% 节能空间。',
    metrics:[{k:'单位电耗',v:'0.412 kWh/m³',s:'环比 -4.3%'},{k:'最优泵站',v:'2 号站',s:'0.381 kWh/m³'},{k:'待优化',v:'1 号站',s:'0.447 kWh/m³'},{k:'置信度',v:'94 %',s:'高'}],
    points:['2 号站变频改造后日均电耗下降 8.6%','1 号站 23:00—05:00 长期处于 38% 低负荷区','4 号站与 5 号站存在 2 台泵同时低频运行的低效组合','整体电耗下降未影响末端压力合格率（99.2%）'],
    suggest:['将 1 号站夜间切换为小泵单机运行','4/5 号站合并调度，减少同时低频运行','按当前优化节奏，年化可节约电费约 18.6 万元']
  }
];

const AI_REPORTS = [
  { id:'AB-01', name:'10 月运营月报智能解读', reports:'污水处理运行日报 × 4', tpl:'运营月报模板', time:'2026-10-30 06:40', status:'done', level:'warn',
    summary:'10 月整体处理量 362.4 万吨，环比 +3.2%；吨水电耗 0.318 kWh/m³，环比 -1.8%。主要异常为 10 月 14—16 日进水氨氮连续超标，导致出水总氮短时逼近限值。',
    points:['处理量环比 +3.2%，产能利用率 91.4%','吨水电耗连续 3 个月下降，累计 -6.1%','10/14—10/16 进水氨氮超标 3 次，出水总氮最高 14.2 mg/L','药剂单耗环比 +7.4%，与进水水质波动正相关'] },
  { id:'AB-02', name:'供热周报对比分析', reports:'换热站能耗周报 × 3', tpl:'能耗对比模板', time:'2026-10-28 08:20', status:'done', level:'ok',
    summary:'本周供热量 8,942 GJ，环比 -2.1%（气温回升）。单位面积热耗 0.284 GJ/㎡，低于同期均值 5.6%，节能效果稳定。',
    points:['供热量环比 -2.1%，与度日数变化一致','单位面积热耗优于同期均值 5.6%','3 号站热耗偏高 11.2%，需关注结垢','补水率 1.24%，处于合理区间'] },
  { id:'AB-03', name:'光伏发电日报解读', reports:'光伏组串发电日报 × 7', tpl:'发电效率模板', time:'2026-10-30 07:12', status:'done', level:'danger',
    summary:'10 月 29 日发电量 486.2 MWh，等效利用小时 4.05h，低于近 30 日均值 8.4%。逆变器 7# 组串电流离散度达 21%，判定存在组串失配或遮挡。',
    points:['发电量较近 30 日均值低 8.4%','7# 逆变器 3 号组串电流偏低 19%','14:00 后整体功率曲线出现异常塌陷','组件温度正常，排除高温降额'] }
];

/* ─── 通知 ─── */
const NOTICES = [
  { t:'同步任务失败', d:'报表自动生成任务执行失败，公式 F-004 除零异常', time:'6 分钟前', level:'danger' },
  { t:'水质异常告警', d:'滨江污水处理厂二期 进水氨氮 41.2 mg/L 超阈值', time:'2 小时前', level:'warn' },
  { t:'AI 分析完成', d:'热网供温异常趋势分析已生成 3 条结论', time:'8 小时前', level:'info' },
  { t:'客户账号停用', d:'嘉禾生态农业园 已停用，数据保留', time:'1 天前', level:'mute' }
];
