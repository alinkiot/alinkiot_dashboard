const PanelWorkspace = (() => {
  const key = 'letu-panels-v1', clone = value => JSON.parse(JSON.stringify(value));
  const validId = id => typeof id === 'string' && /^[a-z0-9-]+$/i.test(id);
  const text = (value, label, max = 80) => {
    if (typeof value !== 'string' || !value.trim() || value.trim().length > max || /[\u0000-\u001f]/.test(value)) throw new Error(label + '格式不正确');
    return value.trim();
  };
  const seedProducts = DEVICE_TYPES.map(t => ({
    id: 'product-' + t.key, name: t.name, type: t.key, description: t.name + '示例物模型',
    properties: [
      { key: 'value', name: Curves.metrics[t.key], type: 'number', unit: t.unit, writable: false, source: 'telemetry' },
      { key: 'signal', name: '信号强度', type: 'number', unit: '%', writable: false, source: 'signal' },
      { key: 'running', name: '模拟运行开关', type: 'boolean', unit: '', writable: true, source: 'custom' }
    ]
  }));
  const seedCurves = Curves.list().map(c => ({ device: c.device, property: 'value', name: c.name }));
  let state = { products: seedProducts, bindings: {}, locations: {}, values: {}, scenes: [],
    panels: [{ id: 'curve-default', kind: 'curve', owner: '', name: '基础曲线面板', series: seedCurves, html: null }] };
  let loadError = false;
  const productFor = (device, data = state) =>
    data.products.find(p => p.id === (data.bindings[device.id] || 'product-' + device.type));
  const properties = input => {
    if (!Array.isArray(input) || !input.length || input.length > 20) throw new Error('产品须包含 1–20 个属性');
    const seen = new Set();
    return input.map(p => {
      if (!p || typeof p.key !== 'string' || !/^[a-z][a-z0-9_]{0,31}$/.test(p.key) ||
          ['constructor', 'prototype', '__proto__'].includes(p.key) || seen.has(p.key)) throw new Error('属性标识须唯一，使用小写字母开头的字母、数字、下划线');
      seen.add(p.key);
      if (!['number', 'boolean', 'string'].includes(p.type) || typeof p.writable !== 'boolean' ||
          !['custom', 'telemetry', 'signal'].includes(p.source)) throw new Error('属性类型或来源无效');
      if (p.source !== 'custom' && (p.writable || p.type !== 'number')) throw new Error('历史测点和信号仅支持只读数值');
      const unit = typeof p.unit === 'string' ? p.unit.trim() : '';
      if (unit.length > 20 || /[\u0000-\u001f]/.test(unit)) throw new Error('单位格式不正确');
      return { key: p.key, name: text(p.name, '属性名称', 40), type: p.type, unit, writable: p.writable, source: p.source };
    });
  };
  const productFields = (input, all, except) => {
    const name = text(input.name, '产品名称');
    if (all.some(p => p.id !== except && p.name === name)) throw new Error('产品名称已存在');
    const type = DEVICE_TYPES.find(t => t.key === input.type);
    if (!type) throw new Error('请选择设备类型');
    const props = properties(input.properties);
    if (props.some(p => p.source === 'telemetry' && p.unit !== type.unit)) throw new Error('历史测点单位须与设备类型一致，不做隐式换算');
    if (props.filter(p => p.source === 'telemetry').length > 1 || props.filter(p => p.source === 'signal').length > 1) throw new Error('示例历史测点和信号各只能映射一个属性');
    const description = String(input.description || '').trim();
    if (description.length > 300) throw new Error('产品描述最多 300 字');
    return { name, type: type.key, description, properties: props };
  };
  const deviceIds = (ids, project) => {
    if (!Array.isArray(ids) || ids.length > 100 || new Set(ids).size !== ids.length ||
        ids.some(id => !DEVICES.some(d => d.id === id && (!project || d.project === project)))) throw new Error('设备须存在、不可重复且必须属于所选项目，最多 100 台');
    return [...ids];
  };
  const seriesFields = (series, data = state) => {
    if (!Array.isArray(series) || series.length > 12) throw new Error('每个曲线面板最多 12 条系列');
    const seen = new Set();
    return series.map(s => {
      const d = DEVICES.find(d => d.id === s.device), p = d && productFor(d, data)?.properties.find(p => p.key === s.property);
      if (!p || p.type !== 'number') throw new Error('请选择有效设备的数值属性');
      const key = s.device + ':' + s.property;
      if (seen.has(key)) throw new Error('设备属性不可重复');
      seen.add(key);
      return { device: d.id, property: p.key, name: text(s.name, '系列名称') };
    });
  };
  const htmlValue = value => {
    if (value === null) return null;
    if (!value || typeof value.source !== 'string' || value.source.length > 2800000 ||
        typeof value.filename !== 'string' || value.filename.length > 160) throw new Error('上传面板格式或大小无效');
    return { source: value.source, filename: value.filename };
  };
  const sceneFields = input => {
    if (!PROJECTS.some(p => p.id === input.project)) throw new Error('请选择有效项目');
    return { name: text(input.name, '场景名称'), project: input.project, devices: deviceIds(input.devices, input.project) };
  };
  const panelFields = (input, data = state) => {
    if (!['product', 'scene', 'curve', 'screen'].includes(input.kind)) throw new Error('面板类型无效');
    const ownerValid = input.kind === 'curve' ? input.owner === '' : input.kind === 'product' ?
      data.products.some(p => p.id === input.owner) : input.kind === 'scene' ?
        data.scenes.some(s => s.id === input.owner) : PROJECTS.some(p => p.id === input.owner);
    if (!ownerValid) throw new Error('面板所属对象不存在');
    return { kind: input.kind, owner: input.owner, name: text(input.name, '面板名称'),
      series: input.kind === 'curve' ? seriesFields(input.series, data) : [], html: htmlValue(input.html) };
  };
  const record = value => value && typeof value === 'object' && !Array.isArray(value);
  const locationFields = input => {
    if (input === null) return null;
    if (!input || !Number.isFinite(input.lat) || Math.abs(input.lat) > 90 || !Number.isFinite(input.lng) || Math.abs(input.lng) > 180) throw new Error('经纬度无效');
    return { lat: input.lat, lng: input.lng };
  };
  const typed = (p, value) => (p.type === 'number' && typeof value === 'number' && Number.isFinite(value)) ||
    (p.type === 'boolean' && typeof value === 'boolean') || (p.type === 'string' && typeof value === 'string' && value.length <= 200);
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const saved = JSON.parse(raw);
      if (saved.version !== 1 || !record(saved.data)) throw new Error('无效存档');
      const data = saved.data;
      if (!Array.isArray(data.products) || data.products.length > 40 || !Array.isArray(data.scenes) ||
          data.scenes.length > 100 || !Array.isArray(data.panels) || data.panels.length > 200 + PROJECTS.length ||
          !record(data.bindings) || !record(data.locations) || !record(data.values)) throw new Error('无效存档');
      const loaded = { products: [], scenes: [], panels: [], bindings: {}, locations: {}, values: {} };
      for (const p of data.products) {
        if (!p || !validId(p.id) || loaded.products.some(x => x.id === p.id)) throw new Error('无效产品');
        loaded.products.push({ id: p.id, ...productFields(p, loaded.products, p.id) });
      }
      if (seedProducts.some(p => !loaded.products.some(x => x.id === p.id && x.type === p.type))) throw new Error('缺少内置类型');
      for (const [id, product] of Object.entries(data.bindings)) {
        const d = DEVICES.find(d => d.id === id), p = loaded.products.find(p => p.id === product);
        if (!d || !p || p.type !== d.type) throw new Error('无效产品绑定');
        loaded.bindings[id] = product;
      }
      for (const [id, value] of Object.entries(data.locations)) {
        if (!DEVICES.some(d => d.id === id)) throw new Error('无效定位');
        loaded.locations[id] = locationFields(value);
      }
      for (const s of data.scenes) {
        if (!s || !validId(s.id) || loaded.scenes.some(x => x.id === s.id)) throw new Error('无效场景');
        loaded.scenes.push({ id: s.id, ...sceneFields(s) });
      }
      for (const p of data.panels) {
        if (!p || !validId(p.id) || loaded.panels.some(x => x.id === p.id)) throw new Error('无效面板');
        if (p.id.startsWith('screen-') && (p.kind !== 'screen' || p.id !== 'screen-' + p.owner)) throw new Error('无效基础大屏');
        loaded.panels.push({ id: p.id, ...panelFields(p, loaded) });
      }
      for (const [id, values] of Object.entries(data.values)) {
        const d = DEVICES.find(d => d.id === id);
        if (!d || !record(values)) throw new Error('无效模拟状态');
        const accepted = {};
        for (const [key, value] of Object.entries(values)) {
          const p = productFor(d, loaded).properties.find(p => p.key === key && p.source === 'custom' && p.writable);
          if (!p || !typed(p, value)) throw new Error('无效模拟状态');
          accepted[key] = value;
        }
        loaded.values[id] = accepted;
      }
      state = loaded;
    }
  } catch (e) { loadError = true; }
  const save = () => {
    try {
      const raw = JSON.stringify({ version: 1, data: state });
      if (raw.length > 4000000) throw new Error('存档过大');
      localStorage.setItem(key, raw);
      return true;
    } catch (e) { return false; }
  };
  const changed = new Set();
  const notify = () => changed.forEach(fn => { try { fn(); } catch (e) {} });
  const commit = () => { const saved = save(); notify(); return saved; };
  const panel = id => state.panels.find(p => p.id === id);
  return {
    loadError,
    products: () => clone(state.products),
    product: id => clone(state.products.find(p => p.id === id) || null),
    productFor: id => { const d = DEVICES.find(d => d.id === id); return d ? clone(productFor(d)) : null; },
    syncProduct(id, input) {
      const old = state.products.find(p => p.id === id);
      if (id && !old) throw new Error('产品不存在');
      const value = productFields(input, state.products, id);
      if (old) {
        if (old.type !== value.type && (old.id.startsWith('product-') || DEVICES.some(d => productFor(d).id === id))) throw new Error('已绑定设备或内置产品不可修改类型');
        const used = state.panels.flatMap(p => p.series).filter(s => this.productFor(s.device)?.id === id);
        if (used.some(s => {
          const before = old.properties.find(p => p.key === s.property), after = value.properties.find(p => p.key === s.property);
          return !after || ['type', 'unit', 'source'].some(k => before[k] !== after[k]);
        })) throw new Error('属性正在曲线中使用，请先移除相关系列再修改其类型、单位、来源或删除');
        Object.assign(old, value);
        DEVICES.filter(d => productFor(d).id === id).forEach(d => {
          if (!state.values[d.id]) return;
          state.values[d.id] = Object.fromEntries(Object.entries(state.values[d.id]).filter(([key, value]) => {
            const p = old.properties.find(p => p.key === key && p.source === 'custom' && p.writable);
            return p && typed(p, value);
          }));
        });
      } else {
        if (state.products.length >= 40) throw new Error('最多保存 40 个产品');
        state.products.push({ id: crypto.randomUUID(), ...value });
      }
      return commit();
    },
    removeProduct(id) {
      if (!state.products.some(p => p.id === id)) throw new Error('产品不存在');
      if (id.startsWith('product-') || DEVICES.some(d => productFor(d).id === id)) throw new Error('内置产品或已绑定设备的产品不可删除');
      state.products = state.products.filter(p => p.id !== id);
      state.panels = state.panels.filter(p => !(p.kind === 'product' && p.owner === id));
      return commit();
    },
    bindDevice(id, productId, location) {
      const d = DEVICES.find(d => d.id === id), p = state.products.find(p => p.id === productId);
      if (!d || !p || p.type !== d.type) throw new Error('产品类型须匹配设备类型');
      const coords = locationFields(location);
      if (productFor(d).id !== productId && state.panels.some(p => p.series.some(s => s.device === id))) throw new Error('设备正在曲线中使用，请先移除相关系列再更换产品');
      if (productFor(d).id !== productId) delete state.values[id];
      state.bindings[id] = productId;
      state.locations[id] = coords;
      return commit();
    },
    scenes: project => clone(state.scenes.filter(s => !project || s.project === project)),
    saveScene(id, input) {
      const old = state.scenes.find(s => s.id === id);
      if (id && !old) throw new Error('场景不存在');
      const value = sceneFields(input);
      if (state.scenes.some(s => s.id !== id && s.project === value.project && s.name === value.name)) throw new Error('同项目场景名称已存在');
      if (old && old.project !== value.project) throw new Error('场景创建后不可改项目');
      if (old) Object.assign(old, value);
      else {
        if (state.scenes.length >= 100) throw new Error('最多保存 100 个场景');
        state.scenes.push({ id: crypto.randomUUID(), ...value });
      }
      return commit();
    },
    removeScene(id) {
      if (!state.scenes.some(s => s.id === id)) throw new Error('场景不存在');
      state.scenes = state.scenes.filter(s => s.id !== id);
      state.panels = state.panels.filter(p => !(p.kind === 'scene' && p.owner === id));
      return commit();
    },
    panels: (kind, owner = '') => clone(state.panels.filter(p => p.kind === kind && p.owner === owner)),
    panel: id => clone(panel(id) || null),
    savePanel(id, input) {
      const old = panel(id);
      if (id && !old) throw new Error('面板不存在');
      const value = panelFields(input);
      if (state.panels.some(p => p.id !== id && p.kind === value.kind && p.owner === value.owner && p.name === value.name)) throw new Error('同范围面板名称已存在');
      if (old && (old.kind !== value.kind || old.owner !== value.owner)) throw new Error('不可改变面板归属');
      if (old) Object.assign(old, value);
      else {
        if (state.panels.filter(p => p.id !== 'screen-' + p.owner).length >= 200) throw new Error('最多保存 200 个自建面板');
        state.panels.push({ id: crypto.randomUUID(), ...value });
      }
      return commit();
    },
    removePanel(id) {
      if (!panel(id)) throw new Error('面板不存在');
      state.panels = state.panels.filter(p => p.id !== id);
      return commit();
    },
    ensureScreen(project) {
      if (!PROJECTS.some(p => p.id === project)) throw new Error('项目不存在');
      const id = 'screen-' + project;
      if (!panel(id)) state.panels.push({ id, kind: 'screen', owner: project, name: '基础项目大屏', series: [], html: null });
      return id;
    },
    addDeviceCurve(device) {
      const d = DEVICES.find(d => d.id === device), prop = d && productFor(d).properties.find(p => p.source === 'telemetry');
      if (!prop) throw new Error('设备没有历史数值属性');
      let target = panel('curve-default');
      if (!target) {
        target = { id: 'curve-default', kind: 'curve', owner: '', name: '基础曲线面板', series: [], html: null };
        state.panels.push(target);
      }
      if (!target.series.some(s => s.device === device && s.property === prop.key)) {
        target.series = seriesFields([...target.series, { device, property: prop.key, name: d.name }]);
      }
      return commit();
    },
    device(id) {
      const d = DEVICES.find(d => d.id === id);
      if (!d) throw new Error('设备不存在');
      const product = productFor(d), values = {};
      product.properties.forEach(p => {
        values[p.key] = p.source === 'telemetry' ? d.value : p.source === 'signal' ? d.signal : state.values[id]?.[p.key] ?? null;
      });
      return { id: d.id, name: d.name, code: d.code, project: d.project, product: product.id,
        status: d.status, updated: d.updated, location: clone(state.locations[id] || null), properties: clone(product.properties), values };
    },
    control(id, property, value) {
      const d = DEVICES.find(d => d.id === id), p = d && productFor(d).properties.find(p => p.key === property);
      if (!p || !p.writable || p.source !== 'custom') throw new Error('属性不可控制');
      if (d.status !== 'online') throw new Error('设备离线，不能模拟控制');
      if (!typed(p, value)) throw new Error('控制值类型不正确或超长');
      if (!state.values[id]) state.values[id] = {};
      state.values[id][property] = value;
      return { simulated: true, persisted: commit(), device: this.device(id) };
    },
    history(id, property, from, to) {
      const d = DEVICES.find(d => d.id === id), p = d && productFor(d).properties.find(p => p.key === property);
      if (!p || p.type !== 'number') throw new Error('无效数值属性');
      const start = Telemetry.parse(from), end = Telemetry.parse(to);
      if (start > end || end - start > 90 * 86400000) throw new Error('时间范围须有序且最多 90 天');
      if (p.source !== 'telemetry') return [];
      return Telemetry.query(id, from, to).map(r => ({ time: r.time, value: r.value }));
    },
    contextDevices(kind, owner, panelId, deviceId) {
      const p = panelId && panel(panelId);
      if (panelId && (!p || p.kind !== kind || p.owner !== owner)) throw new Error('面板归属不匹配');
      if (kind === 'product') {
        const d = DEVICES.find(d => d.id === deviceId);
        if (!d || productFor(d).id !== owner) throw new Error('请选择该产品的设备');
        return [deviceId];
      }
      if (kind === 'scene') {
        const s = state.scenes.find(s => s.id === owner);
        if (!s) throw new Error('场景不存在');
        return deviceIds(s.devices, s.project);
      }
      if (kind === 'screen') {
        if (!PROJECTS.some(p => p.id === owner)) throw new Error('项目不存在');
        return DEVICES.filter(d => d.project === owner).map(d => d.id);
      }
      if (kind === 'curve' && p) return [...new Set(p.series.map(s => s.device))];
      throw new Error('展示范围无效');
    },
    subscribe(fn) { changed.add(fn); return () => changed.delete(fn); }
  };
})();
