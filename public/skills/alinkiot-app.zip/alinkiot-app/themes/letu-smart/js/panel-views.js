function panelFinish(saved, message, selected) {
  if (selected) Workspace.page(CURRENT).selected = selected;
  Workspace.save();
  go(CURRENT);
  toast(saved ? message + '（本地演示）' : message + '，但存储失败，刷新将丢失', saved ? 'ok' : 'warn');
}
function panelError(form, error) {
  const host = form.querySelector('[data-editor-error]');
  host.textContent = error.message;
  host.hidden = false;
}
const panelErrorHTML = '<p data-editor-error role="alert" hidden style="color:var(--danger)"></p>';
function panelNotice() {
  return `<p class="hint">本浏览器演示：产品属性、场景与面板配置本地保存，未接入统一账号权限。定位不伪造；控制仅模拟，不下发硬件指令。</p>
    ${PanelWorkspace.loadError ? '<p class="hint" style="color:var(--warn)">产品/面板存档无法读取，已回退初始配置。</p>' : ''}
    <p class="hint"><a href="sdk/example.html" download="example.html">下载 HTML 示例</a> · <a href="sdk/alinkiot-panel.js" download="alinkiot-panel.js">下载面板 SDK</a> · <a href="sdk/README.md" target="_blank" rel="noopener">SDK 使用说明</a></p>`;
}
function panelConfirm(title, body, run) {
  openModal(title, `<p>${escapeHTML(body)}</p><p class="hint">仅影响本地配置，不删除设备与遥测。</p>`,
    '<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" data-panel-confirm>确认</button>');
  document.querySelector('[data-panel-confirm]').onclick = () => {
    try { panelFinish(run(), '操作已完成'); } catch (e) { toast(e.message, 'warn'); }
  };
}
function requestProductSync() {
  toast('未连接产品来源接口或数据库，本次未执行同步；当前属性为本地样本', 'info');
}
function openProductProperties(product) {
  openDrawer('查看属性 · ' + product.name, `
    <p class="hint">属性由接口或数据库同步，后台仅查看，不手工新增、修改或删除。当前为本地样本，未连接真实来源。</p>
    <p>${escapeHTML(product.description)}</p>
    <div class="table-wrap"><table class="tbl"><thead><tr><th>标识</th><th>名称</th><th>类型</th><th>单位</th><th>来源映射</th><th>访问</th></tr></thead><tbody>
      ${product.properties.map(p => `<tr><td>${escapeHTML(p.key)}</td><td>${escapeHTML(p.name)}</td><td>${escapeHTML(p.type)}</td>
        <td>${escapeHTML(p.unit) || '—'}</td><td>${escapeHTML(p.source)}</td><td>${p.writable ? '可控制（仅模拟）' : '只读'}</td></tr>`).join('')}
    </tbody></table></div><p class="hint">名称、类型、单位和读写性均以来源为准，HTML 上传只能定制展示，不能新增属性或开放写权限。</p>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button><button class="btn btn-primary" onclick="requestProductSync()">同步属性</button>');
}
function openDeviceBinding(deviceId) {
  const device = PanelWorkspace.device(deviceId), raw = DEVICES.find(d => d.id === deviceId);
  openModal('设备产品与定位', `<form id="deviceBindingForm">
    <p>${escapeHTML(device.name)} · ${escapeHTML(device.code)}</p>
    <div class="form-field"><label>所属产品（同设备类型）</label><select class="sel" name="product">
      ${PanelWorkspace.products().filter(p => p.type === raw.type).map(p => `<option value="${p.id}" ${p.id === device.product ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <div class="form-row"><div class="form-field"><label>经度 WGS84</label><input class="inp" name="lng" type="number" step="any" min="-180" max="180" value="${device.location?.lng ?? ''}"/></div>
      <div class="form-field"><label>纬度 WGS84</label><input class="inp" name="lat" type="number" step="any" min="-90" max="90" value="${device.location?.lat ?? ''}"/></div></div>
    <p class="hint">两个坐标都留空表示未定位；不会调用浏览器定位或外部地图。更换产品先移除设备的曲线引用。</p>${panelErrorHTML}</form>`,
    '<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" form="deviceBindingForm" type="submit">保存设备配置</button>');
  const form = document.getElementById('deviceBindingForm');
  form.onsubmit = event => {
    event.preventDefault();
    try {
      const lng = form.elements.lng.value, lat = form.elements.lat.value;
      if ((!lng) !== (!lat)) throw new Error('经纬度须同时填写或同时留空');
      panelFinish(PanelWorkspace.bindDevice(deviceId, form.elements.product.value, lng ? { lng: Number(lng), lat: Number(lat) } : null), '设备配置已保存');
    } catch (e) { panelError(form, e); }
  };
}
function singleProjectSelect(id, project) {
  return `<label>项目 <select class="sel" id="${id}" aria-label="项目">
    ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></label>`;
}
function openSceneEditor(scene, projectId) {
  const project = scene?.project || projectId || Workspace.project || PROJECTS[0]?.id;
  openDrawer(scene ? '编辑场景与关联设备' : '新建项目场景', `<form id="sceneForm">
    <div class="form-field"><label>场景名称</label><input class="inp" name="name" required maxlength="80" value="${escapeHTML(scene?.name || '')}"/></div>
    <div class="form-field"><label>项目</label><select class="sel" name="project" ${scene ? 'disabled' : ''}>
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <input class="inp" data-scene-search placeholder="搜索设备名称或编号" aria-label="搜索关联设备"/>
    <p class="hint" data-scene-count></p><div data-scene-devices class="panel-device-picker"></div>
    <p class="hint">每场景最多 100 台本项目设备。不同场景可关联同一设备；取消不会改变已有关系。</p>${panelErrorHTML}</form>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" form="sceneForm" type="submit">保存场景</button>');
  const form = document.getElementById('sceneForm'), selected = new Set(scene?.devices || []);
  const paint = () => {
    const query = form.querySelector('[data-scene-search]').value.trim().toLowerCase();
    const list = DEVICES.filter(d => d.project === form.elements.project.value && (d.name + d.code).toLowerCase().includes(query));
    form.querySelector('[data-scene-devices]').innerHTML = list.map(d => `<label class="check-line"><input type="checkbox" value="${d.id}" ${selected.has(d.id) ? 'checked' : ''}/><i></i>${escapeHTML(d.name)} · ${d.code}</label>`).join('') || '<p class="hint">无匹配设备</p>';
    form.querySelector('[data-scene-count]').textContent = '已选 ' + selected.size + ' 台（含搜索隐藏项）';
  };
  form.elements.project.onchange = () => { selected.clear(); paint(); };
  form.querySelector('[data-scene-search]').oninput = paint;
  form.querySelector('[data-scene-devices]').onchange = event => {
    if (event.target.checked) selected.add(event.target.value); else selected.delete(event.target.value);
    paint();
  };
  form.onsubmit = event => {
    event.preventDefault();
    try {
      const saved = PanelWorkspace.saveScene(scene?.id, { name: form.elements.name.value, project: form.elements.project.value, devices: [...selected] });
      Workspace.setProject(form.elements.project.value);
      const added = PanelWorkspace.scenes(form.elements.project.value).find(s => s.name === form.elements.name.value.trim());
      panelFinish(saved, '场景已保存', added.id);
    } catch (e) { panelError(form, e); }
  };
  paint();
}
function seriesRow(series) {
  const device = DEVICES.find(d => d.id === series?.device) || DEVICES[0];
  if (!device) return '';
  return `<div class="series-row" data-series-row>
    <select class="sel" data-series-device aria-label="系列设备">${DEVICES.map(d =>
      `<option value="${d.id}" ${d.id === device.id ? 'selected' : ''}>${escapeHTML(projName(d.project))} / ${escapeHTML(d.name)} · ${d.code}</option>`).join('')}</select>
    <select class="sel" data-series-property aria-label="系列属性">${PanelWorkspace.productFor(device.id).properties.filter(p => p.type === 'number').map(p =>
      `<option value="${p.key}" ${series?.property === p.key ? 'selected' : ''}>${escapeHTML(p.name)} (${escapeHTML(p.unit) || '无单位'})${p.source === 'telemetry' ? '' : ' · 无历史'}</option>`).join('')}</select>
    <input class="inp" data-series-name aria-label="系列名称" maxlength="80" required value="${escapeHTML(series?.name || device.name)}"/>
    <button class="btn btn-sm btn-ghost" type="button" data-remove-series>移除系列</button>
  </div>`;
}
function openPanelEditor(kind, owner, item) {
  openDrawer(kind === 'screen' ? item ? '编辑大屏' : '新建大屏' : item ? '编辑面板' : '新建面板', `<form id="panelForm">
    <div class="form-field"><label>面板名称</label><input class="inp" name="name" required maxlength="80" value="${escapeHTML(item?.name || '')}"/></div>
    ${kind === 'screen' ? `<div class="form-field"><label>所属项目</label><select class="sel" name="project" required aria-label="大屏所属项目" ${item ? 'disabled' : ''}>
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === owner ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select>
      ${item ? '<small>已有大屏的项目归属不可修改。</small>' : ''}</div>` : ''}
    ${kind === 'curve' ? `<h4>设备属性系列</h4><div data-series>${(item?.series || []).map(seriesRow).join('')}</div>
      <button class="btn btn-ghost" type="button" data-add-series>添加设备属性</button>
      <p class="hint">最多 12 条系列，跨项目设备分图展示。没有历史来源的数值属性显示无历史，不将模拟控制写成历史。</p>` : ''}
    <div class="form-field"><label>上传自定义 HTML / ZIP（可选）</label>
      <input class="inp" name="upload" type="file" accept=".html,.htm,.zip"/>
      <small>${item?.html ? '当前文件：' + escapeHTML(item.html.filename) : '未上传时使用基础视图'}</small></div>
    ${item?.html ? '<label><input type="checkbox" name="restore"/>移除自定义内容，恢复基础视图</label>' : ''}
    <p class="hint">HTML ≤500 KB；ZIP ≤1 MB，解压总大小 ≤2 MB、≤80 条目，根目录必须有 index.html。资源随包上传，禁止 CDN/网络、路径穿越、模块脚本。不支持多页面应用；面板可通过 AlinkIoT SDK 使用本页关联设备。</p>
    <p class="hint">上传页面运行于 sandbox iframe，不可读取后台 DOM/存储。请仅上传可信面板；浏览器隔离不是生产级网络隔离，不要在演示中放入秘密或真实设备凭证。</p>
    ${panelErrorHTML}</form>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" type="submit" form="panelForm">保存面板</button>');
  const form = document.getElementById('panelForm');
  form.querySelector('[data-add-series]')?.addEventListener('click', () => {
    if (form.querySelectorAll('[data-series-row]').length >= 12) return panelError(form, new Error('最多 12 条系列'));
    form.querySelector('[data-series]').insertAdjacentHTML('beforeend', seriesRow());
  });
  form.addEventListener('click', event => event.target.closest('[data-remove-series]')?.closest('[data-series-row]').remove());
  form.addEventListener('change', event => {
    if (!event.target.matches('[data-series-device]')) return;
    const row = event.target.closest('[data-series-row]'), device = DEVICES.find(d => d.id === event.target.value);
    row.querySelector('[data-series-property]').innerHTML = PanelWorkspace.productFor(device.id).properties.filter(p => p.type === 'number').map(p =>
      `<option value="${p.key}">${escapeHTML(p.name)} (${escapeHTML(p.unit)})${p.source === 'telemetry' ? '' : ' · 无历史'}</option>`).join('');
    row.querySelector('[data-series-name]').value = device.name;
  });
  let busy = false;
  form.onsubmit = async event => {
    event.preventDefault();
    if (busy) return;
    const submit = document.querySelector('[form="panelForm"]');
    busy = true;
    submit.disabled = true;
    submit.textContent = '校验与保存…';
    try {
      const file = form.elements.upload.files[0];
      if (file && form.elements.restore?.checked) throw new Error('上传新文件与恢复基础视图不可同时选择');
      const html = file ? await PanelUpload.read(file) : form.elements.restore?.checked ? null : item?.html || null;
      if (!form.isConnected || !form.closest('.drawer.on')) return;
      const series = [...form.querySelectorAll('[data-series-row]')].map(row => ({
        device: row.querySelector('[data-series-device]').value, property: row.querySelector('[data-series-property]').value,
        name: row.querySelector('[data-series-name]').value
      }));
      const panelOwner = kind === 'screen' && !item ? form.elements.project.value : owner;
      const saved = PanelWorkspace.savePanel(item?.id, { kind, owner: panelOwner, name: form.elements.name.value, series, html });
      const selected = item?.id || PanelWorkspace.panels(kind, panelOwner).slice(-1)[0].id;
      if (kind === 'screen' && !item) Workspace.setProject(panelOwner);
      if (kind === 'curve' || kind === 'screen') Workspace.page(CURRENT).selected = selected;
      else Workspace.page(CURRENT).panel = selected;
      if (kind === 'scene') Workspace.page(CURRENT).tab = 'custom';
      panelFinish(saved, '面板已保存');
    } catch (e) { if (form.isConnected) panelError(form, e); }
    finally { busy = false; submit.disabled = false; submit.textContent = '保存面板'; }
  };
}
function panelCard(item, selected, base = false) {
  return `<article class="card panel-card ${selected === item.id ? 'selected' : ''}">
    <div class="card-body"><div class="panel-card-icon">${icon(item.kind === 'curve' ? 'chart' : 'monitor')}</div>
      <h3>${escapeHTML(item.name)}</h3><p class="hint">${item.html ? '自定义 · ' + escapeHTML(item.html.filename) : '基础面板'}${item.kind === 'curve' ? ' · ' + item.series.length + ' 个设备属性' : ''}</p>
      <div class="panel-actions"><button class="btn btn-primary btn-sm" data-panel-open="${item.id}">${item.kind === 'screen' ? '查看大屏' : '查看面板'}</button>
        ${item.kind === 'screen' ? screenShare(item) : ''}
        <button class="btn btn-ghost btn-sm" data-panel-edit="${item.id}">编辑 / 上传</button>
        ${base ? '' : `<button class="btn btn-ghost btn-sm" data-panel-delete="${item.id}">删除</button>`}</div></div></article>`;
}
function screenShare(item) {
  return `<a class="btn btn-ghost btn-sm" href="screen.html?project=${encodeURIComponent(item.owner)}&panel=${encodeURIComponent(item.id)}" target="_blank" rel="noopener" title="独立页展示，仅同浏览器本地存档可用">分享</a>`;
}
function deviceTable(ids, readonly = false) {
  return `<div class="table-wrap"><table class="tbl"><thead><tr><th>设备</th><th>产品</th><th>状态</th><th>定位 WGS84</th><th>属性值</th><th>操作</th></tr></thead><tbody>
    ${ids.map(id => {
      const d = PanelWorkspace.device(id), product = PanelWorkspace.product(d.product);
      return `<tr><td>${escapeHTML(d.name)}<small style="display:block">${d.code}</small></td><td>${escapeHTML(product.name)}</td>
        <td>${badge(d.status)}</td><td>${d.location ? d.location.lng + ', ' + d.location.lat : '未定位'}</td>
        <td>${d.properties.map(p => `${escapeHTML(p.name)}：${escapeHTML(String(d.values[p.key] ?? '—'))} ${escapeHTML(p.unit)}`).join('<br>')}</td>
        <td>${readonly ? '—' : `<button class="btn btn-sm btn-ghost" data-bind-device="${id}">产品 / 定位</button>`}</td></tr>`;
    }).join('')}</tbody></table>${ids.length ? '' : '<div class="empty"><h4>暂无关联设备</h4></div>'}</div>`;
}
function locationPlot(ids) {
  const devices = ids.map(id => PanelWorkspace.device(id)), located = devices.filter(d => d.location);
  return `<div class="location-plot"><svg viewBox="0 0 720 240" role="img" aria-label="设备经纬度示意图">
    <path d="M0 120H720M360 0V240" stroke="currentColor" opacity=".2"/>
    ${located.map(d => `<circle cx="${(d.location.lng + 180) * 2}" cy="${(90 - d.location.lat) * 240 / 180}" r="5" fill="var(--accent)">
      <title>${escapeHTML(d.name)} · ${d.location.lng}, ${d.location.lat}</title></circle>`).join('')}
    </svg><p class="hint">WGS84 经纬度示意（非真实地图） · 已定位 ${located.length} / ${devices.length} 台；坐标详见设备列表。</p></div>`;
}
function customViewer(item) {
  return `<div class="panel-viewer">
    <label><input type="checkbox" data-panel-control/>允许本次模拟控制（默认关闭，仅本地状态）</label>
    <p class="hint" data-control-result role="status">未执行控制；请勿上传真实设备凭证。网络请求受 CSP 限制，但不保证阻断脚本自身跳转等所有浏览器网络行为。</p>
    <div data-custom-host></div></div>`;
}
function mountPanelContent(scope, options) {
  const item = options.panelId && PanelWorkspace.panel(options.panelId);
  if (item?.html) {
    const dispose = PanelHost.mount(scope.querySelector('[data-custom-host]'), { ...options,
      allowControl: () => scope.querySelector('[data-panel-control]').checked,
      onControl: (args, result) => {
        scope.querySelector('[data-control-result]').textContent = `模拟控制：${args.device} / ${args.property} = ${String(args.value)}；` +
          (result.persisted ? '已保存本地状态，未下发硬件指令' : '仅内存生效，存储失败');
      }
    });
    scope._cleanup = dispose;
  }
}
function mountPanelActions(scope, kind, owner) {
  scope.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.panelOpen) {
      if (kind === 'curve') Workspace.page('curves').opened = true;
      if (kind === 'screen') Workspace.page('bigscreen').opened = true;
      panelFinish(true, '面板已打开', button.dataset.panelOpen);
    }
    if (button.dataset.panelEdit) openPanelEditor(kind, owner, PanelWorkspace.panel(button.dataset.panelEdit));
    if (button.dataset.panelDelete) {
      const item = PanelWorkspace.panel(button.dataset.panelDelete);
      panelConfirm('删除面板', '删除 ' + item.name + ' 及其上传内容？', () => PanelWorkspace.removePanel(item.id));
    }
    if (button.hasAttribute('data-panel-add')) openPanelEditor(kind, owner);
    if (button.dataset.bindDevice) openDeviceBinding(button.dataset.bindDevice);
  });
}

function productPreview() {
  const state = Workspace.page('products'), products = PanelWorkspace.products();
  const product = products.find(p => p.id === state.selected) || products[0];
  if (!product) return '<div class="empty">暂无产品</div>';
  const devices = DEVICES.filter(d => PanelWorkspace.productFor(d.id).id === product.id);
  const device = devices.find(d => d.id === state.device) || devices[0];
  const panels = PanelWorkspace.panels('product', product.id), current = panels.find(p => p.id === state.panel);
  const snapshot = device && PanelWorkspace.device(device.id);
  return `<div class="card-head"><div><h3>${escapeHTML(product.name)} · 设备面板预览</h3>
    <p class="hint">本产品设备共用同一界面，选择设备仅切换实例数据。</p></div></div><div class="card-body">
    <div class="panel-actions"><label>预览设备 <select class="sel" data-product-device aria-label="产品预览设备" ${device ? '' : 'disabled'}>
      ${devices.map(d => `<option value="${d.id}" ${d.id === device?.id ? 'selected' : ''}>${escapeHTML(d.name)} · ${d.code}</option>`).join('')}</select></label>
      <label>面板 <select class="sel" data-product-panel aria-label="产品面板"><option value="">基础设备面板</option>
        ${panels.map(p => `<option value="${p.id}" ${p.id === current?.id ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></label>
      <button class="btn btn-ghost" data-panel-add>上传新面板</button>
      ${current ? `<button class="btn btn-ghost" data-panel-edit="${current.id}">编辑 / 上传</button><button class="btn btn-ghost" data-panel-delete="${current.id}">删除面板</button>` : ''}
    </div>
    ${!snapshot ? '<div class="empty"><h4>暂无可预览设备</h4><p>绑定该产品的设备后，即可在此预览其操作界面。</p></div>' : current?.html ? customViewer(current) : `
      <div class="product-device-status"><h3>${escapeHTML(snapshot.name)}</h3>${badge(snapshot.status)}
        <span class="hint">${snapshot.code} · 采样 ${escapeHTML(snapshot.updated)} · 本地快照</span></div>
      <h4>设备状态</h4><div class="panel-grid">
        ${snapshot.properties.map(p => `<div class="card"><div class="card-body"><div class="hint">${escapeHTML(p.name)}</div>
          <div class="product-property-value">${escapeHTML(snapshot.values[p.key] === null ? '—' :
            p.type === 'boolean' ? snapshot.values[p.key] ? '开启' : '关闭' : String(snapshot.values[p.key]))}
            <small>${escapeHTML(p.unit)}</small></div>
          <span class="hint">${p.writable ? '可控制属性' : '只读属性'}</span></div></div>`).join('')}
      </div>
      <h4>设备控制</h4><label><input type="checkbox" data-product-control-permit/>允许本次模拟控制（不下发硬件指令）</label>
      <div class="panel-grid">${snapshot.properties.filter(p => p.writable && p.source === 'custom').map(p => `
        <form data-product-control="${p.key}" class="card"><div class="card-body"><label>${escapeHTML(p.name)}
          ${p.type === 'boolean' ? `<select class="sel" name="value" aria-label="${escapeHTML(p.name)}"><option value="true" ${snapshot.values[p.key] === true ? 'selected' : ''}>开启</option><option value="false" ${snapshot.values[p.key] === false ? 'selected' : ''}>关闭</option></select>` :
          `<input class="inp" name="value" aria-label="${escapeHTML(p.name)}" type="${p.type === 'number' ? 'number' : 'text'}" ${p.type === 'number' ? 'step="any"' : 'maxlength="200"'} required value="${escapeHTML(String(snapshot.values[p.key] ?? ''))}"/>`}</label>
          <button class="btn btn-primary btn-sm" type="submit" ${snapshot.status === 'online' ? '' : 'disabled'}>执行模拟</button>
        </div></form>`).join('') || '<p class="hint">该产品无可控制属性。</p>'}</div>
      <p class="hint" data-product-control-result role="status">${snapshot.status === 'online' ? '仅修改本地模拟状态，属性写权限以同步定义为准。' : '设备离线，不可执行模拟控制。'}</p>
    `}
  </div>`;
}
VIEWS.products = {
  group: '资产管理', title: '产品管理',
  render() {
    const state = Workspace.page('products'), products = PanelWorkspace.products();
    const selected = products.find(p => p.id === state.selected) || products[0];
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">产品管理</div>
      <div class="page-desc">从接口或数据库同步一类设备的属性 · 本地只读展示与面板配置</div></div>
      <div class="page-actions"><button class="btn btn-ghost" data-product-sync>${icon('refresh')}同步产品属性</button></div></div>${panelNotice()}
      <div class="panel-grid">${products.map(p => `<article class="card panel-card product-select-card ${selected?.id === p.id ? 'selected' : ''}"><div class="card-body">
        <button class="product-card-select" data-product-open="${p.id}" aria-label="选择产品 ${escapeHTML(p.name)}" aria-pressed="${selected?.id === p.id}"></button>
        <h3>${escapeHTML(p.name)}</h3><p class="hint">${escapeHTML(p.description)} · ${p.properties.length} 个属性 · ${DEVICES.filter(d => PanelWorkspace.productFor(d.id).id === p.id).length} 台设备</p>
        <div class="panel-actions"><button class="btn btn-sm btn-primary" data-product-open="${p.id}">查看面板</button>
          <button class="btn btn-sm btn-ghost" data-product-properties="${p.id}">查看属性</button></div>
      </div></article>`).join('')}</div>
      <section class="card" data-product-preview style="margin-top:16px">${productPreview()}</section></div>`;
  },
  mount(scope) {
    const state = Workspace.page('products');
    let dispose;
    const selectedProduct = () => PanelWorkspace.products().find(p => p.id === state.selected) || PanelWorkspace.products()[0];
    const activate = () => {
      const product = selectedProduct();
      if (!product) return;
      const current = PanelWorkspace.panels('product', product.id).find(p => p.id === state.panel);
      const device = scope.querySelector('[data-product-device]').value;
      if (current?.html && device) {
        const host = scope.querySelector('[data-product-preview]');
        mountPanelContent(host, { kind: 'product', owner: product.id, panelId: current.id, deviceId: device });
        dispose = host._cleanup;
      }
    };
    const refresh = () => {
      const view = document.getElementById('view'), scrollTop = view.scrollTop;
      dispose?.(); dispose = null;
      scope.querySelector('[data-product-preview]').innerHTML = productPreview();
      const product = selectedProduct();
      scope.querySelectorAll('.product-select-card').forEach(card => {
        const selected = card.querySelector('[data-product-open]').dataset.productOpen === product?.id;
        card.classList.toggle('selected', selected);
        card.querySelector('.product-card-select').setAttribute('aria-pressed', String(selected));
      });
      activate();
      view.scrollTop = scrollTop;
    };
    scope._cleanup = () => dispose?.();
    scope.querySelector('[data-product-sync]').onclick = requestProductSync;
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (button?.dataset.productOpen && button.dataset.productOpen !== selectedProduct()?.id) {
        Object.assign(state, { selected: button.dataset.productOpen, device: '', panel: '' });
        Workspace.save();
        refresh();
      }
      if (button?.dataset.productProperties) openProductProperties(PanelWorkspace.product(button.dataset.productProperties));
      if (button?.hasAttribute('data-panel-add')) openPanelEditor('product', selectedProduct().id);
      if (button?.dataset.panelEdit) openPanelEditor('product', selectedProduct().id, PanelWorkspace.panel(button.dataset.panelEdit));
      if (button?.dataset.panelDelete) panelConfirm('删除面板', '删除该产品面板及上传内容？', () => PanelWorkspace.removePanel(button.dataset.panelDelete));
    });
    scope.addEventListener('change', event => {
      const key = event.target.matches('[data-product-device]') ? 'device' : event.target.matches('[data-product-panel]') ? 'panel' : null;
      if (key) { state[key] = event.target.value; Workspace.save(); refresh(); }
    });
    scope.addEventListener('submit', event => {
      const form = event.target.closest('[data-product-control]');
      if (!form) return;
      event.preventDefault();
      const result = scope.querySelector('[data-product-control-result]');
      try {
        if (!scope.querySelector('[data-product-control-permit]').checked) throw new Error('请先允许本次模拟控制');
        const id = scope.querySelector('[data-product-device]').value;
        const property = PanelWorkspace.device(id).properties.find(p => p.key === form.dataset.productControl);
        const input = form.elements.value.value;
        const value = property.type === 'boolean' ? input === 'true' : property.type === 'number' ? Number(input) : input;
        const response = PanelWorkspace.control(id, property.key, value);
        refresh();
        scope.querySelector('[data-product-control-permit]').checked = true;
        scope.querySelector('[data-product-control-result]').textContent = response.persisted ?
          '模拟状态已保存，未下发硬件指令。' : '模拟状态仅内存生效，存储失败。';
      } catch (e) { result.textContent = e.message; }
    });
    activate();
  }
};

function currentScene() {
  const scenes = PanelWorkspace.scenes(Workspace.project || PROJECTS[0]?.id);
  return scenes.find(s => s.id === Workspace.page('scenes').selected) || scenes[0];
}
function sceneDetail() {
  const current = currentScene(), state = Workspace.page('scenes');
  if (!current) return '<div class="card-head"><h3>场景</h3><div class="panel-actions scene-actions"><button class="btn btn-primary btn-sm" data-scene-add>新建场景</button></div></div><div class="empty"><h4>该项目暂无场景</h4><p>点击右上方新建场景并关联设备</p></div>';
  const panels = PanelWorkspace.panels('scene', current.id), selected = panels.find(p => p.id === state.panel) || panels[0];
  const tabs = [['devices', '设备列表'], ['map', '设备地图'], ...panels.map(p => [p.id, p.name])];
  const tab = state.tab === 'custom' && selected ? selected.id : state.tab === 'map' ? 'map' : 'devices';
  return `<div class="card-head"><div><h3>${escapeHTML(current.name)}</h3>
    <p class="hint">${escapeHTML(projName(current.project))} · ${current.devices.length} 台设备</p></div>
    <div class="panel-actions scene-actions"><button class="btn btn-primary btn-sm" data-scene-add>新建场景</button>
      <button class="btn btn-ghost btn-sm" data-scene-edit="${current.id}">编辑关联</button>
      <button class="btn btn-ghost btn-sm" data-scene-delete="${current.id}">删除场景</button></div></div>
    <div class="scene-tabs"><div class="scene-tab-list" role="tablist" aria-label="场景展示">${tabs.map(([key, name]) =>
      `<button class="scene-tab" id="scene-tab-${key}" role="tab" data-scene-tab="${key}" aria-selected="${key === tab}" aria-controls="scene-tab-content" tabindex="${key === tab ? 0 : -1}">${escapeHTML(name)}</button>`).join('')}</div>
      <button class="scene-tab scene-tab-add" data-panel-add>+ 新建面板</button></div>
    <div class="card-body" id="scene-tab-content" role="tabpanel" aria-labelledby="scene-tab-${tab}" tabindex="0">
      ${tab === 'devices' ? deviceTable(current.devices) : tab === 'map' ? locationPlot(current.devices) : `
        <div class="panel-actions">
          ${selected ? `<button class="btn btn-ghost" data-panel-edit="${selected.id}">编辑 / 上传</button><button class="btn btn-ghost" data-panel-delete="${selected.id}">删除面板</button>` : ''}</div>
        ${selected?.html ? customViewer(selected) : '<div class="empty"><h4>暂无自定义内容</h4><p>上传 HTML 定制本场景的设备展示，支持保存多套面板。</p></div>'}
      `}
    </div>`;
}
VIEWS.scenes = {
  group: '数据应用', title: '场景管理',
  render() {
    const project = Workspace.project || PROJECTS[0]?.id, current = currentScene();
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">场景管理</div><div class="page-desc">一个项目多个场景 · 一个场景多台设备 · 多个自定义展示</div></div>
      </div>${panelNotice()}
      <div class="scene-workspace"><nav class="card scene-tree" aria-label="项目与场景"><div class="card-head"><h3>项目 / 场景</h3></div>
        ${PROJECTS.map(p => {
          const scenes = PanelWorkspace.scenes(p.id);
          return `<details data-scene-project="${p.id}" ${p.id === project ? 'open' : ''}><summary>${escapeHTML(p.name)} <span class="hint">${scenes.length}</span></summary>
            <div class="scene-tree-children">${scenes.map(s =>
              `<button class="scene-tree-node" data-scene-open="${s.id}" aria-current="${current?.id === s.id ? 'true' : 'false'}"><span>${escapeHTML(s.name)}</span><small>${s.devices.length} 台</small></button>`).join('') || '<p class="hint">暂无场景</p>'}
              </div></details>`;
        }).join('')}</nav>
        <section class="card scene-detail" data-scene-detail>${sceneDetail()}</section>
      </div></div>`;
  },
  mount(scope) {
    const state = Workspace.page('scenes');
    let dispose;
    const activate = () => {
      const current = currentScene();
      if (!current || state.tab !== 'custom') return;
      const panels = PanelWorkspace.panels('scene', current.id);
      const selected = panels.find(p => p.id === state.panel) || panels[0];
      if (selected?.html) {
        const detail = scope.querySelector('[data-scene-detail]');
        mountPanelContent(detail, { kind: 'scene', owner: current.id, panelId: selected.id });
        dispose = detail._cleanup;
      }
    };
    const refresh = (focusTab = false) => {
      dispose?.(); dispose = null;
      scope.querySelector('[data-scene-detail]').innerHTML = sceneDetail();
      const current = currentScene();
      scope.querySelectorAll('[data-scene-open]').forEach(button =>
        button.setAttribute('aria-current', String(button.dataset.sceneOpen === current?.id)));
      activate();
      if (focusTab) scope.querySelector('[role="tab"][aria-selected="true"]')?.focus();
    };
    const switchTab = tab => {
      const panel = PanelWorkspace.panels('scene', currentScene().id).find(p => p.id === tab);
      state.tab = panel ? 'custom' : tab;
      if (panel) state.panel = panel.id;
      Workspace.save();
      refresh(true);
    };
    scope._cleanup = () => dispose?.();
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      if (button.hasAttribute('data-scene-add')) openSceneEditor();
      if (button.dataset.sceneOpen && button.dataset.sceneOpen !== currentScene()?.id) {
        const scene = PanelWorkspace.scenes().find(s => s.id === button.dataset.sceneOpen);
        Workspace.setProject(scene.project);
        Object.assign(state, { selected: scene.id, panel: '', tab: 'devices' });
        Workspace.save();
        refresh();
      }
      if (button.dataset.sceneTab) switchTab(button.dataset.sceneTab);
      if (button.dataset.sceneEdit) openSceneEditor(currentScene());
      if (button?.dataset.sceneDelete) panelConfirm('删除场景', '同时删除该场景的自定义面板，不删除关联设备。', () => PanelWorkspace.removeScene(button.dataset.sceneDelete));
      const current = currentScene();
      if (button.hasAttribute('data-panel-add')) openPanelEditor('scene', current.id);
      if (button.dataset.panelEdit) openPanelEditor('scene', current.id, PanelWorkspace.panel(button.dataset.panelEdit));
      if (button.dataset.panelDelete) panelConfirm('删除面板', '删除该场景面板及上传内容？', () => PanelWorkspace.removePanel(button.dataset.panelDelete));
      if (button.dataset.bindDevice) openDeviceBinding(button.dataset.bindDevice);
    });
    scope.addEventListener('keydown', event => {
      const tab = event.target.closest('[data-scene-tab]');
      if (!tab || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const tabs = ['devices', 'map', ...PanelWorkspace.panels('scene', currentScene().id).map(p => p.id)];
      const index = tabs.indexOf(tab.dataset.sceneTab);
      switchTab(tabs[event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 :
        (index + (event.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length]);
    });
    activate();
  }
};

VIEWS.curves = {
  group: '数据应用', title: '曲线管理',
  render() {
    const state = Workspace.page('curves'), panels = PanelWorkspace.panels('curve');
    const selected = panels.find(p => p.id === state.selected) || panels[0];
    const opened = state.opened && selected;
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">曲线管理</div>
      <div class="page-desc">卡片管理多套曲线面板 · 选择设备的数值属性 · 基础视图或上传 HTML</div></div>
      <div class="page-actions">${opened ? `<button class="btn btn-ghost" data-curve-back>返回列表</button>
        <button class="btn btn-ghost" data-panel-edit="${selected.id}">编辑 / 上传</button>` :
        '<button class="btn btn-primary" data-panel-add>新建曲线面板</button>'}</div></div>${panelNotice()}
      ${!opened ? `<div class="panel-grid">${panels.map(p => panelCard(p, selected?.id)).join('')}</div>
        ${panels.length ? '' : '<div class="empty"><h4>暂无曲线面板</h4><p>新建基础或 HTML 曲线面板</p></div>'}` : `
      <div class="card" style="margin-top:16px"><div class="card-head"><h3>${escapeHTML(selected.name)}</h3>
        <div class="ch-right"><select class="sel" data-panel-range aria-label="曲线时间范围">
          ${[['24', '近24小时'], ['7', '近7天'], ['30', '近30天']].map(([key, name]) => `<option value="${key}" ${(state.range || Curves.range) === key ? 'selected' : ''}>${name}</option>`).join('')}</select></div></div>
        <div class="card-body"><p class="hint">固定样本截止 2026-10-30 00:00（UTC+8）。不同单位分图；没有历史的属性不造曲线。上传面板通过 SDK 自行查询时间。</p>
          ${selected.html ? customViewer(selected) : `<div class="grid g2">${selected.series.map((s, i) => {
            const d = PanelWorkspace.device(s.device), p = d.properties.find(p => p.key === s.property);
            return `<div class="curve-card"><div class="cc-head"><div class="cc-title">${escapeHTML(s.name)}<small>${escapeHTML(projName(d.project))} · ${escapeHTML(p.name)} · ${escapeHTML(p.unit)}</small></div></div>
              <div class="cc-body"><div class="chart" data-panel-chart="${i}" style="height:190px"></div><p class="hint" data-series-stats="${i}"></p>
                ${p.source === 'telemetry' ? `<button class="btn btn-sm btn-ghost" data-panel-history="${i}">查看历史明细</button>` : ''}</div></div>`;
          }).join('')}</div>${selected.series.length ? '' : '<div class="empty"><h4>尚未选择设备属性</h4><p>编辑面板添加系列</p></div>'}`}
        </div></div>`}</div>`;
  },
  mount(scope) {
    const state = Workspace.page('curves'), panels = PanelWorkspace.panels('curve');
    const selected = panels.find(p => p.id === state.selected) || panels[0];
    mountPanelActions(scope, 'curve', '');
    scope.querySelector('[data-curve-back]')?.addEventListener('click', () => {
      state.opened = false; Workspace.save(); go('curves');
    });
    if (!state.opened || !selected) return;
    scope.querySelector('[data-panel-range]').onchange = event => { state.range = event.target.value; Workspace.save(); go('curves'); };
    if (selected.html) return mountPanelContent(scope, { kind: 'curve', owner: '', panelId: selected.id });
    const range = ['24', '7', '30'].includes(state.range) ? state.range : Curves.range;
    const time = range === '24' ? { from: Telemetry.format(Telemetry.end - 86400000).slice(0, 16).replace(' ', 'T'), to: Telemetry.format(Telemetry.end).slice(0, 16).replace(' ', 'T') } : Telemetry.defaults(range);
    scope.querySelectorAll('[data-panel-chart]').forEach((host, i) => {
      const series = selected.series[i], d = PanelWorkspace.device(series.device), p = d.properties.find(p => p.key === series.property);
      const rows = PanelWorkspace.history(d.id, p.key, time.from, time.to);
      if (rows.length) Charts.line(host, { labels: rows.map(r => Telemetry.format(r.time).slice(5, 16)), height: 190, unit: escapeHTML(p.unit), yDec: 3, xLabels: 4,
        series: [{ name: escapeHTML(series.name), data: rows.map(r => r.value), color: Curves.colors[i % Curves.colors.length] }] });
      else host.textContent = '该属性暂无历史数据';
      const stats = rows.length ? Telemetry.stats(rows.map(r => ({ ...r, count: 1 }))) : null;
      scope.querySelector(`[data-series-stats="${i}"]`).textContent = rows.length + ' 个小时样本 · ' + d.code + ' / ' + p.key +
        (stats ? ` · 最小 ${stats.min.toFixed(3)} / 最大 ${stats.max.toFixed(3)} / 均值 ${stats.average.toFixed(3)} ${p.unit}` : '');
    });
    scope.addEventListener('click', event => {
      const button = event.target.closest('[data-panel-history]');
      if (!button) return;
      const series = selected.series[Number(button.dataset.panelHistory)], device = DEVICES.find(d => d.id === series.device);
      Workspace.setProject(device.project);
      Object.assign(Workspace.page('history'), { device: device.id, deviceSearch: '', page: 1,
        query: { from: time.from, to: time.to, aggregation: 'raw', range: 'custom' } });
      Workspace.save();
      go('history');
    });
    scope._cleanup = () => scope.querySelectorAll('[data-panel-chart]').forEach(host => Charts.remove(host));
  }
};

VIEWS.bigscreen = {
  group: '数据应用', title: '项目大屏',
  render() {
    const project = Workspace.project || PROJECTS[0]?.id, state = Workspace.page('bigscreen');
    if (!project) return '<div class="view-in"><div class="empty">暂无项目</div></div>';
    const baseId = PanelWorkspace.ensureScreen(project), panels = PanelWorkspace.panels('screen', project);
    const selected = panels.find(p => p.id === state.selected) || panels.find(p => p.id === baseId);
    const opened = state.opened && selected;
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">项目大屏</div><div class="page-desc">每项目默认基础大屏 · 多大屏卡片 · 编辑上传 HTML / ZIP 自定义</div></div>
      <div class="page-actions">${opened ? `<button class="btn btn-ghost" data-screen-back>返回列表</button>
        <button class="btn btn-ghost" data-panel-edit="${selected.id}">编辑 / 上传</button>${screenShare(selected)}` :
        '<button class="btn btn-primary" data-panel-add>新建大屏</button>'}</div></div>
      ${opened ? '' : `<div class="panel-actions">${singleProjectSelect('screen-project', project)}</div>`}${panelNotice()}
      ${opened ? this.display(project, selected) :
        `<div class="panel-grid">${panels.map(p => panelCard(p, selected.id, p.id === baseId)).join('')}</div>`}</div>`;
  },
  display(project, selected) {
    const devices = DEVICES.filter(d => d.project === project), online = devices.filter(d => d.status === 'online').length;
    const alarms = AlarmStore.snapshot(project).events;
    return `<div class="card"><div class="card-head"><h3>${escapeHTML(selected.name)} · ${escapeHTML(projName(project))}</h3>
        <div class="ch-right"><button class="btn btn-ghost" data-screen-full>${icon('expand')}全屏展示</button></div></div>
        <div class="card-body panel-screen" id="screenBox">${selected.html ? customViewer(selected) : `
          <div class="grid g3"><div class="kpi"><div class="kpi-label">本地设备</div><div class="kpi-val">${devices.length}</div></div>
            <div class="kpi"><div class="kpi-label">在线快照</div><div class="kpi-val">${online}</div></div>
            <div class="kpi"><div class="kpi-label">离线快照</div><div class="kpi-val">${devices.length - online}</div></div></div>
          <div class="grid g2" style="margin-top:16px"><div class="card"><div class="card-body"><h3>首台设备近24小时趋势</h3>
            <div class="chart" data-screen-trend style="height:190px"></div><p class="hint" data-screen-trend-label></p></div></div>
            <div class="card"><div class="card-body"><h3>本项目告警样本 · ${alarms.length} 条</h3>
              <p class="hint">固定事件样本，不是实时检测。物理与处理状态分开。</p>
              ${alarms.map(a => `<p class="hint">${escapeHTML(a.id)} · ${escapeHTML(a.physical)} / ${escapeHTML(a.handling)}</p>`).join('') || '<p class="hint">暂无告警样本</p>'}
              <a class="btn btn-sm btn-ghost" href="index.html#alarms" data-screen-alarms="${project}">查看告警中心</a>
            </div></div></div>
          ${locationPlot(devices.map(d => d.id)) + deviceTable(devices.map(d => d.id), true)}
        `}</div></div>`;
  },
  mount(scope) {
    const project = Workspace.project || PROJECTS[0]?.id;
    if (!project) return;
    const state = Workspace.page('bigscreen');
    mountPanelActions(scope, 'screen', project);
    const filter = scope.querySelector('#screen-project');
    if (filter) filter.onchange = event => {
      Workspace.setProject(event.target.value); state.selected = ''; state.opened = false; Workspace.save(); go('bigscreen');
    };
    scope.querySelector('[data-screen-back]')?.addEventListener('click', () => {
      state.opened = false; Workspace.save(); go('bigscreen');
    });
    scope.querySelector('[data-screen-alarms]')?.addEventListener('click', () => Workspace.setProject(project));
    const selected = PanelWorkspace.panels('screen', project).find(p => p.id === state.selected) || PanelWorkspace.panel('screen-' + project);
    if (state.opened && selected) this.mountDisplay(scope, project, selected);
  },
  mountDisplay(scope, project, selected) {
    scope.querySelector('[data-screen-full]').onclick = async () => {
      try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await scope.querySelector('#screenBox').requestFullscreen();
      } catch (e) { toast('当前浏览器无法进入全屏', 'warn'); }
    };
    if (selected.html) mountPanelContent(scope, { kind: 'screen', owner: project, panelId: selected.id });
    else {
      const host = scope.querySelector('[data-screen-trend]'), device = DEVICES.find(d => d.project === project);
      const property = device && PanelWorkspace.productFor(device.id).properties.find(p => p.source === 'telemetry');
      if (property) {
        const from = Telemetry.format(Telemetry.end - 86400000).slice(0, 16).replace(' ', 'T'), to = Telemetry.format(Telemetry.end).slice(0, 16).replace(' ', 'T');
        const rows = PanelWorkspace.history(device.id, property.key, from, to);
        Charts.line(host, { labels: rows.map(r => Telemetry.format(r.time).slice(5, 16)), height: 190, unit: escapeHTML(property.unit), yDec: 3, xLabels: 4,
          series: [{ name: escapeHTML(device.name), data: rows.map(r => r.value), color: Curves.colors[0] }] });
        scope.querySelector('[data-screen-trend-label]').textContent = device.name + ' · ' + property.name + ' · 固定小时样本';
      } else host.textContent = '暂无可展示的历史测点';
      scope._cleanup = () => Charts.remove(host);
    }
  }
};
