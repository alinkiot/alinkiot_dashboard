const Telemetry = (() => {
  const hour = 3600000;
  const start = Date.parse('2026-10-01T00:00:00+08:00');
  const end = Date.parse('2026-10-30T00:00:00+08:00');
  const format = time => {
    const d = new Date(time + 8 * hour);
    return d.toISOString().slice(0, 19).replace('T', ' ');
  };
  const parse = value => {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) throw new Error('请选择有效的北京时间');
    const time = Date.parse(value + ':00+08:00');
    if (!Number.isFinite(time) || format(time).slice(0, 16).replace(' ', 'T') !== value) throw new Error('时间格式不正确');
    return time;
  };
  const sample = (device, time) => {
    const index = Math.floor((time - start) / hour);
    const seed = Number(device.id.slice(1));
    const base = { flow: 620, level: 3.2, press: .72, water: 18, temp: 62, power: 4200 }[device.type];
    const raw = +(base * (1 + Math.sin(index * .17 + seed) * .12 +
      Math.cos(index * .63 + seed * .3) * .025)).toFixed(3);
    return { time, raw, value: device.formula ? +(raw * 1.0042).toFixed(3) : raw,
      count: 1, formula: device.formula ? '示例系数 ×1.0042' : '原始值' };
  };
  return {
    start, end, format, parse,
    defaults(range = '7') {
      return { from: format(range === 'today' ? end : end - Number(range) * 24 * hour).slice(0, 16).replace(' ', 'T'),
        to: format(end + (range === 'today' ? 23 * hour + 59 * 60000 : 0)).slice(0, 16).replace(' ', 'T') };
    },
    query(deviceId, from, to, aggregation = 'raw') {
      const device = DEVICES.find(d => d.id === deviceId);
      if (!device) throw new Error('请选择有效设备');
      const begin = parse(from), finish = parse(to);
      if (begin > finish) throw new Error('开始时间不能晚于结束时间');
      if (finish - begin > 90 * 24 * hour) throw new Error('单次查询最多 90 天');
      if (!['raw', 'day'].includes(aggregation)) throw new Error('请选择有效聚合粒度');
      const rows = [];
      for (let time = Math.max(start, Math.ceil(begin / hour) * hour); time <= Math.min(end, finish); time += hour) {
        rows.push(sample(device, time));
      }
      if (aggregation === 'raw') return rows;
      const groups = new Map();
      rows.forEach(row => {
        const key = format(row.time).slice(0, 10);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(row);
      });
      return [...groups.values()].map(group => ({
        time: group[0].time,
        raw: +(group.reduce((sum, r) => sum + r.raw, 0) / group.length).toFixed(3),
        value: +(group.reduce((sum, r) => sum + r.value, 0) / group.length).toFixed(3),
        count: group.length, formula: group[0].formula
      }));
    },
    stats(rows) {
      if (!rows.length) return null;
      return { min: Math.min(...rows.map(r => r.value)), max: Math.max(...rows.map(r => r.value)),
        average: rows.reduce((sum, r) => sum + r.value, 0) / rows.length,
        count: rows.length, samples: rows.reduce((sum, r) => sum + r.count, 0) };
    }
  };
})();
