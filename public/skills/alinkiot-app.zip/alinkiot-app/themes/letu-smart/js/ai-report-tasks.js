const AIReportTasks = (() => {
  const key = 'letu-ai-report-tasks-v1';
  let tasks = [], loadError = false;
  function validate(input) {
    const name = String(input.name || '').trim(), prompt = String(input.prompt || '').trim();
    if (!name || name.length > 80) throw new Error('任务名称须为 1–80 字');
    if (!prompt || prompt.length > 2000) throw new Error('报表要求须为 1–2000 字');
    if (!PROJECTS.some(p => p.id === input.project)) throw new Error('请选择有效项目');
    if (!Array.isArray(input.devices) || !input.devices.length || input.devices.length > 100 ||
        new Set(input.devices).size !== input.devices.length ||
        input.devices.some(id => !DEVICES.some(d => d.id === id && d.project === input.project))) throw new Error('请选择 1–100 台本项目设备');
    const from = Telemetry.parse(input.from), to = Telemetry.parse(input.to);
    if (!Number.isFinite(from) || !Number.isFinite(to) || from > to || to - from > 90 * 86400000) throw new Error('时间范围须有效、开始不晚于结束且不超过 90 天');
    return { name, prompt, project: input.project, devices: [...input.devices], from: input.from, to: input.to };
  }
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.version !== 1 || !Array.isArray(data.tasks) || data.tasks.length > 100) throw new Error('无效存档');
      tasks = data.tasks.map(t => {
        if (typeof t.id !== 'string' || !t.id || typeof t.created !== 'string' ||
            !['pending', 'blocked'].includes(t.status)) throw new Error('无效任务');
        return { ...validate(t), id: t.id, created: t.created, status: t.status };
      });
      if (new Set(tasks.map(t => t.id)).size !== tasks.length) throw new Error('重复任务');
    }
  } catch (e) { tasks = []; loadError = true; }
  const clone = value => JSON.parse(JSON.stringify(value));
  const persist = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, tasks })); return true; }
    catch (e) { return false; }
  };
  return {
    get loadError() { return loadError; },
    list: () => clone(tasks),
    task: id => { const task = tasks.find(t => t.id === id); return task ? clone(task) : null; },
    create(input) {
      if (tasks.length >= 100) throw new Error('最多保存 100 个任务');
      const task = { ...validate(input), id: crypto.randomUUID(), created: Telemetry.format(Date.now()), status: 'pending' };
      tasks.push(task);
      return { id: task.id, persisted: persist() };
    },
    generate(id) {
      const task = tasks.find(t => t.id === id);
      if (!task) throw new Error('任务不存在');
      validate(task);
      task.status = 'blocked';
      return persist();
    }
  };
})();
