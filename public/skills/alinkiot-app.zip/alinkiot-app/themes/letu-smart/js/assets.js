const Assets = (() => {
  const key = 'letu-assets-v1';
  const industries = ['水务', '环保', '能源', '供热', '市政', '园区', '制造', '农业'];
  const text = (value, label, max, required = false) => {
    if (typeof value !== 'string') throw new Error(label + '格式不正确');
    const result = value.trim();
    if (required && !result) throw new Error('请填写' + label);
    if (result.length > max) throw new Error(label + '不能超过 ' + max + ' 个字符');
    if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(result)) throw new Error(label + '含有无效字符');
    return result;
  };
  const unique = (list, id, field, value, label) => {
    if (value && list.some(item => item.id !== id && item[field].toLocaleLowerCase() === value.toLocaleLowerCase())) {
      throw new Error(label + '已存在');
    }
  };
  const customerFields = (input, id, list) => {
    const name = text(input.name, '客户名称', 80, true);
    const short = text(input.short, '客户简称', 20, true);
    const contact = text(input.contact, '联系人', 40);
    const phone = text(input.phone, '联系电话', 30);
    if (phone && !/^[+\d()（）\s-]{3,30}$/.test(phone)) throw new Error('联系电话只能包含数字、空格、加号、括号和短横线');
    if (!industries.includes(input.industry)) throw new Error('请选择有效行业');
    unique(list, id, 'name', name, '客户名称');
    return { name, short, contact, phone, industry: input.industry };
  };
  const projectFields = (input, id, list, customers) => {
    const name = text(input.name, '项目名称', 80, true);
    const code = text(input.code, '项目编号', 40, true);
    if (!/^[A-Za-z0-9_-]+$/.test(code)) throw new Error('项目编号只能包含字母、数字、短横线和下划线');
    const desc = text(input.desc, '项目描述', 500);
    const apiId = text(input.apiId, 'API 项目 ID', 80);
    if (input.customer !== '' && !customers.some(c => c.id === input.customer)) throw new Error('所属客户不存在');
    if (!['active', 'paused', 'disabled'].includes(input.status)) throw new Error('项目状态不正确');
    unique(list, id, 'code', code, '项目编号');
    unique(list, id, 'apiId', apiId, 'API 项目 ID');
    return { name, code, desc, apiId, customer: input.customer, status: input.status };
  };
  const counts = () => {
    CUSTOMERS.forEach(c => {
      const projects = PROJECTS.filter(p => p.customer === c.id);
      c.projects = projects.length;
      c.devices = projects.reduce((total, p) => total + p.devices, 0);
    });
    DEVICES.forEach(d => { d.customer = PROJECTS.find(p => p.id === d.project)?.customer || ''; });
  };
  let loadError = false;
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const saved = JSON.parse(raw);
      if (saved.version !== 1 || !Array.isArray(saved.customers) || !Array.isArray(saved.projects) ||
          saved.customers.length > 2000 || saved.projects.length > 10000) throw new Error('无效存档');
      const customers = [], projects = [];
      for (const c of saved.customers) {
        if (!/^C[0-9a-f-]+$/i.test(c.id) || customers.some(item => item.id === c.id) ||
            !['active', 'paused', 'disabled'].includes(c.status) ||
            !/^\d{4}-\d{2}-\d{2}$/.test(c.created) || !['S', 'A', 'B', 'C'].includes(c.level)) throw new Error('无效客户');
        customers.push({ id: c.id, ...customerFields(c, c.id, customers), status: c.status, created: c.created, level: c.level });
      }
      for (const p of saved.projects) {
        if (!/^P[0-9a-f-]+$/i.test(p.id) || projects.some(item => item.id === p.id) ||
            !/^\d{4}-\d{2}-\d{2}$/.test(p.created) ||
            !Number.isSafeInteger(p.devices) || p.devices < 0 ||
            !Number.isSafeInteger(p.online) || p.online < 0 || p.online > p.devices ||
            !Number.isSafeInteger(p.sort)) throw new Error('无效项目');
        projects.push({ id: p.id, ...projectFields(p, p.id, projects, customers),
          devices: p.devices, online: p.online, sort: p.sort, created: p.created });
      }
      if (CUSTOMERS.some(seed => !customers.some(c => c.id === seed.id)) ||
          PROJECTS.some(seed => !projects.some(p => p.id === seed.id))) throw new Error('存档缺少原始样本');
      CUSTOMERS.splice(0, CUSTOMERS.length, ...customers);
      PROJECTS.splice(0, PROJECTS.length, ...projects);
    }
  } catch (e) { loadError = true; }
  counts();
  const save = () => {
    counts();
    try {
      localStorage.setItem(key, JSON.stringify({ version: 1, customers: CUSTOMERS, projects: PROJECTS }));
      return true;
    } catch (e) { return false; }
  };
  const date = () => new Date().toLocaleDateString('sv-SE');
  const id = prefix => prefix + crypto.randomUUID();
  return {
    industries,
    loadError,
    saveCustomer(input, customerId) {
      const existing = CUSTOMERS.find(c => c.id === customerId);
      if (customerId && !existing) throw new Error('客户不存在，请重新打开列表');
      const fields = customerFields(input, customerId, CUSTOMERS);
      if (existing) Object.assign(existing, fields);
      else CUSTOMERS.unshift({ id: id('C'), ...fields, status: 'active', level: 'C', created: date(), devices: 0, projects: 0 });
      return save();
    },
    toggleCustomer(customerId) {
      const c = CUSTOMERS.find(c => c.id === customerId);
      if (!c) throw new Error('客户不存在');
      c.status = c.status === 'active' ? 'disabled' : 'active';
      return save();
    },
    saveProject(input, projectId) {
      const existing = PROJECTS.find(p => p.id === projectId);
      if (projectId && !existing) throw new Error('项目不存在，请重新打开列表');
      const fields = projectFields(input, projectId, PROJECTS, CUSTOMERS);
      if (existing && (fields.code !== existing.code || fields.customer !== existing.customer)) {
        throw new Error('编号不可修改；调整客户归属请使用分配入口');
      }
      if (existing) Object.assign(existing, fields);
      else PROJECTS.unshift({ id: id('P'), ...fields, devices: 0, online: 0, sort: 0, created: date() });
      return save();
    },
    assignProject(projectId, customer) {
      const p = PROJECTS.find(p => p.id === projectId);
      if (!p) throw new Error('项目不存在');
      if (customer && !CUSTOMERS.some(c => c.id === customer)) throw new Error('客户不存在');
      p.customer = customer;
      const persisted = save();
      const grantsPersisted = typeof Accounts === 'undefined' || Accounts.reconcile();
      return persisted && grantsPersisted;
    }
  };
})();

function finishAssetChange(persisted, message, reset = false) {
  if (reset) Object.assign(Workspace.page(CURRENT), { search: '', status: '', cust: '', page: 1 });
  go(CURRENT);
  toast(persisted ? message + '（本地演示）' : message + '，但浏览器存储不可用，刷新将丢失', persisted ? 'ok' : 'warn');
}

function bindAssetForm(submit) {
  const form = document.getElementById('assetForm');
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    try { submit(Object.fromEntries(new FormData(form))); }
    catch (e) {
      const error = form.querySelector('[data-form-error]');
      error.textContent = e.message;
      error.hidden = false;
    }
  });
}

function editCustomer(customer) {
  const c = customer || { name: '', short: '', contact: '', phone: '', industry: '水务' };
  openModal(customer ? '编辑客户' : '新增客户', `
    <form id="assetForm">
      <div class="form-field"><label>客户名称 <span class="req">*</span></label>
        <input class="inp" name="name" required maxlength="80" value="${escapeHTML(c.name)}" placeholder="请输入客户全称"/></div>
      <div class="form-row">
        <div class="form-field"><label>客户简称 <span class="req">*</span></label><input class="inp" name="short" required maxlength="20" value="${escapeHTML(c.short)}"/></div>
        <div class="form-field"><label>所属行业</label><select class="sel" name="industry">
          ${Assets.industries.map(industry => `<option ${c.industry === industry ? 'selected' : ''}>${industry}</option>`).join('')}</select></div>
      </div>
      <div class="form-row">
        <div class="form-field"><label>联系人</label><input class="inp" name="contact" maxlength="40" value="${escapeHTML(c.contact)}"/></div>
        <div class="form-field"><label>联系电话</label><input class="inp" name="phone" type="tel" maxlength="30" value="${escapeHTML(c.phone)}"/></div>
      </div>
      <p class="hint">这里只维护客户档案，不会创建登录账号。客户管理员开通将在账号管理中独立完成。</p>
      <p data-form-error role="alert" hidden style="color:var(--danger)"></p>
    </form>`, `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
      <button type="submit" form="assetForm" class="btn btn-primary">保存客户</button>`);
  bindAssetForm(input => finishAssetChange(Assets.saveCustomer(input, customer?.id), '客户信息已保存', !customer));
}

function editProject(project) {
  const p = project || { name: '', code: '', desc: '', apiId: '', customer: '', status: 'active' };
  openModal(project ? '编辑项目' : '手工新建项目', `
    <form id="assetForm">
      <div class="form-row">
        <div class="form-field"><label>项目名称 <span class="req">*</span></label><input class="inp" name="name" required maxlength="80" value="${escapeHTML(p.name)}"/></div>
        <div class="form-field"><label>项目编号 <span class="req">*</span></label><input class="inp" name="code" required maxlength="40" value="${escapeHTML(p.code)}" ${project ? 'readonly' : ''}/></div>
      </div>
      <div class="form-field"><label>项目描述</label><textarea class="inp" name="desc" rows="3" maxlength="500">${escapeHTML(p.desc)}</textarea></div>
      <div class="form-row">
        <div class="form-field"><label>所属客户</label><select class="sel" name="customer" ${project ? 'disabled' : ''}>
          <option value="">未分配</option>${customerOptions(p.customer)}</select></div>
        <div class="form-field"><label>项目状态</label><select class="sel" name="status">
          ${[['active', '运行中'], ['paused', '已暂停'], ['disabled', '已停用']].map(([value, name]) =>
            `<option value="${value}" ${value === p.status ? 'selected' : ''}>${name}</option>`).join('')}</select></div>
      </div>
      <div class="form-field"><label>API 项目 ID（可选）</label><input class="inp" name="apiId" maxlength="80" value="${escapeHTML(p.apiId)}"/></div>
      <p class="hint">手工项目初始设备数为 0。修改状态不模拟设备上下线；API ID 仅为本地映射，不会调用外部接口。调整归属请使用“分配给客户”。</p>
      <p data-form-error role="alert" hidden style="color:var(--danger)"></p>
    </form>`, `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
      <button type="submit" form="assetForm" class="btn btn-primary">保存项目</button>`);
  bindAssetForm(input => {
    if (project) input.customer = project.customer;
    finishAssetChange(Assets.saveProject(input, project?.id), '项目信息已保存', !project);
  });
}

function customerOptions(selected) {
  return CUSTOMERS.map(c => `<option value="${c.id}" ${selected === c.id ? 'selected' : ''}>${escapeHTML(c.name)}${c.status === 'active' ? '' : '（非正常运营）'}</option>`).join('');
}

function assignProject(project) {
  openModal('调整项目归属', `
    <form id="assetForm">
      <p>${escapeHTML(project.name)}</p>
      <div class="form-field"><label>绑定客户</label><select class="sel" name="customer">
        <option value="">未分配（从客户收回）</option>${customerOptions(project.customer)}</select></div>
      <p class="hint">当前归属：${escapeHTML((CUSTOMERS.find(c => c.id === project.customer) || {}).name || '未分配')}。保存后同时更新客户的项目数与设备数，设备仍属于原项目。</p>
      <p class="hint">转移或收回时会清理原客户下全部相关本地账号授权，包括已停用账号；不会自动给新客户个人账号授权。账号授权请到“角色权限”页维护，其他业务页面尚未接入统一身份。</p>
      <label class="check-line"><input type="checkbox" required name="confirmed"/><i></i>我已确认本次归属调整</label>
      <p data-form-error role="alert" hidden style="color:var(--danger)"></p>
    </form>`, `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
      <button type="submit" form="assetForm" class="btn btn-primary">保存归属</button>`);
  bindAssetForm(input => finishAssetChange(Assets.assignProject(project.id, input.customer), '项目归属已保存'));
}

function confirmCustomerStatus(customer) {
  const disabling = customer.status === 'active';
  openModal(disabling ? '停用客户' : '恢复客户', `
    <p>${escapeHTML(customer.name)}</p>
    <p class="hint">${disabling ? '停用后保留项目、设备和历史数据，不会删除或转移项目。本地演示仅改变档案状态，不拦截登录或数据访问。' : '恢复为正常运营；原项目归属保持不变。'}</p>`,
    `<button class="btn btn-ghost" onclick="closeModal()">取消</button><button class="btn btn-primary" data-confirm-status>确认${disabling ? '停用' : '恢复'}</button>`);
  document.querySelector('[data-confirm-status]').addEventListener('click', () =>
    finishAssetChange(Assets.toggleCustomer(customer.id), disabling ? '客户已停用' : '客户已恢复'));
}

function downloadCSV(filename, rows) {
  const csv = rows.map(row => row.map(value => {
    let text = String(value ?? '');
    if (/^[\s]*[=+\-@]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
