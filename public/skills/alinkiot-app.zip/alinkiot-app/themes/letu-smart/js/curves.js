const Curves = (() => {
  const key = 'letu-curves-v1';
  const metrics = { flow: '瞬时流量', level: '液位', press: '压力', water: '水质浓度', temp: '温度', power: '电能示值' };
  const colors = ['#3b82f6', '#22d3ee', '#818cf8', '#fbbf24', '#34d399', '#fb7185'];
  let items = DEVICES.slice(0, 3).map((d, i) => ({ id: 'seed-' + i, device: d.id, name: d.name + ' · ' + d.code }));
  let range = '7', loadError = false;
  const validate = (input, list, except) => {
    if (!DEVICES.some(d => d.id === input.device)) throw new Error('请选择有效设备');
    if (typeof input.name !== 'string' || !input.name.trim() || input.name.trim().length > 80 ||
        /[\u0000-\u001f]/.test(input.name)) throw new Error('曲线名称须为 1–80 个有效字符');
    if (list.some(c => c.id !== except && c.device === input.device)) throw new Error('该设备已在当前曲线列表中');
    return { device: input.device, name: input.name.trim() };
  };
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const state = JSON.parse(raw);
      if (state.version !== 1 || !Array.isArray(state.items) || state.items.length > 12 ||
          !['24', '7', '30'].includes(state.range)) throw new Error('无效存档');
      const loaded = [];
      for (const c of state.items) {
        if (!c || typeof c.id !== 'string' || !/^[a-z0-9-]+$/i.test(c.id) || loaded.some(x => x.id === c.id)) throw new Error('无效曲线');
        loaded.push({ id: c.id, ...validate(c, loaded, c.id) });
      }
      items = loaded;
      range = state.range;
    }
  } catch (e) { loadError = true; }
  const save = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, items, range })); return true; }
    catch (e) { return false; }
  };
  return {
    metrics, colors, loadError,
    list: () => items.map(c => ({ ...c })),
    get range() { return range; },
    setRange(value) {
      if (!['24', '7', '30'].includes(value)) throw new Error('时间范围不正确');
      range = value;
      return save();
    },
    add(input) {
      const fields = validate(input, items);
      if (items.length >= 12) throw new Error('最多展示 12 台设备，请先移除部分曲线');
      items.push({ id: crypto.randomUUID(), ...fields });
      return save();
    },
    rename(id, name) {
      const item = items.find(c => c.id === id);
      if (!item) throw new Error('曲线已不存在');
      Object.assign(item, validate({ ...item, name }, items, id));
      return save();
    },
    select(ids) {
      if (!Array.isArray(ids) || ids.length > 12 || new Set(ids).size !== ids.length) throw new Error('请选择不超过 12 台不同设备');
      const selected = ids.map(id => {
        const device = DEVICES.find(d => d.id === id);
        if (!device) throw new Error('所选设备不存在');
        return items.find(c => c.device === id) || {
          id: crypto.randomUUID(), ...validate({ device: id, name: device.name + ' · ' + device.code }, [])
        };
      });
      items = selected;
      return save();
    },
    remove(id) {
      if (!items.some(c => c.id === id)) throw new Error('曲线已不存在');
      items = items.filter(c => c.id !== id);
      return save();
    },
    clear() { items = []; return save(); },
    query(device) {
      const time = range === '24' ? {
        from: Telemetry.format(Telemetry.end - 24 * 3600000).slice(0, 16).replace(' ', 'T'),
        to: Telemetry.format(Telemetry.end).slice(0, 16).replace(' ', 'T')
      } : Telemetry.defaults(range);
      return Telemetry.query(device, time.from, time.to);
    }
  };
})();
