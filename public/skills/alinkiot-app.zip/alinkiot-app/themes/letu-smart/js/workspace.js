const Workspace = (() => {
  const key = 'letu-workspace-v1';
  let state = {};
  try { state = JSON.parse(localStorage.getItem(key)) || {}; } catch (e) {}
  if (typeof state !== 'object' || Array.isArray(state)) state = {};
  const pages = state.pages && typeof state.pages === 'object' && !Array.isArray(state.pages) ? state.pages : {};
  let project = PROJECTS.some(p => p.id === state.project) ? state.project : '';
  return {
    page(id) {
      if (!pages[id] || typeof pages[id] !== 'object' || Array.isArray(pages[id])) pages[id] = {};
      return pages[id];
    },
    get project() { return project; },
    setProject(id) {
      project = PROJECTS.some(p => p.id === id) ? id : '';
      ['devices', 'realtime', 'history'].forEach(id => { this.page(id).page = 1; });
      this.save();
    },
    save() {
      try { localStorage.setItem(key, JSON.stringify({ project, pages })); } catch (e) {}
    },
    projectSelect() {
      return `<label>项目范围 <select class="sel" data-project-scope aria-label="项目范围">
        <option value="">全部项目</option>
        ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}
      </select></label>`;
    }
  };
})();
