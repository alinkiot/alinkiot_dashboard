function openSyncTask() {
  openDrawer('新建同步任务', `<form id="syncTaskForm">
    <div class="form-field"><label>任务名称</label><input class="inp" name="name" required maxlength="80"/></div>
    <div class="form-field"><label>项目范围</label><select class="sel" name="project"><option value="">统一任务（全部项目，仅超管）</option>
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === Workspace.project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <div class="form-field"><label>设备平台 URL</label><input class="inp" name="url" type="url" required maxlength="500" value="https://devices.example.com"/></div>
    <div class="form-field"><label>AppID（示例）</label><input class="inp" name="appid" required maxlength="100" value="demo-device-app"/></div>
    <div class="form-field"><label>Secret</label><input class="inp" type="password" disabled placeholder="演示不接收真实 Secret；生产凭证仅后端保存"/></div>
    <button class="btn btn-ghost" type="button" data-sync-discover>获取产品列表（示例）</button>
    <p class="hint">获取来源产品及属性后选择产品，再为数值采样属性绑定公式。不选公式的字段原样保存；输出单位须确认。</p>
    <div data-sync-products></div>
    <div class="form-field"><label>同步间隔（分钟）</label><input class="inp" name="interval" type="number" required min="1" max="1440" step="1" value="5"/></div>
    <label><input type="checkbox" name="enabled"/>保存为启用配置（未运行）</label>
    <p class="hint">产品列表为本地样本，公式为固定模板示例，不是已接通的来源或真实公式库。本次仅保存映射，不请求设备 API、不建表、不计算、不入库、不调度。</p>
    <p data-sync-error role="alert" hidden style="color:var(--danger)"></p></form>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" form="syncTaskForm" type="submit">保存任务</button>');
  const form = document.getElementById('syncTaskForm'), host = form.querySelector('[data-sync-products]');
  let discovered;
  const error = e => { const node = form.querySelector('[data-sync-error]'); node.textContent = e.message; node.hidden = false; };
  const invalidate = () => { discovered = null; host.innerHTML = '<p class="hint">接入配置已改变，请重新获取产品。</p>'; };
  form.elements.url.oninput = invalidate;
  form.elements.appid.oninput = invalidate;
  form.querySelector('[data-sync-discover]').onclick = () => {
    try {
      discovered = SyncWorkspace.discover({ url: form.elements.url.value, appid: form.elements.appid.value });
      host.innerHTML = discovered.products.map(p => `<section class="card" data-sync-product="${p.id}" style="margin-top:12px"><div class="card-body">
        <label><input type="checkbox" data-sync-product-enabled/>${escapeHTML(p.name)}</label>
        <div class="hint">未选产品不参与任务；勾选后可绑定属性公式。</div>
        ${p.properties.filter(prop => prop.type === 'number' && prop.source === 'telemetry').map(prop =>
          `<div class="property-row" data-sync-property="${prop.key}"><span>${escapeHTML(prop.name)}（${escapeHTML(prop.unit)}）</span>
            <select class="sel" data-sync-formula disabled aria-label="${escapeHTML(p.name + ' ' + prop.name)}公式"><option value="">不计算 · 原样保存</option>
              ${SyncWorkspace.formulas().map(f => `<option value="${f.id}">${escapeHTML(f.name)} v${f.version} · ${escapeHTML(f.expression)}</option>`).join('')}</select>
            <label>输出单位 <input class="inp" data-sync-unit disabled maxlength="20" value="${escapeHTML(prop.unit)}"/></label></div>`).join('')}
      </div></section>`).join('') || '<p class="hint">暂无产品样本</p>';
      form.querySelector('[data-sync-error]').hidden = true;
    } catch (e) { invalidate(); error(e); }
  };
  host.onchange = event => {
    if (!event.target.matches('[data-sync-product-enabled]')) return;
    event.target.closest('[data-sync-product]').querySelectorAll('[data-sync-formula],[data-sync-unit]').forEach(input => {
      input.disabled = !event.target.checked;
    });
  };
  form.onsubmit = event => {
    event.preventDefault();
    try {
      if (!discovered) throw new Error('请先获取产品列表');
      const source = SyncWorkspace.discover({ url: form.elements.url.value, appid: form.elements.appid.value });
      if (source.url !== discovered.url || source.appid !== discovered.appid) throw new Error('接入配置已改变，请重新获取产品');
      const products = [...host.querySelectorAll('[data-sync-product]')].filter(card =>
        card.querySelector('[data-sync-product-enabled]').checked).map(card => ({
        id: card.dataset.syncProduct, bindings: [...card.querySelectorAll('[data-sync-property]')].flatMap(row => {
          const formula = SyncWorkspace.formulas().find(f => f.id === row.querySelector('[data-sync-formula]').value);
          return formula ? [{ property: row.dataset.syncProperty, formulaId: formula.id, version: formula.version,
            unit: row.querySelector('[data-sync-unit]').value }] : [];
        })
      }));
      const result = SyncWorkspace.create({ name: form.elements.name.value, url: source.url, appid: source.appid,
        project: form.elements.project.value, interval: Number(form.elements.interval.value), enabled: form.elements.enabled.checked, products });
      Object.assign(Workspace.page('sync'), { selected: result.id, opened: false }); Workspace.save(); go('sync');
      toast(result.persisted ? '任务与公式映射已保存，未执行同步或计算' : '仅内存保存，存储失败，刷新将丢失', result.persisted ? 'ok' : 'warn');
    } catch (e) { error(e); }
  };
}
VIEWS.sync = {
  group: '系统', title: '同步任务',
  render() {
    const state = Workspace.page('sync'), tasks = SyncWorkspace.list(), current = state.opened && SyncWorkspace.task(state.selected);
    const status = task => task.enabled ? '配置已启用 · 未运行' : '配置已停用';
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">同步任务</div>
      <div class="page-desc">接入设备 API → 获取产品属性 → 绑定公式 → 采样计算入库（未接入）</div></div>
      <div class="page-actions">${current ? '<button class="btn btn-ghost" data-sync-back>返回列表</button>' :
        '<button class="btn btn-primary" data-sync-add>新建同步任务</button>'}</div></div>
      <p class="hint">本地任务配置示例：Secret 不保存，产品/公式为样本；未连接 API、数据库、调度与公式执行器，无真实执行记录。</p>
      ${SyncWorkspace.loadError ? '<p class="hint">同步任务存档无法读取，已回退空列表。</p>' : ''}
      ${current ? `<section class="card"><div class="card-head"><h3>${escapeHTML(current.name)}</h3>
        <button class="btn btn-ghost" data-sync-toggle="${current.id}">${current.enabled ? '停用配置' : '启用配置'}</button></div>
        <div class="card-body"><p>项目：${escapeHTML(current.project ? projName(current.project) : '统一任务')}</p>
          <p style="overflow-wrap:anywhere">URL：${escapeHTML(current.url)}</p><p>AppID：${escapeHTML(current.appid)} · Secret 未配置</p>
          <p>间隔：${current.interval} 分钟 · ${status(current)}</p>
          ${current.products.map(p => `<h4>${escapeHTML(p.name)}</h4>${p.bindings.map(b =>
            `<p>${escapeHTML(b.property)} → ${escapeHTML(b.expression)}（v${b.version}） · 输出 ${escapeHTML(b.unit) || '无单位'}</p>`).join('') ||
            '<p class="hint">未绑定公式，采样字段原样保存。</p>'}`).join('')}
          <div class="empty"><h4>暂无执行记录</h4><p>配置保存不代表公式已计算或数据已入库。</p></div></div></section>` :
        `<div class="panel-grid">${tasks.map(task => `<article class="card"><div class="card-body"><h3>${escapeHTML(task.name)}</h3>
          <p class="hint">${escapeHTML(task.project ? projName(task.project) : '统一任务')} · ${task.products.length} 个产品 · 每 ${task.interval} 分钟</p>
          <p>${status(task)}</p><div class="panel-actions"><button class="btn btn-primary btn-sm" data-sync-open="${task.id}">查看任务</button>
            <button class="btn btn-ghost btn-sm" data-sync-toggle="${task.id}">${task.enabled ? '停用配置' : '启用配置'}</button></div>
        </div></article>`).join('')}</div>${tasks.length ? '' : '<div class="empty"><h4>暂无同步任务</h4><p>新建任务并获取产品列表，配置需要处理的属性公式。</p></div>'}`}</div>`;
  },
  mount(scope) {
    const state = Workspace.page('sync');
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      if (button.hasAttribute('data-sync-add')) openSyncTask();
      if (button.dataset.syncOpen) { Object.assign(state, { selected: button.dataset.syncOpen, opened: true }); Workspace.save(); go('sync'); }
      if (button.hasAttribute('data-sync-back')) { state.opened = false; Workspace.save(); go('sync'); }
      if (button.dataset.syncToggle) {
        try {
          const persisted = SyncWorkspace.toggle(button.dataset.syncToggle); go('sync');
          toast('启停配置已更新，未运行同步' + (persisted ? '' : '；存储失败'), persisted ? 'info' : 'warn');
        } catch (e) { toast(e.message, 'warn'); }
      }
    });
  }
};
