function openAIReportTask() {
  const project = Workspace.project || PROJECTS[0]?.id, range = Telemetry.defaults('7');
  openDrawer('新建报表任务', `<form id="aiReportTaskForm">
    <div class="form-field"><label>任务名称</label><input class="inp" name="name" required maxlength="80"/></div>
    <div class="form-field"><label>项目</label><select class="sel" name="project" required aria-label="报表任务项目">
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <div class="form-row"><div class="form-field"><label>开始时间 +08:00</label><input class="inp" name="from" type="datetime-local" required value="${range.from}"/></div>
      <div class="form-field"><label>结束时间 +08:00</label><input class="inp" name="to" type="datetime-local" required value="${range.to}"/></div></div>
    <h4>关联设备</h4><div class="panel-device-picker" data-ai-task-devices></div>
    <div class="form-field"><label>报表要求</label><textarea class="inp" name="prompt" rows="5" style="height:auto" required maxlength="2000" placeholder="例如：生成设备运行周报，包含各设备趋势、关键指标和异常说明，不混合不同单位。"></textarea></div>
    <p class="hint">任务仅保存本地配置，最多 100 台本项目设备、时间范围不超过 90 天。尚未接入 AI 与任务执行服务，不会生成报表或自动调度。</p>
    <p data-ai-task-error role="alert" hidden style="color:var(--danger)"></p></form>`,
    '<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" form="aiReportTaskForm" type="submit">保存任务</button>');
  const form = document.getElementById('aiReportTaskForm');
  const paint = () => {
    form.querySelector('[data-ai-task-devices]').innerHTML = DEVICES.filter(d => d.project === form.elements.project.value).map(d =>
      `<label class="check-line"><input type="checkbox" name="device" value="${d.id}"/><i></i>${escapeHTML(d.name)} · ${escapeHTML(d.code)}</label>`).join('') || '<p class="hint">该项目暂无设备</p>';
  };
  form.elements.project.onchange = paint;
  form.onsubmit = event => {
    event.preventDefault();
    try {
      const result = AIReportTasks.create({ name: form.elements.name.value, project: form.elements.project.value,
        from: form.elements.from.value, to: form.elements.to.value, prompt: form.elements.prompt.value,
        devices: [...form.querySelectorAll('[name=device]:checked')].map(input => input.value) });
      Object.assign(Workspace.page('ai-report'), { selected: result.id, opened: false });
      Workspace.save(); go('ai-report');
      toast(result.persisted ? '任务已保存，尚未生成报表' : '任务仅内存保存，存储失败，刷新将丢失', result.persisted ? 'ok' : 'warn');
    } catch (e) {
      const error = form.querySelector('[data-ai-task-error]');
      error.textContent = e.message; error.hidden = false;
    }
  };
  paint();
}
VIEWS['ai-report'] = {
  group: 'AI 能力', title: '智能报表',
  render() {
    const state = Workspace.page('ai-report'), tasks = AIReportTasks.list();
    const current = state.opened && AIReportTasks.task(state.selected);
    const status = task => task.status === 'blocked' ? '未接入 AI · 未生成' : '待生成';
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">智能报表</div>
      <div class="page-desc">新建报表任务 · 指定数据范围与报表要求 · 由 AI 生成报表（未接入）</div></div>
      <div class="page-actions">${current ? '<button class="btn btn-ghost" data-ai-task-back>返回列表</button>' :
        '<button class="btn btn-primary" data-ai-task-add>新建报表任务</button>'}</div></div>
      <p class="hint">本地任务演示，未连接 AI、数据库与执行服务，不生成报告、不自动运行；任务未按账号隔离。</p>
      ${AIReportTasks.loadError ? '<p class="hint">任务存档无法读取，已回退空列表。</p>' : ''}
      ${current ? `<section class="card"><div class="card-head"><h3>${escapeHTML(current.name)}</h3>
        <button class="btn btn-primary" data-ai-task-generate="${current.id}">AI 生成报表</button></div><div class="card-body">
        <p>项目：${escapeHTML(projName(current.project))}</p><p>时间：${escapeHTML(current.from)} 至 ${escapeHTML(current.to)}（+08:00）</p>
        <p>创建：${escapeHTML(current.created)}</p><p>状态：${status(current)}</p>
        <h4>报表要求</h4><p style="white-space:pre-wrap;overflow-wrap:anywhere">${escapeHTML(current.prompt)}</p>
        <h4>关联设备（${current.devices.length} 台）</h4><ul>${current.devices.map(id => {
          const device = DEVICES.find(d => d.id === id);
          return `<li>${escapeHTML(device?.name || id)} · ${escapeHTML(device?.code || '设备已移除')}</li>`;
        }).join('')}</ul><div class="empty"><h4>暂无生成报表</h4><p>未接入 AI，未发送请求，也没有生成结果。</p></div>
      </div></section>` : `<div class="panel-grid">${tasks.map(task => `<article class="card"><div class="card-body">
        <h3>${escapeHTML(task.name)}</h3><p class="hint">${escapeHTML(projName(task.project))} · ${task.devices.length} 台设备</p>
        <p class="hint">${escapeHTML(task.from)} 至 ${escapeHTML(task.to)}</p><p>${status(task)}</p>
        <div class="panel-actions"><button class="btn btn-primary btn-sm" data-ai-task-open="${task.id}">查看任务</button>
          <button class="btn btn-ghost btn-sm" data-ai-task-generate="${task.id}">AI 生成报表</button></div>
      </div></article>`).join('')}</div>${tasks.length ? '' : '<div class="empty"><h4>暂无报表任务</h4><p>新建任务并指定项目、设备、时间与报表要求。</p></div>'}`}</div>`;
  },
  mount(scope) {
    const state = Workspace.page('ai-report');
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      if (button.hasAttribute('data-ai-task-add')) openAIReportTask();
      if (button.dataset.aiTaskOpen) {
        Object.assign(state, { selected: button.dataset.aiTaskOpen, opened: true }); Workspace.save(); go('ai-report');
      }
      if (button.hasAttribute('data-ai-task-back')) { state.opened = false; Workspace.save(); go('ai-report'); }
      if (button.dataset.aiTaskGenerate) {
        try {
          const persisted = AIReportTasks.generate(button.dataset.aiTaskGenerate);
          go('ai-report');
          toast('未接入 AI，本次未发送请求、未生成报表' + (persisted ? '' : '；状态存储失败'), 'warn');
        } catch (e) { toast(e.message, 'warn'); }
      }
    });
  }
};
