const Accounts = (() => {
  const key = 'letu-accounts-v1';
  const roles = { superadmin: '超级管理员', admin: '客户管理员', user: '普通用户' };
  const capabilities = {
    export: '导出数据', report: '生成与下载报表', shared: '编辑共享曲线/报表/大屏',
    governance: '治理与接入配置', sync: '项目同步任务', alarms: '告警配置与处理'
  };
  const ceiling = role => role === 'admin' ? Object.keys(capabilities) : role === 'user' ? ['export', 'report'] : [];
  const grant = (project, role) => ({ project, capabilities: ceiling(role) });
  const seed = (id, name, role, customer, projects) => ({
    id, username: id, name, role, customer, status: 'active', grants: projects.map(p => grant(p, role))
  });
  let users = [
    seed('admin', '系统管理员', 'superadmin', '', []),
    seed('chenzy', '陈志远', 'admin', 'C001', ['P1001', 'P1002', 'P1003']),
    seed('wangxl', '王晓琳', 'admin', 'C001', ['P1002']),
    seed('liwn', '李婉宁', 'admin', 'C002', ['P2001', 'P2002']),
    seed('wanght', '王海涛', 'admin', 'C003', ['P3001', 'P3002', 'P3003', 'P3004']),
    seed('lizq', '李清泉', 'user', 'C001', ['P1001', 'P1002']),
    seed('wangf', '王芳', 'user', 'C002', ['P2001']),
    seed('zhaol', '赵磊', 'user', 'C001', [])
  ];
  let actorId = 'admin';
  let loadError = false;
  const clone = value => JSON.parse(JSON.stringify(value));
  const cleanText = (value, label, max) => {
    if (typeof value !== 'string' || !value.trim() || value.trim().length > max ||
        /[\u0000-\u001f]/.test(value)) throw new Error(label + '不能为空或超过 ' + max + ' 个字符');
    return value.trim();
  };
  const validateGrants = (grants, role) => {
    if (!Array.isArray(grants)) throw new Error('项目授权格式不正确');
    const seen = new Set();
    return grants.map(g => {
      if (!g || typeof g.project !== 'string' || seen.has(g.project) || !Array.isArray(g.capabilities) ||
          g.capabilities.some(c => !ceiling(role).includes(c)) ||
          new Set(g.capabilities).size !== g.capabilities.length) throw new Error('项目授权重复或突破固定角色上限');
      seen.add(g.project);
      return { project: g.project, capabilities: [...g.capabilities] };
    });
  };
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const state = JSON.parse(raw);
      if (state.version !== 1 || !Array.isArray(state.users) || !state.users.length || state.users.length > 5000) throw new Error('无效存档');
      const loaded = [];
      for (const u of state.users) {
        if (!u || typeof u.id !== 'string' || !/^[A-Za-z0-9-]+$/.test(u.id) ||
            loaded.some(x => x.id === u.id) || !Object.hasOwn(roles, u.role) ||
            !['active', 'disabled'].includes(u.status)) throw new Error('无效账号');
        const username = cleanText(u.username, '登录账号', 40);
        const name = cleanText(u.name, '显示姓名', 40);
        if (!/^[A-Za-z][A-Za-z0-9_.-]{2,39}$/.test(username) ||
            loaded.some(x => x.username.toLowerCase() === username.toLowerCase())) throw new Error('登录账号重复或格式不正确');
        if (u.role === 'superadmin' ? u.id !== 'admin' || u.customer !== '' || u.status !== 'active' :
            !CUSTOMERS.some(c => c.id === u.customer)) throw new Error('账号客户或角色不正确');
        const grants = validateGrants(u.grants, u.role);
        if (u.role === 'superadmin' && grants.length) throw new Error('超管不绑定项目授权');
        loaded.push({ id: u.id, username, name, role: u.role, customer: u.customer, status: u.status, grants });
      }
      if (!loaded.some(u => u.id === 'admin' && u.role === 'superadmin')) throw new Error('缺少演示超管');
      users = loaded;
      actorId = typeof state.actorId === 'string' ? state.actorId : 'admin';
    }
  } catch (e) { loadError = true; }
  const actor = () => {
    const u = users.find(u => u.id === actorId);
    if (!u || u.status !== 'active') throw new Error('当前演示账号不可用，请切换身份');
    return u;
  };
  const effective = user => user.grants.filter(g => PROJECTS.some(p => p.id === g.project && p.customer === user.customer));
  const save = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, users, actorId })); return true; }
    catch (e) { return false; }
  };
  const reconcile = () => {
    let changed = false;
    users.forEach(u => {
      const grants = effective(u);
      if (grants.length !== u.grants.length) { u.grants = grants; changed = true; }
    });
    if (!users.some(u => u.id === actorId && u.status === 'active')) { actorId = 'admin'; changed = true; }
    return changed ? save() : true;
  };
  reconcile();
  const scopeProjects = (who, customer) => who.role === 'superadmin'
    ? PROJECTS.filter(p => p.customer === customer)
    : PROJECTS.filter(p => p.customer === who.customer && effective(who).some(g => g.project === p.id));
  const manage = target => {
    const who = actor();
    if (!target || target.id === who.id ||
        !(who.role === 'superadmin' && target.role === 'admin' ||
          who.role === 'admin' && target.customer === who.customer && target.role === 'user')) {
      throw new Error('只能按固定角色边界管理账号，不能修改本人或跨客户账号');
    }
    return who;
  };
  const mergeGrants = (who, target, requested) => {
    const grants = validateGrants(requested, target.role);
    const allowed = new Set(scopeProjects(who, target.customer).map(p => p.id));
    for (const g of grants) {
      if (!allowed.has(g.project)) throw new Error('只能分配本客户且自己已获授权的项目');
      if (who.role !== 'superadmin') {
        const own = effective(who).find(x => x.project === g.project);
        if (g.capabilities.some(c => !own.capabilities.includes(c))) throw new Error('不能授予本人未获授的操作能力');
        const existing = effective(target).find(x => x.project === g.project);
        const locked = existing?.capabilities.filter(c => !own.capabilities.includes(c)) || [];
        g.capabilities.push(...locked);
      }
    }
    const preserved = effective(target).filter(g => !allowed.has(g.project));
    return [...preserved, ...grants];
  };
  return {
    roles, capabilities, ceiling, loadError,
    actor: () => clone(actor()),
    identities: () => clone(users.filter(u => u.status === 'active')),
    visible() {
      const who = actor();
      return clone(users.filter(u => who.role === 'superadmin' || (who.role === 'admin' ? u.customer === who.customer : u.id === who.id)));
    },
    effective: userId => clone(effective(users.find(u => u.id === userId) || { grants: [] })),
    grantable(customer) {
      const who = actor();
      if (who.role === 'user') return [];
      return clone(scopeProjects(who, who.role === 'superadmin' ? customer : who.customer));
    },
    selectActor(id) {
      if (!users.some(u => u.id === id && u.status === 'active')) throw new Error('请选择可用的演示身份');
      actorId = id;
      return save();
    },
    create(input) {
      const who = actor();
      if (who.role === 'user') throw new Error('普通用户不能创建账号');
      const role = who.role === 'superadmin' ? 'admin' : 'user';
      if (input.role !== role) throw new Error('不能突破固定角色创建账号');
      const customer = who.role === 'superadmin' ? input.customer : who.customer;
      if (input.customer !== customer || !CUSTOMERS.some(c => c.id === customer)) throw new Error('所属客户不在允许范围');
      const username = cleanText(input.username, '登录账号', 40);
      const name = cleanText(input.name, '显示姓名', 40);
      if (!/^[A-Za-z][A-Za-z0-9_.-]{2,39}$/.test(username)) throw new Error('账号须以字母开头，3–40 位，仅含字母、数字、点、短横线或下划线');
      if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) throw new Error('登录账号已存在');
      const target = { id: crypto.randomUUID(), username, name, role, customer, status: 'active', grants: [] };
      target.grants = mergeGrants(who, target, input.grants);
      users.push(target);
      return save();
    },
    update(userId, input) {
      const target = users.find(u => u.id === userId);
      const who = manage(target);
      if (input.role !== target.role || input.customer !== target.customer || input.username !== target.username) {
        throw new Error('账号、固定角色与客户归属不可修改');
      }
      const name = cleanText(input.name, '显示姓名', 40);
      const grants = mergeGrants(who, target, input.grants);
      Object.assign(target, { name, grants });
      return save();
    },
    canEdit(userId) {
      try { manage(users.find(u => u.id === userId)); return true; } catch (e) { return false; }
    },
    canToggle(userId) {
      const who = actor(), target = users.find(u => u.id === userId);
      return !!target && who.role === 'admin' && who.id !== target.id && target.customer === who.customer &&
        ['admin', 'user'].includes(target.role);
    },
    toggle(userId) {
      const who = actor(), target = users.find(u => u.id === userId);
      if (!this.canToggle(userId)) throw new Error('账号停用与恢复由本企业其他管理员处理，不能操作本人');
      if (target.status === 'active' && target.role === 'admin' &&
          users.filter(u => u.customer === who.customer && u.role === 'admin' && u.status === 'active').length <= 1) {
        throw new Error('不能停用本客户最后一个可用管理员');
      }
      target.status = target.status === 'active' ? 'disabled' : 'active';
      return save();
    },
    reconcile
  };
})();
