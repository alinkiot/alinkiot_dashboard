(() => {
  const scope = document.getElementById('screen-page');
  try {
    const theme = localStorage.getItem('letu-theme');
    if (theme === 'light' || theme === 'dark') document.documentElement.dataset.theme = theme;
  } catch (e) {}
  const params = new URLSearchParams(location.search), project = params.get('project'), id = params.get('panel');
  const validProject = PROJECTS.some(p => p.id === project);
  if (validProject && id === 'screen-' + project) PanelWorkspace.ensureScreen(project);
  const selected = validProject && PanelWorkspace.panels('screen', project).find(p => p.id === id);
  if (!selected) {
    scope.innerHTML = '<div class="empty"><h4>大屏不存在或已删除</h4><a class="btn btn-ghost" href="index.html#bigscreen">返回大屏管理</a></div>';
    return;
  }
  document.title = selected.name + ' · ' + projName(project) + ' · AlinkIoT';
  scope.innerHTML = VIEWS.bigscreen.display(project, selected);
  VIEWS.bigscreen.mountDisplay(scope, project, selected);
  scope.querySelector('[data-screen-alarms]')?.addEventListener('click', () => Workspace.setProject(project));
  window.addEventListener('pagehide', () => scope._cleanup?.());
})();
