const AlarmStore = (() => {
  const key = 'letu-alarms-v1';
  const states = new Map();
  const handling = ['待确认', '已确认', '已处理'];
  const stamp = () => Telemetry.format(Date.now());
  const make = project => {
    const devices = DEVICES.filter(d => d.project === project);
    if (!devices.length) return { rule: null, events: [], attempts: [] };
    const first = devices[0], second = devices[1] || first, third = devices[2] || first;
    const threshold = +(Number(first.value ?? 40) * 1.1).toFixed(3);
    return {
      rule: { device: first.id, threshold, recovery: +(threshold - Math.max(.001, threshold * .05)).toFixed(3),
        duration: 60, level: '高', enabled: true, version: 1 },
      events: [
        { id: 'AL-001', device: first.id, metric: '测点超限', evidence: '固定超限样本（非实时检测）',
          level: '高', physical: '活动', handling: '待确认', time: '2026-10-30 14:30:00',
          ruleVersion: 1, actions: [] },
        { id: 'AL-002', device: second.id, metric: '心跳超时', evidence: '固定样本：超过 10 分钟未收到心跳',
          level: '中', physical: '活动', handling: '待确认', time: '2026-10-30 14:20:00',
          ruleVersion: 1, actions: [] },
        { id: 'AL-003', device: third.id, metric: '测点超限', evidence: '历史异常样本，已恢复',
          level: '中', physical: '已恢复', handling: '已处理', time: '2026-10-30 13:00:00',
          ruleVersion: 1, actions: [{ time: '2026-10-30 13:25:00', action: '已处理', note: '初始样本：已核查' }] }
      ],
      attempts: []
    };
  };
  const validDevice = (id, project) => DEVICES.some(d => d.id === id && d.project === project);
  const validateRule = (rule, project) => {
    if (!rule || !validDevice(rule.device, project) || !Number.isFinite(rule.threshold) || !Number.isFinite(rule.recovery) ||
        Math.abs(rule.threshold) > 1e9 || Math.abs(rule.recovery) > 1e9 || rule.recovery >= rule.threshold ||
        !Number.isInteger(rule.duration) || rule.duration < 1 || rule.duration > 86400 ||
        !['高', '中', '低'].includes(rule.level) || typeof rule.enabled !== 'boolean' ||
        !Number.isSafeInteger(rule.version) || rule.version < 1) throw new Error('规则参数无效：恢复值须低于触发值，持续时间须为 1–86400 秒整数');
    return { device: rule.device, threshold: rule.threshold, recovery: rule.recovery,
      duration: rule.duration, level: rule.level, enabled: rule.enabled, version: rule.version };
  };
  const text = (value, max) => typeof value === 'string' && value.length <= max && !/[\u0000-\u001f]/.test(value);
  const validStamp = value => text(value, 19) && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value);
  let loadError = false;
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const saved = JSON.parse(raw);
      if (saved.version !== 1 || !Array.isArray(saved.projects) || saved.projects.length > 10000) throw new Error('无效存档');
      const loaded = new Map();
      for (const [project, state] of saved.projects) {
        if (!PROJECTS.some(p => p.id === project) || loaded.has(project) || !state ||
            !Array.isArray(state.events) || state.events.length > 100 ||
            !Array.isArray(state.attempts) || state.attempts.length > 100) throw new Error('无效项目告警');
        const rule = state.rule === null ? null : validateRule(state.rule, project);
        const ids = new Set();
        const events = state.events.map(e => {
          if (!e || !/^AL-\d{3}$/.test(e.id) || ids.has(e.id) || !validDevice(e.device, project) ||
              !text(e.metric, 40) || !text(e.evidence, 200) || !['高', '中', '低'].includes(e.level) ||
              !['活动', '已恢复'].includes(e.physical) || !handling.includes(e.handling) ||
              !validStamp(e.time) || !Number.isSafeInteger(e.ruleVersion) || e.ruleVersion < 1 ||
              !Array.isArray(e.actions) || e.actions.length > 3) throw new Error('无效事件');
          ids.add(e.id);
          const actions = e.actions.map(a => {
            if (!a || !validStamp(a.time) || !['已确认', '已处理'].includes(a.action) || !text(a.note, 200)) throw new Error('无效处理记录');
            return { time: a.time, action: a.action, note: a.note };
          });
          return { id: e.id, device: e.device, metric: e.metric, evidence: e.evidence, level: e.level,
            physical: e.physical, handling: e.handling, time: e.time, ruleVersion: e.ruleVersion, actions };
        });
        const attempts = state.attempts.map(a => {
          if (!a || !ids.has(a.event) || !validStamp(a.time)) throw new Error('无效通知记录');
          return { event: a.event, time: a.time };
        });
        loaded.set(project, { rule, events, attempts });
      }
      loaded.forEach((state, project) => states.set(project, state));
    }
  } catch (e) { loadError = true; }
  const get = project => {
    if (!PROJECTS.some(p => p.id === project)) throw new Error('请选择有效项目');
    if (!states.has(project)) states.set(project, make(project));
    return states.get(project);
  };
  const save = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, projects: [...states] })); return true; }
    catch (e) { return false; }
  };
  const adminOnly = role => { if (role !== 'admin') throw new Error('普通用户只能查看告警'); };
  return {
    loadError,
    snapshot: project => JSON.parse(JSON.stringify(get(project))),
    handle(project, id, action, note, role) {
      adminOnly(role);
      if (!text(note, 200) || !note.trim()) throw new Error('请填写 1–200 字处理说明');
      if (!['ack', 'resolve'].includes(action)) throw new Error('处理动作无效');
      const event = get(project).events.find(e => e.id === id);
      if (!event || event.handling === '已处理' || action === 'ack' && event.handling !== '待确认') throw new Error('当前事件状态不允许此操作');
      event.handling = action === 'ack' ? '已确认' : '已处理';
      event.actions.push({ time: stamp(), action: event.handling, note: note.trim() });
      return save();
    },
    saveRule(project, input, role) {
      adminOnly(role);
      const state = get(project);
      const next = validateRule({ ...input, version: (state.rule?.version || 0) + 1 }, project);
      state.rule = next;
      return save();
    },
    toggle(project, role) {
      adminOnly(role);
      const state = get(project);
      if (!state.rule) throw new Error('当前项目没有可编辑规则');
      state.rule = { ...state.rule, enabled: !state.rule.enabled, version: state.rule.version + 1 };
      return save();
    },
    retry(project, role) {
      adminOnly(role);
      const state = get(project);
      const event = state.events.find(e => e.id === 'AL-002');
      if (!event) throw new Error('当前项目没有可重试记录');
      if (state.attempts.length >= 100) throw new Error('本地重试记录已达 100 条上限');
      state.attempts.push({ event: event.id, time: stamp() });
      return save();
    }
  };
})();
