const AIWarningTasks = (() => {
  const key = 'letu-ai-warning-tasks-v1';
  let tasks = [], loadError = false;
  const clone = value => JSON.parse(JSON.stringify(value));
  function validate(input) {
    const name = String(input.name || '').trim(), prompt = String(input.prompt || '').trim();
    const condition = String(input.condition || '').trim();
    if (!name || name.length > 80) throw new Error('任务名称须为 1–80 字');
    if (!prompt || prompt.length > 2000) throw new Error('分析要求须为 1–2000 字');
    if (!condition || condition.length > 1000) throw new Error('触发条件须为 1–1000 字');
    if (!PROJECTS.some(p => p.id === input.project)) throw new Error('请选择有效项目');
    if (!Array.isArray(input.devices) || !input.devices.length || input.devices.length > 100 ||
        new Set(input.devices).size !== input.devices.length ||
        input.devices.some(id => !DEVICES.some(d => d.id === id && d.project === input.project))) throw new Error('请选择 1–100 台本项目设备');
    if (!Number.isInteger(input.interval) || input.interval < 1 || input.interval > 1440) throw new Error('分析间隔须为 1–1440 分钟的整数');
    if (!Number.isInteger(input.window) || input.window < 1 || input.window > 10080) throw new Error('数据窗口须为 1–10080 分钟的整数');
    if (!['高', '中', '低'].includes(input.level) || typeof input.enabled !== 'boolean') throw new Error('预警等级或启用状态无效');
    return { name, project: input.project, devices: [...input.devices], interval: input.interval, window: input.window,
      prompt, condition, level: input.level, enabled: input.enabled };
  }
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.version !== 1 || !Array.isArray(data.tasks) || data.tasks.length > 100) throw new Error('无效存档');
      tasks = data.tasks.map(task => {
        if (typeof task.id !== 'string' || !task.id || typeof task.created !== 'string') throw new Error('无效任务');
        return { ...validate(task), id: task.id, created: task.created };
      });
      if (new Set(tasks.map(t => t.id)).size !== tasks.length) throw new Error('重复任务');
    }
  } catch (e) { tasks = []; loadError = true; }
  const persist = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, tasks })); return true; }
    catch (e) { return false; }
  };
  return {
    get loadError() { return loadError; },
    list: () => clone(tasks),
    task: id => { const task = tasks.find(t => t.id === id); return task ? clone(task) : null; },
    create(input) {
      if (tasks.length >= 100) throw new Error('最多保存 100 个预警任务');
      const task = { ...validate(input), id: crypto.randomUUID(), created: Telemetry.format(Date.now()) };
      tasks.push(task);
      return { id: task.id, persisted: persist() };
    },
    toggle(id) {
      const task = tasks.find(t => t.id === id);
      if (!task) throw new Error('任务不存在');
      if (!task.enabled) validate(task);
      task.enabled = !task.enabled;
      return persist();
    }
  };
})();
