/* ═══════════════════════════════════════════
   乐图智慧 · 页面视图（展示 / 治理 / AI / 系统）
   ═══════════════════════════════════════════ */
window.VIEWS = window.VIEWS || {};

/* ═══════════ 公式配置 ═══════════ */
VIEWS.formula = {
  group: '系统', title: '公式配置',
  render() {
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">公式配置</div>
          <div class="page-desc">数据入库前按公式处理，原始值与计算值双存，公式变更版本留痕</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="test">${icon('play')}公式测试</button>
          <button class="btn btn-primary" data-act="new-formula">${icon('plus')}新建公式</button>
        </div>
      </div>

      <div class="grid g4" style="margin-bottom:16px">
        ${[
          ['公式总数', FORMULAS.length, '条', 'sigma', '覆盖 6 类设备'],
          ['已启用', FORMULAS.filter(f=>f.status==='active').length, '条', 'check', '按优先级顺序执行'],
          ['待发布', 1, '条', 'edit', 'F-007 温度校准'],
          ['计算成功率', '99.94', '%', 'target', '近 7 日异常 26 条']
        ].map(([l,v,u,ic,n]) => `<div class="kpi">
          <div class="kpi-top"><span class="kpi-label">${l}</span><span class="kpi-ico">${icon(ic)}</span></div>
          <div class="kpi-val">${v}<i>${u}</i></div><div class="kpi-foot"><span>${n}</span></div></div>`).join('')}
      </div>

      <div class="card">
        <div class="card-head"><h3><span class="dot-mark"></span>公式列表</h3>
          <div class="ch-right">
            <div class="search-box" style="min-width:200px"><span class="ico-s"></span>
              <input type="text" placeholder="搜索公式名称 / 适用对象" data-filter/></div>
          </div>
        </div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th style="width:56px">优先级</th><th>公式名称</th><th>适用对象</th>
                <th>表达式</th><th>输出</th><th>版本</th><th>状态</th><th style="text-align:right">操作</th></tr></thead>
              <tbody>
                ${FORMULAS.map(f => `<tr data-row>
                  <td><span class="badge accent plain num">P${f.priority}</span></td>
                  <td><div class="cname">${f.name}</div><div class="csub">${f.id}</div></td>
                  <td style="color:var(--text-2);font-size:11.5px;max-width:150px">${f.target}</td>
                  <td><code style="font-family:var(--mono);font-size:11px;color:var(--accent-2);background:var(--accent-soft);padding:3px 7px;border-radius:5px;display:inline-block;max-width:290px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${f.expr}</code></td>
                  <td><span class="tag">${f.unit}</span></td>
                  <td style="font-family:var(--mono);font-size:11px;color:var(--text-3)">${f.version}</td>
                  <td>${badge(f.status, f.status==='active'?'已启用':f.status==='paused'?'已停用':'草稿')}</td>
                  <td><div class="actions">
                    <button class="act-btn" data-act="edit-formula" data-id="${f.id}" title="编辑">${icon('edit')}</button>
                    <button class="act-btn" data-act="history-formula" data-id="${f.id}" title="版本">${icon('clock')}</button>
                    <button class="act-btn danger" data-act="toggle-formula" data-id="${f.id}" title="停用">${icon('pause')}</button>
                  </div></td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="grid g-2-1 mt">
        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>表达式预览 · F-004 氨氮浓度折算</h3>
            <div class="ch-right"><span class="badge ok">语法校验通过</span></div></div>
          <div class="card-body">
            <div class="formula-box">
              <span class="var">NH3N</span> <span class="op">=</span> (<span class="var">A450</span> <span class="op">-</span> <span class="var">blank</span>) <span class="op">×</span> <span class="const">1.42</span> <span class="op">/</span> <span class="var">sample_vol</span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px">
              ${[['A450','吸光度','0.386'],['blank','空白值','0.012'],['sample_vol','取样体积','25.0'],['NH3N','计算结果','21.24']].map(([k,n,v]) => `
                <div style="padding:10px 12px;border-radius:9px;background:var(--panel-hi);border:1px solid var(--line)">
                  <div style="font-family:var(--mono);font-size:11px;color:var(--accent)">${k}</div>
                  <div style="font-size:10.5px;color:var(--text-3);margin:1px 0 4px">${n}</div>
                  <div class="num" style="font-size:14px;font-weight:600">${v}</div></div>`).join('')}
            </div>
            <div class="hint" style="margin-top:12px">支持四则运算、常用数学函数（abs / min / max / round / if）与多测点参与运算；单位换算与精度按输出配置自动处理。</div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>异常处理</h3></div>
          <div class="card-body">
            <div class="timeline">
              <div class="tl-item danger"><div class="tl-t">除零异常 · 3 条</div><div class="tl-d">F-004 sample_vol = 0，保留原始值并标记未计算</div><div class="tl-time">06:30:00</div></div>
              <div class="tl-item warn"><div class="tl-t">缺参 · 12 条</div><div class="tl-d">测点 A450 无数据，跳过该条记录</div><div class="tl-time">05:12:44</div></div>
              <div class="tl-item done"><div class="tl-t">单位换算完成</div><div class="tl-d">mg/L → μg/L，共 1,286 条</div><div class="tl-time">04:00:00</div></div>
            </div>
            <div class="hint" style="margin-top:14px">公式错误、缺参、除零不阻断同步任务，异常明细独立记录可追溯。</div>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      const f = FORMULAS.find(x => x.id === b.dataset.id);
      const act = b.dataset.act;
      if (act === 'edit-formula' || act === 'new-formula') {
        openDrawer(act === 'new-formula' ? '新建公式' : '编辑公式 · ' + f.name, `
          <div class="form-field"><label>公式名称 <span class="req">*</span></label><input class="inp" value="${f ? f.name : ''}"/></div>
          <div class="form-row">
            <div class="form-field"><label>适用设备类型</label><select class="sel" style="width:100%">
              ${DEVICE_TYPES.map(t=>`<option>${t.name}</option>`).join('')}</select></div>
            <div class="form-field"><label>优先级</label><input class="inp" value="${f ? f.priority : 8}"/></div>
          </div>
          <div class="form-field"><label>表达式 <span class="req">*</span></label>
            <textarea class="inp" rows="4" style="font-family:var(--mono);font-size:12.5px">${f ? f.expr : ''}</textarea>
            <div class="hint">可用变量从右侧测点列表选择；支持 abs / min / max / round / if 等函数。</div></div>
          <div class="form-row">
            <div class="form-field"><label>输出单位</label><input class="inp" value="${f ? f.unit : ''}"/></div>
            <div class="form-field"><label>小数位</label><input class="inp" value="${f ? f.dec : 2}"/></div>
          </div>
          <div class="form-field"><label>启用状态</label>
            <label class="switch"><input type="checkbox" ${!f || f.status==='active'?'checked':''}/><i></i></label></div>
          <div class="hint">公式变更后新数据按新公式计算，历史数据保留原计算结果。</div>`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">取消</button>
           <button class="btn btn-ghost" onclick="toast('语法校验通过，示例计算结果 21.24','ok')">${icon('play')}测试</button>
           <button class="btn btn-primary" onclick="closeDrawer();toast('公式已保存，版本号 +1')">保存</button>`);
      }
      if (act === 'history-formula') {
        openDrawer('版本留痕 · ' + f.name, `
          <div class="timeline">
            <div class="tl-item done"><div class="tl-t">${f.version} · 当前版本</div>
              <div class="tl-d" style="font-family:var(--mono);font-size:11px;color:var(--accent-2)">${f.expr}</div>
              <div class="tl-time">${f.updated} · 系统管理员</div></div>
            <div class="tl-item"><div class="tl-t">v3 · 历史版本</div>
              <div class="tl-d">系数由 1.38 调整为 1.42，精度 2 位</div><div class="tl-time">2026-08-22 · 系统管理员</div></div>
            <div class="tl-item"><div class="tl-t">v2 · 历史版本</div>
              <div class="tl-d">新增空白值 blank 参与运算</div><div class="tl-time">2026-05-14 · 系统管理员</div></div>
            <div class="tl-item"><div class="tl-t">v1 · 初始版本</div>
              <div class="tl-d">首次创建</div><div class="tl-time">2026-03-02 · 系统管理员</div></div>
          </div>`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>
           <button class="btn btn-primary" onclick="closeDrawer();toast('已回滚到 v3','warn')">回滚到 v3</button>`);
      }
      if (act === 'toggle-formula') toast('公式状态已切换', 'warn');
      if (act === 'test') toast('公式测试通过，示例结果 21.24 mg/L', 'ok');
    });
  }
};

/* ═══════════ 同步任务 ═══════════ */
VIEWS.sync = {
  group: '系统', title: '同步任务',
  render() {
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">同步任务</div>
          <div class="page-desc">配置第三方 API 同步频率、启停与手动执行，监控执行结果</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="logs">${icon('list')}同步日志</button>
          <button class="btn btn-primary" data-act="run">${icon('play')}立即执行一次</button>
        </div>
      </div>

      <div class="grid g-2-1" style="margin-bottom:16px">
        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>实时数据落库 · 定时配置</h3>
            <div class="ch-right"><span class="badge ok pulse">运行中</span>
              <label class="switch"><input type="checkbox" checked/><i></i></label></div></div>
          <div class="card-body">
            <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
              ${['每 1 分钟','每 5 分钟','每 15 分钟','每小时','每天 02:00'].map((s,i) =>
                `<button class="chip ${i===1?'on':''}">${s}</button>`).join('')}
            </div>
            <div class="form-row">
              <div class="form-field" style="margin:0"><label>Cron 表达式</label>
                <input class="inp" value="0 */5 * * * ?" style="font-family:var(--mono);font-size:13px"/></div>
              <div class="form-field" style="margin:0"><label>同步策略</label>
                <select class="sel" style="width:100%"><option>增量同步（按唯一键 upsert）</option><option>全量同步</option></select></div>
            </div>
            <div style="display:flex;gap:24px;margin-top:16px;padding-top:14px;border-top:1px solid var(--line)">
              <div><div style="font-size:10.5px;color:var(--text-3)">上次执行</div><div class="num" style="font-size:13px;font-weight:600;margin-top:2px">2026-10-30 00:25:03</div></div>
              <div><div style="font-size:10.5px;color:var(--text-3)">下次执行</div><div class="num" style="font-size:13px;font-weight:600;margin-top:2px;color:var(--accent)">2026-10-30 00:30:00</div></div>
              <div><div style="font-size:10.5px;color:var(--text-3)">耗时</div><div class="num" style="font-size:13px;font-weight:600;margin-top:2px">12.4s</div></div>
              <div><div style="font-size:10.5px;color:var(--text-3)">写入行数</div><div class="num" style="font-size:13px;font-weight:600;margin-top:2px">4,286</div></div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><h3><span class="dot-mark"></span>今日执行概况</h3></div>
          <div class="card-body">
            <div class="chart" id="syncGauge" style="height:118px"></div>
            <div class="metric-inline" style="margin-top:14px;justify-content:space-between">
              <div><b class="ok">286</b><span>成功</span></div>
              <div><b class="danger">2</b><span>失败</span></div>
              <div><b>99.3%</b><span>成功率</span></div>
            </div>
          </div>
        </div>
      </div>

      <div class="card" style="margin-bottom:16px">
        <div class="card-head"><h3><span class="dot-mark"></span>任务列表</h3>
          <div class="ch-right"><span class="badge plain">6 个任务 · 5 个运行中</span></div></div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th>任务名称</th><th>Cron</th><th>策略</th><th class="num">写入行数</th>
                <th>上次执行</th><th>下次执行</th><th>结果</th><th style="text-align:right">操作</th></tr></thead>
              <tbody>
                ${SYNC_TASKS.map(t => `<tr>
                  <td><div class="cname">${t.name}</div><div class="csub">${t.desc}</div></td>
                  <td><code style="font-family:var(--mono);font-size:11px;color:var(--accent-2)">${t.cron}</code></td>
                  <td><span class="tag">${t.scope}</span></td>
                  <td class="num">${nf(t.rows)}</td>
                  <td style="font-family:var(--mono);font-size:10.5px;color:var(--text-3)">${t.last}</td>
                  <td style="font-family:var(--mono);font-size:10.5px;color:var(--text-3)">${t.next}</td>
                  <td>${badge(t.result)}</td>
                  <td><div class="actions">
                    <button class="act-btn" data-act="run-one" title="立即执行">${icon('play')}</button>
                    <button class="act-btn" data-act="toggle-task" title="启停">${t.status === 'running' ? icon('pause') : icon('play')}</button>
                    <button class="act-btn" data-act="task-detail" title="详情">${icon('eye')}</button>
                  </div></td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3><span class="dot-mark"></span>同步日志</h3>
          <div class="ch-right"><span class="badge accent plain">最近 14 条</span></div></div>
        <div class="card-body flush">
          <div class="table-wrap" style="max-height:340px;overflow:auto">
            <table class="tbl">
              <thead><tr><th>执行时间</th><th>任务</th><th>结果</th><th class="num">写入行数</th><th>耗时</th><th>说明</th></tr></thead>
              <tbody>
                ${SYNC_LOGS.map(l => `<tr>
                  <td style="font-family:var(--mono);font-size:11px;color:var(--text-3)">${l.time}</td>
                  <td style="font-size:12px">${l.task}</td>
                  <td>${badge(l.status)}</td>
                  <td class="num">${l.rows ? nf(l.rows) : '—'}</td>
                  <td class="num" style="font-size:11.5px;color:var(--text-3)">${l.cost}</td>
                  <td style="font-size:11.5px;color:${l.status==='failed'?'var(--danger)':'var(--text-2)'};max-width:340px">${l.msg}</td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    Charts.gauge(document.getElementById('syncGauge'), {
      value: 99.3, max: 100, height: 118, text: '99.3%', label: '今日同步成功率'
    });
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.dataset.act === 'run') toast('已触发同步，预计 12s 完成');
      if (b.dataset.act === 'run-one') toast('任务已提交执行队列');
      if (b.dataset.act === 'toggle-task') toast('任务状态已切换', 'warn');
      if (b.dataset.act === 'logs') toast('已在下方展示最近同步日志', 'info');
      if (b.dataset.act === 'task-detail') {
        openDrawer('任务详情 · 实时数据落库', `
          <dl class="kv">
            <dt>任务名称</dt><dd>实时数据落库</dd>
            <dt>Cron</dt><dd style="font-family:var(--mono)">0 */5 * * * ?</dd>
            <dt>同步策略</dt><dd>增量同步 · 按「项目 + 设备」唯一键 upsert</dd>
            <dt>数据保留</dt><dd>原始数据 365 天，计算值 730 天</dd>
            <dt>失败重试</dt><dd>最多 3 次，间隔 30s / 120s / 300s</dd>
            <dt>当前状态</dt><dd>${badge('running')}</dd>
          </dl>
          <div style="font-size:12px;font-weight:600;margin:20px 0 10px">最近 5 次执行</div>
          <div class="timeline">
            ${SYNC_LOGS.slice(0,5).map((l,i) => `<div class="tl-item ${l.status==='failed'?'danger':'done'}">
              <div class="tl-t">${l.status === 'success' ? '执行成功' : '执行失败'} · ${nf(l.rows)} 行</div>
              <div class="tl-d">${l.msg}</div><div class="tl-time">${l.time}</div></div>`).join('')}
          </div>`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>
           <button class="btn btn-primary" onclick="closeDrawer();toast('任务已手动执行')">立即执行</button>`);
      }
    });
  }
};

/* ═══════════ 智能诊断（整页） ═══════════ */
VIEWS.assistant = {
  group: 'AI 能力', title: '智能诊断',
  render() {
    return `<div class="view-in" style="max-width:1240px">
      <div class="page-head">
        <div><div class="page-title">智能诊断</div>
          <div class="page-desc">基于知识库与当前业务上下文回答问题，结果沿用三层数据权限过滤</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="kb">${icon('db')}知识库管理</button>
          <button class="btn btn-ghost" data-act="new-session">${icon('plus')}新建会话</button>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:280px minmax(0,1fr);gap:16px">
        <div>
          <div class="card" style="margin-bottom:16px">
            <div class="card-head"><h3><span class="dot-mark"></span>当前上下文</h3></div>
            <div class="card-body tight">
              <div style="padding:8px 6px">
                <div style="font-size:11px;color:var(--text-3);margin-bottom:6px">所在项目</div>
                <div class="chip on" style="height:28px">西区供热管网<span class="x">${icon('x')}</span></div>
                <div style="font-size:11px;color:var(--text-3);margin:12px 0 6px">查询条件</div>
                <div class="chip" style="height:28px">近 7 天</div>
                <div class="chip" style="height:28px;margin-left:4px">温度传感器</div>
              </div>
              <div class="hint" style="padding:0 6px 8px">助手会自动携带上述上下文，无需重复描述。</div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h3><span class="dot-mark"></span>知识库</h3>
              <div class="ch-right"><span class="badge accent plain">6 篇</span></div></div>
            <div class="card-body tight">
              ${['产品说明书 v2.6','第三方 API 接口文档','业务规则与口径说明','换热站运维手册','历史故障报告汇编','报表模板配置指引'].map((n,i) => `
                <div class="list-row" style="padding:8px 10px;border:0;border-radius:8px">
                  <span class="row-ico teal" style="width:24px;height:24px">${icon('doc')}</span>
                  <div class="lr-body"><b style="font-size:11.8px">${n}</b><small>已入库 · ${i+1}.2 MB</small></div>
                </div>`).join('')}
            </div>
          </div>
        </div>

        <div class="card" style="display:flex;flex-direction:column;height:calc(100vh - 200px);min-height:560px">
          <div class="card-head">
            <div class="chat-ava" style="width:28px;height:28px;border-radius:9px">${icon('sparkles')}</div>
            <h3>智能诊断</h3>
            <span class="sub">固定示例回复 · 未连接模型与知识库</span>
            <div class="ch-right"><span class="badge warn">模拟</span></div>
          </div>
          <div class="chat-body" id="pageChatBody" style="padding:20px 22px">
            <div class="msg">
              <span class="m-ava">AI</span>
              <div class="bubble">
                你好，我是乐图智能助手。当前上下文：<b>西区供热管网</b> · 近 7 天 · 温度传感器。<br/>
                可以帮你解读数据、对比设备、定位异常，或查询平台功能与业务规则。
              </div>
            </div>
          </div>
          <div class="chat-sugs" id="pageChatSugs">
            <button class="chat-sug">3 号换热站为什么供温偏低？</button>
            <button class="chat-sug">对比 1# 与 3# 站的热耗</button>
            <button class="chat-sug">这个项目的在线率是否正常？</button>
            <button class="chat-sug">如何配置一条新公式？</button>
          </div>
          <div class="chat-input-wrap">
            <div class="chat-input">
              <textarea id="pageChatInput" rows="1" placeholder="输入问题，Enter 发送 / Shift+Enter 换行"></textarea>
              <button class="chat-send" id="pageChatSend">${icon('send')}</button>
            </div>
            <div class="chat-ctx" style="padding:8px 0 0">
              <span class="ctx-chip">${icon('pin')}西区供热管网</span>
              <span class="ctx-chip">近 7 天</span>
              <span style="margin-left:auto">回答基于已上传知识库与当前账号可见数据</span>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    bindPageChat(scope);
    scope.querySelector('[data-act="kb"]')?.addEventListener('click', () => {
      openDrawer('知识库管理', `
        <div style="display:flex;gap:8px;margin-bottom:16px">
          <button class="btn btn-primary btn-sm">${icon('upload')}上传文档</button>
          <button class="btn btn-ghost btn-sm">${icon('refresh')}重新入库</button>
        </div>
        ${['产品说明书 v2.6','第三方 API 接口文档','业务规则与口径说明','换热站运维手册','历史故障报告汇编','报表模板配置指引'].map((n,i) => `
          <div class="list-row" style="padding:12px 0">
            <span class="row-ico teal" style="width:30px;height:30px">${icon('doc')}</span>
            <div class="lr-body"><b>${n}</b><small>已入库 · ${(i+1)*0.6+0.6} MB · 2026-10-${String(28-i).padStart(2,'0')}</small></div>
            <span class="badge ok">可用</span>
            <button class="act-btn danger">${icon('trash')}</button>
          </div>`).join('')}`,
        `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>
         <button class="btn btn-primary" onclick="closeDrawer();toast('知识库已同步')">同步到智能体</button>`);
    });
    scope.querySelector('[data-act="new-session"]')?.addEventListener('click', () => {
      document.getElementById('pageChatBody').innerHTML = `<div class="msg"><span class="m-ava">AI</span>
        <div class="bubble">新会话已开始。当前上下文：<b>西区供热管网</b> · 近 7 天。</div></div>`;
      toast('已新建会话');
    });
  }
};

/* ─── 通用聊天逻辑（页面内） ─── */
function aiReply(q) {
  const t = q.toLowerCase();
  if (t.includes('供温') || t.includes('偏低') || t.includes('3 号') || t.includes('3号'))
    return `结合近 7 天数据，<b>3 号换热站二次侧供温</b>平均 58.4℃，低于目标值 62℃ 共 5.8%。关键证据：<br/>
      · 一次侧流量稳定在 142 m³/h，排除热源波动<br/>
      · 回温差由 18.2℃ 收窄至 12.6℃，换热效率下降<br/>
      · 相邻 4 号站运行正常，属单站问题<br/>
      判断为<b>换热器结垢</b>导致，建议安排化学清洗，预计恢复效率 8~11%。`;
  if (t.includes('热耗') || t.includes('对比'))
    return `近 7 天热耗对比（GJ/万㎡）：<br/>
      · 1# 站 <b>284</b> · 2# 站 <b>262</b> · 3# 站 <b>318</b>（最高）· 4# 站 <b>271</b><br/>
      3# 站较均值高 11.2%，与供温偏低同源。若完成清洗，预计可回落至 285 左右，年化节约约 <b>6.2 万元</b>。`;
  if (t.includes('在线率') || t.includes('正常'))
    return `西区供热管网当前在线率 <b>96.0%</b>（311 / 324），近 30 日均值 96.4%，处于正常区间（阈值 95%）。<br/>
      离线 13 台中 9 台为通讯模块弱信号，建议巡检 5#、7# 换热站的网关。`;
  if (t.includes('公式') || t.includes('配置'))
    return `配置公式的步骤：<br/>
      1. 进入「公式配置」→ 新建公式<br/>
      2. 选择适用设备类型与产品型号，设置优先级<br/>
      3. 编写表达式（支持四则运算与 abs/min/max/round/if）<br/>
      4. 设置输出单位与小数位，点击「测试」校验<br/>
      5. 保存后版本号 +1，新数据按新公式计算，历史数据保留原结果。`;
  if (t.includes('异常') || t.includes('告警'))
    return `当前项目有 <b>3</b> 条异常：<br/>
      · 3 号站供温持续偏低（6.2h，严重）<br/>
      · 1 号站回温差收窄（疑似结垢，警告）<br/>
      · 6 号站补水率 2.1% 偏高（警告）<br/>
      其中 3 号站与 1 号站高度相关，建议合并处置。`;
  return `我已结合当前上下文（西区供热管网 · 近 7 天 · 温度传感器）分析。这个问题涉及平台数据与业务规则，我可以继续追问细化，或切换到「智能分析」做定时趋势与异常识别。你也可以指定具体设备或时间范围，我再精确查询。`;
}

function bindPageChat(scope) {
  const body = scope.querySelector('#pageChatBody');
  const input = scope.querySelector('#pageChatInput');
  const send = scope.querySelector('#pageChatSend');
  const sugs = scope.querySelector('#pageChatSugs');
  if (!body || !input) return;

  const push = (who, html) => {
    const d = document.createElement('div');
    d.className = 'msg' + (who === 'me' ? ' me' : '');
    d.innerHTML = `<span class="m-ava">${who === 'me' ? '我' : 'AI'}</span><div class="bubble">${html}</div>`;
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
    return d;
  };

  const ask = (q) => {
    if (!q.trim()) return;
    push('me', q);
    input.value = '';
    const t = push('ai', '<div class="typing"><i></i><i></i><i></i></div>');
    setTimeout(() => {
      t.querySelector('.bubble').innerHTML = aiReply(q);
      body.scrollTop = body.scrollHeight;
    }, 760);
  };

  send?.addEventListener('click', () => ask(input.value));
  input?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); }
  });
  input?.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 88) + 'px';
  });
  sugs?.querySelectorAll('.chat-sug').forEach(b => b.addEventListener('click', () => ask(b.textContent)));
}

/* ═══════════ 智能分析 ═══════════ */
VIEWS['ai-analysis'] = {
  group: 'AI 能力', title: '智能分析',
  render() {
    const r = AI_RESULTS[0];
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">智能分析</div>
          <div class="page-desc">对指定设备历史数据做趋势、异常与对比分析，生成文字结论并落库存档</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="run-task">${icon('play')}立即执行</button>
          <button class="btn btn-primary" data-act="new-task">${icon('plus')}新建分析任务</button>
        </div>
      </div>

      <div class="grid g4" style="margin-bottom:16px">
        ${AI_TASKS.map(t => `<div class="kpi" style="cursor:pointer">
          <div class="kpi-top"><span class="kpi-label" style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.name}</span>
            ${badge(t.status, t.status==='active'?'启用':'暂停')}</div>
          <div style="font-size:11.5px;color:var(--text-2);margin:2px 0 10px;height:34px;overflow:hidden">${t.target}</div>
          <div style="display:flex;align-items:center;gap:8px;font-size:10.5px;color:var(--text-3)">
            <span>${icon('clock')}</span><span>${t.freq}</span>
            <span style="margin-left:auto" class="badge ${t.level}">${t.result}</span>
          </div>
        </div>`).join('')}
      </div>

      <div class="grid g-1-2">
        <div class="card" style="align-self:start">
          <div class="card-head"><h3><span class="dot-mark"></span>分析结果</h3>
            <div class="ch-right"><span class="badge accent plain">${AI_RESULTS.length}</span></div></div>
          <div class="card-body tight">
            ${AI_RESULTS.map((x, i) => `
              <div class="list-row" style="padding:11px;border:0;border-radius:9px;cursor:pointer;${i===0?'background:var(--accent-soft)':''}">
                <span class="row-ico ${x.level==='danger'?'rose':x.level==='warn'?'amber':'green'}" style="width:28px;height:28px">${icon('brain')}</span>
                <div class="lr-body"><b style="font-size:12px">${x.task}</b>
                  <small>${x.project} · ${x.time.slice(5,16)}</small></div>
              </div>`).join('')}
          </div>
        </div>

        <div class="card">
          <div class="card-head">
            <h3><span class="dot-mark"></span>${r.task}</h3>
            <div class="ch-right">
              <span class="badge ${r.level}">${r.level==='danger'?'严重异常':r.level==='warn'?'需关注':'运行良好'}</span>
              <span class="badge plain">${r.time}</span>
              <button class="btn btn-sm btn-ghost" data-act="export">${icon('download')}导出</button>
            </div>
          </div>
          <div class="card-body">
            <div style="padding:14px 16px;border-radius:11px;background:var(--accent-soft);border:1px solid var(--accent-line);margin-bottom:18px">
              <div style="display:flex;align-items:center;gap:7px;font-size:11.5px;font-weight:600;color:var(--accent);margin-bottom:6px">
                ${icon('sparkles')}AI 结论摘要</div>
              <div style="font-size:12.8px;line-height:1.8;color:var(--text)">${r.summary}</div>
            </div>

            <div class="grid g4" style="margin-bottom:18px">
              ${r.metrics.map(m => `<div style="padding:12px;border-radius:10px;background:var(--panel-hi);border:1px solid var(--line)">
                <div style="font-size:10.5px;color:var(--text-3)">${m.k}</div>
                <div class="num" style="font-size:17px;font-weight:700;margin:3px 0 1px">${m.v}</div>
                <div style="font-size:10px;color:var(--text-3)">${m.s}</div></div>`).join('')}
            </div>

            <div class="chart" id="aiChart" style="height:200px;margin-bottom:18px"></div>

            <div class="grid g2">
              <div>
                <div style="font-size:12px;font-weight:600;margin-bottom:10px">关键发现</div>
                <div class="timeline">
                  ${r.points.map((p, i) => `<div class="tl-item ${i===0?'warn':''}">
                    <div class="tl-d" style="font-size:12px;color:var(--text-2)">${p}</div></div>`).join('')}
                </div>
              </div>
              <div>
                <div style="font-size:12px;font-weight:600;margin-bottom:10px">处置建议</div>
                ${r.suggest.map((s, i) => `<div style="display:flex;gap:9px;padding:10px 12px;border-radius:9px;background:var(--panel-hi);border:1px solid var(--line);margin-bottom:8px">
                  <span style="width:18px;height:18px;border-radius:5px;background:var(--accent);color:#fff;font-size:10px;font-weight:700;display:grid;place-items:center;flex:0 0 auto">${i+1}</span>
                  <span style="font-size:12px;line-height:1.6;color:var(--text-2)">${s}</span></div>`).join('')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  },
  mount(scope) {
    Charts.line(document.getElementById('aiChart'), {
      labels: timeLabels(28, 86400000 * 7), height: 200, yDec: 1, unit: '℃',
      series: [
        { name: '3# 站供温', data: genSeries(28, 57.4, 3.2, 0.16), color: '#fbbf24' },
        { name: '目标值', data: new Array(28).fill(62), color: '#3b82f6', width: 1.4, area: false }
      ]
    });
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.dataset.act === 'new-task') {
        openModal('新建分析任务', `
          <div class="form-field"><label>任务名称 <span class="req">*</span></label><input class="inp" placeholder="例如：热网供温异常趋势分析"/></div>
          <div class="form-field"><label>分析目标</label>
            <select class="sel" style="width:100%"><option>趋势分析</option><option>异常识别</option><option>对比分析</option><option>相关性分析</option></select></div>
          <div class="form-field"><label>参与分析的设备（可跨项目）</label>
            <div style="border:1px solid var(--line-2);border-radius:10px;padding:6px;max-height:180px;overflow:auto">
              ${DEVICES.slice(0, 6).map((d, i) => `<label class="check-line"><input type="checkbox" ${i<3?'checked':''}/><i></i>
                ${d.name}<span class="cl-meta">${escapeHTML(projName(d.project).slice(0,8))}</span></label>`).join('')}
            </div></div>
          <div class="form-row">
            <div class="form-field"><label>执行频率</label><select class="sel" style="width:100%">
              <option>每日 07:00</option><option>每 6 小时</option><option>每周一 08:00</option></select></div>
            <div class="form-field"><label>启用状态</label>
              <label class="switch"><input type="checkbox" checked/><i></i></label></div>
          </div>`,
          `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
           <button class="btn btn-primary" onclick="closeModal();toast('分析任务已创建')">创建</button>`);
      }
      if (b.dataset.act === 'run-task') toast('分析任务已提交，预计 40s 后出结果');
      if (b.dataset.act === 'export') toast('分析报告已导出为 PDF', 'ok');
    });
  }
};

/* ═══════════ 操作日志 ═══════════ */
VIEWS.logs = {
  group: '系统', title: '操作日志',
  render() {
    return `<div class="view-in">
      <div class="page-head">
        <div><div class="page-title">操作日志</div>
          <div class="page-desc">登录登出与关键操作留痕，按三层权限自动过滤可见范围</div></div>
        <div class="page-actions">
          <button class="btn btn-ghost" data-act="export">${icon('download')}导出日志</button>
          <button class="btn btn-ghost" data-act="retention">${icon('gear')}保留策略</button>
        </div>
      </div>

      <div class="card" style="margin-bottom:16px">
        <div class="card-body" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:13px 18px">
          <div class="search-box" style="min-width:200px"><span class="ico-s"></span>
            <input type="text" placeholder="搜索操作人 / 对象" data-filter/></div>
          <select class="sel" data-mod><option value="">全部模块</option>
            ${['登录','客户管理','项目管理','公式配置','同步任务','大屏配置','数据导出','角色权限'].map(m=>`<option>${m}</option>`).join('')}</select>
          <select class="sel"><option>全部操作类型</option><option>新增</option><option>编辑</option><option>删除</option><option>导出</option><option>登录</option></select>
          <input class="inp" type="date" value="2026-10-23" style="width:150px;height:36px"/>
          <span style="color:var(--text-3);font-size:12px">至</span>
          <input class="inp" type="date" value="2026-10-30" style="width:150px;height:36px"/>
          <button class="btn btn-soft btn-sm" data-act="search">${icon('filter')}筛选</button>
          <span style="margin-left:auto;font-size:11.5px;color:var(--text-3)">共 12 条记录 · 保留 180 天</span>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3><span class="dot-mark"></span>日志列表</h3>
          <div class="ch-right"><span class="badge accent plain">实时写入</span></div></div>
        <div class="card-body flush">
          <div class="table-wrap">
            <table class="tbl">
              <thead><tr><th>时间</th><th>操作人</th><th>模块</th><th>操作类型</th><th>操作对象</th><th>说明</th><th>IP</th><th></th></tr></thead>
              <tbody>
                ${LOGS.map((l, i) => `<tr data-row data-mod="${l.module}">
                  <td style="font-family:var(--mono);font-size:11px;color:var(--text-3);white-space:nowrap">${l.time}</td>
                  <td><div class="cell-main"><span class="avatar" style="width:24px;height:24px;font-size:10px;border-radius:7px">${l.user.slice(0,1)}</span>
                    <div><div class="cname" style="font-size:12px">${l.user}</div><div class="csub">${l.role}</div></div></div></td>
                  <td><span class="tag">${l.module}</span></td>
                  <td><span class="badge ${l.level==='danger'?'danger':l.level==='warn'?'warn':'mute'} plain">${l.action}</span></td>
                  <td style="font-size:12px;color:var(--text-2);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${l.target}</td>
                  <td style="font-size:11.5px;color:var(--text-3);max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${l.detail}</td>
                  <td style="font-family:var(--mono);font-size:10.5px;color:var(--text-3)">${l.ip}</td>
                  <td><div class="actions"><button class="act-btn" data-act="log-detail" data-i="${i}">${icon('eye')}</button></div></td>
                </tr>`).join('')}
              </tbody>
            </table>
            <div data-empty style="display:none" class="empty">
              <div class="empty-ico">${icon('list')}</div><h4>没有匹配的日志</h4><p>调整筛选条件后重试</p></div>
          </div>
        </div>
        ${pager(LOGS.length, 1, 12)}
      </div>
    </div>`;
  },
  mount(scope) {
    bindRowFilter(scope);
    bindSelectFilter(scope, '[data-mod]', 'mod');
    scope.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.dataset.act === 'log-detail') {
        const l = LOGS[+b.dataset.i];
        openDrawer('日志详情', `
          <dl class="kv">
            <dt>操作时间</dt><dd style="font-family:var(--mono)">${l.time}</dd>
            <dt>操作人</dt><dd>${l.user}（${l.role}）</dd>
            <dt>所属模块</dt><dd>${l.module}</dd>
            <dt>操作类型</dt><dd>${l.action}</dd>
            <dt>操作对象</dt><dd>${l.target}</dd>
            <dt>来源 IP</dt><dd style="font-family:var(--mono)">${l.ip}</dd>
            <dt>风险等级</dt><dd>${badge(l.level, l.level==='danger'?'高':l.level==='warn'?'中':'低')}</dd>
          </dl>
          <div style="font-size:12px;font-weight:600;margin:20px 0 8px">关键信息</div>
          <div style="padding:12px 14px;border-radius:9px;background:var(--panel-hi);border:1px solid var(--line);font-size:12.5px;line-height:1.8;color:var(--text-2)">${l.detail}</div>
          <div style="font-size:12px;font-weight:600;margin:20px 0 8px">变更前后</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="padding:10px 12px;border-radius:8px;background:var(--danger-soft);font-size:11.5px;font-family:var(--mono)">
              <div style="color:var(--danger);margin-bottom:4px">变更前</div>v3 · 系数 1.38</div>
            <div style="padding:10px 12px;border-radius:8px;background:var(--ok-soft);font-size:11.5px;font-family:var(--mono)">
              <div style="color:var(--ok);margin-bottom:4px">变更后</div>v4 · 系数 1.42</div>
          </div>`,
          `<button class="btn btn-ghost" onclick="closeDrawer()">关闭</button>`);
      }
      if (b.dataset.act === 'export') toast('日志已导出为 Excel', 'ok');
      if (b.dataset.act === 'retention') openModal('日志保留策略', `
        <div class="form-field"><label>保留周期</label>
          <select class="sel" style="width:100%"><option>90 天</option><option selected>180 天</option><option>365 天</option><option>永久保留</option></select></div>
        <div class="form-field"><label>归档方式</label>
          <select class="sel" style="width:100%"><option>按时间分区归档后清理</option><option>导出到对象存储后清理</option></select></div>
        <div class="hint">日志独立建表存储；数据量大时按时间归档清理，清理操作本身也会记录日志。</div>`,
        `<button class="btn btn-ghost" onclick="closeModal()">取消</button>
         <button class="btn btn-primary" onclick="closeModal();toast('保留策略已更新')">保存</button>`);
      if (b.dataset.act === 'search') toast('已按条件筛选');
    });
  }
};
