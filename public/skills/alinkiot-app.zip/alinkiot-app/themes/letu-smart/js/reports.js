const Reports = (() => {
  const key = 'letu-reports-v1';
  const fields = { samples: '样本数', min: '最小值', max: '最大值', average: '平均值' };
  let items = [{ id: 'seed-report', name: '设备运行统计', fields: Object.keys(fields), decimals: 2 }];
  let loadError = false;
  const validate = (input, list, except) => {
    if (!input || typeof input.name !== 'string' || !input.name.trim() || input.name.trim().length > 80 ||
        /[\u0000-\u001f]/.test(input.name)) throw new Error('模板名称须为 1–80 个有效字符');
    const name = input.name.trim();
    if (list.some(t => t.id !== except && t.name === name)) throw new Error('模板名称已存在');
    if (!Array.isArray(input.fields) || !input.fields.length || input.fields.some(f => !Object.hasOwn(fields, f)) ||
        new Set(input.fields).size !== input.fields.length) throw new Error('请至少选择一项有效统计字段，不可重复');
    if (!Number.isInteger(input.decimals) || input.decimals < 0 || input.decimals > 3) throw new Error('小数位须为 0–3');
    return { name, fields: Object.keys(fields).filter(f => input.fields.includes(f)), decimals: input.decimals };
  };
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const state = JSON.parse(raw);
      if (state.version !== 1 || !Array.isArray(state.items) || state.items.length > 20) throw new Error('无效存档');
      const loaded = [];
      for (const t of state.items) {
        if (!t || typeof t.id !== 'string' || !/^[a-z0-9-]+$/i.test(t.id) || loaded.some(x => x.id === t.id)) throw new Error('无效模板');
        loaded.push({ id: t.id, ...validate(t, loaded, t.id) });
      }
      items = loaded;
    }
  } catch (e) { loadError = true; }
  const save = () => {
    try { localStorage.setItem(key, JSON.stringify({ version: 1, items })); return true; }
    catch (e) { return false; }
  };
  return {
    fields, loadError,
    list: () => items.map(t => ({ ...t, fields: [...t.fields] })),
    put(id, input) {
      if (id && !items.some(t => t.id === id)) throw new Error('模板已不存在');
      const value = validate(input, items, id);
      if (!id && items.length >= 20) throw new Error('最多保存 20 个模板');
      if (id) items = items.map(t => t.id === id ? { id, ...value } : t);
      else items.push({ id: crypto.randomUUID(), ...value });
      return save();
    },
    remove(id) {
      if (!items.some(t => t.id === id)) throw new Error('模板已不存在');
      items = items.filter(t => t.id !== id);
      return save();
    },
    generate(id, projectId, from, to) {
      const template = items.find(t => t.id === id);
      if (!template) throw new Error('请选择有效模板');
      const project = PROJECTS.find(p => p.id === projectId);
      if (!project) throw new Error('请选择有效项目');
      const begin = Telemetry.parse(from), end = Telemetry.parse(to);
      if (begin > end) throw new Error('开始时间不能晚于结束时间');
      if (end - begin > 90 * 86400000) throw new Error('单次查询最多 90 天');
      const rows = DEVICES.filter(d => d.project === projectId).map(d => {
        const stats = Telemetry.stats(Telemetry.query(d.id, from, to));
        return { device: d.id, name: d.name, code: d.code, metric: Curves.metrics[d.type], unit: d.unit,
          samples: stats?.samples || 0, min: stats?.min ?? null, max: stats?.max ?? null, average: stats?.average ?? null };
      });
      return { template: { ...template, fields: [...template.fields] }, project: { id: project.id, name: project.name }, from, to, rows };
    },
    value(report, row, field) {
      return row[field] === null ? '—' : field === 'samples' ? String(row[field]) : row[field].toFixed(report.template.decimals);
    },
    csv(report) {
      return [
        ['模板', report.template.name, '项目', report.project.name, '开始时间（UTC+8）', report.from, '结束时间（UTC+8）', report.to],
        ['设备名称', '编号', '指标', '单位', ...report.template.fields.map(f => fields[f])],
        ...report.rows.map(r => [r.name, r.code, r.metric, r.unit, ...report.template.fields.map(f => this.value(report, r, f))])
      ];
    }
  };
})();
