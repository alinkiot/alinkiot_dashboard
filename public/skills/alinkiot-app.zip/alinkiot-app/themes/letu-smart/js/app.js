/* ═══════════════════════════════════════════
   乐图智慧 · 应用外壳 / 路由 / 主题
   ═══════════════════════════════════════════ */

const NAV = [
  { group: '总览', items: [{ id: 'dashboard', name: '工作台', icon: 'grid' }] },
  { group: 'AI 能力', items: [
    { id: 'assistant', name: '智能诊断', icon: 'sparkles' },
    { id: 'ai-analysis', name: '智能分析', icon: 'brain' },
    { id: 'ai-warning', name: '智能预警', icon: 'alert' },
    { id: 'ai-report', name: '智能报表', icon: 'layers' }
  ]},
  { group: '告警中心', items: [
    { id: 'alarms', name: '告警事件', icon: 'activity' },
    { id: 'alarm-rules', name: '告警规则', icon: 'shield' }
  ]},
  { group: '数据应用', items: [
    { id: 'realtime', name: '实时查询', icon: 'activity' },
    { id: 'history', name: '历史查询', icon: 'clock' },
    { id: 'scenes', name: '场景管理', icon: 'layers' },
    { id: 'curves', name: '曲线管理', icon: 'chart' },
    { id: 'bigscreen', name: '项目大屏', icon: 'monitor' },
    { id: 'reports', name: '报表中心', icon: 'file' }
  ]},
  { group: '资产管理', items: [
    { id: 'customers', name: '客户管理', icon: 'users' },
    { id: 'projects', name: '项目管理', icon: 'folder' },
    { id: 'products', name: '产品管理', icon: 'layers' },
    { id: 'devices', name: '设备档案', icon: 'cpu' }
  ]},
  { group: '系统', items: [
    { id: 'agent-access', name: '智能体接入', icon: 'brain' },
    { id: 'formula', name: '公式配置', icon: 'sigma' },
    { id: 'sync', name: '同步任务', icon: 'refresh' },
    { id: 'roles', name: '角色权限', icon: 'shield' },
    { id: 'logs', name: '操作日志', icon: 'list' }
  ]}
];

let CURRENT = 'dashboard';
let CLEANUP = null;
const MOBILE_MENU = window.matchMedia('(max-width:860px)');
function syncMenuButtons() {
  const app = document.getElementById('app');
  const expanded = MOBILE_MENU.matches ? app.classList.contains('mobile-open') : !app.classList.contains('collapsed');
  const button = document.getElementById('tbMenu');
  button.setAttribute('aria-expanded', String(expanded));
  button.setAttribute('aria-label', expanded ? '收起侧边菜单' : '展开侧边菜单');
}
function toggleMenu() {
  const app = document.getElementById('app');
  if (MOBILE_MENU.matches) {
    app.classList.remove('collapsed');
    app.classList.toggle('mobile-open');
  } else {
    app.classList.toggle('collapsed');
  }
  syncMenuButtons();
  setTimeout(() => Charts.redrawAll(), 320);
}

/* ─── 主题 ─── */
function applyTheme(t, silent) {
  if (t !== 'dark' && t !== 'light') t = 'dark';
  document.documentElement.dataset.theme = t;
  document.documentElement.style.colorScheme = t;
  try { localStorage.setItem('letu-theme', t); } catch (e) {}
  const label = t === 'dark' ? '科技蓝' : '明亮白';
  document.querySelectorAll('.ts-label, .theme-pill-label').forEach(e => e.textContent = label);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? '#050810' : '#f2f5fa');
  if (!silent) setTimeout(() => Charts.redrawAll(), 60);
}
function toggleTheme() {
  applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}

/* ─── 导航 ─── */
function buildNav() {
  const nav = document.getElementById('sbNav');
  nav.innerHTML = NAV.map(g => `
    <div class="nav-group">
      <div class="nav-group-t">${g.group}</div>
      ${g.items.map(it => `
        <div class="nav-item" role="button" tabindex="0" data-nav="${it.id}" data-menu-tip="${it.name}" aria-label="${it.name}">
          ${icon(it.icon)}
          <span>${it.name}</span>
          ${it.id === 'assistant' ? '<span class="nav-tag">AI</span>' : ''}
        </div>`).join('')}
    </div>`).join('');

  nav.querySelectorAll('[data-nav]').forEach(el => {
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }
    });
    el.addEventListener('click', () => {
      go(el.dataset.nav);
      document.getElementById('app').classList.remove('mobile-open');
      syncMenuButtons();
    });
  });
}

function markNav(id) {
  document.querySelectorAll('[data-nav]').forEach(el => {
    el.classList.toggle('on', el.dataset.nav === id);
    if (el.dataset.nav === id) el.setAttribute('aria-current', 'page');
    else el.removeAttribute('aria-current');
  });
}

/* ─── 路由 ─── */
function go(id, push = true) {
  if (!VIEWS[id]) id = 'dashboard';
  closeModal();
  closeDrawer();
  closeCmdk();
  document.getElementById('tbNotify').classList.remove('open');
  if (CLEANUP) { try { CLEANUP(); } catch (e) {} CLEANUP = null; }

  const v = VIEWS[id];
  CURRENT = id;
  markNav(id);
  document.body.classList.toggle('page-assistant', id === 'assistant');

  document.getElementById('crumbs').innerHTML =
    `<span class="c-group">${v.group}</span><span class="c-sep">/</span><span class="c-cur">${v.title}</span>`;
  document.title = v.title + ' · AlinkIoT';

  const view = document.getElementById('view');
  view.innerHTML = v.render();
  view.scrollTo({ top: 0, behavior: 'instant' });

  const scope = view.querySelector('.view-in') || view;
  if (v.mount) {
    try { v.mount(scope); } catch (e) { console.error('[mount]', id, e); }
  }
  if (scope._cleanup) CLEANUP = scope._cleanup;

  view.tabIndex = -1;
  view.focus({ preventScroll: true });
  if (push && location.hash !== '#' + id) history.pushState(null, '', '#' + id);
  if (!push && location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
}

/* ─── 登录 ─── */
function enterApp(page = 'dashboard') {
  const auth = document.getElementById('auth');
  auth.classList.add('gone');
  setTimeout(() => { auth.style.display = 'none'; }, 520);

  const app = document.getElementById('app');
  app.classList.add('on');
  app.setAttribute('aria-hidden', 'false');
  document.body.classList.add('logged-in');

  buildNav();
  go(page, false);
  setTimeout(() => {
    toast('欢迎回来，系统管理员', 'ok');
  }, 700);
}
function logout() {
  const app = document.getElementById('app');
  app.classList.remove('on');
  app.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('logged-in');
  const auth = document.getElementById('auth');
  auth.style.display = '';
  requestAnimationFrame(() => auth.classList.remove('gone'));
  toast('已安全退出登录', 'info');
}

/* ─── 悬浮助手 ─── */
const POP_MSGS = [];
function renderPopChat() {
  const body = document.getElementById('popBody');
  if (!body) return;
  body.innerHTML = POP_MSGS.map(m => `
    <div class="msg ${m.who === 'me' ? 'me' : ''}">
      <span class="m-ava">${m.who === 'me' ? '我' : 'AI'}</span>
      <div class="bubble">${m.html}</div>
    </div>`).join('');
  body.scrollTop = body.scrollHeight;
}
function buildChatPop() {
  const pop = document.getElementById('chatPop');
  pop.innerHTML = `
    <div class="chat-head">
      <div class="chat-ava">${icon('sparkles')}</div>
      <div><b>乐图智能助手</b><small>本地模拟 · 未连接模型与知识库</small></div>
      <button class="chat-close" id="popClose">${icon('x')}</button>
    </div>
    <div class="chat-body" id="popBody"></div>
    <div class="chat-sugs" id="popSugs">
      <button class="chat-sug">这个项目在线率正常吗？</button>
      <button class="chat-sug">帮我解读最近 7 天趋势</button>
      <button class="chat-sug">如何配置公式？</button>
    </div>
    <div class="chat-input-wrap">
      <div class="chat-input">
        <textarea id="popInput" rows="1" placeholder="问点什么…"></textarea>
        <button class="chat-send" id="popSend">${icon('send')}</button>
      </div>
    </div>`;

  POP_MSGS.length = 0;
  POP_MSGS.push({ who: 'ai', html: '你好，我是乐图智能助手。当前上下文：<b>西区供热管网</b>。可以帮你解读数据、定位异常或查询平台功能。' });
  renderPopChat();

  const input = pop.querySelector('#popInput');
  const send = () => {
    const q = input.value.trim();
    if (!q) return;
    POP_MSGS.push({ who: 'me', html: q });
    POP_MSGS.push({ who: 'ai', html: '<div class="typing"><i></i><i></i><i></i></div>' });
    renderPopChat();
    input.value = '';
    setTimeout(() => {
      POP_MSGS[POP_MSGS.length - 1] = { who: 'ai', html: aiReply(q) };
      renderPopChat();
    }, 720);
  };
  pop.querySelector('#popSend').addEventListener('click', send);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  });
  pop.querySelectorAll('.chat-sug').forEach(b => b.addEventListener('click', () => { input.value = b.textContent; send(); }));
  pop.querySelector('#popClose').addEventListener('click', () => pop.classList.remove('open'));
}

/* ─── 命令面板 ─── */
function buildCmdk() {
  const list = document.getElementById('cmdkList');

  const render = (q = '') => {
    const all = [];
    NAV.forEach(g => g.items.forEach(it => all.push({ type: 'page', id: it.id, name: it.name, group: g.group, icon: it.icon })));
    CUSTOMERS.forEach(c => all.push({ type: 'customer', id: 'customers', name: c.name, group: '客户', icon: 'users' }));
    PROJECTS.forEach(p => all.push({ type: 'project', id: 'projects', name: p.name, group: '项目', icon: 'folder' }));
    DEVICES.slice(0, 8).forEach(d => all.push({ type: 'device', id: 'devices', name: d.name + ' · ' + d.code, group: '设备', icon: 'cpu' }));
    const hits = all.filter(x => !q || x.name.toLowerCase().includes(q.toLowerCase()));
    if (!hits.length) { list.innerHTML = `<div class="empty" style="padding:32px"><h4>没有匹配结果</h4></div>`; return; }
    let html = '', lastGroup = '';
    hits.slice(0, 18).forEach((x, i) => {
      if (x.group !== lastGroup) { html += `<div class="cm-group">${x.group}</div>`; lastGroup = x.group; }
      html += `<div class="cm-item ${i === 0 ? 'on' : ''}" data-cm="${x.id}">
        <span class="cm-ico">${icon(x.icon)}</span>${escapeHTML(x.name)}
        <span class="cm-sub">${x.type === 'page' ? '页面' : '打开'}</span></div>`;
    });
    list.innerHTML = html;
    list.querySelectorAll('[data-cm]').forEach(el => el.addEventListener('click', () => {
      closeCmdk(); go(el.dataset.cm);
    }));
  };
  render();
  const inp = document.getElementById('cmdkInput');
  inp.addEventListener('input', () => render(inp.value));
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const items = [...list.querySelectorAll('.cm-item')];
      if (!items.length) return;
      const index = items.findIndex(el => el.classList.contains('on'));
      const next = (index + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
      items.forEach((el, i) => el.classList.toggle('on', i === next));
      items[next].scrollIntoView({ block: 'nearest' });
    }
    if (e.key === 'Enter') {
      const on = list.querySelector('.cm-item.on') || list.querySelector('.cm-item');
      if (on) { closeCmdk(); go(on.dataset.cm); }
    }
  });
}
function openCmdk() {
  document.getElementById('cmdk').classList.add('open');
  const inp = document.getElementById('cmdkInput');
  inp.value = ''; inp.focus();
  inp.dispatchEvent(new Event('input'));
  document.getElementById('cmdk').setAttribute('aria-hidden', 'false');
  document.getElementById('cmdkList').querySelectorAll('.cm-item').forEach((el, i) => el.classList.toggle('on', i === 0));
}
function closeCmdk() {
  const cmdk = document.getElementById('cmdk');
  if (!cmdk.classList.contains('open')) return;
  cmdk.classList.remove('open');
  cmdk.setAttribute('aria-hidden', 'true');
  document.getElementById('tbSearch').focus({ preventScroll: true });
}

/* ─── 通知 ─── */
function buildNotify() {
  document.getElementById('notifyPop').innerHTML = `
    <div class="notify-head"><span>通知</span><span style="color:var(--accent)">全部已读</span></div>
    ${NOTICES.map(n => `<div class="notify-item">
      <span class="ni-ico" style="background:var(--${n.level === 'mute' ? 'panel-hi' : n.level + '-soft'});color:var(--${n.level === 'mute' ? 'text-3' : n.level})">
        ${icon(n.level === 'danger' ? 'alert' : n.level === 'warn' ? 'alert' : n.level === 'info' ? 'sparkles' : 'check')}</span>
      <div class="ni-body"><b>${n.t}</b><small>${n.d}</small>
        <div style="font-size:10px;color:var(--text-3);margin-top:2px">${n.time}</div></div>
    </div>`).join('')}`;
}

/* ─── 初始化 ─── */
document.addEventListener('DOMContentLoaded', () => {
  let saved = 'dark';
  try { saved = localStorage.getItem('letu-theme') || 'dark'; } catch (e) {}
  applyTheme(saved, true);

  /* 登录页装饰图标 */
  document.querySelectorAll('[data-ico]').forEach(el => {
    el.innerHTML = icon(el.dataset.ico === 'user' ? 'user' : 'lock');
  });
  document.getElementById('pwEye').innerHTML = icon('eye');
  document.getElementById('authLogo').outerHTML = '<span class="logo-mark" id="authLogo"></span>';
  document.getElementById('sbLogo').outerHTML = '<span class="logo-mark small" id="sbLogo"></span>';
  document.getElementById('tbMenu').innerHTML = icon('menu');
  document.getElementById('tbRefresh').innerHTML = icon('refresh');
  document.getElementById('sbOut')?.remove?.();
  const out = document.getElementById('logoutBtn');
  if (out) out.innerHTML = icon('logout');
  document.querySelector('#tbNotify .tb-icon').innerHTML = icon('bell') + '<span class="badge-dot"></span>';

  /* 登录 */
  document.getElementById('loginForm').addEventListener('submit', e => {
    e.preventDefault();
    const btn = document.getElementById('loginBtn');
    btn.innerHTML = '<span>正在进入演示…</span>';
    setTimeout(() => { btn.innerHTML = '<span>进入演示</span>'; enterApp(); }, 520);
  });
  document.getElementById('pwEye').addEventListener('click', () => {
    const p = document.getElementById('loginPass');
    p.type = p.type === 'password' ? 'text' : 'password';
  });

  document.getElementById('authTheme').addEventListener('click', toggleTheme);
  document.getElementById('themeSwitch').addEventListener('click', toggleTheme);
  document.getElementById('logoutBtn').addEventListener('click', logout);

  /* 侧边栏折叠 */
  document.getElementById('tbMenu').addEventListener('click', toggleMenu);
  MOBILE_MENU.addEventListener('change', () => {
    document.getElementById('app').classList.remove('mobile-open');
    syncMenuButtons();
    setTimeout(() => Charts.redrawAll(), 320);
  });
  syncMenuButtons();

  /* 刷新 */
  document.getElementById('tbRefresh').addEventListener('click', () => {
    go(CURRENT);
    toast('已重新载入本地演示，查询条件保留', 'info');
  });

  /* 搜索 / 命令面板 */
  document.getElementById('tbSearch').addEventListener('click', openCmdk);
  document.getElementById('cmdk').addEventListener('click', e => {
    if (e.target.id === 'cmdk') closeCmdk();
  });
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCmdk(); }
    if (e.key === 'Escape') {
      if (document.getElementById('modal').classList.contains('on')) closeModal();
      else if (document.getElementById('drawer').classList.contains('on')) closeDrawer();
      else closeCmdk();
    }
  });

  /* 通知 */
  const notify = document.getElementById('tbNotify');
  notify.querySelector('.tb-icon').addEventListener('click', e => {
    e.stopPropagation();
    notify.classList.toggle('open');
  });
  document.addEventListener('click', () => notify.classList.remove('open'));

  /* 遮罩关闭 */
  document.getElementById('drawerMask').addEventListener('click', closeDrawer);
  document.getElementById('modalMask').addEventListener('click', closeModal);

  /* 悬浮助手 */
  buildChatPop();
  document.getElementById('fab').addEventListener('click', () => {
    document.getElementById('chatPop').classList.toggle('open');
  });

  /* 全局 data-go */
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]');
    if (g) {
      if (g.dataset.project) Workspace.setProject(g.dataset.project);
      go(g.dataset.go);
    }
  });

  buildNotify();
  buildCmdk();
  if (Assets.loadError) toast('无法读取本地档案存档，当前使用初始样本；请留意浏览器存储设置', 'warn');
  window.addEventListener('hashchange', () => {
    if (document.body.classList.contains('logged-in')) go(location.hash.slice(1), false);
  });

  /* 若已登录态（演示直接进入） */
  if (location.hash && VIEWS[location.hash.slice(1)]) {
    enterApp(location.hash.slice(1));
  }
});

/* 暴露给内联事件 */
window.go = go;
window.closeDrawer = closeDrawer;
window.closeModal = closeModal;
window.toast = toast;

{
  const tip = document.createElement("div");
  tip.id = "menu-tip";
  tip.className = "menu-tip";
  tip.setAttribute("role", "tooltip");
  tip.hidden = true;
  document.body.append(tip);
  let active;
  const hide = () => {
    active?.removeAttribute("aria-describedby");
    active = null;
    tip.hidden = true;
  };
  const show = (event) => {
    const item = event.target.closest("[data-menu-tip]");
    if (!item || !item.closest(".menu-collapsed, .collapsed")) return;
    hide();
    active = item;
    tip.textContent = item.dataset.menuTip;
    tip.hidden = false;
    item.setAttribute("aria-describedby", tip.id);
    const rect = item.getBoundingClientRect();
    tip.style.left = `${Math.max(8, Math.min(rect.right + 10, innerWidth - tip.offsetWidth - 8))}px`;
    tip.style.top = `${Math.max(8, Math.min(rect.top + (rect.height - tip.offsetHeight) / 2, innerHeight - tip.offsetHeight - 8))}px`;
  };
  document.addEventListener("pointerover", show);
  document.addEventListener("focusin", show);
  for (const type of ["pointerout", "focusout"]) document.addEventListener(type, (event) => {
    if (active && !active.contains(event.relatedTarget)) hide();
  });
  document.addEventListener("click", hide);
  document.addEventListener("scroll", hide, true);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hide(); });
  window.addEventListener("resize", hide);
}
