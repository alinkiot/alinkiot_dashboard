function openAgentAccess(config) {
  const project = config?.project || Workspace.project || PROJECTS[0]?.id;
  openDrawer(config ? '编辑智能体接入' : '新增智能体接入', `<form id="agentAccessForm">
    <div class="form-field"><label>项目</label><select class="sel" name="project" required ${config ? 'disabled' : ''} aria-label="智能体接入项目">
      ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></div>
    <div class="form-field"><label>平台 URL</label><input class="inp" name="url" type="url" required maxlength="500" value="${escapeHTML(config?.url || 'https://agents.example.com')}" placeholder="https://agents.example.com"/></div>
    <div class="form-field"><label>AppID（示例）</label><input class="inp" name="appid" required maxlength="100" value="${escapeHTML(config?.appid || 'demo-app')}"/></div>
    <div class="form-field"><label>Secret</label><input class="inp" type="password" disabled placeholder="本地示例不接收或保存真实 Secret"/>
      <small>生产版由 Python 后端加密保存，浏览器只显示配置状态，不回显凭证。</small></div>
    <p class="hint">每项目一份配置；点击接入自动同步并保存数字人示例，之后可点“更新数字人”。更改 URL 或 AppID 后重新同步并清空选择。演示仅使用固定样本，不请求平台，请勿输入真实凭证。</p>
    <p data-agent-error role="alert" hidden style="color:var(--danger)"></p></form>`,
    `<button class="btn btn-ghost" onclick="closeDrawer()">取消</button><button class="btn btn-primary" form="agentAccessForm" type="submit">${config ? '保存接入' : '接入'}</button>`);
  const form = document.getElementById('agentAccessForm');
  form.onsubmit = event => {
    event.preventDefault();
    try {
      const project = form.elements.project.value;
      if (!config && AgentAccess.config(project)) throw new Error('该项目已配置接入，请从列表编辑');
      const persisted = AgentAccess.save({ project, url: form.elements.url.value, appid: form.elements.appid.value });
      Workspace.setProject(project); go('agent-access');
      toast(persisted ? '接入与数字人示例已保存，未请求真实平台' : '仅内存保存，存储失败，刷新将丢失', persisted ? 'ok' : 'warn');
    } catch (e) {
      const error = form.querySelector('[data-agent-error]');
      error.textContent = e.message; error.hidden = false;
    }
  };
}
VIEWS['agent-access'] = {
  group: '系统', title: '智能体接入',
  render() {
    const project = Workspace.project || PROJECTS[0]?.id, config = AgentAccess.config(project);
    const avatars = AgentAccess.avatars(project), target = AgentAccess.target(project);
    return `<div class="view-in"><div class="page-head"><div><div class="page-title">智能体接入</div>
      <div class="page-desc">按项目接入智能体平台 · 获取可用数字人 · 配置后续 AI 调用目标</div></div>
      <div class="page-actions"><button class="btn btn-primary" data-agent-add>新增接入</button></div></div>
      <div class="panel-actions"><label>项目 <select class="sel" data-agent-project aria-label="智能体项目筛选">
        ${PROJECTS.map(p => `<option value="${p.id}" ${p.id === project ? 'selected' : ''}>${escapeHTML(p.name)}</option>`).join('')}</select></label></div>
      <p class="hint">本地示例：不保存真实 Secret、不发网络请求。数字人列表为固定样本，选择仅保存项目调用目标，不代表平台已连接或 AI 已可用。</p>
      ${AgentAccess.loadError ? '<p class="hint">接入存档无法读取，已回退空配置。</p>' : ''}
      ${config ? `<section class="card"><div class="card-head"><h3>${escapeHTML(projName(project))}</h3><div class="panel-actions">
        <button class="btn btn-ghost" data-agent-edit>编辑接入</button><button class="btn btn-primary" data-agent-load>更新数字人</button></div></div>
        <div class="card-body"><p>URL：${escapeHTML(config.url)}</p><p>AppID：${escapeHTML(config.appid)}</p><p>Secret：未配置（演示不保存）</p>
          <p>平台连接：未连接 · ${config.loaded ? '数字人示例已同步保存，未请求平台' : '尚未同步数字人示例'}</p>
          <p class="hint">最近示例同步：${escapeHTML(config.syncedAt || '暂无记录')}</p></div></section>
        <div class="panel-grid">${avatars.map(a => `<article class="card panel-card ${config.selected === a.id ? 'selected' : ''}"><div class="card-body">
          <h3>${escapeHTML(a.name)}</h3><p class="hint">${escapeHTML(a.id)} · ${escapeHTML(a.description)}</p>
          <button class="btn btn-sm ${config.selected === a.id ? 'btn-ghost' : 'btn-primary'}" data-agent-select="${a.id}" ${config.selected === a.id ? 'disabled' : ''}>${config.selected === a.id ? '当前数字人' : '选择数字人'}</button>
        </div></article>`).join('')}</div>
        ${target ? `<section class="card" style="margin-top:16px"><div class="card-body"><h3>本项目调用目标（示例）</h3>
          <p style="overflow-wrap:anywhere">${escapeHTML(target.url)} + ${escapeHTML(target.avatar.name)}（${escapeHTML(target.avatar.id)}）</p>
          <p class="hint">供后续 AI 功能按项目读取。平台协议与鉴权尚未接入，不能真实调用；不是直接拼接 URL 后发送凭证。</p></div></section>` :
          '<div class="empty"><h4>尚未选择数字人</h4><p>从已同步列表选择本项目使用的数字人。</p></div>'}` :
        '<div class="empty"><h4>该项目尚未接入智能体平台</h4><p>新增 URL 与示例 AppID 配置后获取数字人列表。</p></div>'}</div>`;
  },
  mount(scope) {
    scope.querySelector('[data-agent-project]').onchange = event => { Workspace.setProject(event.target.value); go('agent-access'); };
    scope.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button) return;
      const project = Workspace.project || PROJECTS[0]?.id;
      if (button.hasAttribute('data-agent-add')) openAgentAccess();
      if (button.hasAttribute('data-agent-edit')) openAgentAccess(AgentAccess.config(project));
      try {
        if (button.hasAttribute('data-agent-load') || button.dataset.agentSelect) {
          const persisted = button.dataset.agentSelect ? AgentAccess.select(project, button.dataset.agentSelect) : AgentAccess.loadAvatars(project);
          go('agent-access');
          toast((button.dataset.agentSelect ? '数字人选择已更新' : '数字人示例已更新并保存，未请求平台') +
            (persisted ? '' : '；存储失败，刷新将丢失'), persisted ? 'info' : 'warn');
        }
      } catch (e) { toast(e.message, 'warn'); }
    });
  }
};
