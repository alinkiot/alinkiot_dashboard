const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');

function runtime(storage = new Map(), disabled = false) {
  const context = vm.createContext({
    crypto: { randomUUID },
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => {
        if (disabled) throw new Error('Storage disabled');
        storage.set(key, value);
      }
    }
  });
  for (const file of ['data.js', 'ui.js', 'assets.js', 'accounts.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}

test('superadmin opens customer admins only; usernames and fixed customer constraints are enforced', () => {
  const storage = new Map(), run = runtime(storage);
  const input = `{username:'new.admin', name:'新管理员', role:'admin', customer:'C001',
    grants:[{project:'P1001', capabilities:['governance','export']}]} `;
  assert.equal(run(`Accounts.create(${input})`), true);
  assert.throws(() => run(`Accounts.create(${input})`), /登录账号已存在/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'NEW.ADMIN'})`), /登录账号已存在/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.user', role:'user'})`), /固定角色/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.admin', grants:[{project:'P2001',capabilities:[]}]})`), /本客户/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.admin', customer:''})`), /所属客户/);
  assert.throws(() => run(`Accounts.update('lizq', {})`), /固定角色边界/);
  const reload = runtime(storage);
  assert.equal(reload(`Accounts.visible().find(u => u.username === 'new.admin').role`), 'admin');
  assert.ok(!storage.get('letu-accounts-v1').includes('password'));
});

test('admin can only create own-customer ordinary users using own project and capability subset', () => {
  const run = runtime();
  run(`Accounts.selectActor('wangxl')`);
  const input = `{username:'new.user', name:'普通用户', role:'user', customer:'C001',
    grants:[{project:'P1002',capabilities:['report']}]} `;
  assert.equal(run(`Accounts.create(${input})`), true);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.user', customer:'C002'})`), /所属客户/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.user', role:'admin'})`), /固定角色/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.user', grants:[{project:'P1001', capabilities:[]}]})`), /自己已获授权/);
  assert.throws(() => run(`Accounts.create({...${input}, username:'other.user', grants:[{project:'P1002', capabilities:['alarms']}]})`), /角色上限/);
  assert.throws(() => run(`Accounts.update('wangf', {})`), /跨客户/);
  assert.throws(() => run(`Accounts.update('wangxl', {})`), /本人/);
  run(`Accounts.selectActor('lizq')`);
  assert.equal(run('Accounts.visible().length'), 1);
  assert.throws(() => run(`Accounts.create(${input})`), /普通用户不能创建/);
  assert.throws(() => run(`Accounts.toggle('chenzy')`), /本企业其他管理员/);
});

test('editing preserves other-admin projects and capabilities outside the acting admin grant', () => {
  const run = runtime();
  run(`var chen = Accounts.visible().find(u => u.id === 'chenzy');
    Accounts.update('chenzy', {...chen, grants:[{project:'P1001',capabilities:[]}]});
    Accounts.selectActor('chenzy');
    var lizq = Accounts.visible().find(u => u.id === 'lizq');
    Accounts.update('lizq', {...lizq, name:'修改姓名', grants:[{project:'P1001',capabilities:[]}]})`);
  assert.equal(run(`Accounts.effective('lizq').length`), 2);
  assert.equal(run(`Accounts.effective('lizq').find(g => g.project === 'P1001').capabilities.includes('export')`), true);
  assert.equal(run(`Accounts.effective('lizq').find(g => g.project === 'P1002').capabilities.includes('report')`), true);
  assert.throws(() => run(`Accounts.update('lizq', {...lizq, grants:[{project:'P1001',capabilities:['export']}]})`), /本人未获授/);
  assert.throws(() => run(`Accounts.update('lizq', {...lizq, role:'admin', grants:[]})`), /不可修改/);
});

test('disabling an admin or withdrawing their grants does not cascade to ordinary users', () => {
  const storage = new Map(), run = runtime(storage);
  const before = run(`JSON.stringify(Accounts.effective('lizq'))`);
  run(`var chen = Accounts.visible().find(u => u.id === 'chenzy');
    Accounts.update('chenzy', {...chen, grants:[]})`);
  assert.equal(run(`JSON.stringify(Accounts.effective('lizq'))`), before);
  run(`Accounts.selectActor('wangxl'); Accounts.toggle('chenzy')`);
  assert.equal(run(`Accounts.identities().some(u => u.id === 'chenzy')`), false);
  assert.throws(() => run(`Accounts.selectActor('chenzy')`), /可用/);
  assert.throws(() => run(`Accounts.toggle('wangxl')`), /本人/);
  assert.equal(run(`JSON.stringify(Accounts.effective('lizq'))`), before);
  const reload = runtime(storage);
  assert.equal(reload(`Accounts.actor().id`), 'wangxl');
  assert.equal(reload(`JSON.stringify(Accounts.effective('lizq'))`), before);
  reload(`Accounts.toggle('chenzy')`);
  assert.equal(reload(`Accounts.identities().some(u => u.id === 'chenzy')`), true);
});

test('transferring and reclaiming customer projects revokes all old-customer grants, including disabled accounts', () => {
  const storage = new Map(), run = runtime(storage);
  run(`Accounts.selectActor('wangxl'); Accounts.toggle('chenzy'); Assets.assignProject('P1001', 'C002')`);
  assert.equal(run(`Accounts.effective('chenzy').some(g => g.project === 'P1001')`), false);
  assert.equal(run(`Accounts.effective('lizq').some(g => g.project === 'P1001')`), false);
  assert.equal(run(`Accounts.effective('liwn').some(g => g.project === 'P1001')`), false);
  run(`Assets.assignProject('P1001', 'C001')`);
  assert.equal(run(`Accounts.effective('lizq').some(g => g.project === 'P1001')`), false);
  run(`Assets.assignProject('P1002', '')`);
  const reload = runtime(storage);
  assert.equal(reload(`Accounts.effective('wangxl').length`), 0);
  assert.equal(reload(`Accounts.effective('lizq').length`), 0);
});

test('invalid stored roles fall back atomically; storage failure is reported', () => {
  const storage = new Map(), run = runtime(storage);
  run(`Accounts.selectActor('chenzy')`);
  const saved = JSON.parse(storage.get('letu-accounts-v1'));
  saved.users.find(u => u.id === 'lizq').grants[0].capabilities.push('alarms');
  storage.set('letu-accounts-v1', JSON.stringify(saved));
  const reload = runtime(storage);
  assert.equal(reload('Accounts.loadError'), true);
  assert.equal(reload('Accounts.actor().role'), 'superadmin');
  assert.equal(reload(`Accounts.effective('lizq')[0].capabilities.includes('alarms')`), false);
  const memory = runtime(new Map(), true);
  assert.equal(memory(`Accounts.create({username:'memory.admin', name:'内存管理员', role:'admin', customer:'C001',grants:[]})`), false);
  assert.equal(memory(`Accounts.visible().some(u => u.username === 'memory.admin')`), true);
});
