const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const zlib = require('node:zlib');
const context = vm.createContext({ TextDecoder, Blob, DecompressionStream });
vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/panel-upload.js'), 'utf8') + '\nglobalThis.upload = PanelUpload;', context);
function archive(name = 'index.html', method = 8, content = '<h1>面板</h1>') {
  const input = Buffer.from(content), filename = Buffer.from(name), packed = method ? zlib.deflateRawSync(input) : input;
  let crc = 0xffffffff;
  for (const byte of input) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  crc = (crc ^ 0xffffffff) >>> 0;
  const head = Buffer.alloc(30), dir = Buffer.alloc(46), end = Buffer.alloc(22);
  head.writeUInt32LE(0x04034b50); head.writeUInt16LE(20, 4); head.writeUInt16LE(method, 8);
  head.writeUInt32LE(crc, 14); head.writeUInt32LE(packed.length, 18); head.writeUInt32LE(input.length, 22); head.writeUInt16LE(filename.length, 26);
  dir.writeUInt32LE(0x02014b50); dir.writeUInt16LE(20, 4); dir.writeUInt16LE(20, 6);
  dir.writeUInt16LE(method, 10); dir.writeUInt32LE(crc, 16); dir.writeUInt32LE(packed.length, 20);
  dir.writeUInt32LE(input.length, 24); dir.writeUInt16LE(filename.length, 28);
  end.writeUInt32LE(0x06054b50); end.writeUInt16LE(1, 8); end.writeUInt16LE(1, 10);
  end.writeUInt32LE(dir.length + filename.length, 12); end.writeUInt32LE(head.length + filename.length + packed.length, 16);
  return { buffer: Buffer.concat([head, filename, packed, dir, filename, end]), offset: head.length + filename.length + packed.length };
}
const arrayBuffer = buffer => buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.length);
test('ZIP stored and deflated entries are verified and decompressed without dependencies', async () => {
  for (const method of [0, 8]) {
    const data = archive('index.html', method);
    const files = await context.upload.unzip(arrayBuffer(data.buffer));
    assert.equal(new TextDecoder().decode(files.get('index.html')), '<h1>面板</h1>');
  }
});
test('ZIP path traversal, absent entrypoint, CRC damage and expansion claims are rejected', async () => {
  for (const name of ['../index.html', '/index.html', 'a\\index.html']) {
    await assert.rejects(() => context.upload.unzip(arrayBuffer(archive(name).buffer)), /路径/);
  }
  await assert.rejects(() => context.upload.unzip(arrayBuffer(archive('folder/index.html').buffer)), /根目录/);
  const corrupt = archive();
  corrupt.buffer.writeUInt32LE(1234, corrupt.offset + 16);
  await assert.rejects(() => context.upload.unzip(arrayBuffer(corrupt.buffer)), /校验/);
  const oversized = archive();
  oversized.buffer.writeUInt32LE(2000001, oversized.offset + 24);
  await assert.rejects(() => context.upload.unzip(arrayBuffer(oversized.buffer)), /大小/);
  const link = archive();
  link.buffer.writeUInt32LE((0xa000 << 16) >>> 0, link.offset + 38);
  await assert.rejects(() => context.upload.unzip(arrayBuffer(link.buffer)), /符号链接/);
});
