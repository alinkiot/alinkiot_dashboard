const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), blocked = false) {
  const context = vm.createContext({ URL, crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (blocked) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'curves.js', 'panel-workspace.js', 'sync-workspace.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
const input = `{name:'温度同步',project:'P1001',url:'https://devices.example.com',appid:'demo',interval:5,enabled:false,
  products:[{id:'product-temp',bindings:[{property:'value',formulaId:'demo-divide10',version:1,unit:'℃'}]}]}`;
test('discovered products can bind pinned formulas and persist without changing device data or storing secrets', () => {
  const storage = new Map(), run = runtime(storage);
  assert.equal(run(`SyncWorkspace.discover({url:'https://devices.example.com',appid:'demo'}).products.length`), 6);
  run(`const before=JSON.stringify(DEVICES);const result=SyncWorkspace.create({...${input},secret:'NOT-SAVED'})`);
  assert.equal(run('result.persisted'), true);
  assert.equal(runtime(storage)('SyncWorkspace.list()[0].products[0].bindings[0].expression'), 'value / 10');
  run(`SyncWorkspace.toggle(result.id)`);
  assert.equal(run('SyncWorkspace.task(result.id).enabled'), true);
  assert.equal(run('JSON.stringify(DEVICES)===before'), true);
  assert.doesNotMatch(storage.get('letu-sync-workspace-v1'), /secret|NOT-SAVED/);
  run(`SyncWorkspace.create({...${input},products:[{id:'product-temp',bindings:[]}]})`);
  assert.equal(run('SyncWorkspace.list()[1].products[0].bindings.length'), 0);
});
test('invalid product fields, formula versions, duplicate bindings and source credentials are rejected', () => {
  const run = runtime();
  for (const update of [`products:[]`, `interval:0`, `url:'https://devices.example.com?secret=x'`,
    `products:[{id:'missing',bindings:[]}]`,
    `products:[{id:'product-temp',bindings:[{property:'running',formulaId:'demo-divide10',version:1,unit:''}]}]`,
    `products:[{id:'product-temp',bindings:[{property:'value',formulaId:'demo-divide10',version:2,unit:''}]}]`]) {
    assert.throws(() => run(`SyncWorkspace.create({...${input},${update}})`));
  }
  assert.equal(run('SyncWorkspace.list().length'), 0);
});
test('failed persistence remains explicit and corrupted storage resets safely', () => {
  const blocked = runtime(new Map(), true);
  assert.equal(blocked(`SyncWorkspace.create(${input}).persisted`), false);
  assert.equal(blocked('SyncWorkspace.list().length'), 1);
  const bad = runtime(new Map([['letu-sync-workspace-v1','{"version":1,"tasks":[{}]}']]));
  assert.equal(bad('SyncWorkspace.loadError'), true);
  assert.equal(bad('SyncWorkspace.list().length'), 0);
});
