const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), disabled = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (disabled) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'curves.js', 'reports.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
test('template mutations persist, validate atomically, and allow intentional empty lists', () => {
  const storage = new Map(), run = runtime(storage);
  run(`Reports.put(null,{name:'<统计>&"',fields:['average','samples'],decimals:3})`);
  assert.equal(runtime(storage)(`Reports.list()[1].name`), '<统计>&"');
  assert.equal(run(`Reports.list()[1].fields.join(',')`), 'samples,average');
  for (const input of [
    `{name:'设备运行统计',fields:['min'],decimals:2}`,
    `{name:'  ',fields:['min'],decimals:2}`,
    `{name:'bad',fields:[],decimals:2}`,
    `{name:'bad',fields:['min','min'],decimals:2}`,
    `{name:'bad',fields:['inherited'],decimals:2}`,
    `{name:'bad',fields:['min'],decimals:4}`
  ]) assert.throws(() => run(`Reports.put(null,${input})`));
  assert.equal(run('Reports.list().length'), 2);
  run(`Reports.put('seed-report',{name:'重命名',fields:['max'],decimals:0})`);
  assert.equal(runtime(storage)('Reports.list()[0].name'), '重命名');
  assert.throws(() => run(`Reports.put('missing',{name:'无效',fields:['min'],decimals:2})`), /不存在/);
  run(`Reports.list().forEach(t => Reports.remove(t.id))`);
  assert.equal(runtime(storage)('Reports.list().length'), 0);
});
test('report preview and all CSV rows use the historical dataset with independent units', () => {
  const run = runtime();
  run(`const range=Telemetry.defaults('7'); const report=Reports.generate('seed-report','P1001',range.from,range.to)`);
  assert.equal(run('report.rows.length'), 26);
  assert.equal(run(`JSON.stringify(report.rows[0])`), run(`(() => {
    const d=DEVICES.find(d=>d.project==='P1001'), stats=Telemetry.stats(Telemetry.query(d.id,range.from,range.to));
    return JSON.stringify({device:d.id,name:d.name,code:d.code,metric:Curves.metrics[d.type],unit:d.unit,
      samples:stats.samples,min:stats.min,max:stats.max,average:stats.average});
  })()`));
  assert.equal(run('Reports.csv(report).length'), 28);
  assert.equal(run('Reports.csv(report)[2][7]'), run('report.rows[0].average.toFixed(2)'));
  const snapshot = run('JSON.stringify(report)');
  run(`Reports.put('seed-report',{name:'修改后',fields:['min'],decimals:0}); DEVICES[0].name='改名'`);
  assert.equal(run('JSON.stringify(report)'), snapshot);
  assert.equal(run('Reports.csv(report)[0][1]'), '设备运行统计');
});
test('empty samples and projects remain empty, and invalid ranges fail even without devices', () => {
  const run = runtime();
  run(`const outside=Reports.generate('seed-report','P1001','2026-09-01T00:00','2026-09-02T00:00')`);
  assert.equal(run('outside.rows[0].samples'), 0);
  assert.equal(run(`Reports.value(outside,outside.rows[0],'average')`), '—');
  run(`PROJECTS.push({id:'empty',name:'空项目'})`);
  assert.equal(run(`Reports.generate('seed-report','empty','2026-10-01T00:00','2026-10-01T00:00').rows.length`), 0);
  assert.throws(() => run(`Reports.generate('seed-report','empty','2026-10-02T00:00','2026-10-01T00:00')`), /开始/);
  assert.throws(() => run(`Reports.generate('seed-report','empty','2026-01-01T00:00','2026-10-01T00:00')`), /90/);
  assert.throws(() => run(`Reports.generate('seed-report','missing','2026-10-01T00:00','2026-10-01T00:00')`), /项目/);
});
test('malformed storage falls back atomically; failed saves retain memory changes', () => {
  const storage = new Map([['letu-reports-v1', JSON.stringify({ version: 1, items: [
    { id: 'okay', name: '半份存档', fields: ['min'], decimals: 2 }, null
  ] })]]);
  const run = runtime(storage);
  assert.equal(run('Reports.loadError'), true);
  assert.equal(run('Reports.list()[0].id'), 'seed-report');
  const blocked = runtime(new Map(), true);
  assert.equal(blocked(`Reports.remove('seed-report')`), false);
  assert.equal(blocked('Reports.list().length'), 0);
});
