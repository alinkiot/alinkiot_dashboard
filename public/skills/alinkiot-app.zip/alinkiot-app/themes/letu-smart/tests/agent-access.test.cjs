const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function runtime(storage = new Map(), blocked = false) {
  const context = vm.createContext({ URL, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (blocked) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'agent-access.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
test('project configuration discovers demo avatars and persists independent call targets without secrets', () => {
  const storage = new Map(), run = runtime(storage);
  run(`AgentAccess.save({project:'P1001',url:'https://agents.example.com/',appid:'demo',secret:'DO-NOT-STORE'});
    AgentAccess.save({project:'P1002',url:'https://other.example.com',appid:'other'});`);
  assert.equal(run(`AgentAccess.avatars('P1001').length`), 3);
  assert.equal(JSON.parse(storage.get('letu-agent-access-v1')).entries[0].avatars.length, 3);
  assert.equal(runtime(storage)(`AgentAccess.avatars('P1001').length`), 3);
  assert.equal(run(`AgentAccess.target('P1001')`), null);
  run(`AgentAccess.loadAvatars('P1001');AgentAccess.select('P1001','demo-report')`);
  assert.equal(run(`AgentAccess.target('P1001').avatar.id`), 'demo-report');
  assert.equal(run(`AgentAccess.target('P1001').callable`), false);
  assert.equal(run(`AgentAccess.target('P1002')`), null);
  run(`AgentAccess.loadAvatars('P1001')`);
  assert.equal(run(`AgentAccess.avatars('P1001').length`), 3);
  assert.equal(run(`AgentAccess.target('P1001').avatar.id`), 'demo-report');
  assert.equal(runtime(storage)(`AgentAccess.target('P1001').url`), 'https://agents.example.com');
  assert.doesNotMatch(storage.get('letu-agent-access-v1'), /secret|DO-NOT-STORE/);
  run(`AgentAccess.save({...AgentAccess.config('P1001'),url:'https://new.example.com'})`);
  assert.equal(run(`AgentAccess.target('P1001')`), null);
  assert.equal(run(`AgentAccess.avatars('P1001').length`), 3);
});
test('invalid URLs and out-of-scope avatar selection are rejected without changing configuration', () => {
  const run = runtime();
  for (const url of ['javascript:alert(1)', 'file:///tmp/demo', 'https://user:pass@example.com',
    'https://example.com?secret=x', 'https://example.com#token', 'not a url']) {
    assert.throws(() => run(`AgentAccess.save({project:'P1001',url:${JSON.stringify(url)},appid:'demo'})`));
  }
  assert.equal(run('AgentAccess.list().length'), 0);
  assert.throws(() => run(`AgentAccess.loadAvatars('P1001')`), /先新增/);
  run(`AgentAccess.save({project:'P1001',url:'https://agents.example.com',appid:'demo'})`);
  run(`AgentAccess.select('P1001','demo-report')`);
  run(`AgentAccess.loadAvatars('P1001')`);
  assert.throws(() => run(`AgentAccess.select('P1001','other-platform-avatar')`), /当前列表/);
});
test('malformed saved targets and failed persistence have explicit recovery', () => {
  const bad = runtime(new Map([['letu-agent-access-v1','{"version":1,"entries":[{}]}']]));
  assert.equal(bad('AgentAccess.loadError'), true);
  assert.equal(bad('AgentAccess.list().length'), 0);
  const run = runtime(new Map(), true);
  assert.equal(run(`AgentAccess.save({project:'P1001',url:'https://agents.example.com',appid:'demo'})`), false);
  assert.equal(run(`AgentAccess.loadAvatars('P1001')`), false);
  assert.equal(run(`AgentAccess.select('P1001','demo-analysis')`), false);
  assert.equal(run(`AgentAccess.target('P1001').avatar.id`), 'demo-analysis');
});
