const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), disabled = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (disabled) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'curves.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
test('create, rename and removal persist without changing device data', () => {
  const storage = new Map(), run = runtime(storage);
  assert.throws(() => run(`Curves.add({device:'D00001',name:'重复'})`), /已在/);
  assert.throws(() => run(`Curves.add({device:'missing',name:'无效'})`), /有效设备/);
  assert.throws(() => run(`Curves.add({device:'D00004',name:'  '})`), /名称/);
  run(`Curves.add({device:'D00004',name:'<趋势>&"'}); Curves.rename(Curves.list()[0].id, '重命名')`);
  const reload = runtime(storage);
  assert.equal(reload('Curves.list().length'), 4);
  assert.equal(reload('Curves.list()[0].name'), '重命名');
  assert.equal(reload('Curves.list()[3].name'), '<趋势>&"');
  reload('Curves.remove(Curves.list()[0].id)');
  assert.equal(reload('DEVICES.length'), run('DEVICES.length'));
  reload('Curves.clear()');
  assert.equal(runtime(storage)('Curves.list().length'), 0);
});
test('device selection is atomic, capped and preserves existing names', () => {
  const run = runtime();
  run(`Curves.rename(Curves.list()[0].id,'保留名称')`);
  assert.throws(() => run(`Curves.select(['D00001','D00001'])`), /不同设备/);
  assert.throws(() => run(`Curves.select(['missing'])`), /不存在/);
  assert.equal(run('Curves.list().length'), 3);
  run(`Curves.select(DEVICES.slice(0,12).map(d => d.id))`);
  assert.equal(run('Curves.list()[0].name'), '保留名称');
  assert.throws(() => run(`Curves.add({device:'D00013',name:'超限'})`), /最多/);
  assert.throws(() => run(`Curves.select(DEVICES.slice(0,13).map(d => d.id))`), /12/);
  assert.equal(run('Curves.list().length'), 12);
});
test('curve values are identical to the historical dataset at matching timestamps', () => {
  const storage = new Map(), run = runtime(storage);
  assert.equal(run(`JSON.stringify(Curves.query('D00001'))`),
    run(`JSON.stringify(Telemetry.query('D00001',Telemetry.defaults('7').from,Telemetry.defaults('7').to))`));
  run(`Curves.setRange('24')`);
  assert.equal(run(`Curves.query('D00001').length`), 25);
  assert.equal(runtime(storage)('Curves.range'), '24');
  assert.throws(() => run(`Curves.setRange('bad')`), /时间范围/);
});
test('bad storage falls back and disabled storage reports memory-only changes', () => {
  const storage = new Map([['letu-curves-v1', '{"version":1,"items":[null],"range":"7"}']]);
  assert.equal(runtime(storage)('Curves.loadError'), true);
  const run = runtime(new Map(), true);
  assert.equal(run('Curves.clear()'), false);
  assert.equal(run('Curves.list().length'), 0);
});
