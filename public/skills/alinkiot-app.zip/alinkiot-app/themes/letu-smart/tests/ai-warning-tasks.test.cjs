const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), blocked = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (blocked) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'alarm-store.js', 'ai-warning-tasks.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
const input = `{name:'运行预警',project:'P1001',devices:['D00001'],interval:15,window:60,
  prompt:'分析持续异常',condition:'有数据证据时触发',level:'中',enabled:false}`;
test('warning task scope and timing persist; enabling never creates an alarm or execution record', () => {
  const storage = new Map(), run = runtime(storage);
  run(`const before=JSON.stringify(AlarmStore.snapshot('P1001'));const result=AIWarningTasks.create(${input})`);
  assert.equal(run('result.persisted'), true);
  assert.equal(runtime(storage)('AIWarningTasks.list()[0].window'), 60);
  assert.equal(run('AIWarningTasks.toggle(result.id)'), true);
  assert.equal(runtime(storage)('AIWarningTasks.list()[0].enabled'), true);
  assert.equal(run(`JSON.stringify(AlarmStore.snapshot('P1001'))===before`), true);
  assert.equal(run('AIWarningTasks.task(result.id).lastRun'), undefined);
  run('const copy=AIWarningTasks.list();copy[0].devices=[]');
  assert.equal(run('AIWarningTasks.task(result.id).devices.length'), 1);
  run('AIWarningTasks.toggle(result.id)');
  assert.equal(run('AIWarningTasks.task(result.id).enabled'), false);
});
test('warning tasks reject invalid schedules, missing triggers and cross-project devices', () => {
  const run = runtime();
  for (const update of [`interval:0`, `interval:1.5`, `interval:1441`, `window:0`, `window:10081`,
    `devices:[]`, `devices:['D00027']`, `devices:['D00001','D00001']`,
    `condition:' '`, `prompt:' '`, `level:'紧急'`, `enabled:'true'`]) {
    assert.throws(() => run(`AIWarningTasks.create({...${input},${update}})`));
  }
  assert.equal(run('AIWarningTasks.list().length'), 0);
  assert.throws(() => run(`AIWarningTasks.toggle('missing')`), /不存在/);
});
test('corrupted storage and persistence failures are explicit; stale scope cannot be re-enabled', () => {
  const bad = runtime(new Map([['letu-ai-warning-tasks-v1','{"version":1,"tasks":[{}]}']]));
  assert.equal(bad('AIWarningTasks.loadError'), true);
  assert.equal(bad('AIWarningTasks.list().length'), 0);
  const run = runtime(new Map(), true);
  assert.equal(run(`AIWarningTasks.create(${input}).persisted`), false);
  assert.equal(run('AIWarningTasks.toggle(AIWarningTasks.list()[0].id)'), false);
  run(`DEVICES.find(d=>d.id==='D00001').project='P1002'`);
  assert.equal(run('AIWarningTasks.toggle(AIWarningTasks.list()[0].id)'), false);
  assert.throws(() => run('AIWarningTasks.toggle(AIWarningTasks.list()[0].id)'), /本项目/);
  assert.equal(run('AIWarningTasks.list()[0].enabled'), false);
});
