const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), blocked = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (blocked) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'ai-report-tasks.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
const input = `{name:'运行周报',project:'P1001',devices:['D00001'],prompt:'总结运行状态',...Telemetry.defaults('7')}`;
test('task creation persists scope and requirements, while generation is explicitly blocked without a result', () => {
  const storage = new Map(), run = runtime(storage);
  run(`const result=AIReportTasks.create(${input})`);
  assert.equal(run('result.persisted'), true);
  assert.equal(runtime(storage)('AIReportTasks.list()[0].prompt'), '总结运行状态');
  assert.equal(run('AIReportTasks.task(result.id).status'), 'pending');
  assert.equal(run('AIReportTasks.generate(result.id)'), true);
  assert.equal(runtime(storage)('AIReportTasks.list()[0].status'), 'blocked');
  assert.equal(run('AIReportTasks.task(result.id).report'), undefined);
  run('const copy=AIReportTasks.list();copy[0].devices=[]');
  assert.equal(run('AIReportTasks.task(result.id).devices.length'), 1);
});
test('task inputs enforce project membership, time ordering, nonempty requirements and bounded selection', () => {
  const run = runtime();
  for (const update of [`devices:[]`, `devices:['D00027']`, `devices:['D00001','D00001']`,
    `project:'missing'`, `prompt:' '`, `from:'2026-10-30T00:00',to:'2026-10-01T00:00'`,
    `from:'2026-01-01T00:00',to:'2026-10-30T00:00'`]) {
    assert.throws(() => run(`AIReportTasks.create({...${input},${update}})`));
  }
  assert.equal(run('AIReportTasks.list().length'), 0);
  assert.throws(() => run(`AIReportTasks.generate('missing')`), /不存在/);
});
test('bad storage recovers to an explicit empty state and blocked persistence keeps memory only', () => {
  const bad = runtime(new Map([['letu-ai-report-tasks-v1', '{"version":1,"tasks":[{}]}']]));
  assert.equal(bad('AIReportTasks.loadError'), true);
  assert.equal(bad('AIReportTasks.list().length'), 0);
  const run = runtime(new Map(), true);
  assert.equal(run(`AIReportTasks.create(${input}).persisted`), false);
  assert.equal(run('AIReportTasks.list().length'), 1);
  assert.equal(run('AIReportTasks.generate(AIReportTasks.list()[0].id)'), false);
  assert.equal(run('AIReportTasks.list()[0].status'), 'blocked');
});
