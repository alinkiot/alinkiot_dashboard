const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), disabled = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (disabled) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'ui.js', 'assets.js', 'telemetry.js', 'alarm-store.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
test('handling persists independently from physical recovery and cannot repeat completed transitions', () => {
  const storage = new Map(), run = runtime(storage);
  assert.throws(() => run(`AlarmStore.handle('P1001','AL-001','ack','核查','user')`), /只能查看/);
  assert.throws(() => run(`AlarmStore.handle('P1001','AL-001','ack','  ','admin')`), /处理说明/);
  assert.throws(() => run(`AlarmStore.handle('P1001','AL-001','bad','说明','admin')`), /无效/);
  run(`AlarmStore.handle('P1001','AL-001','ack','<核查>&"','admin')`);
  assert.throws(() => run(`AlarmStore.handle('P1001','AL-001','ack','重复','admin')`), /状态/);
  run(`AlarmStore.handle('P1001','AL-001','resolve','处理完成','admin')`);
  assert.throws(() => run(`AlarmStore.handle('P1001','AL-001','resolve','重复','admin')`), /状态/);
  const reload = runtime(storage);
  assert.equal(reload(`AlarmStore.snapshot('P1001').events[0].physical`), '活动');
  assert.equal(reload(`AlarmStore.snapshot('P1001').events[0].handling`), '已处理');
  assert.equal(reload(`AlarmStore.snapshot('P1001').events[0].actions[0].note`), '<核查>&"');
  assert.equal(reload(`AlarmStore.snapshot('P1002').events[0].handling`), '待确认');
});
test('rule versions change without modifying historical event evidence or version', () => {
  const storage = new Map(), run = runtime(storage);
  const before = run(`JSON.stringify(AlarmStore.snapshot('P1001').events)`);
  run(`var rule = AlarmStore.snapshot('P1001').rule`);
  assert.throws(() => run(`AlarmStore.saveRule('P1001',{...rule,recovery:rule.threshold},'admin')`), /恢复值/);
  assert.throws(() => run(`AlarmStore.saveRule('P1001',{...rule,device:'D00027'},'admin')`), /无效/);
  assert.throws(() => run(`AlarmStore.saveRule('P1001',rule,'user')`), /只能查看/);
  run(`AlarmStore.saveRule('P1001',{...rule,threshold:100,recovery:90,duration:120,level:'低'},'admin');
    AlarmStore.toggle('P1001','admin')`);
  const reload = runtime(storage);
  assert.equal(reload(`AlarmStore.snapshot('P1001').rule.version`), 3);
  assert.equal(reload(`AlarmStore.snapshot('P1001').rule.enabled`), false);
  assert.equal(reload(`JSON.stringify(AlarmStore.snapshot('P1001').events)`), before);
});
test('notification retries are bounded, persistent and project-isolated', () => {
  const storage = new Map(), run = runtime(storage);
  assert.throws(() => run(`AlarmStore.retry('P1001','user')`), /只能查看/);
  run(`AlarmStore.retry('P1001','admin')`);
  assert.equal(runtime(storage)(`AlarmStore.snapshot('P1001').attempts.length`), 1);
  assert.equal(run(`AlarmStore.snapshot('P1002').attempts.length`), 0);
  run(`for(let i=1;i<100;i++) AlarmStore.retry('P1001','admin')`);
  assert.throws(() => run(`AlarmStore.retry('P1001','admin')`), /上限/);
  assert.ok(!storage.get('letu-alarms-v1').includes('delivered'));
});
test('empty projects, malformed storage and storage failures have explicit outcomes', () => {
  const run = runtime(new Map(), true);
  assert.equal(run(`AlarmStore.handle('P1001','AL-001','ack','说明','admin')`), false);
  run(`Assets.saveProject({name:'空项目',code:'EMPTY',desc:'',apiId:'',customer:'',status:'active'})`);
  assert.equal(run(`AlarmStore.snapshot(PROJECTS[0].id).events.length`), 0);
  assert.equal(run(`AlarmStore.snapshot(PROJECTS[0].id).rule`), null);
  assert.throws(() => run(`AlarmStore.snapshot('missing')`), /有效项目/);
  const storage = new Map([['letu-alarms-v1','{"version":1,"projects":[["P1001",null]]}']]);
  const fallback = runtime(storage);
  assert.equal(fallback('AlarmStore.loadError'), true);
  assert.equal(fallback(`AlarmStore.snapshot('P1001').events.length`), 3);
});
