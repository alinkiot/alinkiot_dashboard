const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');

function runtime(storage = new Map(), disabled = false) {
  const context = vm.createContext({
    crypto: { randomUUID },
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => {
        if (disabled) throw new Error('Storage disabled');
        storage.set(key, value);
      }
    }
  });
  for (const file of ['data.js', 'ui.js', 'assets.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}

test('customer edits persist raw text, reject duplicates and create no account credentials', () => {
  const storage = new Map();
  const run = runtime(storage);
  run(`Assets.saveCustomer({name: '<客户> "甲"', short: '甲', contact: '联系人', phone: '+86 123-456', industry: '水务'})`);
  assert.equal(run('CUSTOMERS[0].projects'), 0);
  assert.throws(() => run(`Assets.saveCustomer({name: '<客户> "甲"', short: '乙', contact: '', phone: '', industry: '水务'})`), /已存在/);
  assert.throws(() => run(`Assets.saveCustomer({name: ' ', short: '乙', contact: '', phone: '', industry: '水务'})`), /请填写/);
  const reload = runtime(storage);
  assert.equal(reload('CUSTOMERS[0].name'), '<客户> "甲"');
  assert.equal(reload('Assets.loadError'), false);
  assert.ok(!storage.get('letu-assets-v1').includes('password'));
});

test('transferring and reclaiming a project update both customers and dependent device ownership', () => {
  const storage = new Map();
  const run = runtime(storage);
  const before = run(`JSON.stringify(CUSTOMERS.filter(c => ['C001','C002'].includes(c.id)).map(c => [c.projects,c.devices]))`);
  run(`Assets.assignProject('P1001', 'C002')`);
  assert.equal(run(`CUSTOMERS.find(c => c.id === 'C001').projects`), 2);
  assert.equal(run(`CUSTOMERS.find(c => c.id === 'C002').devices`), 704);
  assert.equal(run(`DEVICES.filter(d => d.project === 'P1001').every(d => d.customer === 'C002')`), true);
  run(`Assets.toggleCustomer('C002')`);
  assert.equal(run(`PROJECTS.find(p => p.id === 'P1001').customer`), 'C002');
  run(`Assets.toggleCustomer('C002'); Assets.assignProject('P1001', '')`);
  assert.equal(run(`DEVICES.filter(d => d.project === 'P1001').every(d => d.customer === '')`), true);
  const reload = runtime(storage);
  assert.equal(reload(`PROJECTS.find(p => p.id === 'P1001').customer`), '');
  assert.equal(reload(`DEVICES.filter(d => d.project === 'P1001').every(d => d.customer === '')`), true);
  run(`Assets.assignProject('P1001', 'C001')`);
  assert.equal(run(`JSON.stringify(CUSTOMERS.filter(c => ['C001','C002'].includes(c.id)).map(c => [c.projects,c.devices]))`), before);
});

test('project creation and edit enforce unique mappings and preserve read-only ownership fields', () => {
  const storage = new Map();
  const run = runtime(storage);
  run(`var input = {name: '新项目', code: 'MANUAL-1', desc: '</textarea>', apiId: 'NEW-API', customer: '', status: 'active'};
    Assets.saveProject(input); var projectId = PROJECTS[0].id`);
  assert.equal(run('PROJECTS[0].devices'), 0);
  assert.throws(() => run('Assets.saveProject(input)'), /项目编号已存在/);
  assert.throws(() => run(`Assets.saveProject({...input, code: 'MANUAL-2'})`), /API 项目 ID已存在/);
  assert.throws(() => run(`Assets.saveProject({...input, code: 'CHANGED'}, projectId)`), /编号不可修改/);
  assert.throws(() => run(`Assets.saveProject({...input, customer: 'C001'}, projectId)`), /调整客户归属/);
  run(`Assets.saveProject({...input, status: 'paused', name: '修改后'}, projectId)`);
  const reload = runtime(storage);
  assert.equal(reload('PROJECTS[0].name'), '修改后');
  assert.equal(reload('PROJECTS[0].status'), 'paused');
  assert.equal(reload('PROJECTS[0].desc'), '</textarea>');
});

test('bad storage falls back atomically and unavailable storage reports memory-only updates', () => {
  const storage = new Map([['letu-assets-v1', '{"version":1,"customers":[null],"projects":[]}']]);
  const run = runtime(storage);
  assert.equal(run('Assets.loadError'), true);
  assert.equal(run('CUSTOMERS.length'), 10);
  assert.equal(run('PROJECTS.length'), 19);
  const memory = runtime(new Map(), true);
  assert.equal(memory(`Assets.saveProject({name:'内存项目',code:'MEMORY',desc:'',apiId:'',customer:'',status:'active'})`), false);
  assert.equal(memory('PROJECTS[0].name'), '内存项目');
});
