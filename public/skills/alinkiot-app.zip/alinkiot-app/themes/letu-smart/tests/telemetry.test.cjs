const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const context = vm.createContext({});
for (const file of ['data.js', 'telemetry.js']) {
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
}
const run = source => vm.runInContext(source, context);

test('hour samples are deterministic across ranges and query all inclusive boundaries', () => {
  const rows = JSON.parse(run(`JSON.stringify(Telemetry.query('D00001', '2026-10-01T00:00', '2026-10-01T02:00'))`));
  assert.equal(rows.length, 3);
  assert.equal(run(`Telemetry.format(${rows[0].time})`), '2026-10-01 00:00:00');
  assert.equal(run(`Telemetry.query('D00001', '2026-10-01T01:00', '2026-10-01T01:00')[0].value`), rows[1].value);
  assert.equal(run(`Telemetry.query('D00001', '2026-10-01T00:01', '2026-10-01T01:59').length`), 1);
  assert.equal(run(`Telemetry.query('D00001', '2026-10-01T00:01', '2026-10-01T00:59').length`), 0);
  assert.notEqual(run(`Telemetry.query('D00002', '2026-10-01T01:00', '2026-10-01T01:00')[0].value`), rows[1].value);
});

test('daily averages and statistics derive from the same raw results', () => {
  run(`var raw = Telemetry.query('D00001', '2026-10-01T00:00', '2026-10-02T00:00');
    var days = Telemetry.query('D00001', '2026-10-01T00:00', '2026-10-02T00:00', 'day')`);
  assert.equal(run('days.length'), 2);
  assert.equal(run('days[0].count'), 24);
  assert.equal(run('days[1].count'), 1);
  assert.equal(run('days[0].value'), run('+(raw.slice(0,24).reduce((sum,r) => sum + r.value, 0) / 24).toFixed(3)'));
  assert.equal(run('Telemetry.stats(days).samples'), 25);
  assert.equal(run('Telemetry.stats(days).count'), 2);
  assert.equal(run('Telemetry.stats(raw).max'), run('Math.max(...raw.map(r => r.value))'));
  assert.equal(run('Telemetry.stats([])'), null);
});

test('fixed sample window produces empty results outside it and handles invalid intervals', () => {
  assert.equal(run(`Telemetry.query('D00001', '2026-11-01T00:00', '2026-11-02T00:00').length`), 0);
  assert.equal(run(`Telemetry.query('D00001', '2026-10-30T00:00', '2026-10-30T23:59').length`), 1);
  assert.throws(() => run(`Telemetry.query('missing', '2026-10-01T00:00', '2026-10-02T00:00')`), /有效设备/);
  assert.throws(() => run(`Telemetry.query('D00001', '2026-10-02T00:00', '2026-10-01T00:00')`), /晚于/);
  assert.throws(() => run(`Telemetry.query('D00001', '2026-01-01T00:00', '2026-10-01T00:00')`), /90 天/);
  assert.throws(() => run(`Telemetry.parse('2026-02-30T00:00')`), /格式/);
  assert.throws(() => run(`Telemetry.query('D00001', '2026-10-01T00:00', '2026-10-02T00:00', 'minute')`), /聚合/);
});
