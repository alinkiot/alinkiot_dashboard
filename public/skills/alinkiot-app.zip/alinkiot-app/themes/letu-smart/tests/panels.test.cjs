const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { randomUUID } = require('node:crypto');
function runtime(storage = new Map(), blocked = false) {
  const context = vm.createContext({ crypto: { randomUUID }, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => { if (blocked) throw new Error('disabled'); storage.set(key, value); }
  } });
  for (const file of ['data.js', 'telemetry.js', 'curves.js', 'panel-workspace.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js', file), 'utf8'), context);
  }
  return source => vm.runInContext(source, context);
}
test('synced products validate metadata, bind matching devices, and retain valid simulated state on updates', () => {
  const storage = new Map(), run = runtime(storage);
  run(`const d=DEVICES.find(d=>d.status==='online' && !Curves.list().some(c=>c.device===d.id));
    const product=PanelWorkspace.productFor(d.id); product.name='自建产品';
    PanelWorkspace.syncProduct(null,product);
    const custom=PanelWorkspace.products().at(-1);
    PanelWorkspace.bindDevice(d.id,custom.id,{lng:0,lat:0});
    PanelWorkspace.control(d.id,'running',true);
    PanelWorkspace.syncProduct(custom.id,{...custom,name:'改名'});`);
  assert.equal(run(`PanelWorkspace.device(d.id).values.running`), true);
  assert.equal(runtime(storage)(`PanelWorkspace.products().at(-1).name`), '改名');
  assert.equal(run(`JSON.stringify(PanelWorkspace.device(d.id).location)`), '{"lat":0,"lng":0}');
  assert.throws(() => run(`PanelWorkspace.bindDevice(d.id,'product-'+DEVICE_TYPES.find(t=>t.key!==d.type).key,null)`), /类型/);
  assert.throws(() => run(`PanelWorkspace.bindDevice(d.id,custom.id,{lng:181,lat:0})`), /经纬度/);
  assert.throws(() => run(`PanelWorkspace.removeProduct(custom.id)`), /绑定/);
  assert.throws(() => run(`PanelWorkspace.syncProduct(null,{...custom,name:'坏属性',properties:[{...custom.properties[0],key:'__proto__'}]})`), /标识/);
  assert.throws(() => run(`PanelWorkspace.syncProduct(null,{...custom,name:'单位不符',properties:[{...custom.properties[0],unit:'x'}]})`), /单位/);
  assert.throws(() => run(`PanelWorkspace.syncProduct(null,{...custom,name:'可写遥测',properties:[{...custom.properties[0],writable:true}]})`), /只读/);
});
test('scenes enforce project membership, isolate panels, and remove associations without deleting devices', () => {
  const storage = new Map(), run = runtime(storage);
  run(`PanelWorkspace.saveScene(null,{name:'场景A',project:'P1001',devices:['D00001','D00002']});
    const s=PanelWorkspace.scenes('P1001')[0];
    PanelWorkspace.savePanel(null,{name:'显示一',kind:'scene',owner:s.id,series:[],html:{source:'<b>A</b>',filename:'A.html'}});
    const p=PanelWorkspace.panels('scene',s.id)[0]`);
  assert.equal(runtime(storage)(`PanelWorkspace.scenes('P1001')[0].devices.length`), 2);
  assert.equal(run(`PanelWorkspace.contextDevices('scene',s.id,p.id).join(',')`), 'D00001,D00002');
  assert.throws(() => run(`PanelWorkspace.saveScene(s.id,{...s,devices:['D00027']})`), /项目/);
  assert.throws(() => run(`PanelWorkspace.contextDevices('screen','P1002',p.id)`), /归属/);
  run(`PanelWorkspace.saveScene(s.id,{...s,devices:['D00002']})`);
  assert.equal(run(`PanelWorkspace.contextDevices('scene',s.id,p.id).join(',')`), 'D00002');
  const count = run('DEVICES.length');
  run(`PanelWorkspace.removeScene(s.id)`);
  assert.equal(run(`PanelWorkspace.panels('scene',s.id).length`), 0);
  assert.equal(run('DEVICES.length'), count);
});
test('curve panels select numeric properties, preserve legacy choices and prevent dangling bindings', () => {
  const run = runtime();
  assert.equal(run(`PanelWorkspace.panels('curve')[0].series.length`), 3);
  run(`const d=DEVICES[0], p=PanelWorkspace.productFor(d.id), range=Telemetry.defaults('7')`);
  assert.equal(run(`JSON.stringify(PanelWorkspace.history(d.id,'value',range.from,range.to))`),
    run(`JSON.stringify(Telemetry.query(d.id,range.from,range.to).map(r=>({time:r.time,value:r.value})))`));
  assert.equal(run(`PanelWorkspace.history(d.id,'signal',range.from,range.to).length`), 0);
  assert.throws(() => run(`PanelWorkspace.savePanel(null,{name:'错误',kind:'curve',owner:'',series:[{device:d.id,property:'running',name:'开关'}],html:null})`), /数值/);
  assert.throws(() => run(`PanelWorkspace.syncProduct(p.id,{...p,properties:p.properties.filter(x=>x.key!=='value')})`), /曲线/);
  run(`PanelWorkspace.syncProduct(null,{...p,name:'新产品'})`);
  assert.throws(() => run(`PanelWorkspace.bindDevice(d.id,PanelWorkspace.products().at(-1).id,null)`), /曲线/);
  run(`PanelWorkspace.addDeviceCurve(d.id);PanelWorkspace.addDeviceCurve(d.id)`);
  assert.equal(run(`PanelWorkspace.panel('curve-default').series.length`), 3);
});
test('project screens start with one base and support persisted custom packages and restore', () => {
  const storage = new Map(), run = runtime(storage);
  run(`const id=PanelWorkspace.ensureScreen('P1001'); PanelWorkspace.ensureScreen('P1001');
    const p=PanelWorkspace.panel(id);
    PanelWorkspace.savePanel(id,{...p,html:{source:'<b>屏</b>',filename:'screen.zip'}})`);
  assert.equal(run(`PanelWorkspace.panels('screen','P1001').length`), 1);
  assert.equal(runtime(storage)(`PanelWorkspace.panels('screen','P1001')[0].html.filename`), 'screen.zip');
  assert.equal(run(`PanelWorkspace.contextDevices('screen','P1001',id).length`), 26);
  assert.throws(() => run(`PanelWorkspace.savePanel(id,{...p,owner:'P1002'})`), /归属/);
  run(`PanelWorkspace.savePanel(id,{...p,html:null})`);
  assert.equal(runtime(storage)(`PanelWorkspace.panels('screen','P1001')[0].html`), null);
});
test('simulation is typed, offline-aware and observable without altering snapshots or historical data', () => {
  const run = runtime();
  run(`const on=DEVICES.find(d=>d.status==='online'), off=DEVICES.find(d=>d.status==='offline');
    let updates=0; const stop=PanelWorkspace.subscribe(()=>updates++);`);
  assert.throws(() => run(`PanelWorkspace.control(on.id,'value',3)`), /不可控制/);
  assert.throws(() => run(`PanelWorkspace.control(on.id,'running','true')`), /类型/);
  assert.throws(() => run(`PanelWorkspace.control(off.id,'running',true)`), /离线/);
  run(`PanelWorkspace.control(on.id,'running',true)`);
  assert.equal(run('updates'), 1);
  assert.equal(run('PanelWorkspace.device(on.id).values.running'), true);
  run(`stop(); PanelWorkspace.control(on.id,'running',false)`);
  assert.equal(run('updates'), 1);
  assert.equal(run('DEVICES.find(d=>d.id===on.id).running'), undefined);
});
test('invalid saved relations fall back atomically; failed storage keeps explicit memory state', () => {
  const storage = new Map(), run = runtime(storage);
  run(`PanelWorkspace.control(DEVICES.find(d=>d.status==='online').id,'running',true)`);
  const saved = JSON.parse(storage.get('letu-panels-v1'));
  saved.data.bindings.D00001 = 'missing';
  storage.set('letu-panels-v1', JSON.stringify(saved));
  assert.equal(runtime(storage)('PanelWorkspace.loadError'), true);
  const blocked = runtime(new Map(), true);
  assert.equal(blocked(`PanelWorkspace.addDeviceCurve('D00004')`), false);
  assert.equal(blocked(`PanelWorkspace.panel('curve-default').series.length`), 4);
});
test('product UI exposes synced properties read-only and unconfigured sync does not mutate data', () => {
  const run = runtime();
  run(`globalThis.VIEWS={}; globalThis.Workspace={page:()=>({}),save:()=>{}};
    globalThis.escapeHTML=value=>String(value).replaceAll('<','&lt;').replaceAll('>','&gt;');
    globalThis.icon=()=>'';globalThis.badge=()=>'';globalThis.projName=()=>'';globalThis.go=()=>{};
    let drawer,notice,syncHandler;
    globalThis.openDrawer=(...args)=>{drawer=args};
    globalThis.toast=message=>{notice=message};`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  run(`openProductProperties(PanelWorkspace.products()[0])`);
  assert.match(run('drawer[1]'), /后台仅查看/);
  assert.doesNotMatch(run('drawer[1]'), /<input|<select|<textarea|保存产品/);
  assert.match(run('drawer[2]'), /requestProductSync\(\).*同步属性/);
  assert.match(run('VIEWS.products.render()'), /查看属性/);
  assert.doesNotMatch(run('VIEWS.products.render()'), /新建产品|编辑属性|data-product-delete/);
  const before = run('JSON.stringify(PanelWorkspace.products())');
  run(`const button={}; VIEWS.products.mount({
    querySelector:selector=>selector==='[data-product-sync]'?button:{value:''},
    addEventListener:()=>{}
  });button.onclick();`);
  assert.match(run('notice'), /本次未执行同步/);
  assert.equal(run('JSON.stringify(PanelWorkspace.products())'), before);
});
test('selecting a product switches its panel directly, while properties and repeated selections preserve context', () => {
  const run = runtime();
  run(`globalThis.VIEWS={}; const page={selected:'product-flow',device:'chosen',panel:'custom'};
    let saves=0,routes=0,drawer;
    globalThis.Workspace={page:()=>page,save:()=>saves++};
    globalThis.escapeHTML=value=>String(value);
    globalThis.icon=()=>'';globalThis.badge=()=>'';globalThis.projName=()=>'';
    globalThis.go=()=>routes++;globalThis.openDrawer=(...args)=>{drawer=args};
    globalThis.document={getElementById:()=>({scrollTop:100})};
    globalThis.toast=()=>{}; const clicks=[];
    const preview={innerHTML:''};
    const scope={querySelector:selector=>selector==='[data-product-preview]'?preview:{value:''},
      querySelectorAll:()=>[],addEventListener:(type,fn)=>{if(type==='click')clicks.push(fn)}};
    function click(dataset){clicks.forEach(fn=>fn({target:{closest:()=>({dataset,hasAttribute:()=>false})}}))}`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  const html = run('VIEWS.products.render()');
  assert.match(html, /class="product-card-select"[^>]*data-product-open="product-flow"[^>]*aria-pressed="true"/);
  assert.doesNotMatch(html, />设备与面板<\/button>/);
  assert.match(html, /data-product-open="product-flow">查看面板<\/button>/);
  run(`VIEWS.products.mount(scope);click({productProperties:'product-level'})`);
  assert.equal(run('page.selected'), 'product-flow');
  assert.equal(run('routes'), 0);
  assert.match(run('drawer[0]'), /查看属性/);
  run(`click({productOpen:'product-flow'})`);
  assert.equal(run('page.panel'), 'custom');
  assert.equal(run('routes'), 0);
  run(`click({productOpen:'product-level'})`);
  assert.equal(run('page.selected'), 'product-level');
  assert.equal(run('page.device'), '');
  assert.equal(run('page.panel'), '');
  assert.equal(run('saves'), 1);
  assert.equal(run('routes'), 0);
  assert.match(run('preview.innerHTML'), /设备面板预览/);
  assert.match(run('preview.innerHTML'), /设备状态/);
  assert.match(run('preview.innerHTML'), /设备控制/);
  assert.doesNotMatch(run('preview.innerHTML'), /<table/);
});
test('scene navigation groups projects and keeps device, map and custom content in separate tabs', () => {
  const run = runtime();
  run(`globalThis.VIEWS={}; const page={};
    globalThis.Workspace={project:'P1001',page:()=>page,save:()=>{}};
    globalThis.escapeHTML=value=>String(value);
    globalThis.icon=()=>'';globalThis.badge=()=>'';globalThis.projName=id=>id;
    PanelWorkspace.saveScene(null,{name:'场景A',project:'P1001',devices:['D00001']});
    PanelWorkspace.saveScene(null,{name:'场景B',project:'P1002',devices:['D00027']});
    const a=PanelWorkspace.scenes('P1001')[0], b=PanelWorkspace.scenes('P1002')[0];
    PanelWorkspace.savePanel(null,{name:'场景面板',kind:'scene',owner:a.id,series:[],html:{source:'<b>A</b>',filename:'A.html'}});
    PanelWorkspace.savePanel(null,{name:'第二面板',kind:'scene',owner:a.id,series:[],html:{source:'<b>B</b>',filename:'B.html'}});
    page.selected=a.id;page.panel=PanelWorkspace.panels('scene',a.id)[0].id;`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  const html = run('VIEWS.scenes.render()');
  assert.equal((html.match(/<details data-scene-project=/g) || []).length, run('PROJECTS.length'));
  assert.match(html, /data-scene-project="P1001" open/);
  assert.match(html, /场景A/);
  assert.match(html, /场景B/);
  assert.doesNotMatch(html.match(/<nav class="card scene-tree"[\s\S]*?<\/nav>/)[0], /data-scene-add|data-scene-project-add/);
  assert.match(run('sceneDetail()'), /scene-actions"><button[^>]*data-scene-add>新建场景<\/button>\s*<button[^>]*data-scene-edit/);
  assert.match(html, /设备列表<\/button>.*设备地图<\/button>.*场景面板<\/button>.*第二面板<\/button>/s);
  assert.match(html, /第二面板<\/button><\/div>\s*<button class="scene-tab scene-tab-add" data-panel-add>\+ 新建面板<\/button>/);
  assert.doesNotMatch(html, /data-scene-panel|>自定义面板<\/button>/);
  assert.equal((html.match(/data-panel-add/g) || []).length, 1);
  assert.match(run('sceneDetail()'), /<table/);
  assert.doesNotMatch(run('sceneDetail()'), /location-plot|data-custom-host/);
  run(`page.tab='map'`);
  assert.match(run('sceneDetail()'), /location-plot/);
  assert.doesNotMatch(run('sceneDetail()'), /<table|data-custom-host/);
  run(`page.tab='custom'`);
  assert.match(run('sceneDetail()'), /data-custom-host/);
  assert.doesNotMatch(run('sceneDetail()'), /<table|location-plot/);
  run(`page.panel=PanelWorkspace.panels('scene',a.id)[1].id`);
  assert.match(run('sceneDetail()'), new RegExp('data-scene-tab="' + run('page.panel') + '" aria-selected="true"'));
  run(`PanelWorkspace.removePanel(page.panel)`);
  assert.doesNotMatch(run('sceneDetail()'), /第二面板/);
  assert.match(run('sceneDetail()'), /data-custom-host/);
  run(`Workspace.project='P1002';page.selected=b.id;page.panel=''`);
  assert.match(run('sceneDetail()'), /<table/);
  assert.doesNotMatch(run('sceneDetail()'), /data-custom-host|场景面板/);
  run(`Workspace.project='P1003'`);
  assert.match(run('sceneDetail()'), /该项目暂无场景/);
  assert.match(run('sceneDetail()'), /data-scene-add/);
});
test('scene panel tabs select independent uploads and dispose the previous SDK host', () => {
  const run = runtime();
  run(`globalThis.VIEWS={}; const page={tab:'devices'};
    globalThis.Workspace={project:'P1001',page:()=>page,save:()=>{}};
    globalThis.escapeHTML=value=>String(value);
    globalThis.icon=()=>'';globalThis.badge=()=>'';globalThis.projName=id=>id;
    PanelWorkspace.saveScene(null,{name:'场景',project:'P1001',devices:['D00001']});
    const scene=PanelWorkspace.scenes('P1001')[0];page.selected=scene.id;
    for (const name of ['面板一','面板二']) PanelWorkspace.savePanel(null,{
      name,kind:'scene',owner:scene.id,series:[],html:{source:'<b>'+name+'</b>',filename:name+'.html'}});
    const panels=PanelWorkspace.panels('scene',scene.id), mounted=[];
    let disposed=0;
    globalThis.PanelHost={mount:(host,options)=>{mounted.push(options.panelId);return ()=>disposed++}};
    const listeners={},detail={innerHTML:'',querySelector:()=>({checked:false})};
    const scope={querySelector:s=>s==='[data-scene-detail]'?detail:{focus:()=>{}},
      querySelectorAll:()=>[],addEventListener:(type,fn)=>listeners[type]=fn};
    function clickTab(id){listeners.click({target:{closest:()=>({
      dataset:{sceneTab:id},hasAttribute:()=>false
    })}})}`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  run(`VIEWS.scenes.mount(scope);clickTab(panels[0].id);clickTab(panels[1].id)`);
  assert.equal(run('page.panel'), run('panels[1].id'));
  assert.equal(run('mounted.join()'), run('panels.map(p=>p.id).join()'));
  assert.equal(run('disposed'), 1);
  run(`listeners.keydown({key:'Home',preventDefault:()=>{},target:{closest:()=>({dataset:{sceneTab:panels[1].id}})}})`);
  assert.equal(run('page.tab'), 'devices');
  assert.equal(run('disposed'), 2);
  run(`listeners.keydown({key:'End',preventDefault:()=>{},target:{closest:()=>({dataset:{sceneTab:'devices'}})}})`);
  assert.equal(run('page.panel'), run('panels[1].id'));
  assert.equal(run('page.tab'), 'custom');
  run('scope._cleanup()');
  assert.equal(run('disposed'), 3);
});
test('screen cards open in-page details while sharing links to dedicated pages', () => {
  const run = runtime();
  run(`globalThis.VIEWS={};const page={};globalThis.Workspace={project:'P1001',page:()=>page};
    globalThis.escapeHTML=value=>String(value);globalThis.icon=()=>'';globalThis.badge=()=>'';
    globalThis.projName=id=>id;globalThis.AlarmStore={snapshot:()=>({events:[]})};`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  const html = run('VIEWS.bigscreen.render()');
  assert.match(html, /data-panel-open="screen-P1001">查看大屏/);
  assert.match(html, /href="screen.html\?project=P1001&panel=screen-P1001" target="_blank" rel="noopener"[^>]*>分享/);
  assert.doesNotMatch(html, /screenBox|data-screen-trend|data-custom-host/);
  assert.match(html, /data-panel-edit="screen-P1001"/);
  assert.doesNotMatch(html, /data-panel-delete="screen-P1001"/);
  const display = run(`VIEWS.bigscreen.display('P1001',PanelWorkspace.panel('screen-P1001'))`);
  assert.match(display, /screenBox|data-screen-trend/);
  assert.doesNotMatch(display, /data-bind-device|data-panel-add/);
  run(`page.opened=true;page.selected='screen-P1001'`);
  const detail = run('VIEWS.bigscreen.render()');
  assert.match(detail, /data-screen-back|screenBox/);
  assert.doesNotMatch(detail, /class="panel-grid"|id="screen-project"/);
  assert.match(detail, />分享<\/a>/);
});
test('new screen drawer saves under the chosen project and existing screen ownership stays read-only', async () => {
  const run = runtime();
  run(`globalThis.VIEWS={};globalThis.CURRENT='bigscreen';const page={};
    globalThis.Workspace={page:()=>page,save:()=>{},setProject:id=>{Workspace.project=id}};
    globalThis.escapeHTML=value=>String(value);globalThis.go=()=>{};globalThis.toast=()=>{};
    let drawer;
    globalThis.openDrawer=(...args)=>drawer=args;
    const form={elements:{name:{value:'新大屏'},project:{value:'P1002'},upload:{files:[]}},
      querySelector:()=>null,querySelectorAll:()=>[],addEventListener:()=>{},
      isConnected:true,closest:()=>true};
    globalThis.document={getElementById:()=>form,querySelector:()=>({})};`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  run(`openPanelEditor('screen','P1001')`);
  assert.equal(run('drawer[0]'), '新建大屏');
  assert.match(run('drawer[1]'), /name="project" required aria-label="大屏所属项目" >/);
  assert.match(run('drawer[1]'), /value="P1001" selected/);
  await run(`form.onsubmit({preventDefault:()=>{}})`);
  assert.equal(run('Workspace.project'), 'P1002');
  assert.equal(run(`PanelWorkspace.panel(page.selected).owner`), 'P1002');
  assert.equal(run(`PanelWorkspace.panels('screen','P1001').length`), 0);
  run(`openPanelEditor('screen','P1002',PanelWorkspace.panel(page.selected))`);
  assert.match(run('drawer[1]'), /aria-label="大屏所属项目" disabled/);
  run(`openPanelEditor('product','product-pressure')`);
  assert.doesNotMatch(run('drawer[1]'), /name="project"/);
});
test('curve cards open an in-page detail with a return action rather than an inline list preview', () => {
  const run = runtime();
  run(`globalThis.VIEWS={};const page={};
    globalThis.Workspace={page:()=>page,save:()=>{}};
    globalThis.escapeHTML=value=>String(value);globalThis.icon=()=>'';globalThis.projName=id=>id;
    globalThis.CURRENT='curves';globalThis.go=()=>{};globalThis.toast=()=>{};
    let click;
    const scope={addEventListener:(type,fn)=>{if(type==='click')click=fn}};`);
  run(fs.readFileSync(path.join(__dirname, '../js/panel-views.js'), 'utf8'));
  const list = run('VIEWS.curves.render()');
  assert.match(list, /panel-grid|data-panel-open/);
  assert.doesNotMatch(list, /data-panel-chart|data-panel-range|data-curve-back/);
  run(`mountPanelActions(scope,'curve','');click({target:{closest:()=>({
    dataset:{panelOpen:'curve-default'},hasAttribute:()=>false
  })}})`);
  assert.equal(run('page.opened'), true);
  assert.equal(run('page.selected'), 'curve-default');
  const detail = run('VIEWS.curves.render()');
  assert.match(detail, /data-curve-back|data-panel-chart|data-panel-range/);
  assert.doesNotMatch(detail, /class="panel-grid"|data-panel-open/);
  run(`page.opened=false`);
  assert.doesNotMatch(run('VIEWS.curves.render()'), /data-panel-chart/);
});
