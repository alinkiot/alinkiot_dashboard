function installAlinkIoTPanelSDK() {
  if (window.AlinkIoT) return;
  let port, next = 0, context;
  const pending = new Map(), listeners = new Set();
  let accept, reject;
  const connected = new Promise((resolve, fail) => { accept = resolve; reject = fail; });
  connected.catch(() => {});
  const timer = setTimeout(() => reject(new Error('未连接 AlinkIoT 面板宿主，请在平台中预览')), 8000);
  window.addEventListener('message', function init(event) {
    if (event.source !== parent || event.data?.type !== 'alinkiot:init' || !event.ports[0] || port) return;
    port = event.ports[0];
    window.removeEventListener('message', init);
    port.onmessage = ({ data }) => {
      if (data.type === 'ready') {
        context = data.context;
        clearTimeout(timer);
        accept(context);
      } else if (data.type === 'state') {
        listeners.forEach(fn => { try { fn(data.devices); } catch (e) { console.error(e); } });
      } else if (pending.has(data.id)) {
        const request = pending.get(data.id);
        pending.delete(data.id);
        clearTimeout(request.timer);
        if (data.error) request.reject(new Error(data.error));
        else request.resolve(data.result);
      }
    };
    port.start();
  });
  const request = async (method, args = {}) => {
    await connected;
    return new Promise((resolve, reject) => {
      const id = String(++next);
      const timer = setTimeout(() => { pending.delete(id); reject(new Error('SDK 请求超时或面板已关闭')); }, 8000);
      pending.set(id, { resolve, reject, timer });
      port.postMessage({ id, method, args });
    });
  };
  window.AlinkIoT = Object.freeze({
    ready: () => connected.then(value => structuredClone(value)),
    getContext: () => connected.then(() => structuredClone(context)),
    getDevices: () => request('devices'),
    getState: device => request('state', { device }),
    history: (device, property, from, to) => request('history', { device, property, from, to }),
    control: (device, property, value) => request('control', { device, property, value }),
    subscribe(listener) {
      if (typeof listener !== 'function') throw new Error('订阅参数须为函数');
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  });
}
if (document.currentScript?.hasAttribute('data-panel-host')) {
  window.AlinkIoTPanelSDKSource = '(' + installAlinkIoTPanelSDK.toString() + ')();';
} else installAlinkIoTPanelSDK();
