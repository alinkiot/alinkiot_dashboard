# AlinkIoT 面板 SDK（本地演示 v1）

产品、场景、曲线和大屏共用同一 SDK。上传 HTML 或包含 `index.html` 的 ZIP，在面板内引入：

```html
<script src="alinkiot-panel.js"></script>
<script>
AlinkIoT.ready().then(async context => {
  const devices = await AlinkIoT.getDevices();
  document.getElementById('output').textContent = JSON.stringify(devices, null, 2);
}).catch(error => {
  document.getElementById('output').textContent = error.message;
});
</script>
<pre id="output"></pre>
```

使用 [example.html](example.html) 作为起点。SDK 文件名固定为 `alinkiot-panel.js`，可放包内任意目录并用相对路径引入；宿主在上传预览时内置注入相同 SDK，不需联网或重复打包。独立打开 HTML 没有宿主，`ready()` 会超时；须上传后预览。

## 接口

| 方法 | 返回与行为 |
|---|---|
| `ready()` / `getContext()` | Promise：`{version:1, mode:"local-demo", kind, owner, panelId, deviceIds, timezone:"Asia/Shanghai"}` |
| `getDevices()` | Promise：当前面板允许的全部设备快照 |
| `getState(deviceId)` | Promise：范围内一台设备 |
| `history(deviceId, property, from, to)` | Promise：`[{time:毫秒时间戳,value}]`；北京时间 `YYYY-MM-DDTHH:mm`、含两端、最多 90 天；仅历史来源数值属性有数据，其他数值属性返回空数组 |
| `subscribe(listener)` | 控制或模型变更时回调范围内的全部快照；返回取消订阅函数。初次快照请主动 `getDevices()`，并非实时硬件订阅 |
| `control(deviceId, property, value)` | Promise：`{simulated:true,persisted,device}`；只修改本浏览器模拟属性，**不下发任何硬件指令** |

设备形状：

```js
{
  id, name, code, project, product, status, updated,
  location: { lat, lng }, // WGS84；未定位为 null
  properties: [{ key, name, type, unit, writable, source }],
  values: { value: 123.4, signal: 90, running: null }
}
```

`type` 为 `number / boolean / string`，`source` 为 `telemetry / signal / custom`。`values` 对未赋值属性返回 `null`，不填假零；当前设备快照与固定历史样本不是同一采样时刻。`updated` 是种子设备采样时间，不是模拟控制回执时间。

范围由宿主配置决定，上传页不能自行扩大：

- 产品：当前选中的一台绑定设备，而非全产品设备。
- 场景：该场景关联的设备集合。
- 曲线：面板系列涉及的设备；历史查询进一步限制到所选设备属性。
- 大屏：当前项目全部设备。

不存在“读取任意项目/全部用户/执行任意 API”的方法。超范围、无效属性、只读写入、离线控制、类型错误会拒绝 Promise。控制需先在宿主勾选“允许本次模拟控制”，每次重新打开/刷新默认关闭；`persisted:false` 表示只在内存生效。

## 上传约定

- HTML 单文件 ≤500 KB；ZIP ≤1 MB，解压总大小 ≤2 MB、≤80 条目；根目录 `index.html`。
- ZIP 支持 STORE/DEFLATE，验证 CRC；拒绝加密、分卷、ZIP64、符号链接、绝对路径、反斜线、`.`/`..` 路径和重复文件。
- 支持 UTF-8 的本地 CSS、普通 JS，PNG/JPEG/GIF/WebP/SVG 图片及 WOFF/WOFF2 字体；图片/字体冻结为 data URL，CSS/JS 内联。CSS 不支持 `@import`，资源路径不支持查询参数或片段（CSS 内部 `#id` 引用除外）。
- 禁止 CDN、远程依赖、ES Modules、`srcset`；不支持服务端页面、多页面跳转、动态读取包内 JSON、视频或音频。请将数据/库打包到普通 JS 中。
- 移除 meta、base、表单、嵌套 iframe/object/embed；不是完整站点托管器。上传失败保留旧面板，编辑勾选“恢复基础视图”移除自定义内容。

## 隔离与边界

预览为 `sandbox="allow-scripts"` 的不透明源 iframe，无 `allow-same-origin`，不能读取后台 DOM、localStorage、凭证或其他面板。通过专属 `MessageChannel` 通信，宿主每次请求重查关联范围、类型与可写性；每秒最多 30 请求，切页关闭端口与订阅。

CSP 禁止 fetch/XHR/WebSocket、外部脚本/图片及子框架；发生再次页面加载时关闭通道。但浏览器 CSP **不能保证阻止任意脚本自身跳转等全部网络行为，也不能防止恶意代码占满主线程**。只上传可信面板、仅使用演示数据，不放入秘密。正式平台还需独立隔离域、资源审查、网络策略、版本发布、服务端逐次授权及控制审计；本 SDK 不提供真实设备控制权限。
