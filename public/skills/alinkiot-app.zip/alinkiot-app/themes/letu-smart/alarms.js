"use strict";

window.AlarmCenter = (() => {
  const names = { alarms: "告警事件", "alarm-rules": "告警规则" };
  const escape = escapeHTML;
  const ui = { role: "admin", physical: "", handling: "", level: "", device: "", search: "", page: 1, detail: "", feedback: "" };
  let lastProject = "";
  const device = id => DEVICES.find(d => d.id === id);
  const table = (headers, rows) => `<div class="alarm-table"><table><thead><tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.join("") || `<tr><td colspan="${headers.length}">没有符合条件的记录</td></tr>`}</tbody></table></div>`;
  const row = cells => `<tr>${cells.map(c => `<td>${c}</td>`).join("")}</tr>`;
  const select = (field, label, options) => `<label>${label} <select data-alarm-field="${field}"><option value="">全部</option>${options.map(([value, name]) =>
    `<option value="${value}" ${ui[field] === value ? "selected" : ""}>${escape(name)}</option>`).join("")}</select></label>`;
  function render(page, project) {
    if (lastProject !== project) {
      Object.assign(ui, { device: "", detail: "", search: "", physical: "", handling: "", level: "", page: 1, feedback: "" });
      lastProject = project;
    }
    const s = AlarmStore.snapshot(project), admin = ui.role === "admin";
    const devices = DEVICES.filter(d => d.project === project);
    let body;
    if (page === "alarms") {
      const rows = s.events.filter(e => (!ui.physical || e.physical === ui.physical) && (!ui.handling || e.handling === ui.handling) &&
        (!ui.level || e.level === ui.level) && (!ui.device || e.device === ui.device) &&
        `${e.id} ${device(e.device)?.name} ${device(e.device)?.code} ${e.evidence}`.toLowerCase().includes(ui.search.trim().toLowerCase()));
      ui.page = Math.min(ui.page, Math.max(1, Math.ceil(rows.length / 2)));
      const e = s.events.find(item => item.id === ui.detail);
      body = `<div class="alarm-controls">
        <form data-alarm-search><label>搜索 <input name="search" value="${escape(ui.search)}" placeholder="事件 / 设备 / 证据" maxlength="100"></label><button>查询</button></form>
        ${select("physical", "物理状态", [["活动", "活动"], ["已恢复", "已恢复"]])}
        ${select("handling", "处理状态", ["待确认", "已确认", "已处理"].map(v => [v, v]))}
        ${select("level", "等级", ["高", "中", "低"].map(v => [v, v]))}
        ${select("device", "设备", devices.map(d => [d.id, d.name + " · " + d.code]))}
        <button type="button" data-alarm-action="reset">清除筛选</button>
        <span>活动 ${s.events.filter(item => item.physical === "活动").length} / 已恢复 ${s.events.filter(item => item.physical === "已恢复").length}</span>
      </div>` +
        table(["事件", "设备 / 测点", "等级", "触发证据", "物理状态", "处理状态", "发生时间 +08:00", "操作"],
          rows.slice((ui.page - 1) * 2, ui.page * 2).map(item => row([item.id,
            escape(device(item.device).name) + "<br>" + escape(device(item.device).code), item.level, escape(item.evidence),
            item.physical, item.handling, item.time,
            `<button type="button" data-alarm-action="detail" data-id="${item.id}">查看详情</button>`]))) +
        `<div class="alarm-controls"><span>筛选结果 ${rows.length} 条 · 第 ${ui.page} 页 · 每页 2 条演示</span>
          <button data-alarm-action="prev" ${ui.page <= 1 ? "disabled" : ""}>上一页</button>
          <button data-alarm-action="next" ${ui.page * 2 >= rows.length ? "disabled" : ""}>下一页</button></div>` +
        (e ? `<section class="alarm-detail"><h3>${e.id} · ${escape(device(e.device).name)}</h3>
          <p>规则版本 v${e.ruleVersion} / ${escape(e.metric)} / ${escape(e.evidence)} / ${e.physical} / ${e.handling}</p>
          <p>历史证据不随规则修改，人工处理不改变物理状态。</p>
          <ul>${e.actions.map(a => `<li>${a.time} 演示管理员：${a.action}，${escape(a.note)}</li>`).join("") || "<li>暂无处理记录</li>"}</ul>
          ${admin ? `<form data-alarm-handle="${e.id}"><label>处理说明 <input name="note" required maxlength="200" placeholder="填写核查或处理情况"></label>
            <button name="action" value="ack" ${e.handling !== "待确认" ? "disabled" : ""}>确认告警</button>
            <button name="action" value="resolve" ${e.handling === "已处理" ? "disabled" : ""}>记录处理</button></form>` :
            "<p>普通用户只可查看，不可确认或处理。</p>"}</section>` : "");
    } else if (page === "alarm-rules") {
      const r = s.rule;
      body = r ? table(["规则", "范围", "条件 / 恢复", "状态", "操作"], [
        row([`测点超限 v${r.version}`, escape(device(r.device).name) + "<br>" + escape(device(r.device).code),
          `计算值 &gt; ${r.threshold} ${device(r.device).unit} 持续 ${r.duration} 秒；低于 ${r.recovery} ${device(r.device).unit} 恢复 · ${r.level}等级`,
          r.enabled ? "启用" : "停用", admin ? '<button data-alarm-action="toggle">切换启停</button>' : "只读"])
      ]) + `<form class="alarm-detail" data-alarm-rule><h3>当前项目规则配置</h3>
        <label>设备 <select name="device" ${admin ? "" : "disabled"}>${devices.map(d =>
          `<option value="${d.id}" ${d.id === r.device ? "selected" : ""}>${escape(d.name)} · ${d.code}（${d.unit}）</option>`).join("")}</select></label>
        <p>设备单位：<b data-rule-unit>${device(r.device).unit}</b>。更换设备时请按新单位重新核对阈值。</p>
        <label>触发值 <input type="number" step="0.001" min="-1000000000" max="1000000000" name="threshold" required value="${r.threshold}" ${admin ? "" : "disabled"}></label>
        <label>恢复值 <input type="number" step="0.001" min="-1000000000" max="1000000000" name="recovery" required value="${r.recovery}" ${admin ? "" : "disabled"}></label>
        <label>持续秒数 <input type="number" min="1" max="86400" step="1" name="duration" required value="${r.duration}" ${admin ? "" : "disabled"}></label>
        <label>等级 <select name="level" ${admin ? "" : "disabled"}>${["高", "中", "低"].map(v => `<option ${v === r.level ? "selected" : ""}>${v}</option>`).join("")}</select></label>
        <button ${admin ? "" : "disabled"}>保存本地规则</button><p>保存生成新版本，既有事件保留原版本与证据。仅配置演示，不执行检测、不通知、不重新计算历史。</p></form>` :
        '<p class="alarm-detail">当前项目没有设备，暂无规则。请先接入设备档案。</p>';
    }
    if (page === "alarms") {
      body += '<section class="alarm-detail"><h3>通知记录</h3>' + (s.events.length ? table(["事件", "渠道", "接收人", "投递状态", "本地重试次数", "操作"], [
        row(["AL-001", "站内", "演示管理员", "样本记录，未发送", "0", "—"]),
        row(["AL-002", "邮件", "当前项目管理员", "未配置，未发送", String(s.attempts.length),
          admin ? '<button data-alarm-action="retry">模拟重试</button>' : "只读"])
      ]) + `<section class="alarm-detail"><h3>最近 10 次演示重试</h3><ul>${s.attempts.slice(-10).reverse().map(a =>
        `<li>${a.time} · ${a.event} · 邮件未配置，未发送</li>`).join("") || "<li>暂无重试</li>"}</ul>
        <p>只记录本地操作，不创建后台任务或发送消息，不标记送达。完整记录最多 100 条。</p></section>` :
        '<p class="alarm-detail">当前项目没有事件或通知记录。</p>') + '</section>';
    }
    return `<section class="alarm-center" data-alarm-root data-project="${project}" data-page="${page}">
      <div class="alarm-controls"><h2>${names[page]}</h2><label>本模块演示角色 <select data-alarm-field="role">
        <option value="admin" ${admin ? "selected" : ""}>客户管理员</option><option value="user" ${admin ? "" : "selected"}>普通用户</option></select></label></div>
      <p class="alarm-notice">项目：${escape(projName(project))} · 设备取自本地档案，事件仍为固定模拟样本，不等于真实检测结果或概览统计。
        处理、规则与重试记录保存在本浏览器；角色只控制告警模块演示，不是账号认证，与权限页身份独立。</p>
      ${AlarmStore.loadError ? '<p class="alarm-notice">告警存档读取失败，当前使用初始告警样本。</p>' : ''}
      ${body}<p class="alarm-feedback" role="status">${escape(ui.feedback)}</p></section>`;
  }
  function refresh(root) { root.outerHTML = render(root.dataset.page, root.dataset.project); }
  const feedback = (persisted, message) => {
    ui.feedback = persisted ? message : message + "；浏览器存储失败，刷新将丢失";
  };
  document.addEventListener("change", event => {
    const root = event.target.closest("[data-alarm-root]");
    if (!root) return;
    if (event.target.name === "device" && event.target.closest("[data-alarm-rule]")) {
      root.querySelector("[data-rule-unit]").textContent = device(event.target.value).unit;
      return;
    }
    const field = event.target.dataset.alarmField;
    if (!["role", "physical", "handling", "level", "device"].includes(field)) return;
    ui[field] = event.target.value;
    ui.detail = ""; ui.page = 1; ui.feedback = "";
    refresh(root);
  });
  document.addEventListener("click", event => {
    const button = event.target.closest("[data-alarm-action]"), root = button?.closest("[data-alarm-root]");
    if (!root || button.disabled) return;
    const action = button.dataset.alarmAction;
    try {
      if (action === "navigate") { go(button.dataset.id); return; }
      if (action === "detail") ui.detail = button.dataset.id;
      if (action === "prev") ui.page--;
      if (action === "next") ui.page++;
      if (action === "reset") Object.assign(ui, { physical: "", handling: "", level: "", device: "", search: "", page: 1, detail: "" });
      if (action === "toggle") feedback(AlarmStore.toggle(root.dataset.project, ui.role), "本地规则启停已更新，版本递增，未执行检测。");
      if (action === "retry") feedback(AlarmStore.retry(root.dataset.project, ui.role), "已记录模拟重试；邮件未配置，未发送，未标记送达。");
    } catch (e) { ui.feedback = e.message; }
    refresh(root);
  });
  document.addEventListener("submit", event => {
    const form = event.target, root = form.closest("[data-alarm-root]");
    if (!root) return;
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    try {
      if (form.hasAttribute("data-alarm-search")) {
        ui.search = String(data.get("search")); ui.page = 1; ui.detail = "";
      } else if (form.hasAttribute("data-alarm-rule")) {
        const previous = AlarmStore.snapshot(root.dataset.project).rule;
        const persisted = AlarmStore.saveRule(root.dataset.project, {
          device: data.get("device"), threshold: Number(data.get("threshold")), recovery: Number(data.get("recovery")),
          duration: Number(data.get("duration")), level: data.get("level"), enabled: previous.enabled
        }, ui.role);
        feedback(persisted, "本地规则已保存为新版本，历史事件不变，未执行检测。");
      } else if (form.hasAttribute("data-alarm-handle")) {
        const persisted = AlarmStore.handle(root.dataset.project, form.dataset.alarmHandle, event.submitter?.value, String(data.get("note")), ui.role);
        const item = AlarmStore.snapshot(root.dataset.project).events.find(e => e.id === form.dataset.alarmHandle);
        feedback(persisted, `已记录本地处理，物理状态仍为“${item.physical}”。`);
      } else return;
    } catch (e) {
      ui.feedback = e.message;
      root.querySelector(".alarm-feedback").textContent = ui.feedback;
      return;
    }
    refresh(root);
  });
  return {
    render, has: page => Object.hasOwn(names, page),
    resetProject() { Object.assign(ui, { device: "", detail: "", search: "", physical: "", handling: "", level: "", page: 1, feedback: "" }); }
  };
})();
