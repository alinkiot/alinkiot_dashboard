for (const [id, title] of Object.entries({ alarms: "告警事件", "alarm-rules": "告警规则" })) {
  VIEWS[id] = {
    group: "告警中心", title,
    render() {
      const project = Workspace.project || PROJECTS[0]?.id;
      if (!project) return '<div class="empty">请先创建项目</div>';
      return `<div class="view-in"><label class="alarm-controls">当前项目
        <select class="sel" id="alarm-project" aria-label="告警项目">${PROJECTS.map(p =>
          `<option value="${p.id}" ${p.id === project ? "selected" : ""}>${escapeHTML(p.name)}</option>`).join("")}</select>
        <span>单项目告警样本</span></label>${AlarmCenter.render(id, project)}</div>`;
    },
    mount(scope) {
      scope.querySelector("#alarm-project")?.addEventListener("change", event => {
        Workspace.setProject(event.target.value);
        AlarmCenter.resetProject();
        go(id);
      });
    }
  };
}
