"use strict";

window.AlarmCenter = (() => {
  const projects = new Map();
  const names = { alarms: "告警事件", "alarm-rules": "告警规则", "alarm-notifications": "通知记录" };
  const escape = (value) => String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  function get(project) {
    if (!projects.has(project)) projects.set(project, {
      role: "admin", filter: "all", detail: null, feedback: "", threshold: 40, enabled: true,
      events: [
        { id: "AL-001", device: "演示测点 A", metric: "温度", value: "46 ℃", level: "高", physical: "活动", handling: "待确认", time: "2026-10-30 14:30", actions: [] },
        { id: "AL-002", device: "演示测点 B", metric: "心跳超时", value: "超过 10 分钟", level: "中", physical: "活动", handling: "待确认", time: "2026-10-30 14:20", actions: [] },
        { id: "AL-003", device: "演示测点 C", metric: "温度", value: "历史峰值 44 ℃", level: "中", physical: "已恢复", handling: "已处理", time: "2026-10-30 13:00", actions: ["13:20 系统样本：温度恢复", "13:25 演示管理员：已核查"] }
      ]
    });
    return projects.get(project);
  }
  const table = (headers, rows) => `<div class="alarm-table"><table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.join("") || `<tr><td colspan="${headers.length}">没有符合条件的记录</td></tr>`}</tbody></table></div>`;
  const row = (cells) => `<tr>${cells.map((c) => `<td>${c}</td>`).join("")}</tr>`;
  function render(page, project) {
    const s = get(project), admin = s.role === "admin";
    let body;
    if (page === "alarms") {
      const rows = s.events.filter((e) => s.filter === "all" || (s.filter === "active" ? e.physical === "活动" : e.physical === "已恢复"));
      const e = s.events.find((item) => item.id === s.detail);
      body = `<div class="alarm-controls"><label>物理状态 <select data-alarm-field="filter"><option value="all" ${s.filter === "all" ? "selected" : ""}>全部</option><option value="active" ${s.filter === "active" ? "selected" : ""}>活动</option><option value="recovered" ${s.filter === "recovered" ? "selected" : ""}>已恢复</option></select></label><span>活动 ${s.events.filter((item) => item.physical === "活动").length} / 已恢复 ${s.events.filter((item) => item.physical === "已恢复").length}</span></div>` +
        table(["事件", "设备 / 测点", "等级", "触发证据", "物理状态", "处理状态", "发生时间 +08:00", "操作"], rows.map((item) => row([item.id, item.device, item.level, item.value, item.physical, item.handling, item.time, `<button type="button" data-alarm-action="detail" data-id="${item.id}">查看详情</button>`]))) +
        (e ? `<section class="alarm-detail"><h3>${e.id} · ${e.device}</h3><p>规则版本 v1 / ${e.metric} / ${e.value} / ${e.physical} / ${e.handling}</p><p>物理恢复由检测决定，人工确认或处理不会恢复设备。历史证据不随规则修改。</p><ul>${e.actions.map((a) => `<li>${escape(a)}</li>`).join("") || "<li>暂无处理记录</li>"}</ul>${admin ? `<form data-alarm-handle="${e.id}"><label>处理说明 <input name="note" required maxlength="200" placeholder="填写核查或处理情况"></label><button name="action" value="ack" ${e.handling !== "待确认" ? "disabled" : ""}>确认告警</button><button name="action" value="resolve" ${e.handling === "已处理" ? "disabled" : ""}>记录处理</button></form>` : "<p>普通用户只可查看，不可确认或处理。</p>"}</section>` : "");
    } else if (page === "alarm-rules") {
      body = table(["规则", "范围", "条件 / 恢复", "状态", "操作"], [
        row(["温度超限 v1", "当前项目 / 演示测点 A、C", `温度 &gt; ${s.threshold} ℃ 持续 60 秒；低于 ${s.threshold - 2} ℃ 恢复`, s.enabled ? "启用" : "停用", admin ? '<button type="button" data-alarm-action="toggle">切换启停</button>' : "只读"]),
        row(["设备离线 v1", "当前项目 / 演示测点 B", "10 分钟无有效心跳；收到有效心跳恢复", "启用", "固定样本"])
      ]) + `<form class="alarm-detail" data-alarm-rule><h3>阈值配置预览</h3><label>触发温度（℃） <input name="threshold" type="number" min="-50" max="150" step="0.1" value="${s.threshold}" required ${admin ? "" : "disabled"}></label><button type="submit" ${admin ? "" : "disabled"}>保存本地演示配置</button><p>样本 46 ℃；持续时间 60 秒，恢复回差 2 ℃。仅修改内存配置，不执行检测、不改写历史事件、不发布真实规则。</p></form>`;
    } else {
      body = table(["事件", "渠道", "接收人", "投递状态", "说明", "操作"], [
        row(["AL-001", "站内", "演示管理员", "模拟记录", "未创建真实通知", "—"]),
        row(["AL-002", "邮件", "当前项目管理员", "未配置", "无邮件凭证，未发送", admin ? '<button type="button" data-alarm-action="retry">模拟重试</button>' : "只读"])
      ]) + '<p class="alarm-detail">基础渠道为站内通知；外部渠道需服务端配置。真实投递须重新验证接收人项目权限，持久化重试并去重。此处不会发送请求，也不显示虚假送达。</p>';
    }
    return `<section class="alarm-center" data-alarm-root data-project="${escape(project)}" data-page="${page}"><div class="alarm-controls"><h2>${names[page]}</h2><label>演示角色 <select data-alarm-field="role"><option value="admin" ${admin ? "selected" : ""}>客户管理员</option><option value="user" ${admin ? "" : "selected"}>普通用户</option></select></label></div><p class="alarm-notice">项目：${escape(project)} · 独立告警样本，与概览统计口径不同。本地内存演示，刷新重置，无真实检测、认证或通知服务。</p><div class="alarm-links">${Object.entries(names).map(([id, title]) => `<button type="button" data-alarm-action="navigate" data-id="${id}" ${id === page ? 'aria-current="page"' : ""}>${title}</button>`).join("")}</div>${body}<p class="alarm-feedback" role="status">${escape(s.feedback)}</p></section>`;
  }
  function refresh(root) { root.outerHTML = render(root.dataset.page, root.dataset.project); }
  document.addEventListener("change", (event) => {
    const field = event.target.dataset.alarmField, root = event.target.closest("[data-alarm-root]");
    if (!root || !field) return;
    get(root.dataset.project)[field] = event.target.value;
    refresh(root);
  });
  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-alarm-action]"), root = button?.closest("[data-alarm-root]");
    if (!root) return;
    const s = get(root.dataset.project), action = button.dataset.alarmAction;
    if (action === "navigate") {
      if (document.getElementById("sbNav")) window.go(button.dataset.id);
      else location.hash = button.dataset.id;
      return;
    }
    if (action === "detail") s.detail = button.dataset.id;
    else if (s.role !== "admin") return;
    else if (action === "toggle") { s.enabled = !s.enabled; s.feedback = "已更新本地启停状态，未发布真实规则。"; }
    else if (action === "retry") s.feedback = "模拟重试：邮件渠道未配置，未发送，未标记送达。";
    refresh(root);
  });
  document.addEventListener("submit", (event) => {
    const form = event.target, root = form.closest("[data-alarm-root]");
    if (!root) return;
    event.preventDefault();
    const s = get(root.dataset.project);
    if (s.role !== "admin" || !form.reportValidity()) return;
    if (form.hasAttribute("data-alarm-rule")) {
      s.threshold = Number(new FormData(form).get("threshold"));
      s.feedback = `本地阈值已设为 ${s.threshold} ℃，样本 46 ℃ ${46 > s.threshold ? "超过" : "未超过"}阈值；不执行实时检测。`;
    } else if (form.hasAttribute("data-alarm-handle")) {
      const e = s.events.find((item) => item.id === form.dataset.alarmHandle);
      if (!e || e.handling === "已处理") return;
      const ack = event.submitter?.value === "ack";
      if (ack && e.handling !== "待确认") return;
      e.handling = ack ? "已确认" : "已处理";
      e.actions.push(`${new Date().toLocaleTimeString("zh-CN")} 演示管理员：${e.handling}，${new FormData(form).get("note")}`);
      s.feedback = `已记录本地处理，物理状态仍为“${e.physical}”。`;
    }
    refresh(root);
  });
  return { render, has: (page) => Object.hasOwn(names, page) };
})();
