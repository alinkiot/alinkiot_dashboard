"use strict";

// Keep this map aligned with tokens.json so the reference works over file://.
const THEMES = {
  "ocean-light": {
    "color-scheme": "light", bg: "#f3f6fb", surface: "#ffffff", "surface-alt": "#edf3fc",
    sidebar: "#102444", "sidebar-text": "#e0e9fa", text: "#172b4d", muted: "#536580",
    border: "#d8e2ef", primary: "#245ad8", "on-primary": "#ffffff", accent: "#087f78",
    warning: "#976000", danger: "#c13449", shadow: "0 12px 32px rgba(24, 50, 90, 0.07)"
  },
  midnight: {
    "color-scheme": "dark", bg: "#0c1424", surface: "#152238", "surface-alt": "#1c2d48",
    sidebar: "#09111f", "sidebar-text": "#d9e5fc", text: "#edf3ff", muted: "#a7b9d5",
    border: "#304461", primary: "#93b7ff", "on-primary": "#102444", accent: "#57d9c2",
    warning: "#ffce75", danger: "#ff96a5", shadow: "0 12px 32px rgba(0, 0, 0, 0.18)"
  },
  industrial: {
    "color-scheme": "dark", bg: "#0d1b1b", surface: "#152a29", "surface-alt": "#1d3935",
    sidebar: "#091614", "sidebar-text": "#d6f1e7", text: "#e9f8f1", muted: "#a3c4b8",
    border: "#36564c", primary: "#6ce9b2", "on-primary": "#10291e", accent: "#80c9ff",
    warning: "#f3cf83", danger: "#ffa0a0", shadow: "0 12px 32px rgba(0, 0, 0, 0.18)"
  }
};

const PAGES = {
  alarms: ["告警事件", "项目告警、物理恢复与确认处理。"],
  "alarm-rules": ["告警规则", "阈值、离线检测与恢复策略。"],
  "alarm-notifications": ["通知记录", "站内与外部渠道投递记录。"],
  overview: ["运行概览", "从设备连接到数据洞察，让每一个项目清晰可见。"],
  projects: ["项目管理", "接口同步、手动新建和外部绑定，统一管理项目归属。"],
  permissions: ["权限管理", "超管分配客户管理员，客户管理员在权限范围内管理普通用户。"],
  devices: ["设备档案", "每类设备独立字段与档案表，通过注册表统一关联。"],
  realtime: ["实时查询", "查看最新值、采样时间与数据质量，区分过期和缺失。"],
  history: ["历史查询", "按时间范围查询与聚合，保留单位、质量及来源时间。"],
  curves: ["曲线管理", "动态关联不同设备与测点，异单位双轴展示。"],
  dashboard: ["项目大屏", "每个项目独立配置、版本化发布、受控访问。"],
  reports: ["报表中心", "统一计算口径，按项目生成报表并授权导出。"],
  governance: ["数据治理", "在同步链路中使用版本化安全公式，保留原始值。"],
  sync: ["同步任务", "项目任务与统一任务，支持增量、幂等、重试及审计。"]
};
const NAV_GROUPS = [
  { title: "运行中心", pages: ["overview"] },
  { title: "告警中心", pages: ["alarms", "alarm-rules", "alarm-notifications"] },
  { title: "资产与权限", pages: ["projects", "permissions", "devices"] },
  { title: "数据应用", pages: ["realtime", "history", "curves"] },
  { title: "展示与报表", pages: ["dashboard", "reports"] },
  { title: "治理与同步", pages: ["governance", "sync"] }
];
const PROJECTS = {
  park: { name: "未来科技园", customer: "未来园区运营", total: 128, online: 124, water: 38.6, power: 286, factor: 1 },
  factory: { name: "滨江智造工厂", customer: "滨江制造集团", total: 86, online: 82, water: 27.8, power: 412, factor: 1.3 }
};
const state = {
  page: "overview", project: "park", range: "day",
  series: { flow: true, power: true },
  syncEnabled: { park: true, factory: true },
  conversations: { park: [], factory: [] }
};
const $ = (id) => document.getElementById(id);
const project = () => PROJECTS[state.project];
const rangeLabel = () => $("range-select").selectedOptions[0].textContent;
const escapeText = (value) => {
  const element = document.createElement("span");
  element.textContent = String(value);
  return element.innerHTML;
};

function applyTheme(id) {
  if (!Object.hasOwn(THEMES, id)) id = "ocean-light";
  document.documentElement.dataset.theme = id;
  for (const [key, value] of Object.entries(THEMES[id])) {
    document.documentElement.style.setProperty(key === "color-scheme" ? key : `--${key}`, value);
  }
  $("theme-select").value = id;
  try { localStorage.setItem("alinkiot-theme", id); } catch { /* Storage can be disabled for local files. */ }
}

function panel(title, body, subtitle = "") {
  return `<section class="panel"><div class="panel-header"><div><h2>${escapeText(title)}</h2>${subtitle ? `<p class="panel-subtitle">${escapeText(subtitle)}</p>` : ""}</div><span class="tag">DEMO</span></div>${body}</section>`;
}

function table(headers, rows) {
  return `<div class="table-wrap"><table><thead><tr>${headers.map((v) => `<th scope="col">${escapeText(v)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((v) => `<td>${escapeText(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

function renderMetrics() {
  const p = project();
  const metrics = [
    ["设备总数", p.total, "台", "水表 / 电表 · 独立档案"],
    ["在线设备", p.online, "台", `在线率 ${(p.online / p.total * 100).toFixed(1)}% · 固定样本`],
    ["最新流量", p.water, "m³/h", "水表 W-001 · 示例采样"],
    ["最新功率", p.power, "kW", "电表 E-001 · 示例采样"]
  ];
  $("metrics").innerHTML = metrics.map(([label, value, unit, foot]) =>
    `<article class="metric"><div class="metric-label">${escapeText(label)}</div><div class="metric-value">${value}<small>${unit}</small></div><div class="metric-foot">${escapeText(foot)}</div></article>`
  ).join("");
}

function chart() {
  const week = state.range === "week";
  const flow = week ? [22, 31, 25, 38, 29, 34, 30] : [16, 22, 19, 34, 28, 38, 31];
  const power = week ? [160, 220, 280, 210, 330, 290, 260] : [180, 160, 230, 280, 220, 310, 260];
  const labels = week ? ["10/24", "10/25", "10/26", "10/27", "10/28", "10/29", "10/30"] : ["00:00", "04:00", "08:00", "12:00", "16:00", "20:00", "24:00"];
  const points = (values, max) => values.map((value, i) => `${55 + i * 95},${220 - value * project().factor / max * 175}`).join(" ");
  const grid = [0, 1, 2, 3, 4].map((i) => {
    const y = 220 - i * 44;
    return `<line class="grid-line" x1="55" x2="625" y1="${y}" y2="${y}"/><text x="42" y="${y + 4}" text-anchor="end">${i * 15}</text><text x="638" y="${y + 4}">${i * 150}</text>`;
  }).join("");
  return `<div class="legend">
    <label><input type="checkbox" data-series="flow" ${state.series.flow ? "checked" : ""}><span class="legend-dot"></span>水表 W-001 · 流量（左轴 m³/h）</label>
    <label><input type="checkbox" data-series="power" ${state.series.power ? "checked" : ""}><span class="legend-dot power"></span>电表 E-001 · 功率（右轴 kW）</label>
    </div><svg class="chart" viewBox="0 0 700 270" role="img" aria-labelledby="trend-title trend-description">
      <title id="trend-title">跨设备趋势 · 本地固定样本</title>
      <desc id="trend-description">左轴流量 0 至 60 立方米每小时，右轴功率 0 至 600 千瓦；${escapeText(rangeLabel())}。下方表格提供相同采样值。</desc>
      <text x="10" y="20">m³/h</text><text x="638" y="20">kW</text>${grid}
      ${state.series.flow ? `<polyline class="flow" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="${points(flow, 60)}"/>` : ""}
      ${state.series.power ? `<polyline class="power" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="${points(power, 600)}"/>` : ""}
      ${labels.map((v, i) => `<text x="${55 + i * 95}" y="250" text-anchor="middle">${v}</text>`).join("")}
    </svg>
    <details><summary class="muted">查看图表采样值</summary>${table(
      ["时间", ...(state.series.flow ? ["流量 m³/h"] : []), ...(state.series.power ? ["功率 kW"] : [])],
      labels.map((label, i) => [label, ...(state.series.flow ? [(flow[i] * project().factor).toFixed(1)] : []), ...(state.series.power ? [(power[i] * project().factor).toFixed(1)] : [])])
    )}</details>
    <p class="muted">示例仅展示双轴与系列组合，不代表因果关系。指标卡是独立的最新值快照。</p>`;
}

function deviceRows() {
  return [
    ["W-001", "水表", "device_water_meter", "北区进水口", "在线", "2026-10-30 10:30:00"],
    ["E-001", "电表", "device_power_meter", "1 号配电室", "在线", "2026-10-30 10:30:00"],
    ["W-002", "水表", "device_water_meter", "南区进水口", "过期 · 12 分钟", "2026-10-30 10:18:00"]
  ];
}

function renderContent() {
  if (AlarmCenter.has(state.page)) return AlarmCenter.render(state.page, project().name);
  const p = project();
  switch (state.page) {
    case "overview":
      return `<div class="content-grid">${panel("用量与负载趋势", chart(), `${p.name} · 不同设备，同一视图`)}
        ${panel("项目运行摘要", `<div class="info-row"><div>设备接入<small>API / 数据库来源</small></div><span class="info-value">2 类</span></div>
          <div class="info-row"><div>同步状态<small>最近示例执行 10:30</small></div><span class="tag">${state.syncEnabled[state.project] ? "已启用" : "已暂停"}</span></div>
          <div class="info-row"><div>数据质量<small>缺失与异常需要单独处理</small></div><span class="warning">3 条待核查</span></div>
          <div class="callout">从历史查询或同步任务点击“AI 分析”，会携带当前项目与筛选范围打开同一个聊天窗。</div>`)}
        </div>${panel("设备快照", table(["设备", "类型", "档案表", "位置", "状态", "采样时间"], deviceRows()))}`;
    case "projects":
      return panel("项目来源与授权", table(["项目", "客户", "来源", "外部绑定", "管理员"], [
        [p.name, p.customer, state.project === "park" ? "HTTP API" : "数据库视图", `source-01 / ${state.project}`, "本客户管理员"],
        [`${p.name} · 扩建区`, p.customer, "手动新建", "待绑定", "待超管分配"]
      ])) + panel("同步与手动绑定", '<p class="muted">真实应用支持新建、同步、外部绑定与冲突处理；重复同步不覆盖客户归属和项目权限。</p><span class="tag">本模板不执行项目写入</span>');
    case "permissions":
      return panel("三级授权边界", table(["角色", "用户管理", "项目授权", "数据范围"], [
        ["超管", "创建客户管理员", "分配客户与管理员", "显式全局权限"],
        ["客户管理员", "本客户普通用户", "自己授权范围的子集", `${p.customer} / 获授项目`],
        ["普通用户", "不可管理", "不可再授权", "自己获授项目 / 默认只读"]
      ])) + panel("权限不由主题或前端按钮决定", '<p class="muted">后端必须检查每个资源的客户、项目、角色与操作能力；撤权后下载、大屏与 AI 上下文也必须立即受限。</p>');
    case "devices":
      return panel("分类设备档案", table(["设备", "类型", "独立档案表", "位置", "状态", "采样时间"], deviceRows())) +
        panel("字段字典示例", table(["设备类型", "专属档案字段", "采样字段", "时序表"], [
          ["水表", "口径 / 安装位置", "flow_m3h / total_m3", "telemetry_water_meter"],
          ["电表", "额定电压 / 相数", "voltage_v / power_kw / energy_kwh", "telemetry_power_meter"]
        ]));
    case "realtime":
      return panel("最新采样", table(["设备", "测点", "最新值", "单位", "质量", "采样时间"], [
        ["W-001", "瞬时流量", p.water, "m³/h", "有效", "2026-10-30 10:30"],
        ["E-001", "有功功率", p.power, "kW", "有效", "2026-10-30 10:30"],
        ["W-002", "瞬时流量", "—", "m³/h", "过期，非零值", "2026-10-30 10:18"]
      ]), "演示基准时间：2026-10-30 10:30；固定数据不轮询");
    case "history":
      return panel("历史聚合趋势", chart(), `${rangeLabel()} · 示例聚合 · Asia/Shanghai`);
    case "curves":
      return panel("跨设备曲线组合", chart(), "勾选系列动态组合；水表流量与电表功率使用不同轴") +
        panel("视图配置", table(["视图", "范围", "可见性", "对齐策略"], [["水电联动观察", p.name, "个人视图 · 演示", state.range === "week" ? "按日聚合 / 不插值" : "4 小时采样 / 不插值"]]));
    case "dashboard":
      return panel("项目独立大屏预览", `<div class="screen-preview"><h3>${escapeText(p.name)} · 运行态势</h3><div class="screen-tiles">
        <div class="screen-tile">接入设备<strong>${p.total}</strong>台</div>
        <div class="screen-tile">在线率<strong>${(p.online / p.total * 100).toFixed(1)}%</strong>固定样本</div>
        <div class="screen-tile">最新负载<strong>${p.power}</strong>kW</div>
        </div></div><p class="muted">独立项目布局示意 · 草稿 v3 / 已发布 v2。生产应用使用受保护的独立路由，发布不等于公开。</p>`);
    case "reports":
      return panel("报表记录", table(["报表", "项目", "周期", "状态", "计算口径"], [
        ["用水日报", p.name, "2026-10-29", "已完成 · 示例", "累计量差值 / 处理复位"],
        ["用电日报", p.name, "2026-10-29", "已完成 · 示例", "电量差值 / 标记缺测"],
        ["设备质量周报", p.name, "10-24 至 10-30", "待生成 · 示例", "完整率 / 过期率"]
      ])) + panel("导出约束", '<p class="muted">模板不生成下载文件。正式实现采用异步生成、下载重新鉴权、到期清理及电子表格公式注入防护。</p>');
    case "governance":
      return panel("同步公式预览", `<p class="muted">仅提供三种固定变换，不执行任意表达式。生产公式需由服务端白名单 AST 解释器处理。</p>
        <form id="formula-form" class="formula-form">
          <label>原始值<input id="formula-value" type="number" step="any" value="1250" min="-1000000000" max="1000000000" required></label>
          <label>治理公式<select id="formula-kind"><option value="liters">value * 0.001 · L → m³</option><option value="calibration">(value - 4) * 0.5 · 校准</option><option value="temperature">value * 1.8 + 32 · ℃ → ℉</option></select></label>
          <button class="button primary" type="submit">预览结果</button>
        </form><output id="formula-result" class="callout" aria-live="polite">原始值 1250 L → 处理值 1.25 m³ · 固定规则 v1 / 不写入数据库</output>`) +
        panel("规则版本", table(["测点", "公式", "版本", "异常策略"], [["水表累计量", "value * 0.001", "v1", "保留原始值并标记质量"], ["温度", "value * 1.8 + 32", "v1", "隔离非数值"]]));
    case "sync":
      return panel("项目同步任务", table(["任务", "范围", "调度", "游标", "状态"], [
        ["设备与测点同步", p.name, "每 5 分钟 / Asia/Shanghai", "10:30 + event-128", state.syncEnabled[state.project] ? "已启用" : "已暂停"],
        ["全平台来源同步", "超管统一任务", "每小时 / Asia/Shanghai", "按项目维护", "此处只展示当前项目片段"]
      ]) + `<p><button id="toggle-sync" class="button" type="button">${state.syncEnabled[state.project] ? "暂停" : "启用"}项目任务（演示）</button></p>`) +
        panel("执行记录", table(["执行", "项目", "读取 / 写入 / 跳过", "结果", "规则版本"], [
          ["run-demo-1030", p.name, "128 / 124 / 4", "局部失败：4 条身份待映射", "v1"],
          ["run-demo-1025", p.name, "124 / 124 / 0", "成功", "v1"]
        ]), "运行按钮仅改变本页内存状态，不启动实际调度进程");
    default:
      return "";
  }
}

function render() {
  const [title, description] = PAGES[state.page];
  $("page-title").textContent = title;
  $("breadcrumb").textContent = title;
  $("page-description").textContent = description;
  $("project-name").textContent = project().name;
  $("page-status").textContent = "";
  document.title = `${title} · AlinkIoT 主题参考`;
  $("navigation").innerHTML = NAV_GROUPS.map((group, index) =>
    `<section class="nav-group" aria-labelledby="nav-group-${index}">
      <h2 class="nav-group-title" id="nav-group-${index}">${group.title}</h2>
      <div class="nav-group-items">${group.pages.map((key) =>
        `<a class="nav-item" href="#${key}" data-menu-tip="${PAGES[key][0]}" aria-label="${PAGES[key][0]}" ${key === state.page ? 'aria-current="page"' : ""}>${menuIcon(key)}<span class="nav-item-label">${PAGES[key][0]}</span></a>`
      ).join("")}</div>
    </section>`
  ).join("");
  renderMetrics();
  $("content").innerHTML = renderContent();
  $("chat-context").textContent = `${project().name} · 本地演示`;
}

function appendMessage(role, text) {
  state.conversations[state.project].push({ role, text });
  renderMessages();
}

function renderMessages() {
  $("chat-messages").replaceChildren();
  const messages = state.conversations[state.project];
  const visible = messages.length ? messages : [{ role: "assistant", text: "你好，我是本地演示助手。可通过“AI 分析当前页”查看受控上下文示例。此处不会连接真实模型或读取业务数据。" }];
  for (const { role, text } of visible) {
    const message = document.createElement("p");
    message.className = `message ${role}`;
    message.textContent = `${role === "user" ? "你" : "演示助手"}：${text}`;
    $("chat-messages").append(message);
  }
  $("chat-messages").scrollTop = $("chat-messages").scrollHeight;
}

function openChat() {
  $("chat-panel").hidden = false;
  $("chat-launcher").setAttribute("aria-expanded", "true");
  renderMessages();
  $("chat-input").focus();
}

function closeChat() {
  $("chat-panel").hidden = true;
  $("chat-launcher").setAttribute("aria-expanded", "false");
  $("chat-launcher").focus();
}

function analyzePage() {
  const templates = {
    realtime: "realtime_health", history: "history_trend", curves: "curve_compare",
    reports: "report_summary", governance: "governance_explain", sync: "sync_failure"
  };
  const template = templates[state.page] || "project_overview_demo";
  const selected = [["flow", "W-001 流量 m³/h"], ["power", "E-001 功率 kW"]]
    .filter(([key]) => state.series[key]).map(([, label]) => label).join("、") || "未选择系列";
  appendMessage("user", `分析「${PAGES[state.page][0]}」\n项目：${project().name}\n范围：${rangeLabel()} / Asia/Shanghai\n模板：${template}`);
  let detail = `固定样本中 ${project().online}/${project().total} 台设备在线。W-002 的示例采样已过期，需核查数据源与采样链路。`;
  if (state.page === "sync") detail = "示例执行有 4 条设备身份未映射，应先核查项目绑定及外部设备 ID，再决定是否重试；不能跳过失败片段推进其游标。";
  if (state.page === "governance") detail = `当前预览：${$("formula-result").textContent}。正式规则应保留原始值与版本，拒绝任意代码执行。`;
  if (["history", "curves"].includes(state.page)) detail = `当前系列：${selected}。流量与功率单位不同，应分别读轴。演示点来自所选时间范围的本地固定样本，不能推断因果或真实异常。`;
  appendMessage("assistant", `【模拟分析，非模型输出】\n${detail}\n局限：没有真实接口、连续样本或模型连接；本结论仅演示页面上下文传递方式。`);
  openChat();
}

$("collapse-menu").addEventListener("click", () => {
  const collapsed = document.body.classList.toggle("menu-collapsed");
  $("collapse-menu").setAttribute("aria-expanded", String(!collapsed));
  $("collapse-menu").setAttribute("aria-label", collapsed ? "展开侧边菜单" : "收起侧边菜单");
});
$("theme-select").addEventListener("change", (event) => applyTheme(event.target.value));
$("project-select").addEventListener("change", (event) => {
  state.project = event.target.value;
  $("chat-input").value = "";
  render();
  renderMessages();
});
$("range-select").addEventListener("change", (event) => {
  state.range = event.target.value;
  render();
});
$("content").addEventListener("change", (event) => {
  const series = event.target.dataset.series;
  if (series && Object.hasOwn(state.series, series)) {
    state.series[series] = event.target.checked;
    $("content").innerHTML = renderContent();
    $("content").querySelector(`[data-series="${series}"]`).focus();
  }
});
$("content").addEventListener("click", (event) => {
  if (event.target.id !== "toggle-sync") return;
  state.syncEnabled[state.project] = !state.syncEnabled[state.project];
  render();
  $("toggle-sync").focus();
  $("page-status").textContent = "已改变本地演示状态，未调用实际调度服务。";
});
$("content").addEventListener("submit", (event) => {
  if (event.target.id !== "formula-form") return;
  event.preventDefault();
  const value = Number($("formula-value").value);
  const transforms = {
    liters: [(v) => v * 0.001, "L", "m³"],
    calibration: [(v) => (v - 4) * 0.5, "原始单位", "校准单位"],
    temperature: [(v) => v * 1.8 + 32, "℃", "℉"]
  };
  if (!Number.isFinite(value) || Math.abs(value) > 1e9) {
    $("formula-result").textContent = "请输入范围内的有限数值。";
    return;
  }
  const [transform, inputUnit, outputUnit] = transforms[$("formula-kind").value];
  $("formula-result").textContent = `原始值 ${value} ${inputUnit} → 处理值 ${Number(transform(value).toFixed(6))} ${outputUnit} · 固定规则 v1 / 不写入数据库`;
});
$("chat-launcher").addEventListener("click", () => $("chat-panel").hidden ? openChat() : closeChat());
$("close-chat").addEventListener("click", closeChat);
$("analyze-page").addEventListener("click", analyzePage);
$("chat-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const text = $("chat-input").value.trim();
  if (!text) return;
  appendMessage("user", text);
  $("chat-input").value = "";
  appendMessage("assistant", `【模拟回复】当前项目为「${project().name}」。已记录你的问题，但本模板没有连接真实模型，不能据此给出真实业务判断。正式应用需由服务端验证项目权限、构建脱敏上下文后调用 AI。`);
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("chat-panel").hidden) closeChat();
});
window.addEventListener("hashchange", () => {
  const page = location.hash.slice(1);
  state.page = Object.hasOwn(PAGES, page) ? page : "overview";
  render();
  window.scrollTo({ top: 0, behavior: "instant" });
});
$("navigation").addEventListener("click", (event) => {
  if (!event.target.closest('a[href^="#"]')) return;
  requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" }));
});

let savedTheme = "ocean-light";
try { savedTheme = localStorage.getItem("alinkiot-theme") || savedTheme; } catch { /* Use the default when storage is unavailable. */ }
applyTheme(savedTheme);
const initialPage = location.hash.slice(1);
if (Object.hasOwn(PAGES, initialPage)) state.page = initialPage;
render();

{
  const tip = document.createElement("div");
  tip.id = "menu-tip";
  tip.className = "menu-tip";
  tip.setAttribute("role", "tooltip");
  tip.hidden = true;
  document.body.append(tip);
  let active;
  const hide = () => {
    active?.removeAttribute("aria-describedby");
    active = null;
    tip.hidden = true;
  };
  const show = (event) => {
    const item = event.target.closest("[data-menu-tip]");
    if (!item || !item.closest(".menu-collapsed, .collapsed")) return;
    hide();
    active = item;
    tip.textContent = item.dataset.menuTip;
    tip.hidden = false;
    item.setAttribute("aria-describedby", tip.id);
    const rect = item.getBoundingClientRect();
    tip.style.left = `${Math.max(8, Math.min(rect.right + 10, innerWidth - tip.offsetWidth - 8))}px`;
    tip.style.top = `${Math.max(8, Math.min(rect.top + (rect.height - tip.offsetHeight) / 2, innerHeight - tip.offsetHeight - 8))}px`;
  };
  document.addEventListener("pointerover", show);
  document.addEventListener("focusin", show);
  for (const type of ["pointerout", "focusout"]) document.addEventListener(type, (event) => {
    if (active && !active.contains(event.relatedTarget)) hide();
  });
  document.addEventListener("click", hide);
  document.addEventListener("scroll", hide, true);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hide(); });
  window.addEventListener("resize", hide);
}
