function menuIcon(page) {
  const paths = {
    overview: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
    projects: "M3 7h7l2-3h9v16H3z",
    permissions: "M12 2l8 4v6c0 5-8 9-8 9s-8-4-8-9V6z",
    devices: "M5 5h14v14H5z M9 9h6v6H9z M9 2v3 M15 2v3 M9 19v3 M15 19v3",
    realtime: "M2 12h5l3-7 4 14 3-7h5",
    history: "M12 3a9 9 0 1 0 9 9 M12 6v6l4 2",
    curves: "M3 3v18h18 M6 16l4-6 4 3 6-7",
    dashboard: "M3 4h18v13H3z M8 21h8 M12 17v4",
    reports: "M6 3h9l4 4v14H6z M9 11h7 M9 15h7",
    governance: "M4 5h16 M4 12h16 M4 19h16 M8 3v4 M16 10v4 M11 17v4",
    sync: "M20 8A8 8 0 0 0 6 5L3 8 M3 3v5h5 M4 16a8 8 0 0 0 14 3l3-3 M21 21v-5h-5",
    assistant: "M4 4h16v13H9l-5 4z M8 9h8 M8 13h5",
    analysis: "M12 2l2 7 7 3-7 2-2 8-3-8-7-2 7-3z",
    alarms: "M12 3a6 6 0 0 0-6 6v5l-2 3h16l-2-3V9a6 6 0 0 0-6-6 M10 21h4",
    "alarm-rules": "M4 5h16 M4 12h16 M4 19h16 M8 3v4 M16 10v4 M11 17v4",
    "alarm-notifications": "M3 5h18v14H3z M3 5l9 7 9-7"
  };
  return `<svg class="menu-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[page]}"/></svg>`;
}
