{
  const page = document.createElement("section");
  page.className = "login-page";
  page.setAttribute("aria-label", "澄明登录页");
  page.innerHTML = `
    <header class="login-brand">A / AlinkIoT <span>CLEAR CONSOLE</span></header>
    <div class="login-layout">
      <div class="login-story"><p class="login-eyebrow">CONNECTED OPERATIONS</p><h1>连接设备，<br>让数据清晰可见。</h1><p>从项目接入到数据洞察，以清晰的工作空间管理每一份设备数据。</p><div class="login-features"><span>项目与设备管理</span><span>实时与历史查询</span><span>数据治理与 AI 分析</span></div></div>
      <form class="login-card"><p class="login-eyebrow">WELCOME BACK</p><h2>登录工作空间</h2><p>澄明 · Clear Console</p>
        <label for="login-user">账号</label><input id="login-user" name="username" autocomplete="username" value="admin" required placeholder="请输入账号">
        <label for="login-password">密码</label><div class="login-password"><input id="login-password" name="password" type="password" autocomplete="current-password" value="demo123" required placeholder="请输入密码"><button type="button" class="login-eye" aria-label="显示密码" aria-pressed="false">显示</button></div>
        <p class="login-notice">本地演示 · 任意非空账号密码均可进入。不验证身份，不保存或发送输入内容。</p>
        <button class="login-submit" type="submit">进入演示工作空间 →</button>
      </form>
    </div><footer class="login-footer">主题参考 / 无真实认证、数据库或 AI 连接</footer>`;
  document.body.append(page);
  document.getElementById("logout").addEventListener("click", () => {
    const url = new URL(location.href);
    url.hash = "";
    location.replace(url.href);
  });
  const enter = () => {
    document.body.classList.remove("login-pending");
    page.hidden = true;
    document.querySelector("main")?.focus({ preventScroll: true });
    window.dispatchEvent(new Event("resize"));
  };
  page.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    page.querySelector("form").reset();
    enter();
  });
  page.querySelector(".login-eye").addEventListener("click", (event) => {
    const input = page.querySelector("#login-password");
    const visible = input.type === "password";
    input.type = visible ? "text" : "password";
    event.currentTarget.textContent = visible ? "隐藏" : "显示";
    event.currentTarget.setAttribute("aria-label", visible ? "隐藏密码" : "显示密码");
    event.currentTarget.setAttribute("aria-pressed", String(visible));
  });
  if (location.hash && document.querySelector(`#navigation a[href="${CSS.escape(location.hash)}"]`)) enter();
}
