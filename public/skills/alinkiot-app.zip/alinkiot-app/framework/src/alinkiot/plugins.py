import hashlib
import json
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import (
    JSON, BigInteger, Boolean, Column, DateTime, Double, ForeignKey, Index, Integer,
    MetaData, String, Table, UniqueConstraint, inspect, insert, select, text, update,
)
from sqlalchemy.schema import CreateColumn
from sqlalchemy.dialects.mysql import TINYINT

from . import models

IDENTIFIER = r"^[a-z][a-z0-9_]{0,23}$"
RESERVED = {"id", "device_id", "event_time", "source_key", "raw_values",
            "formula_versions", "quality", "ingested_at"}


class FieldSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(pattern=IDENTIFIER)
    type: str
    length: int = Field(default=200, ge=1, le=1000)
    unit: str = Field(default="", max_length=20)

    @model_validator(mode="after")
    def valid(self):
        if self.name in RESERVED or self.type not in {"number", "integer", "text", "boolean"}:
            raise ValueError("Unsupported or reserved product field")
        return self


class ProductSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(pattern=IDENTIFIER)
    name: str = Field(min_length=1, max_length=100)
    archive_fields: list[FieldSpec] = Field(default_factory=list, max_length=50)
    metrics: list[FieldSpec] = Field(min_length=1, max_length=50)

    @model_validator(mode="after")
    def unique_fields(self):
        for fields in (self.archive_fields, self.metrics):
            if len({f.name for f in fields}) != len(fields):
                raise ValueError("Duplicate product field")
        return self


class Manifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_version: int = Field(ge=1, le=1)
    id: str = Field(pattern=IDENTIFIER)
    version: int = Field(ge=1, le=1000000)
    name: str = Field(min_length=1, max_length=100)
    products: list[ProductSpec] = Field(min_length=1, max_length=20)

    @model_validator(mode="after")
    def unique_products(self):
        if len({p.id for p in self.products}) != len(self.products):
            raise ValueError("Duplicate product")
        return self


def discover(directory: Path) -> list[Manifest]:
    manifests = []
    for path in sorted(directory.glob("*/plugin.json")):
        if path.is_symlink() or path.parent.is_symlink() or path.stat().st_size > 100000:
            raise ValueError("Invalid plugin file")
        manifests.append(Manifest.model_validate_json(path.read_text()))
    if len(manifests) > 50 or len({m.id for m in manifests}) != len(manifests):
        raise ValueError("Too many or duplicate plugins")
    return manifests


def field_type(field: FieldSpec):
    return {"number": Double(), "integer": BigInteger(), "text": String(field.length),
            "boolean": Boolean()}[field.type]


def tables(manifest: Manifest):
    meta = MetaData()
    models.devices.to_metadata(meta)
    result = []
    for product in manifest.products:
        prefix = f"p_{manifest.id}_{product.id}"
        archive = Table(prefix + "_devices", meta,
                        Column("device_id", String(36), ForeignKey("device_registry.id"), primary_key=True),
                        *(Column(f.name, field_type(f), nullable=True) for f in product.archive_fields))
        samples = Table(prefix + "_samples", meta,
                        Column("id", BigInteger().with_variant(Integer(), "sqlite"),
                               primary_key=True, autoincrement=True),
                        Column("device_id", String(36), ForeignKey("device_registry.id"), nullable=False),
                        Column("event_time", DateTime, nullable=False),
                        Column("source_key", String(100), nullable=False),
                        Column("raw_values", JSON, nullable=False),
                        Column("formula_versions", JSON, nullable=False),
                        Column("quality", String(32), nullable=False),
                        Column("ingested_at", DateTime, nullable=False),
                        *(Column(f.name, field_type(f), nullable=True) for f in product.metrics),
                        UniqueConstraint("device_id", "source_key"),
                        Index(f"ix_{manifest.id}_{product.id}_time", "device_id", "event_time"))
        result.extend([archive, samples])
    return result


def compatible(previous: Manifest, current: Manifest):
    new_products = {p.id: p for p in current.products}
    for old in previous.products:
        new = new_products.get(old.id)
        if not new:
            raise ValueError("Removing a product requires a reviewed migration")
        for group in ("archive_fields", "metrics"):
            fields = {f.name: f for f in getattr(new, group)}
            for field in getattr(old, group):
                if field.name not in fields or fields[field.name] != field:
                    raise ValueError("Only additive nullable fields are supported")


def ensure_table(connection, table: Table):
    inspector = inspect(connection)
    if not inspector.has_table(table.name):
        table.create(connection)
        return
    existing = {c["name"]: c for c in inspector.get_columns(table.name)}
    if set(existing) - set(table.c.keys()):
        raise ValueError("Database schema differs from plugin manifest")
    if inspector.get_pk_constraint(table.name)["constrained_columns"] != [c.name for c in table.primary_key]:
        raise ValueError("Database primary key differs from manifest")
    unique_columns = {tuple(c["column_names"]) for c in inspector.get_unique_constraints(table.name)}
    for constraint in table.constraints:
        if isinstance(constraint, UniqueConstraint) and tuple(c.name for c in constraint.columns) not in unique_columns:
            raise ValueError("Database uniqueness differs from manifest")
    indexes = {i["name"]: i for i in inspector.get_indexes(table.name)}
    for index in table.indexes:
        if index.name not in indexes or indexes[index.name]["column_names"] != [c.name for c in index.columns]:
            raise ValueError("Database index differs from manifest")
    foreign_keys = inspector.get_foreign_keys(table.name)
    for constraint in table.foreign_key_constraints:
        expected_keys = [e.parent.name for e in constraint.elements]
        target = constraint.elements[0].column.table.name
        targets = [e.column.name for e in constraint.elements]
        if not any(f["constrained_columns"] == expected_keys and f["referred_table"] == target
                   and f["referred_columns"] == targets for f in foreign_keys):
            raise ValueError("Database foreign key differs from manifest")
    for column in table.columns:
        old = existing.get(column.name)
        if old:
            expected = column.type.dialect_impl(connection.dialect)
            actual = old["type"]
            boolean_mysql = (isinstance(expected, Boolean) and connection.dialect.name == "mysql"
                             and isinstance(actual, TINYINT) and actual.display_width == 1)
            if ((not boolean_mysql and expected._type_affinity is not actual._type_affinity) or
                isinstance(expected, BigInteger) and not isinstance(actual, BigInteger) or
                isinstance(expected, Double) and not isinstance(actual, Double) or
                isinstance(expected, String) and expected.length != actual.length or
                bool(column.nullable) != bool(old["nullable"])):
                raise ValueError("Database field type differs from manifest")
        else:
            if not column.nullable or column.primary_key:
                raise ValueError("Cannot add a required field to an existing table")
            name = connection.dialect.identifier_preparer.quote(table.name)
            definition = str(CreateColumn(column).compile(dialect=connection.dialect))
            connection.execute(text(f"ALTER TABLE {name} ADD COLUMN {definition}"))


def apply(connection, manifests: list[Manifest]):
    # MySQL DDL auto-commits: validate every manifest before any table changes.
    plans = []
    owners = {}
    for product in connection.execute(select(models.products)).mappings():
        for name in (product["archive_table"], product["telemetry_table"]):
            owners[name] = (product["plugin_id"], product["code"])
    for manifest in manifests:
        for product in manifest.products:
            owner = (manifest.id, product.id)
            for suffix in ("devices", "samples"):
                name = f"p_{manifest.id}_{product.id}_{suffix}"
                if name in owners and owners[name] != owner:
                    raise ValueError("Product table names collide")
                owners[name] = owner
        data = manifest.model_dump()
        digest = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
        old = connection.execute(select(models.plugins).where(models.plugins.c.id == manifest.id)).mappings().first()
        if old:
            if manifest.version < old["version"] or (
                manifest.version == old["version"] and digest != old["digest"]
            ):
                raise ValueError("Plugin changes require an increasing version")
            compatible(Manifest.model_validate(old["manifest"]), manifest)
        plans.append((manifest, data, digest, old is not None))
    for manifest, _, _, _ in plans:
        for table in tables(manifest):
            ensure_table(connection, table)
    connection.commit()
    with connection.begin():
        for manifest, data, digest, exists in plans:
            values = {"version": manifest.version, "digest": digest, "manifest": data}
            if exists:
                connection.execute(update(models.plugins).where(models.plugins.c.id == manifest.id).values(**values))
            else:
                connection.execute(insert(models.plugins).values(id=manifest.id, **values))
            for product in manifest.products:
                query = (models.products.c.plugin_id == manifest.id) & (models.products.c.code == product.id)
                values = {"name": product.name, "schema_version": manifest.version,
                          "archive_table": f"p_{manifest.id}_{product.id}_devices",
                          "telemetry_table": f"p_{manifest.id}_{product.id}_samples",
                          "definition": product.model_dump()}
                if connection.execute(select(models.products.c.id).where(query)).first():
                    connection.execute(update(models.products).where(query).values(**values))
                else:
                    connection.execute(insert(models.products).values(plugin_id=manifest.id, code=product.id, **values))
