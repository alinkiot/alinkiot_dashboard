import os
import secrets
from datetime import timedelta
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, SecretStr
from sqlalchemy import delete, insert, select, update
from sqlalchemy.exc import IntegrityError

from . import models
from .core import effective_projects, record, router
from .business import router as business_router
from .installer import DatabaseSetupError, install, install_plugins, installed, prepare_database
from .plugins import discover
from .security import digest, hash_password, verify_password
from .state import DatabaseInput, State

STATIC = Path(__file__).parent / "static"


class InstallInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    database: DatabaseInput
    admin_username: str = Field(pattern=r"^[a-zA-Z][a-zA-Z0-9_.-]{2,79}$")
    admin_password: SecretStr = Field(min_length=12, max_length=128)
    seed_demo: bool = False


class LoginInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    username: str = Field(min_length=1, max_length=80)
    password: SecretStr = Field(max_length=128)


def create_app(state_dir=None, plugin_dir=None):
    state = State(Path(state_dir or os.environ.get("ALINK_STATE_DIR", "var")))
    plugin_dir = Path(plugin_dir or os.environ.get("ALINK_PLUGIN_DIR", "plugins")).resolve()
    app = FastAPI(title="AlinkIoT Framework", docs_url=None, redoc_url=None, openapi_url=None)
    dummy_hash = hash_password(secrets.token_urlsafe(32))

    # Validation errors must not echo install/database/login secrets.
    @app.exception_handler(RequestValidationError)
    async def invalid_input(request, error):
        return JSONResponse(status_code=422, content={"detail": "输入格式无效，请检查必填项与长度限制"})

    @app.exception_handler(ValueError)
    async def bad_operation(request, error):
        return JSONResponse(status_code=400, content={"detail": "配置或来源数据校验失败，请检查 schema、授权和标准协议"})

    @app.exception_handler(IntegrityError)
    async def integrity_error(request, error):
        return JSONResponse(status_code=409, content={"detail": "关联或唯一约束冲突，不会覆盖既有数据"})

    @app.middleware("http")
    async def response_headers(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        )
        if request.url.path == "/sandbox":
            inline_scripts = " 'unsafe-inline'" if os.environ.get("ALINK_PANEL_SCRIPTS") == "1" else ""
            response.headers["Content-Security-Policy"] = (
                f"default-src 'none'; script-src 'self'{inline_scripts}; style-src 'unsafe-inline'; "
                "img-src data:; sandbox allow-scripts; frame-ancestors 'self'; base-uri 'none'; form-action 'none'"
            )
        return response

    def configured_engine():
        try:
            config = state.database()
            return config.engine() if config else None
        except Exception:
            raise HTTPException(503, "数据库配置不可读取，请检查受控配置及密钥")

    def is_installed():
        engine = configured_engine()
        if not engine:
            return False
        try:
            return installed(engine)
        except Exception:
            raise HTTPException(503, "数据库不可用；不会重新开放安装")
        finally:
            engine.dispose()

    def require_install_token(x_install_token: str = Header(default="")):
        if is_installed():
            raise HTTPException(409, "安装已完成，安装入口已锁定")
        if not state.check_token(x_install_token):
            raise HTTPException(403, "需要本机一次性安装令牌")

    def engine_dependency():
        if not is_installed():
            raise HTTPException(409, "请先安装")
        engine = configured_engine()
        try:
            yield engine
        finally:
            engine.dispose()

    def actor(authorization: str = Header(default=""), engine=Depends(engine_dependency)):
        token = authorization.removeprefix("Bearer ") if authorization.startswith("Bearer ") else ""
        with engine.connect() as connection:
            user = connection.execute(select(models.users).join(
                models.sessions, models.users.c.id == models.sessions.c.user_id
            ).where(models.sessions.c.token_hash == digest(token),
                    models.sessions.c.expires_at > models.now(),
                    models.users.c.enabled.is_(True))).mappings().first()
        if not user:
            raise HTTPException(401, "会话无效或已过期")
        if user["role"] not in {"superadmin", "admin", "user"}:
            raise HTTPException(403, "账号角色无效")
        if user["role"] != "superadmin":
            with engine.connect() as connection:
                customer = connection.execute(select(models.customers.c.id).where(
                    models.customers.c.id == user["customer_id"], models.customers.c.enabled.is_(True))).first()
            if not customer:
                raise HTTPException(403, "所属客户已停用或不存在")
        return {**dict(user), "_session_hash": digest(token)}

    def superadmin(user=Depends(actor)):
        if user["role"] != "superadmin":
            raise HTTPException(403, "仅超管可管理框架插件")
        return user

    @app.get("/health/live")
    def live():
        return {"status": "ok"}

    @app.get("/health/ready")
    def ready():
        if not is_installed():
            raise HTTPException(503, "尚未安装")
        engine = configured_engine()
        try:
            with engine.connect() as connection:
                version = connection.execute(select(models.installation.c.core_version)).scalar_one()
            return {"status": "ok", "core_version": version}
        finally:
            engine.dispose()

    @app.get("/api/install/status")
    def status():
        return {"installed": is_installed()}

    @app.get("/install")
    def wizard():
        if is_installed():
            raise HTTPException(409, "安装已完成")
        return FileResponse(STATIC / "install.html")

    @app.post("/api/install/test", dependencies=[Depends(require_install_token)])
    def test_database(data: DatabaseInput):
        try:
            return {"ok": True, "database_exists": prepare_database(data)}
        except DatabaseSetupError as error:
            raise HTTPException(400, str(error))
        except Exception:
            raise HTTPException(400, "连接失败：检查 MySQL 8、库名、账户权限与 TLS 设置")

    @app.post("/api/install", dependencies=[Depends(require_install_token)])
    def install_core(data: InstallInput, x_install_token: str = Header(default="")):
        with state.lock():
            # Recheck after taking the process-shared lock.
            if is_installed():
                raise HTTPException(409, "安装已完成")
            if not state.check_token(x_install_token):
                raise HTTPException(403, "安装令牌已失效")
            try:
                manifests = discover(plugin_dir)
                if not manifests:
                    raise ValueError("No plugin manifests")
            except Exception:
                raise HTTPException(400, "插件清单校验失败，检查部署的 plugin.json")
            engine = data.database.engine()
            try:
                prepare_database(data.database, create=True)
                if installed(engine):
                    raise ValueError("Already installed")
                # Persist encrypted connection first so a post-commit crash cannot lose it.
                state.save_database(data.database)
                demo = install(engine, manifests, data.admin_username, data.admin_password.get_secret_value(),
                    seed_demo=data.seed_demo, state=state)
                (state.directory / "install.token").unlink(missing_ok=True)
                return {"installed": True, "plugins": [m.id for m in manifests], "demo": demo}
            except DatabaseSetupError as error:
                raise HTTPException(400, str(error))
            except Exception:
                raise HTTPException(400, "安装失败；检查数据库权限、插件兼容性与备份后重试，不会覆盖既有账号")
            finally:
                engine.dispose()

    @app.post("/api/auth/login")
    def login(data: LoginInput, request: Request, engine=Depends(engine_dependency)):
        key = digest((request.client.host if request.client else "unknown") + ":" + data.username.casefold())
        now = models.now()
        with engine.begin() as connection:
            connection.execute(select(models.installation.c.id).where(
                models.installation.c.id == 1).with_for_update()).first()
            try:
                with connection.begin_nested():
                    connection.execute(insert(models.login_limits).values(key=key, attempts=0, window_start=now))
            except IntegrityError:
                pass
            limit = connection.execute(select(models.login_limits).where(
                models.login_limits.c.key == key).with_for_update()).mappings().one()
            attempts = limit["attempts"] if now - limit["window_start"] < timedelta(minutes=5) else 0
            if attempts >= 5:
                raise HTTPException(429, "登录尝试过多，请稍后重试")
            connection.execute(update(models.login_limits).where(models.login_limits.c.key == key).values(
                attempts=attempts + 1, window_start=limit["window_start"] if attempts else now))
            user = connection.execute(select(models.users).where(models.users.c.username == data.username)).mappings().first()
            valid = verify_password(data.password.get_secret_value(), user["password_hash"] if user else dummy_hash)
            customer_ok = user and (user["role"] == "superadmin" or connection.execute(
                select(models.customers.c.id).where(models.customers.c.id == user["customer_id"],
                    models.customers.c.enabled.is_(True))).first())
            if not valid or not user or not user["enabled"] or not customer_ok or user["role"] not in {"superadmin", "admin", "user"}:
                result = None
            else:
                token = secrets.token_urlsafe(32)
                connection.execute(insert(models.sessions).values(
                    token_hash=digest(token), user_id=user["id"], expires_at=now + timedelta(hours=1)))
                connection.execute(update(models.login_limits).where(models.login_limits.c.key == key).values(attempts=0))
                record(connection, user, "auth.login", user["id"])
                result = {"access_token": token, "token_type": "bearer", "expires_in": 3600}
        if result is None:
            raise HTTPException(401, "账号或密码错误")
        return result

    @app.post("/api/auth/logout")
    def logout(authorization: str = Header(default=""), user=Depends(actor), engine=Depends(engine_dependency)):
        with engine.begin() as connection:
            connection.execute(delete(models.sessions).where(models.sessions.c.token_hash == digest(authorization[7:])))
            record(connection, user, "auth.logout", user["id"])
        return {"ok": True}

    @app.get("/api/me")
    def me(user=Depends(actor), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            projects = effective_projects(connection, user)
        return {**{key: user[key] for key in ("id", "username", "role", "customer_id")}, "project_ids": [p["id"] for p in projects]}

    @app.get("/api/plugins")
    def plugin_list(user=Depends(superadmin), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in connection.execute(select(
                models.plugins.c.id, models.plugins.c.version, models.plugins.c.manifest
            )).mappings()]

    @app.post("/api/plugins/install")
    def plugin_install(user=Depends(superadmin), engine=Depends(engine_dependency)):
        try:
            manifests = discover(plugin_dir)
            install_plugins(engine, manifests, user["id"])
            return {"ok": True, "plugins": [m.id for m in manifests]}
        except Exception:
            raise HTTPException(400, "插件安装失败：仅支持受审的新增产品/可空字段与递增版本")

    @app.get("/")
    def home():
        return FileResponse(STATIC / "home.html")

    @app.get("/screen")
    def screen():
        return FileResponse(STATIC / "screen.html")

    @app.get("/sandbox")
    def sandbox():
        return FileResponse(STATIC / "sandbox.html")

    app.include_router(router(engine_dependency, actor))
    def business_engine():
        engine = configured_engine()
        if engine is None:
            raise HTTPException(409, "请先安装")
        try:
            with engine.connect() as connection:
                if connection.execute(select(models.installation.c.core_version)).scalar_one() < 2:
                    raise HTTPException(503, "请运行 alinkiot upgrade 升级业务表")
            yield engine
        finally:
            engine.dispose()
    app.include_router(business_router(business_engine, actor, state))
    @app.get("/theme/letu-smart/{filename}", include_in_schema=False)
    def letu_styles(filename: str):
        if filename not in {"styles.css", "alarms.css", "panels.css"}:
            raise HTTPException(404, "主题资源不存在")
        bundled = STATIC / "letu-smart" / filename
        source = Path(__file__).resolve().parents[3] / "themes" / "letu-smart" / filename
        return FileResponse(source if source.is_file() else bundled, media_type="text/css")

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app


app = create_app()
