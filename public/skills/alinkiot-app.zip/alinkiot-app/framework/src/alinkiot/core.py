from contextlib import contextmanager
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator
from sqlalchemy import delete, exists, func, insert, select, update

from . import models
from .security import hash_password, verify_password

CAPABILITIES = {
    "export": "数据导出", "report": "报表生成与下载", "configure": "共享配置管理",
    "sync": "项目同步管理", "alarm": "告警配置与处理",
}
USER_CAPABILITIES = {"export", "report"}
PUBLIC_USER_COLUMNS = [
    models.users.c.id, models.users.c.created_at, models.users.c.username,
    models.users.c.role, models.users.c.customer_id, models.users.c.enabled,
]


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class CustomerInput(Input):
    name: str = Field(min_length=1, max_length=100)
    enabled: bool = True


class ProjectInput(Input):
    name: str = Field(min_length=1, max_length=100)
    timezone: str = Field(default="Asia/Shanghai", max_length=64)

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value):
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("Unknown IANA timezone")
        return value


class AssignmentInput(Input):
    customer_id: str | None = Field(default=None, max_length=36)


class UserCreate(Input):
    username: str = Field(pattern=r"^[a-zA-Z][a-zA-Z0-9_.-]{2,79}$")
    password: SecretStr = Field(min_length=12, max_length=128)
    customer_id: str | None = Field(default=None, max_length=36)
    enabled: bool = True


class UserUpdate(Input):
    enabled: bool
    password: SecretStr | None = Field(default=None, min_length=12, max_length=128)


class PasswordInput(Input):
    current_password: SecretStr = Field(max_length=128)
    new_password: SecretStr = Field(min_length=12, max_length=128)


class GrantInput(Input):
    project_id: str = Field(min_length=1, max_length=36)
    capabilities: list[Literal["export", "report", "configure", "sync", "alarm"]] = Field(default_factory=list, max_length=5)


class GrantsInput(Input):
    grants: list[GrantInput] = Field(max_length=200)


def record(connection, actor, action, resource_id, **detail):
    connection.execute(insert(models.audit).values(actor_id=actor["id"], action=action,
        detail={"resource_id": resource_id, "customer_id": actor["customer_id"], **detail}))


def customer_active(connection, customer_id):
    customer = connection.execute(select(models.customers).where(
        models.customers.c.id == customer_id)).mappings().first()
    if not customer or not customer["enabled"]:
        raise HTTPException(400, "客户不存在或已停用")
    return customer


def effective_projects(connection, user):
    if user["role"] == "superadmin":
        query = select(models.projects)
    else:
        query = select(models.projects).join(models.grants,
            models.grants.c.project_id == models.projects.c.id).where(
            models.projects.c.customer_id == user["customer_id"],
            models.grants.c.user_id == user["id"])
    return [dict(row) for row in connection.execute(query.order_by(
        models.projects.c.created_at, models.projects.c.id)).mappings()]


def visible_user(connection, user_id, actor):
    query = select(models.users).where(models.users.c.id == user_id)
    if actor["role"] == "user":
        query = query.where(models.users.c.id == actor["id"])
    elif actor["role"] == "admin":
        query = query.where(models.users.c.customer_id == actor["customer_id"])
    user = connection.execute(query).mappings().first()
    if not user:
        raise HTTPException(404, "账号不存在或无权访问")
    return user


def manageable_user(connection, user_id, actor):
    user = visible_user(connection, user_id, actor)
    allowed_role = {"superadmin": "admin", "admin": "user"}.get(actor["role"])
    if user["role"] != allowed_role:
        raise HTTPException(403, "超管仅管理客户管理员，客户管理员仅管理本客户普通用户")
    return user


@contextmanager
def mutation(engine, actor):
    with engine.begin() as connection:
        # Serializes core mutations, including project transfer versus grant updates.
        connection.execute(select(models.installation.c.id).where(
            models.installation.c.id == 1).with_for_update()).first()
        current = connection.execute(select(models.users).where(
            models.users.c.id == actor["id"])).mappings().one()
        if not current["enabled"] or current["role"] != actor["role"] or current["customer_id"] != actor["customer_id"]:
            raise HTTPException(401, "账号状态已变更，请重新登录")
        if not connection.execute(select(models.sessions.c.token_hash).where(
            models.sessions.c.token_hash == actor["_session_hash"],
            models.sessions.c.expires_at > models.now())).first():
            raise HTTPException(401, "会话已撤销，请重新登录")
        if current["role"] != "superadmin":
            customer_active(connection, current["customer_id"])
        yield connection


def router(engine_dependency, actor_dependency):
    routes = APIRouter(prefix="/api")

    def manager(user=Depends(actor_dependency)):
        if user["role"] not in {"superadmin", "admin"}:
            raise HTTPException(403, "需要管理员权限")
        return user

    def superadmin(user=Depends(actor_dependency)):
        if user["role"] != "superadmin":
            raise HTTPException(403, "仅超管可维护客户和项目归属")
        return user

    @routes.get("/capabilities")
    def capabilities(user=Depends(actor_dependency)):
        return {"labels": CAPABILITIES, "roles": {"superadmin": "超管", "admin": "客户管理员", "user": "普通用户"},
                "user_ceiling": sorted(USER_CAPABILITIES)}

    @routes.get("/customers")
    def customers(q: str = Query(default="", max_length=100), page: int = Query(default=1, ge=1),
                  page_size: int = Query(default=20, ge=1, le=100),
                  user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        query = select(models.customers)
        if user["role"] != "superadmin":
            query = query.where(models.customers.c.id == user["customer_id"])
        if q:
            query = query.where(models.customers.c.name.contains(q, autoescape=True))
        with engine.connect() as connection:
            total = connection.execute(select(func.count()).select_from(query.subquery())).scalar_one()
            rows = connection.execute(query.order_by(models.customers.c.created_at, models.customers.c.id).offset(
                (page - 1) * page_size).limit(page_size)).mappings()
            return {"items": [dict(row) for row in rows], "total": total}

    @routes.post("/customers", status_code=201)
    def create_customer(data: CustomerInput, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            resource_id = connection.execute(insert(models.customers).values(**data.model_dump())).inserted_primary_key[0]
            record(connection, user, "customer.create", resource_id, customer_id=resource_id, name=data.name)
        return {"id": resource_id}

    @routes.put("/customers/{customer_id}")
    def update_customer(customer_id: str, data: CustomerInput, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.customers).where(models.customers.c.id == customer_id)).mappings().first()
            if not old:
                raise HTTPException(404, "客户不存在")
            connection.execute(update(models.customers).where(models.customers.c.id == customer_id).values(**data.model_dump()))
            if not data.enabled:
                connection.execute(delete(models.sessions).where(models.sessions.c.user_id.in_(
                    select(models.users.c.id).where(models.users.c.customer_id == customer_id))))
            record(connection, user, "customer.update", customer_id, customer_id=customer_id,
                   before={"name": old["name"], "enabled": old["enabled"]}, after=data.model_dump())
        return {"ok": True}

    @routes.delete("/customers/{customer_id}")
    def delete_customer(customer_id: str, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            if not connection.execute(select(models.customers.c.id).where(models.customers.c.id == customer_id)).first():
                raise HTTPException(404, "客户不存在")
            for table in (models.users, models.projects):
                if connection.execute(select(table.c.id).where(table.c.customer_id == customer_id).limit(1)).first():
                    raise HTTPException(409, "客户仍关联账号或项目，请停用客户或先调整项目归属")
            connection.execute(delete(models.customers).where(models.customers.c.id == customer_id))
            record(connection, user, "customer.delete", customer_id, customer_id=customer_id)
        return {"ok": True}

    @routes.get("/projects")
    def projects(q: str = Query(default="", max_length=100), page: int = Query(default=1, ge=1),
                 page_size: int = Query(default=20, ge=1, le=100),
                 user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        query = select(models.projects)
        if user["role"] != "superadmin":
            query = query.where(models.projects.c.customer_id == user["customer_id"], exists(
                select(models.grants.c.id).where(models.grants.c.project_id == models.projects.c.id,
                                                models.grants.c.user_id == user["id"])))
        if q:
            query = query.where(models.projects.c.name.contains(q, autoescape=True))
        with engine.connect() as connection:
            total = connection.execute(select(func.count()).select_from(query.subquery())).scalar_one()
            rows = [dict(row) for row in connection.execute(query.order_by(
                models.projects.c.created_at, models.projects.c.id).offset((page - 1) * page_size).limit(page_size)).mappings()]
            for row in rows:
                row["capabilities"] = sorted(CAPABILITIES) if user["role"] == "superadmin" else connection.execute(
                    select(models.grants.c.capabilities).where(models.grants.c.project_id == row["id"],
                        models.grants.c.user_id == user["id"])).scalar_one()
            return {"items": rows, "total": total}

    @routes.post("/projects", status_code=201)
    def create_project(data: ProjectInput, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            resource_id = connection.execute(insert(models.projects).values(**data.model_dump())).inserted_primary_key[0]
            record(connection, user, "project.create", resource_id, name=data.name)
        return {"id": resource_id}

    @routes.put("/projects/{project_id}")
    def update_project(project_id: str, data: ProjectInput, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.projects).where(models.projects.c.id == project_id)).mappings().first()
            if not old:
                raise HTTPException(404, "项目不存在")
            connection.execute(update(models.projects).where(models.projects.c.id == project_id).values(**data.model_dump()))
            record(connection, user, "project.update", project_id, customer_id=old["customer_id"],
                   before={"name": old["name"], "timezone": old["timezone"]}, after=data.model_dump())
        return {"ok": True}

    @routes.put("/projects/{project_id}/assignment")
    def assign_project(project_id: str, data: AssignmentInput, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.projects).where(models.projects.c.id == project_id)).mappings().first()
            if not old:
                raise HTTPException(404, "项目不存在")
            if data.customer_id:
                customer_active(connection, data.customer_id)
            changed = old["customer_id"] != data.customer_id
            if changed:
                connection.execute(delete(models.grants).where(models.grants.c.project_id == project_id))
                connection.execute(update(models.projects).where(models.projects.c.id == project_id).values(customer_id=data.customer_id))
                # Only the superadmin can see the cross-customer transfer details.
                record(connection, user, "project.assignment", project_id, customer_id=None,
                       previous_customer_id=old["customer_id"], new_customer_id=data.customer_id)
        return {"ok": True, "grants_revoked": changed}

    @routes.delete("/projects/{project_id}")
    def delete_project(project_id: str, user=Depends(superadmin), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.projects).where(models.projects.c.id == project_id)).mappings().first()
            if not old:
                raise HTTPException(404, "项目不存在")
            for table in (models.devices, models.jobs, models.connections, models.tasks, models.panels,
                          models.formulas, models.alarm_rules, models.alarm_events, models.reports,
                          models.conversations):
                if connection.execute(select(table.c.id).where(table.c.project_id == project_id).limit(1)).first():
                    raise HTTPException(409, "项目仍关联设备或任务，不能删除")
            connection.execute(delete(models.grants).where(models.grants.c.project_id == project_id))
            connection.execute(delete(models.projects).where(models.projects.c.id == project_id))
            record(connection, user, "project.delete", project_id, customer_id=old["customer_id"])
        return {"ok": True}

    @routes.get("/users")
    def users(q: str = Query(default="", max_length=80), role: Literal["superadmin", "admin", "user"] | None = None,
              page: int = Query(default=1, ge=1), page_size: int = Query(default=20, ge=1, le=100),
              user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        query = select(*PUBLIC_USER_COLUMNS)
        if user["role"] == "admin":
            query = query.where(models.users.c.customer_id == user["customer_id"])
        elif user["role"] == "user":
            query = query.where(models.users.c.id == user["id"])
        if q:
            query = query.where(models.users.c.username.contains(q, autoescape=True))
        if role:
            query = query.where(models.users.c.role == role)
        with engine.connect() as connection:
            total = connection.execute(select(func.count()).select_from(query.subquery())).scalar_one()
            items = [dict(row) for row in connection.execute(query.order_by(
                models.users.c.created_at, models.users.c.id).offset((page - 1) * page_size).limit(page_size)).mappings()]
        return {"items": items, "total": total}

    @routes.post("/users", status_code=201)
    def create_user(data: UserCreate, user=Depends(manager), engine=Depends(engine_dependency)):
        customer_id = data.customer_id if user["role"] == "superadmin" else user["customer_id"]
        if user["role"] == "admin" and data.customer_id not in (None, user["customer_id"]):
            raise HTTPException(403, "不能跨客户创建账号")
        with mutation(engine, user) as connection:
            customer_active(connection, customer_id)
            if connection.execute(select(models.users.c.id).where(models.users.c.username == data.username)).first():
                raise HTTPException(409, "登录账号已存在")
            role = "admin" if user["role"] == "superadmin" else "user"
            resource_id = connection.execute(insert(models.users).values(username=data.username,
                password_hash=hash_password(data.password.get_secret_value()), role=role,
                customer_id=customer_id, enabled=data.enabled)).inserted_primary_key[0]
            record(connection, user, "user.create", resource_id, customer_id=customer_id, username=data.username, role=role)
        return {"id": resource_id, "role": role}

    @routes.put("/users/{user_id}")
    def update_user(user_id: str, data: UserUpdate, user=Depends(manager), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = manageable_user(connection, user_id, user)
            values = {"enabled": data.enabled}
            if data.password:
                values["password_hash"] = hash_password(data.password.get_secret_value())
            connection.execute(update(models.users).where(models.users.c.id == user_id).values(**values))
            if data.password or not data.enabled:
                connection.execute(delete(models.sessions).where(models.sessions.c.user_id == user_id))
            record(connection, user, "user.update", user_id, customer_id=old["customer_id"],
                   before={"enabled": old["enabled"]}, after={"enabled": data.enabled},
                   password_reset=bool(data.password))
        return {"ok": True}

    @routes.put("/me/password")
    def change_password(data: PasswordInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = visible_user(connection, user["id"], user)
            if not verify_password(data.current_password.get_secret_value(), old["password_hash"]):
                raise HTTPException(400, "当前密码错误")
            connection.execute(update(models.users).where(models.users.c.id == user["id"]).values(
                password_hash=hash_password(data.new_password.get_secret_value())))
            connection.execute(delete(models.sessions).where(models.sessions.c.user_id == user["id"]))
            record(connection, user, "auth.password_change", user["id"])
        return {"ok": True, "relogin_required": True}

    @routes.get("/users/{user_id}/grants")
    def user_grants(user_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            target = visible_user(connection, user_id, user)
            grants = connection.execute(select(models.grants.c.project_id, models.grants.c.capabilities).join(
                models.projects, models.projects.c.id == models.grants.c.project_id).where(
                models.grants.c.user_id == user_id, models.projects.c.customer_id == target["customer_id"])).mappings()
            return [dict(row) for row in grants]

    @routes.put("/users/{user_id}/grants")
    def save_grants(user_id: str, data: GrantsInput, user=Depends(manager), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            target = manageable_user(connection, user_id, user)
            customer_active(connection, target["customer_id"])
            if user["role"] == "superadmin":
                editable = {p["id"] for p in connection.execute(select(models.projects).where(
                    models.projects.c.customer_id == target["customer_id"])).mappings()}
                ceiling = set(CAPABILITIES)
                issuer_grants = {}
            else:
                editable = {p["id"] for p in effective_projects(connection, user)}
                ceiling = USER_CAPABILITIES
                issuer_grants = {row["project_id"]: set(row["capabilities"]) for row in connection.execute(
                    select(models.grants).where(models.grants.c.user_id == user["id"])).mappings()}
            if len({g.project_id for g in data.grants}) != len(data.grants):
                raise HTTPException(400, "项目授权不能重复")
            for grant in data.grants:
                if grant.project_id not in editable:
                    raise HTTPException(403, "不能分配未获授权或不属于目标客户的项目")
                caps = set(grant.capabilities)
                if len(caps) != len(grant.capabilities) or not caps <= ceiling:
                    raise HTTPException(403, "授权能力超出固定角色上限")
                if user["role"] != "superadmin" and not caps <= issuer_grants[grant.project_id]:
                    raise HTTPException(403, "不能授予自己未获授的能力")
            # Preserve grants outside this administrator's editable project scope.
            connection.execute(delete(models.grants).where(models.grants.c.user_id == user_id,
                models.grants.c.project_id.in_(editable)))
            for grant in data.grants:
                connection.execute(insert(models.grants).values(user_id=user_id,
                    project_id=grant.project_id, capabilities=sorted(grant.capabilities)))
            record(connection, user, "user.grants", user_id, customer_id=target["customer_id"],
                   grants=[g.model_dump() for g in data.grants])
        return {"ok": True}

    @routes.get("/audit-logs")
    def audit_logs(q: str = Query(default="", max_length=80), page: int = Query(default=1, ge=1),
                   page_size: int = Query(default=20, ge=1, le=100),
                   user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        query = select(models.audit, models.users.c.username.label("actor_username")).outerjoin(
            models.users, models.users.c.id == models.audit.c.actor_id)
        if user["role"] == "admin":
            query = query.where(models.audit.c.detail["customer_id"].as_string() == user["customer_id"])
        elif user["role"] == "user":
            query = query.where(models.audit.c.actor_id == user["id"])
        if q:
            query = query.where(models.audit.c.action.contains(q, autoescape=True))
        with engine.connect() as connection:
            total = connection.execute(select(func.count()).select_from(query.subquery())).scalar_one()
            rows = connection.execute(query.order_by(models.audit.c.created_at.desc(), models.audit.c.id.desc()).offset(
                (page - 1) * page_size).limit(page_size)).mappings()
            return {"items": [dict(row) for row in rows], "total": total}

    return routes
