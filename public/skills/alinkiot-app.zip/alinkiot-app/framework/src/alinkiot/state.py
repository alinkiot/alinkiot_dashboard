import fcntl
import json
import os
import secrets
from contextlib import contextmanager
from pathlib import Path

from cryptography.fernet import Fernet
from pydantic import BaseModel, ConfigDict, Field, SecretStr
from sqlalchemy import URL, create_engine
from sqlalchemy.pool import NullPool


class DatabaseInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    host: str = Field(min_length=1, max_length=253, pattern=r"^[a-zA-Z0-9.:-]+$")
    port: int = Field(default=3306, ge=1, le=65535)
    database: str = Field(pattern=r"^[a-zA-Z][a-zA-Z0-9_]{0,63}$")
    username: str = Field(min_length=1, max_length=80)
    password: SecretStr = Field(max_length=256)
    tls: bool = True

    def engine(self, *, server_only=False):
        return create_engine(
            URL.create("mysql+pymysql", username=self.username,
                       password=self.password.get_secret_value(), host=self.host,
                       port=self.port, database=None if server_only else self.database,
                       query={"charset": "utf8mb4"}),
            poolclass=NullPool,
            connect_args={"connect_timeout": 5, "read_timeout": 30, "write_timeout": 30,
                          **({"ssl": {"check_hostname": True}} if self.tls else {})},
        )


class State:
    def __init__(self, directory: Path):
        self.directory = directory.resolve()
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.directory, 0o700)

    def write(self, name: str, content: str):
        temp = self.directory / (name + ".tmp")
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, self.directory / name)

    @contextmanager
    def lock(self):
        fd = os.open(self.directory / "install.lock", os.O_CREAT | os.O_RDWR, 0o600)
        with os.fdopen(fd, "w") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            yield

    def token(self):
        with self.lock():
            path = self.directory / "install.token"
            if not path.exists():
                self.write("install.token", secrets.token_urlsafe(32))
            return path.read_text().strip()

    def check_token(self, value: str) -> bool:
        path = self.directory / "install.token"
        try:
            return secrets.compare_digest(path.read_text().strip(), value)
        except FileNotFoundError:
            return False

    def cipher(self, create=True):
        value = os.environ.get("ALINK_MASTER_KEY")
        if value:
            return Fernet(value.encode())
        path = self.directory / "master.key"
        if not path.exists():
            if not create:
                raise ValueError("Master key is missing")
            self.write("master.key", Fernet.generate_key().decode())
        return Fernet(path.read_bytes().strip())

    def save_database(self, settings: DatabaseInput):
        data = settings.model_dump(exclude={"password"})
        data["encrypted_password"] = self.cipher().encrypt(
            settings.password.get_secret_value().encode()).decode()
        self.write("database.json", json.dumps(data))

    def database(self):
        path = self.directory / "database.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        encrypted = data.pop("encrypted_password")
        data["password"] = self.cipher(create=False).decrypt(encrypted.encode()).decode()
        return DatabaseInput.model_validate(data)
