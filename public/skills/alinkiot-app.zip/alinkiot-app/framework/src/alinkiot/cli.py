import argparse
import json
import os
import secrets
from pathlib import Path

import uvicorn

from .state import State


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["serve", "install-token", "upgrade", "seed", "worker", "mock"])
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=58239)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    state = State(Path(os.environ.get("ALINK_STATE_DIR", "var")))
    if args.command == "install-token":
        with state.lock():
            if (state.directory / "database.json").exists():
                from .installer import installed
                engine = state.database().engine()
                try:
                    if installed(engine):
                        parser.error("Installation completed; token cannot be recreated")
                finally:
                    engine.dispose()
            path = state.directory / "install.token"
            if not path.exists():
                state.write("install.token", secrets.token_urlsafe(32))
            print(path.read_text().strip())
    elif args.command == "upgrade":
        from .installer import upgrade
        with state.lock():
            engine = state.database().engine()
            try:
                upgrade(engine)
            finally:
                engine.dispose()
        print("Core schema upgraded to version 2")
    elif args.command == "seed":
        from .seed import seed_existing
        with state.lock():
            config = state.database()
            if config is None:
                parser.error("请先安装")
            engine = config.engine()
            try:
                result = seed_existing(engine, state)
            finally:
                engine.dispose()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.command == "worker":
        from .worker import run
        run(state, once=args.once)
    elif args.command == "mock":
        uvicorn.run("alinkiot.mock_platform:app", host=args.host, port=58240 if args.port == 58239 else args.port)
    else:
        uvicorn.run("alinkiot.app:app", host=args.host, port=args.port)
