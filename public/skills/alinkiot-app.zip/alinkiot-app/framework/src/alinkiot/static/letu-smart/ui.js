/* ═══════════════════════════════════════════
   乐图智慧 · UI 基础组件
   ═══════════════════════════════════════════ */

const ICONS = {
  grid:'<rect x="3" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.6"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
  lock:'<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  folder:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  cpu:'<rect x="6.5" y="6.5" width="11" height="11" rx="2"/><rect x="10" y="10" width="4" height="4" rx=".8"/><path d="M9.5 2.5v4M14.5 2.5v4M9.5 17.5v4M14.5 17.5v4M2.5 9.5h4M2.5 14.5h4M17.5 9.5h4M17.5 14.5h4"/>',
  activity:'<path d="M3 12h3.5l2.5 7 4-14 2.5 7H21"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/>',
  chart:'<path d="M3 3v18h18"/><path d="M7.5 15l3.8-4.6 3 2.8 4.7-6.4"/>',
  monitor:'<rect x="2.5" y="3.5" width="19" height="13.5" rx="2.2"/><path d="M8.5 21h7M12 17v4"/>',
  file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
  sigma:'<path d="M18 4H6l6 8-6 8h12"/>',
  refresh:'<path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1"/><path d="M20.5 3.5v5h-5"/>',
  sparkles:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M18.5 15.5l.8 1.9 1.9.8-1.9.8-.8 1.9-.8-1.9-1.9-.8 1.9-.8z"/>',
  brain:'<path d="M9.5 3.5A3 3 0 0 0 6.6 7a3 3 0 0 0-1.6 5.3A3 3 0 0 0 6.8 18a3 3 0 0 0 5.7 1.4V4.9a3 3 0 0 0-3-1.4z"/><path d="M14.5 3.5A3 3 0 0 1 17.4 7a3 3 0 0 1 1.6 5.3A3 3 0 0 1 17.2 18a3 3 0 0 1-5.7 1.4"/>',
  layers:'<path d="M12 3l9 4.8-9 4.8-9-4.8z"/><path d="M3 12.4l9 4.8 9-4.8"/><path d="M3 16.9l9 4.8 9-4.8"/>',
  shield:'<path d="M12 3l8 3v5.6c0 4.8-3.3 8.1-8 9.4-4.7-1.3-8-4.6-8-9.4V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
  list:'<path d="M8.5 6h12M8.5 12h12M8.5 18h12M3.6 6h.01M3.6 12h.01M3.6 18h.01"/>',
  sun:'<circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.2M12 19.8V22M2 12h2.2M19.8 12H22M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M19.1 4.9l-1.6 1.6M6.5 17.5l-1.6 1.6"/>',
  moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  bell:'<path d="M18 8.5a6 6 0 1 0-12 0c0 6.5-2.5 8.5-2.5 8.5h17S18 15 18 8.5"/><path d="M13.7 20.5a2 2 0 0 1-3.4 0"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  download:'<path d="M12 3.5v11.5"/><path d="M7.5 10.5L12 15l4.5-4.5"/><path d="M4 20.5h16"/>',
  upload:'<path d="M12 20V8.5"/><path d="M7.5 12.5L12 8l4.5 4.5"/><path d="M4 3.5h16"/>',
  filter:'<path d="M3.5 5h17l-6.8 8v6l-3.4 1.8V13z"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>',
  send:'<path d="M21.5 2.5L10.5 13.5"/><path d="M21.5 2.5l-7 19-4-8.5-8.5-4z"/>',
  play:'<path d="M7 4.5l13 7.5-13 7.5z"/>',
  pause:'<path d="M9 5v14M15 5v14"/>',
  gear:'<circle cx="12" cy="12" r="3.2"/><path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.1 5.1l1.6 1.6M17.3 17.3l1.6 1.6M18.9 5.1l-1.6 1.6M6.7 17.3l-1.6 1.6"/>',
  chevron:'<path d="M9 6l6 6-6 6"/>',
  chevDown:'<path d="M6 9l6 6 6-6"/>',
  check:'<path d="M4.5 12.5l5 5L19.5 6.5"/>',
  alert:'<path d="M12 3.2l9.3 16.6H2.7z"/><path d="M12 9v4.6M12 17h.01"/>',
  logout:'<path d="M9.5 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4.5"/><path d="M16 16.5l4.5-4.5L16 7.5"/><path d="M20.5 12H9.5"/>',
  edit:'<path d="M12.5 20H21"/><path d="M16.4 3.6a2.2 2.2 0 0 1 3.1 3.1L7.5 18.7 3.5 20l1.3-4z"/>',
  trash:'<path d="M3.5 6.5h17"/><path d="M8.5 6.5V4h7v2.5"/><path d="M6 6.5l1 13.5h10l1-13.5"/>',
  copy:'<rect x="9" y="9" width="11.5" height="11.5" rx="2"/><path d="M5.5 15V5.5a2 2 0 0 1 2-2H15"/>',
  target:'<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/>',
  zap:'<path d="M13.5 2.5L4.5 14h6l-1 7.5L19 9.5h-6z"/>',
  db:'<ellipse cx="12" cy="5.8" rx="8" ry="3"/><path d="M4 5.8v12.4c0 1.66 3.58 3 8 3s8-1.34 8-3V5.8"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/>',
  link:'<path d="M10 13.5a5 5 0 0 0 7.1 0l2-2a5 5 0 0 0-7.1-7.1l-1 1"/><path d="M14 10.5a5 5 0 0 0-7.1 0l-2 2a5 5 0 0 0 7.1 7.1l1-1"/>',
  expand:'<path d="M8.5 3.5H5a1.5 1.5 0 0 0-1.5 1.5v3.5M15.5 3.5H19a1.5 1.5 0 0 1 1.5 1.5v3.5M8.5 20.5H5A1.5 1.5 0 0 1 3.5 19v-3.5M15.5 20.5H19a1.5 1.5 0 0 0 1.5-1.5v-3.5"/>',
  menu:'<path d="M3.5 7h17M3.5 12h17M3.5 17h17"/>',
  calendar:'<rect x="3.5" y="5" width="17" height="15.5" rx="2.2"/><path d="M3.5 10h17M8.5 3v4M15.5 3v4"/>',
  gauge:'<path d="M3.5 18a9 9 0 1 1 17 0"/><path d="M12 18l4-5.5"/><circle cx="12" cy="18" r="1.4"/>',
  trend:'<path d="M3.5 16.5l5.5-5.5 4 4 7.5-8"/><path d="M15 6.5h5.5V12"/>',
  dot:'<circle cx="12" cy="12" r="3.5"/>',
  robot:'<rect x="4" y="7.5" width="16" height="12" rx="3.5"/><path d="M12 3.5v4"/><circle cx="9" cy="13" r="1.2"/><circle cx="15" cy="13" r="1.2"/><path d="M9.5 16.5h5"/>',
  doc:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
  eye:'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  wrench:'<path d="M14.5 6.5a4.5 4.5 0 0 1 6 6l-9 9-3-3 9-9a4.5 4.5 0 0 1-3-3z"/>',
  pin:'<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>'
};

function icon(name, cls = '') {
  return `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`;
}

/* ─── 格式化 ─── */
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}
function nf(n, d = 0) {
  if (n == null) return '—';
  return Number(n).toLocaleString('zh-CN', { minimumFractionDigits: d, maximumFractionDigits: d });
}
function relTime(t) { return t; }

/* ─── 状态徽标 ─── */
const STATUS_MAP = {
  active:   { cls:'ok',     text:'正常' },
  running:  { cls:'ok',     text:'运行中' },
  paused:   { cls:'warn',   text:'已暂停' },
  disabled: { cls:'mute',   text:'已停用' },
  online:   { cls:'ok',     text:'在线' },
  offline:  { cls:'mute',   text:'离线' },
  success:  { cls:'ok',     text:'成功' },
  failed:   { cls:'danger', text:'失败' },
  warn:     { cls:'warn',   text:'警告' },
  danger:   { cls:'danger', text:'严重' },
  ok:       { cls:'ok',     text:'正常' },
  info:     { cls:'info',   text:'提示' },
  draft:    { cls:'mute',   text:'草稿' },
  done:     { cls:'ok',     text:'已生成' },
  mute:     { cls:'mute',   text:'—' }
};
function badge(s, text) {
  const m = STATUS_MAP[s] || STATUS_MAP.mute;
  return `<span class="badge ${m.cls}">${text || m.text}</span>`;
}

/* ─── Toast ─── */
function toast(msg, type = 'ok') {
  const wrap = document.getElementById('toastWrap');
  const icons = { ok:'check', info:'sparkles', warn:'alert', danger:'alert' };
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = `<span class="t-ico">${icon(icons[type] || 'check')}</span><span></span>`;
  t.lastElementChild.textContent = msg;
  wrap.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 2400);
}

/* ─── 抽屉 ─── */
const DIALOG_FOCUS = new Map();
function syncDialogLayers() {
  const modal = document.getElementById('modal');
  const drawer = document.getElementById('drawer');
  document.getElementById('app').inert = modal.classList.contains('on') || drawer.classList.contains('on');
  drawer.inert = modal.classList.contains('on');
}
function prepareDialog(d) {
  DIALOG_FOCUS.set(d, document.activeElement);
  d.setAttribute('role', 'dialog');
  d.setAttribute('aria-modal', 'true');
  d.setAttribute('aria-hidden', 'false');
  d.tabIndex = -1;
  const heading = d.querySelector('h3');
  heading.id = d.id + '-title';
  d.setAttribute('aria-labelledby', heading.id);
  d.querySelector('.x-btn').setAttribute('aria-label', '关闭');
  d.querySelectorAll('.form-field').forEach(field => {
    const control = field.querySelector('input, select, textarea');
    const label = field.querySelector('label');
    if (!control || !label) return;
    control.setAttribute('aria-label', label.textContent.replace('*', '').trim());
    if (label.querySelector('.req')) control.required = true;
  });
  if (!d.dataset.dialogBound) {
    d.dataset.dialogBound = 'true';
    d.addEventListener('click', e => {
      if (!e.target.closest('.modal-foot .btn-primary, .drawer-foot .btn-primary')) return;
      for (const control of d.querySelectorAll('input, select, textarea')) {
        if (control.required && control.type !== 'checkbox' && control.type !== 'radio') {
          control.setCustomValidity(control.value.trim() ? '' : '请填写此项');
        }
        if (!control.reportValidity()) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      }
    }, true);
    d.addEventListener('input', e => e.target.setCustomValidity?.(''));
    d.addEventListener('keydown', e => {
      if (e.key !== 'Tab') return;
      const controls = [...d.querySelectorAll('button, input, select, textarea, a[href], [tabindex]')]
        .filter(el => !el.disabled && el.tabIndex >= 0 && el.getClientRects().length);
      const first = controls[0], last = controls[controls.length - 1];
      if (!first) { e.preventDefault(); d.focus(); }
      else if (e.shiftKey && (document.activeElement === first || document.activeElement === d)) {
        e.preventDefault(); last.focus();
      } else if (!e.shiftKey && (document.activeElement === last || document.activeElement === d)) {
        e.preventDefault(); first.focus();
      }
    });
  }
  syncDialogLayers();
  (d.querySelector('input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button') || d).focus();
}
function hideDialog(id) {
  const d = document.getElementById(id);
  if (!d.classList.contains('on')) return;
  d.classList.remove('on');
  d.setAttribute('aria-hidden', 'true');
  document.getElementById(id + 'Mask').classList.remove('on');
  syncDialogLayers();
  const previous = DIALOG_FOCUS.get(d);
  if (previous?.isConnected && !previous.closest('[inert]')) previous.focus({ preventScroll: true });
  DIALOG_FOCUS.delete(d);
}
function openDrawer(title, bodyHTML, footHTML = '') {
  const d = document.getElementById('drawer');
  const m = document.getElementById('drawerMask');
  d.innerHTML = `
    <div class="drawer-head"><h3>${escapeHTML(title)}</h3><button class="x-btn" onclick="closeDrawer()">${icon('x')}</button></div>
    <div class="drawer-body">${bodyHTML}</div>
    ${footHTML ? `<div class="drawer-foot">${footHTML}</div>` : ''}`;
  m.classList.add('on'); d.classList.add('on');
  prepareDialog(d);
}
function closeDrawer() {
  hideDialog('drawer');
}

/* ─── 弹窗 ─── */
function openModal(title, bodyHTML, footHTML = '') {
  const d = document.getElementById('modal');
  const m = document.getElementById('modalMask');
  d.innerHTML = `
    <div class="modal-head"><h3>${escapeHTML(title)}</h3><button class="x-btn" onclick="closeModal()">${icon('x')}</button></div>
    <div class="modal-body">${bodyHTML}</div>
    ${footHTML ? `<div class="modal-foot">${footHTML}</div>` : ''}`;
  m.classList.add('on'); d.classList.add('on');
  prepareDialog(d);
}
function closeModal() {
  hideDialog('modal');
}

/* ─── 分页条 ─── */
function pager(total, page, size) {
  const pages = Math.max(1, Math.ceil(total / size));
  let nums = '';
  const start = Math.max(1, Math.min(page - 2, pages - 4));
  for (let i = start; i <= Math.min(pages, start + 4); i++) {
    nums += `<button class="pg ${i === page ? 'on' : ''}" data-pg="${i}">${i}</button>`;
  }
  return `<div class="pager" data-size="${size}">
    <span class="pinfo">共 <b class="num">${nf(total)}</b> 条 · 每页 ${size} 条</span>
    <button class="pg" ${page <= 1 ? 'disabled' : ''} data-pg="${page - 1}">‹</button>
    ${nums}
    <button class="pg" ${page >= pages ? 'disabled' : ''} data-pg="${page + 1}">›</button>
  </div>`;
}
