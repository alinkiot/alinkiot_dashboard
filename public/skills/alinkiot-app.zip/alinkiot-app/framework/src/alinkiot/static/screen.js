const share = location.hash.slice(1);
try {document.documentElement.dataset.theme = localStorage.getItem('alink-theme') === 'light' ? 'light' : 'dark';} catch {}
let screenTimer;
async function refreshScreen() {
  try {
    const response = await fetch('/api/shared-panel', {headers: {'X-Panel-Share': share}});
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || '分享读取失败');
    document.getElementById('screen-title').textContent = data.name;
    const host = document.getElementById('screen-content'); host.replaceChildren();
    data.config.series.forEach(series => {
      const sample = data.samples.find(row => row.device_id === series.device_id);
      const card = document.createElement('section');
      card.className = 'card panel-card';
      const body = document.createElement('div'); body.className = 'card-body';
      const heading = document.createElement('h3'); heading.textContent = `${sample?.external_id || '设备'} · ${series.metric}`;
      const value = document.createElement('p'); value.className = 'product-property-value'; value.textContent = `${sample?.values[series.metric] ?? '—'} `;
      const unit = document.createElement('small'); unit.textContent = sample?.units[series.metric] || ''; value.append(unit);
      const time = document.createElement('p'); time.className = 'hint'; time.textContent = sample ? `采样时间：${new Date(sample.time).toLocaleString()}` : '暂无采样';
      body.append(heading, value, time); card.append(body); host.append(card);
    });
    document.getElementById('screen-error').textContent = '';
    screenTimer = setTimeout(refreshScreen, 10000);
  } catch (error) {
    document.getElementById('screen-content').replaceChildren();
    document.getElementById('screen-error').textContent = error.message;
  }
}
document.getElementById('screen-fullscreen').onclick = () => document.documentElement.requestFullscreen().catch(() => {});
window.addEventListener('pagehide', () => clearTimeout(screenTimer));
refreshScreen();
