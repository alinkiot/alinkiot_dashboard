const byId = id => document.getElementById(id);
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  document.querySelectorAll('[data-theme-label]').forEach(label => label.textContent = theme === 'light' ? '明亮白' : '科技蓝');
  document.querySelectorAll('[data-theme-toggle]').forEach(button => {
    button.setAttribute('aria-label', theme === 'light' ? '切换科技蓝主题' : '切换明亮白主题');
  });
  document.querySelector('meta[name="theme-color"]').content = theme === 'light' ? '#f2f5fa' : '#050810';
  Charts.redrawAll();
}
let savedTheme = 'dark';
try {savedTheme = localStorage.getItem('alink-theme') === 'light' ? 'light' : 'dark';} catch {}
applyTheme(savedTheme);
document.querySelectorAll('[data-theme-toggle]').forEach(button => {
  button.onclick = () => {
    const theme = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    applyTheme(theme);
    try {localStorage.setItem('alink-theme', theme);} catch {}
  };
});
document.querySelectorAll('[data-icon]').forEach(element => {
  const template = document.createElement('template');
  template.innerHTML = icon(element.dataset.icon);
  element.prepend(template.content);
});
const mobileMenu = window.matchMedia('(max-width:860px)');
function syncMenu() {
  const expanded = mobileMenu.matches ? byId('workspace').classList.contains('mobile-open') : !byId('workspace').classList.contains('collapsed');
  byId('menu-toggle').setAttribute('aria-expanded', String(expanded));
  byId('menu-toggle').setAttribute('aria-label', expanded ? '收起侧边菜单' : '展开侧边菜单');
}
byId('menu-toggle').onclick = () => {
  if (mobileMenu.matches) {
    byId('workspace').classList.remove('collapsed');
    byId('workspace').classList.toggle('mobile-open');
  } else byId('workspace').classList.toggle('collapsed');
  syncMenu();
  setTimeout(() => Charts.redrawAll(), 320);
};
mobileMenu.addEventListener('change', syncMenu);
document.querySelectorAll('[data-route]').forEach(link => link.addEventListener('click', () => {
  byId('workspace').classList.remove('mobile-open'); syncMenu();
}));
byId('password-eye').onclick = () => {
  const input = login.elements.password;
  input.type = input.type === 'password' ? 'text' : 'password';
  byId('password-eye').setAttribute('aria-label', input.type === 'password' ? '显示密码' : '隐藏密码');
};
const login = byId('login-form');
const workspace = byId('workspace');
const editor = byId('editor');
const editorForm = byId('editor-form');
const roles = {superadmin: '超管', admin: '客户管理员', user: '普通用户'};
const caps = {export: '数据导出', report: '报表生成与下载', configure: '共享配置管理', sync: '项目同步管理', alarm: '告警配置与处理'};
const views = {
  dashboard: ['工作台', '当前账号授权范围内的实时业务概览，不展示离线主题的固定统计样本。', '/api/projects'],
  customers: ['客户管理', '维护客户档案与启停状态；客户停用后，其账号立即失去平台访问权限。', '/api/customers'],
  projects: ['项目管理', '超管新建和分配项目；客户管理员与普通用户仅能查看获授权项目。', '/api/projects'],
  users: ['角色权限', '固定三级权限：超管开通客户管理员，客户管理员维护本客户普通用户。', '/api/users'],
  logs: ['操作日志', '真实操作留痕；超管查看全局，客户管理员查看本客户，普通用户仅查看自己的记录。', '/api/audit-logs'],
  plugins: ['产品插件', '受审的产品声明按产品建表；在平台接入中确认来源映射后由同步任务使用，采样请求不执行任意 DDL。', '/api/plugins']
};
let token = '';
let actor = null;
let route = 'dashboard';
let page = 1;
let query = '';
let roleFilter = '';
let revision = 0;
let saveAction = null;
let editorBusy = false;

function node(tag, text, className) {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = text;
  const classes = {
    'secondary': 'btn btn-ghost btn-sm', 'danger-action': 'btn btn-danger btn-sm',
    'table-scroll': 'table-wrap', 'row-actions': 'panel-actions',
    'empty-state': 'empty', 'plugin-card': 'card card-body panel-card',
    'chart-card': 'card card-body chart', 'grant-card': 'card card-body grant-card',
    'history-toolbar': 'toolbar history-toolbar', 'check': 'check-line'
  };
  if (className) element.className = classes[className] || className;
  if (tag === 'input' || tag === 'textarea') element.classList.add('inp');
  if (tag === 'select') element.classList.add('sel');
  if (tag === 'table') element.classList.add('tbl');
  return element;
}
function checkLabel(label, input) {
  input.classList.remove('inp');
  label.append(input, node('i'));
}
function notify(message) {byId('notice').textContent = message;}
function signedOut(message) {
  token = ''; actor = null; revision++;
  editor.close(); byId('editor-fields').replaceChildren(); byId('content').replaceChildren();
  workspace.hidden = true; byId('entry').hidden = false; login.hidden = false;
  workspace.classList.remove('on', 'mobile-open');
  document.body.classList.remove('logged-in');
  byId('install-entry').hidden = true;
  byId('status').textContent = message;
  if (window.IoT) window.IoT.stop();
  closeCommand();
  byId('notification-list').replaceChildren(); byId('top-notifications').classList.remove('open');
}
async function api(path, options = {}) {
  const requestToken = token;
  const response = await fetch(path, {...options, headers: {
    'Content-Type': 'application/json', ...(requestToken ? {Authorization: 'Bearer ' + requestToken} : {})
  }});
  const data = await response.json();
  if (!response.ok) {
    if (response.status === 401 && requestToken && requestToken === token) signedOut('会话已过期或被撤销，请重新登录。');
    throw new Error(data.detail || '请求失败');
  }
  return data;
}
async function allItems(path) {
  const items = [];
  for (let current = 1; current <= 100; current++) {
    const data = await api(`${path}?page=${current}&page_size=100`);
    items.push(...data.items);
    if (items.length >= data.total) return items;
  }
  throw new Error('数据量过大，请分批使用接口管理。');
}
function action(label, fn, danger = false) {
  const button = node('button', label, danger ? 'danger-action' : 'secondary');
  button.type = 'button';
  button.onclick = async () => {
    button.disabled = true;
    try {await fn();} catch (error) {notify(error.message);}
    finally {button.disabled = false;}
  };
  return button;
}
function canManage(user) {
  return actor.role === 'superadmin' ? user.role === 'admin' : actor.role === 'admin' && user.role === 'user';
}
function labelName(id, names) {return id ? names.get(id) || '已停用或不可见客户' : '未分配';}
function date(value) {return value ? new Date(value + (value.endsWith('Z') ? '' : 'Z')).toLocaleString() : '—';}

function table(headers, rows) {
  const wrapper = node('div', undefined, 'table-scroll');
  const element = node('table');
  const head = node('thead'); const tr = node('tr');
  headers.forEach(title => tr.append(node('th', title)));
  head.append(tr); element.append(head);
  const body = node('tbody');
  for (const cells of rows) {
    const row = node('tr');
    for (const value of cells) {
      const cell = node('td');
      if (value instanceof Node) cell.append(value);
      else cell.textContent = String(value ?? '—');
      row.append(cell);
    }
    body.append(row);
  }
  element.append(body); wrapper.append(element);
  if (!rows.length) wrapper.append(node('p', '暂无记录，请调整筛选或新建数据。', 'empty-state'));
  return wrapper;
}
function buttons(items) {
  const host = node('div', undefined, 'row-actions');
  items.forEach(([label, fn, danger]) => host.append(action(label, fn, danger)));
  return host;
}

async function load() {
  if (!actor) return;
  const version = ++revision;
  const currentRoute = route;
  const [title, description, path] = views[route];
  const collection = ['dashboard', 'products', 'curves', 'scenes', 'dashboards'].includes(route);
  byId('list-card').classList.toggle('card', !collection);
  byId('list-total').parentElement.hidden = collection;
  byId('page-title').textContent = title; byId('page-description').textContent = description;
  const navigation = document.querySelector(`[data-route="${route}"]`);
  const group = navigation?.closest('.nav-group')?.querySelector('.nav-group-t')?.textContent || '系统';
  byId('breadcrumb').replaceChildren(node('span', group, 'c-group'), node('span', '/', 'c-sep'), node('span', title, 'c-cur'));
  document.querySelectorAll('[data-route]').forEach(link => {
    link.classList.toggle('on', link.dataset.route === route);
    if (link.dataset.route === route) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  const create = byId('create-resource');
  create.hidden = !((actor.role === 'superadmin' && ['customers', 'projects'].includes(route)) ||
    (actor.role !== 'user' && route === 'users'));
  create.textContent = route === 'users' ? '新增' + (actor.role === 'superadmin' ? '客户管理员' : '普通用户') : '新建' + (route === 'customers' ? '客户' : '项目');
  byId('role-filter').hidden = route !== 'users';
  byId('search-form').hidden = route === 'plugins';
  byId('search').placeholder = route === 'logs' ? '搜索动作标识，如 user.create' : '搜索名称或登录账号';
  byId('content').replaceChildren(node('p', '正在加载…', 'empty-state'));
  if (window.IoT && window.IoT.routes.includes(route)) {
    create.hidden = true;
    byId('search-form').hidden = true; byId('role-filter').hidden = true;
    return window.IoT.load(version);
  }
  byId('iot-toolbar').hidden = true;
  try {
    if (route === 'dashboard') {
      byId('search-form').hidden = true;
      const [customers, projects, users, logs] = await Promise.all([
        api('/api/customers?page_size=1'), api('/api/projects?page_size=20'),
        api('/api/users?page_size=1'), api('/api/audit-logs?page_size=1')
      ]);
      if (version !== revision || !actor || currentRoute !== route) return;
      const hero = node('div', undefined, 'hero'); const inside = node('div', undefined, 'hero-in');
      const introduction = node('div');
      introduction.append(node('h2', '你好，' + actor.username), node('p', roles[actor.role] + ' · 数据均来自当前授权范围'));
      inside.append(introduction); hero.append(inside);
      const kpis = node('div', undefined, 'grid g4 mt');
      for (const [label, value, symbol] of [['可见客户', customers.total, 'users'], ['授权项目', projects.total, 'folder'],
        ['可见账号', users.total, 'user'], ['操作记录', logs.total, 'list']]) {
        const card = node('div', undefined, 'kpi'); const top = node('div', undefined, 'kpi-top');
        const mark = node('div', undefined, 'kpi-ico'); mark.innerHTML = icon(symbol);
        top.append(node('span', label, 'kpi-label'), mark);
        card.append(top, node('div', String(value), 'kpi-val'), node('div', '当前数据库记录', 'kpi-foot')); kpis.append(card);
      }
      const projectCard = node('section', undefined, 'card mt');
      const head = node('div', undefined, 'card-head'); head.append(node('h3', '授权项目'));
      projectCard.append(head, table(['项目名称', '时区', '操作'], projects.items.map(project => [
        project.name, project.timezone, action('查看项目', () => {location.hash = 'projects';})
      ])));
      byId('content').replaceChildren(hero, kpis, projectCard);
      byId('list-total').textContent = `展示前 ${projects.items.length} 个授权项目`;
      byId('page-previous').hidden = true; byId('page-next').hidden = true; byId('page-number').textContent = '';
      return;
    }
    const params = new URLSearchParams({page, page_size: 20, q: query});
    if (route === 'users' && roleFilter) params.set('role', roleFilter);
    const data = await api(route === 'plugins' ? path : path + '?' + params);
    const customers = ['users', 'projects'].includes(route) ? await allItems('/api/customers') : [];
    if (version !== revision || !actor || currentRoute !== route) return;
    const names = new Map(customers.map(customer => [customer.id, customer.name]));
    if (route === 'plugins') {
      const host = node('div', undefined, 'plugin-grid');
      host.append(action('安装/更新部署目录中的插件', async () => {
        await api('/api/plugins/install', {method: 'POST'}); await load(); notify('插件表与注册信息已更新。');
      }));
      data.forEach(plugin => {
        const card = node('section', undefined, 'plugin-card');
        card.append(node('h3', plugin.manifest.name + ' · v' + plugin.version));
        plugin.manifest.products.forEach(product => {
          card.append(node('p', product.name), node('code', `p_${plugin.id}_${product.id}_devices / _samples`));
        }); host.append(card);
      });
      byId('content').replaceChildren(host);
      byId('list-total').textContent = `${data.length} 个插件`;
      byId('page-number').textContent = ''; byId('page-previous').hidden = true; byId('page-next').hidden = true;
      return;
    }
    let headers, rows;
    if (route === 'customers') {
      headers = ['客户名称', '状态', '创建时间', '操作'];
      rows = data.items.map(customer => [customer.name, customer.enabled ? '正常' : '已停用', date(customer.created_at),
        actor.role === 'superadmin' ? buttons([
          ['编辑', () => editCustomer(customer)],
          ['删除', () => confirmDelete('客户', customer, '/api/customers/' + customer.id), true]
        ]) : '只读']);
    } else if (route === 'projects') {
      headers = ['项目名称', '所属客户', '时区', '可选能力', '操作'];
      rows = data.items.map(project => [project.name, labelName(project.customer_id, names), project.timezone,
        project.capabilities.map(cap => caps[cap] || cap).join('、') || '基础查询',
        actor.role === 'superadmin' ? buttons([
          ['编辑', () => editProject(project)], ['分配客户', () => assignProject(project)],
          ['删除', () => confirmDelete('项目', project, '/api/projects/' + project.id), true]
        ]) : '只读']);
    } else if (route === 'users') {
      headers = ['登录账号', '固定角色', '所属客户', '状态', '操作'];
      rows = data.items.map(user => [user.username, roles[user.role], labelName(user.customer_id, names), user.enabled ? '正常' : '已停用',
        buttons([
          ['查看授权', () => showGrants(user)],
          ...(canManage(user) ? [['编辑/重置密码', () => editUser(user)], ['项目授权', () => editGrants(user)]] : [])
        ])]);
    } else {
      headers = ['时间', '操作者', '动作', '操作详情'];
      rows = data.items.map(log => [date(log.created_at), log.actor_username || '系统', log.action,
        action('查看', () => details('日志详情', [
          ['动作', log.action], ['操作者', log.actor_username || '系统'], ['时间', date(log.created_at)],
          ['脱敏记录', JSON.stringify(log.detail, null, 2)]
        ]))]);
    }
    byId('content').replaceChildren(table(headers, rows));
    byId('list-total').textContent = `共 ${data.total} 条`;
    byId('page-number').textContent = `第 ${page} 页`;
    byId('page-previous').hidden = false; byId('page-next').hidden = false;
    byId('page-previous').disabled = page <= 1;
    byId('page-next').disabled = page * 20 >= data.total;
  } catch (error) {
    if (version !== revision) return;
    byId('content').replaceChildren(node('p', error.message, 'empty-state'));
    byId('list-total').textContent = ''; byId('page-number').textContent = '';
    byId('page-previous').disabled = true; byId('page-next').disabled = true;
    notify(error.message);
  }
}

function field(name, title, value = '', options = {}) {
  const group = node('div', undefined, 'form-field');
  const label = node('label', title);
  const input = node('input');
  input.name = name; input.type = options.type || 'text'; input.value = value;
  Object.entries(options).forEach(([key, val]) => {input[key] = val;});
  input.id = 'field-' + name; label.htmlFor = input.id;
  group.append(label, input); byId('editor-fields').append(group);
  return input;
}
function selectField(name, title, choices, value) {
  const group = node('div', undefined, 'form-field');
  const label = node('label', title); const select = node('select'); select.name = name;
  choices.forEach(([key, text]) => {
    const option = node('option', text); option.value = key; select.append(option);
  });
  select.value = value || ''; select.id = 'field-' + name; label.htmlFor = select.id;
  group.append(label, select); byId('editor-fields').append(group);
  return select;
}
function hint(text) {byId('editor-fields').append(node('p', text, 'hint'));}
function openEditor(title, action) {
  const drawer = ['products', 'sync', 'scenes', 'curves', 'dashboards'].includes(route) && !title.startsWith('删除');
  editor.className = drawer ? 'drawer' : 'modal';
  editor.querySelector(':scope > div:first-child').className = drawer ? 'drawer-head' : 'modal-head';
  editorForm.className = drawer ? 'drawer-body' : 'modal-body';
  editor.querySelector(':scope > div:last-child').className = drawer ? 'drawer-foot' : 'modal-foot';
  byId('editor-title').textContent = title; byId('editor-fields').replaceChildren();
  byId('editor-error').textContent = ''; byId('save-editor').hidden = !action;
  byId('save-editor').textContent = '保存';
  byId('save-editor').disabled = false; saveAction = action;
  if (!editor.open) editor.showModal();
}
function details(title, values) {
  openEditor(title, null);
  values.forEach(([label, value]) => {
    byId('editor-fields').append(node('h3', label), node('pre', value));
  });
}
function formValue(name) {return editorForm.elements[name].value;}
function enabledValue() {return formValue('enabled') === 'true';}
function statusField(value = true) {selectField('enabled', '状态', [['true', '正常'], ['false', '已停用']], String(value));}

function editCustomer(customer) {
  openEditor(customer ? '编辑客户' : '新建客户', async () => {
    await api('/api/customers' + (customer ? '/' + customer.id : ''), {
      method: customer ? 'PUT' : 'POST', body: JSON.stringify({name: formValue('name'), enabled: enabledValue()})
    });
  });
  field('name', '客户名称', customer?.name, {required: true, maxLength: 100});
  statusField(customer?.enabled ?? true);
  hint('停用客户立即撤销其账号会话，保留项目和授权记录；重新启用后需重新登录。');
}
function editProject(project) {
  openEditor(project ? '编辑项目' : '新建项目', async () => {
    await api('/api/projects' + (project ? '/' + project.id : ''), {method: project ? 'PUT' : 'POST',
      body: JSON.stringify({name: formValue('name'), timezone: formValue('timezone')})});
  });
  field('name', '项目名称', project?.name, {required: true, maxLength: 100});
  field('timezone', 'IANA 时区', project?.timezone || 'Asia/Shanghai', {required: true, maxLength: 64});
  hint('新建项目默认未分配，仅超管可见。先分配客户，再为客户管理员分配项目授权。');
}
async function assignProject(project) {
  const customers = await allItems('/api/customers');
  openEditor('分配客户 · ' + project.name, async () => {
    await api('/api/projects/' + project.id + '/assignment', {method: 'PUT',
      body: JSON.stringify({customer_id: formValue('customer_id') || null})});
  });
  selectField('customer_id', '所属客户', [['', '未分配（收回项目）'], ...customers.filter(c => c.enabled || c.id === project.customer_id).map(c => [c.id, c.name])], project.customer_id);
  hint('转移客户或收回项目会立即清除该项目的全部用户授权；选择相同客户不会清除。之后请为新客户管理员重新授权。');
}
async function editUser(user) {
  const customers = actor.role === 'superadmin' && !user ? await allItems('/api/customers') : [];
  openEditor(user ? '编辑账号 · ' + user.username : '新增' + (actor.role === 'superadmin' ? '客户管理员' : '普通用户'), async () => {
    const password = formValue('password');
    const data = {enabled: enabledValue(), ...(password ? {password} : {})};
    if (!user) {
      data.username = formValue('username');
      data.customer_id = actor.role === 'superadmin' ? formValue('customer_id') : actor.customer_id;
    }
    await api('/api/users' + (user ? '/' + user.id : ''), {method: user ? 'PUT' : 'POST', body: JSON.stringify(data)});
  });
  field('username', '登录账号', user?.username, {required: true, readOnly: !!user, maxLength: 80, pattern: '[a-zA-Z][a-zA-Z0-9_.\\-]{2,79}'});
  if (actor.role === 'superadmin' && !user) {
    selectField('customer_id', '所属客户', customers.filter(c => c.enabled).map(c => [c.id, c.name]), customers.find(c => c.enabled)?.id);
    editorForm.elements.customer_id.required = true;
  }
  hint('角色与客户归属固定，不可在编辑中变更。' + (actor.role === 'superadmin' ? '超管只能维护客户管理员。' : '客户管理员只能维护本客户普通用户。'));
  field('password', user ? '重置密码（留空不修改）' : '初始密码', '', {type: 'password', required: !user, minLength: 12, maxLength: 128, autocomplete: 'new-password'});
  statusField(user?.enabled ?? true);
  hint('重置密码或停用账号立即撤销其会话，不会撤销其曾经给其他用户分配的合法授权。');
}
async function showGrants(user) {
  const [grants, projects] = await Promise.all([api('/api/users/' + user.id + '/grants'), allItems('/api/projects')]);
  const names = new Map(projects.map(p => [p.id, p.name]));
  details('项目授权 · ' + user.username, user.role === 'superadmin' ? [['权限', '超管具有全局项目范围']] :
    grants.length ? grants.map(g => [names.get(g.project_id) || '已有授权（当前不可管理）',
      g.capabilities.map(cap => caps[cap]).join('、') || '基础查询']) : [['权限', '未分配项目']]);
}
async function editGrants(user) {
  const [projects, grants] = await Promise.all([allItems('/api/projects'), api('/api/users/' + user.id + '/grants')]);
  const choices = projects.filter(project => project.customer_id === user.customer_id);
  if (choices.length > 200) throw new Error('单次授权最多 200 个项目，请先收紧管理员的项目范围。');
  const prior = new Map(grants.map(grant => [grant.project_id, grant]));
  const groups = [];
  openEditor('项目授权 · ' + user.username, async () => {
    const selected = groups.filter(group => group.selected.checked).map(group => ({
      project_id: group.project.id, capabilities: group.checks.filter(check => check.checked).map(check => check.value)
    }));
    await api('/api/users/' + user.id + '/grants', {method: 'PUT', body: JSON.stringify({grants: selected})});
  });
  hint('选中项目即允许基础查询；可选能力只能在角色上限内授予，未在本页范围内的已有授权原样保留。');
  choices.forEach(project => {
    const group = node('div', undefined, 'grant-card');
    const selected = node('input'); selected.type = 'checkbox'; selected.checked = prior.has(project.id);
    const title = node('label', undefined, 'check'); checkLabel(title, selected); title.append(node('b', project.name)); group.append(title);
    const checks = [];
    Object.entries(caps).forEach(([key, title]) => {
      if (actor.role !== 'superadmin' && (!['export', 'report'].includes(key) || !project.capabilities.includes(key))) return;
      const check = node('input'); check.type = 'checkbox'; check.value = key; check.checked = !!prior.get(project.id)?.capabilities.includes(key);
      const label = node('label', undefined, 'check'); checkLabel(label, check); label.append(node('span', title)); group.append(label); checks.push(check);
    });
    const sync = () => checks.forEach(check => check.disabled = !selected.checked);
    selected.onchange = sync; sync();
    byId('editor-fields').append(group); groups.push({project, selected, checks});
  });
  if (!choices.length) hint('没有可分配项目。超管需先将项目分配给客户，再给管理员授权。');
  grants.filter(g => !choices.some(p => p.id === g.project_id)).forEach(() => hint('保留一项当前管理员无权修改的已有项目授权。'));
}
function confirmDelete(title, resource, path) {
  openEditor('删除' + title, async () => {await api(path, {method: 'DELETE'});});
  hint('确认删除“' + resource.name + '”？仍有关联数据时系统拒绝删除，不会级联清空业务数据。');
  byId('save-editor').textContent = '确认删除';
}
function passwordEditor() {
  openEditor('修改我的密码', async () => {
    await api('/api/me/password', {method: 'PUT', body: JSON.stringify({
      current_password: formValue('current_password'), new_password: formValue('new_password')
    })});
    signedOut('密码已修改，原有会话已撤销，请使用新密码重新登录。');
  });
  field('current_password', '当前密码', '', {type: 'password', required: true, maxLength: 128, autocomplete: 'current-password'});
  field('new_password', '新密码（至少 12 字符）', '', {type: 'password', required: true, minLength: 12, maxLength: 128, autocomplete: 'new-password'});
}
function closeEditor() {
  if (editorBusy) return;
  editor.close(); byId('editor-fields').replaceChildren(); saveAction = null;
}
editor.addEventListener('cancel', event => {
  if (editorBusy) event.preventDefault();
  else closeEditor();
});
byId('close-editor').onclick = closeEditor; byId('cancel-editor').onclick = closeEditor;
editorForm.onsubmit = async event => {
  event.preventDefault();
  if (editorBusy || !saveAction || !editorForm.reportValidity()) return;
  editorBusy = true;
  editor.querySelectorAll('button').forEach(button => button.disabled = true);
  byId('editor-error').textContent = '';
  try {
    await saveAction();
    editor.close(); byId('editor-fields').replaceChildren();
    if (actor) {await load(); notify('操作已保存到数据库。');}
  } catch (error) {byId('editor-error').textContent = error.message;}
  finally {
    editorBusy = false;
    editor.querySelectorAll('button').forEach(button => button.disabled = false);
    byId('save-editor').textContent = '保存';
  }
};
byId('create-resource').onclick = async () => {
  try {
    byId('save-editor').textContent = '保存';
    if (route === 'customers') editCustomer();
    else if (route === 'projects') editProject();
    else if (route === 'users') await editUser();
  } catch (error) {notify(error.message);}
};
byId('search-form').onsubmit = event => {
  event.preventDefault(); query = byId('search').value.trim(); roleFilter = byId('role-filter').value; page = 1; load();
};
byId('refresh-list').onclick = () => load();
byId('top-refresh').onclick = () => load();
let commandItems = [];
let commandRevision = 0;
function closeCommand() {
  commandRevision++;
  byId('command-search').hidden = true; byId('command-search').classList.remove('open');
  byId('command-query').value = ''; byId('command-results').replaceChildren(); commandItems = [];
  workspace.inert = false;
}
function paintCommand() {
  const host = byId('command-results'); host.replaceChildren();
  const term = byId('command-query').value.trim().toLowerCase();
  for (const item of commandItems.filter(item => item.label.toLowerCase().includes(term)).slice(0, 50)) {
    const button = node('div', undefined, 'cm-item');
    button.setAttribute('role', 'button'); button.tabIndex = 0;
    const mark = node('span', undefined, 'cm-ico'); mark.innerHTML = icon(item.icon);
    button.append(mark, node('span', item.label), node('span', item.group, 'cm-sub'));
    button.onclick = async () => {
      closeCommand();
      route = item.route; page = 1; queryReset();
      if (item.query) {query = item.query; byId('search').value = item.query;}
      history.replaceState(null, '', '#' + route); await load();
      if (item.device && actor) details('设备详情', [['档案', JSON.stringify(item.device, null, 2)]]);
    };
    button.onkeydown = event => {if (event.key === 'Enter' || event.key === ' ') {event.preventDefault(); button.click();}};
    host.append(button);
  }
  if (!host.children.length) host.append(node('div', '没有匹配结果', 'empty'));
}
function queryReset() {query = ''; roleFilter = ''; byId('search').value = ''; byId('role-filter').value = '';}
async function openCommand() {
  if (!actor) return;
  const version = ++commandRevision;
  commandItems = Object.keys(views).filter(key => key !== 'plugins' || actor.role === 'superadmin').map(key => ({
    label: views[key][0], route: key, group: '页面', icon: 'grid'
  }));
  byId('command-search').hidden = false; byId('command-search').classList.add('open');
  workspace.inert = true; paintCommand(); byId('command-query').focus();
  try {
    const [customers, projects] = await Promise.all([allItems('/api/customers'), allItems('/api/projects')]);
    if (version !== commandRevision || !actor) return;
    commandItems.push(...customers.map(item => ({label: item.name, route: 'customers', query: item.name, group: '客户', icon: 'users'})),
      ...projects.map(item => ({label: item.name, route: 'projects', query: item.name, group: '项目', icon: 'folder'})));
    const projectId = window.IoT?.project();
    if (projectId) {
      const devices = await api('/api/devices?project_id=' + encodeURIComponent(projectId));
      if (version !== commandRevision || !actor) return;
      commandItems.push(...devices.map(item => ({label: item.name || item.external_id, route: 'devices', group: '设备', icon: 'cpu', device: item})));
    }
    paintCommand();
  } catch (error) {
    if (version === commandRevision) byId('command-results').append(node('p', error.message, 'hint'));
  }
}
byId('top-search').onclick = openCommand;
byId('command-query').oninput = paintCommand;
byId('command-search').onclick = event => {if (event.target === byId('command-search')) closeCommand();};
byId('command-search').addEventListener('keydown', event => {
  if (event.key === 'Escape') {closeCommand(); byId('top-search').focus();}
  if (event.key === 'Tab') {
    const controls = [...byId('command-search').querySelectorAll('input,[role="button"]')];
    const first = controls[0], last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) {event.preventDefault(); last.focus();}
    else if (!event.shiftKey && document.activeElement === last) {event.preventDefault(); first.focus();}
  }
});
window.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && actor) {event.preventDefault(); openCommand();}
});
byId('notification-toggle').onclick = async () => {
  const requestToken = token;
  const host = byId('notification-list');
  byId('top-notifications').classList.toggle('open');
  if (!byId('top-notifications').classList.contains('open')) return;
  host.replaceChildren(node('div', '当前项目通知', 'notify-head'));
  const projectId = window.IoT?.project();
  if (!projectId) {host.append(node('p', '请先在数据应用页面选择项目。', 'hint')); return;}
  try {
    const events = await api('/api/alarm-events?project_id=' + encodeURIComponent(projectId));
    if (!actor || token !== requestToken) return;
    for (const item of events.flatMap(event => event.notifications.map(notification => ({event, notification}))).slice(0, 20)) {
      const button = node('button', undefined, 'notify-item'); button.type = 'button';
      const body = node('div', undefined, 'ni-body');
      body.append(node('b', item.notification.message), node('small', date(item.notification.created_at)));
      button.append(body); button.onclick = () => {
        byId('top-notifications').classList.remove('open'); location.hash = 'alarms';
      };
      host.append(button);
    }
    if (host.children.length === 1) host.append(node('p', '暂无通知记录。', 'hint'));
  } catch (error) {host.append(node('p', error.message, 'hint'));}
};
byId('page-previous').onclick = () => {if (page > 1) {page--; load();}};
byId('page-next').onclick = () => {page++; load();};
byId('change-password').onclick = passwordEditor;
window.addEventListener('hashchange', () => {
  if (!actor) return;
  route = location.hash.slice(1);
  if (!views[route] || (route === 'plugins' && actor.role !== 'superadmin')) route = 'dashboard';
  page = 1; query = ''; roleFilter = ''; byId('search').value = ''; byId('role-filter').value = '';
  closeEditor(); notify(''); load();
});
api('/api/install/status').then(data => {
  byId('status').textContent = data.installed ? '平台已安装，请登录。' : '尚未安装。';
  byId('install-link').hidden = data.installed; login.hidden = !data.installed;
  byId('install-entry').hidden = data.installed;
}).catch(error => {
  byId('entry-error').textContent = error.message; byId('install-entry').hidden = false;
});
login.onsubmit = async event => {
  event.preventDefault();
  const button = byId('login-submit'); button.disabled = true;
  try {
    const data = await api('/api/auth/login', {method: 'POST', body: JSON.stringify({
      username: login.elements.username.value, password: login.elements.password.value
    })});
    token = data.access_token; actor = await api('/api/me'); login.reset();
    byId('user').textContent = actor.username;
    byId('user-role').textContent = roles[actor.role];
    byId('user-avatar').textContent = actor.role === 'user' ? '用' : '管';
    byId('plugins-link').hidden = actor.role !== 'superadmin';
    byId('entry').hidden = true; workspace.hidden = false; byId('chat-toggle').hidden = false;
    workspace.classList.add('on'); document.body.classList.add('logged-in'); syncMenu();
    route = location.hash.slice(1);
    if (!views[route] || (route === 'plugins' && actor.role !== 'superadmin')) route = 'dashboard';
    page = 1; query = ''; roleFilter = ''; notify(''); await load();
  } catch (error) {signedOut(error.message);}
  finally {button.disabled = false;}
};
byId('logout').onclick = async () => {
  try {await api('/api/auth/logout', {method: 'POST'}); signedOut('已退出，会话已撤销。');}
  catch (error) {notify(error.message);}
};
