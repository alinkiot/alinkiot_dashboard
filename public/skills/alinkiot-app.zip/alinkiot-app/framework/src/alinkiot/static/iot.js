(() => {
  const specifications = {
    connections: ['平台接入', '按项目接入设备平台/智能体平台。模拟默认 URL http://127.0.0.1:58240，AppID demo，Secret demo-only。', '/api/connections'],
    products: ['产品管理', '产品字段来自受审插件；来源 schema 需确认映射，采样同步不执行任意 DDL。', '/api/products'],
    devices: ['设备档案', '来源档案与本地扩展分开保存，重新同步不会覆盖本地维护信息。', '/api/devices'],
    realtime: ['实时查询', '每 10 秒读取最新落库采样；不是直接把外部平台响应当作持久化结果。', '/api/telemetry'],
    history: ['历史查询', '读取 MySQL 中的原始/计算值、质量、公式版本和单位；默认近 24 小时。', '/api/telemetry'],
    formulas: ['公式配置', '受限算术表达式，变量 value 和数值参数；每次保存生成不可变版本。', '/api/formulas'],
    sync: ['同步任务', '选择来源、已绑定产品与公式，独立 worker 执行，成功落库后才推进游标。', '/api/tasks'],
    reports: ['报表中心', '定时/手动生成采样 CSV 报表，下载重新鉴权；执行需要独立 worker。', '/api/reports'],
    'ai-report': ['智能报表', '新建任务，通过 HTTP 数字人生成带采样证据的新报表；模拟答案明确标记。', '/api/tasks'],
    'ai-warning': ['智能预警', '定时分析指定设备窗口；布尔预警结果经服务端校验后写入告警事件。', '/api/tasks'],
    diagnosis: ['智能诊断', '通过接入平台 HTTP 问答，参数含 agent。点击右下角助手可继续提问。', '/api/agent/conversations'],
    analysis: ['智能分析', '基于当前项目最新落库数据发起固定分析要求，结果与证据数量持久化。', '/api/agent/conversations'],
    alarms: ['告警事件', '设备规则/智能预警来源分开，处理记录与通知记录放在事件中。通知仅平台内留存。', '/api/alarm-events'],
    rules: ['告警规则', '配置数值阈值，同步落库后评估触发/恢复，处理状态不改变检测状态。', '/api/alarm-rules'],
    scenes: ['场景管理', '按项目关联现场设备，保存配置；设备定位采用离线示意，不冒充在线地图。', '/api/panels'],
    curves: ['曲线管理', '卡片进入当前页详情，关联不同设备属性；各系列按自己的单位绘制。', '/api/panels'],
    dashboards: ['项目大屏', '保存各项目独立布局与数据系列，卡片进入详情，不自动展示第一个大屏。', '/api/panels']
  };
  Object.assign(views, specifications);
  const kinds = {sync: 'sync', reports: 'report', 'ai-report': 'ai_report', 'ai-warning': 'ai_warning'};
  const panelKinds = {scenes: 'scene', curves: 'curve', dashboards: 'dashboard'};
  let projectId = '';
  let timer = null;
  let selectedPanel = null;
  let panelCleanup = null;
  const chartHosts = new Set();
  const project = () => projectId;
  const values = name => editorForm.elements[name].value;
  const scope = path => path + '?project_id=' + encodeURIComponent(projectId);
  const write = (path, payload, method = 'POST') => api(path, {method, body: JSON.stringify(payload)});
  const detail = (title, value) => details(title, [['内容', JSON.stringify(value, null, 2)]]);

  function stopTimer() {if (timer) clearTimeout(timer); timer = null;}
  function cleanupPanel() {
    if (panelCleanup) panelCleanup(); panelCleanup = null;
    chartHosts.forEach(host => Charts.remove(host)); chartHosts.clear();
  }
  function stop() {
    stopTimer(); cleanupPanel(); selectedPanel = null;
    byId('chat-toggle').hidden = true; byId('chat-window').hidden = true;
    byId('chat-messages').replaceChildren(); byId('chat-prompt').value = '';
  }
  async function projectOptions() {
    const projects = await allItems('/api/projects');
    const selector = byId('iot-project');
    selector.replaceChildren();
    projects.forEach(item => {const option = node('option', item.name); option.value = item.id; selector.append(option);});
    if (!projects.some(item => item.id === projectId)) projectId = projects[0]?.id || '';
    selector.value = projectId;
    return projects;
  }
  async function loadIoT(version) {
    stopTimer(); cleanupPanel();
    byId('iot-toolbar').hidden = false;
    byId('page-previous').hidden = true; byId('page-next').hidden = true; byId('page-number').textContent = '';
    const requested = route;
    try {
      const projects = await projectOptions();
      if (version !== revision || requested !== route || !actor) return;
      byId('iot-create').hidden = !projectId || (actor.role === 'user' && !['curves', 'reports', 'ai-report', 'diagnosis', 'analysis'].includes(route));
      byId('iot-create').textContent = ['diagnosis', 'analysis'].includes(route) ? '开始分析' : '新建';
      if (!projects.length) {
        byId('content').replaceChildren(node('p', '暂无获授权项目。超管先新建项目，客户账号请联系管理员分配项目。', 'empty-state'));
        byId('list-total').textContent = '';
        return;
      }
      let path = specifications[route][2];
      const currentProject = projectId;
      if (route !== 'products') path = scope(path);
      if (route === 'realtime') path += '&latest=true';
      const data = await api(path);
      if (version !== revision || requested !== route || currentProject !== projectId || !actor) return;
      byId('content').replaceChildren();
      if (route === 'realtime' || route === 'history') {
        byId('content').append(telemetryTable(data.items));
        byId('list-total').textContent = `${data.items.length} 条采样${data.truncated ? ' · 已达上限，请收紧查询范围' : ''}`;
        if (route === 'history') historyControls();
        else timer = setTimeout(() => {if (actor && route === 'realtime') load();}, 10000);
        return;
      }
      let items = data;
      if (kinds[route] && route !== 'reports') items = data.filter(task => task.kind === kinds[route]);
      if (panelKinds[route]) {
        items = data.filter(panel => panel.kind === panelKinds[route]);
        if (selectedPanel) selectedPanel = items.find(panel => panel.id === selectedPanel.id) || null;
        if (selectedPanel) await panelDetail(selectedPanel);
        else panelCards(items);
      } else renderRows(items);
      if (route === 'reports') {
        const tasks = (await api(scope('/api/tasks'))).filter(task => task.kind === 'report');
        byId('content').append(node('h2', '统计报表任务'), table(['任务', '周期', '状态', '操作'],
          tasks.map(task => [task.name, task.interval_minutes + ' 分钟', task.enabled ? '启用' : '停用', taskButtons(task)])));
      }
      byId('list-total').textContent = `${items.length} 条记录（最多显示 200 条）`;
    } catch (error) {
      if (version !== revision) return;
      byId('content').replaceChildren(node('p', error.message, 'empty-state')); notify(error.message);
    }
  }

  function telemetryTable(items) {
    return table(['设备', '采样时间', '计算值与单位', '质量', '证据'], items.map(row => [
      row.external_id, row.time, Object.entries(row.values).map(([key, value]) => `${key}: ${value ?? '—'} ${row.units[key]}`).join(' / '),
      row.quality, action('原始值/公式版本', () => detail('采样证据', row))
    ]));
  }
  function historyControls() {
    const toolbar = node('form', undefined, 'history-toolbar');
    const start = node('input'); start.type = 'datetime-local'; start.setAttribute('aria-label', '开始时间');
    const end = node('input'); end.type = 'datetime-local'; end.setAttribute('aria-label', '结束时间');
    const submit = node('button', '查询范围'); submit.type = 'submit';
    const analysis = action('智能分析', () => chat('请分析当前项目采样趋势、异常和数据质量，并列出证据及不确定性。'));
    toolbar.append(start, end, submit, analysis);
    toolbar.onsubmit = async event => {
      event.preventDefault(); submit.disabled = true;
      try {
        const params = new URLSearchParams({project_id: projectId});
        if (start.value) params.set('start', new Date(start.value).toISOString());
        if (end.value) params.set('end', new Date(end.value).toISOString());
        const data = await api('/api/telemetry?' + params);
        byId('content').replaceChildren(toolbar, telemetryTable(data.items));
        byId('list-total').textContent = `${data.items.length} 条采样${data.truncated ? ' · 范围超限' : ''}`;
      } catch (error) {notify(error.message);}
      finally {submit.disabled = false;}
    };
    byId('content').prepend(toolbar);
  }

  function renderRows(items) {
    let headers, rows;
    if (route === 'connections') {
      headers = ['名称/类型', '平台地址', '数字人/产品', '操作'];
      rows = items.map(source => [source.name + ' · ' + source.kind, source.url,
        source.catalog.map(item => item.name + (item.available === false ? '（下架）' : '')).join('、'),
        buttons([['详情', () => detail('接入详情（不含 Secret）', source)],
          ...(actor.role !== 'user' ? [
            ['更新列表', async () => {await write('/api/connections/' + source.id + '/refresh'); await load();}],
            ['编辑接入', () => connectionEditor(source)],
            ...(source.kind === 'agent' ? [['选择数字人', () => agentSelection(source)]] :
              actor.role === 'superadmin' ? [['绑定产品表', () => bindProduct(source)]] : [])
          ] : [])])]);
    } else if (route === 'products') {
      byId('iot-create').hidden = true;
      const host = node('div', undefined, 'panel-grid');
      for (const product of items) {
        const card = node('article', undefined, 'card panel-card');
        const body = node('div', undefined, 'card-body');
        body.append(node('h3', product.name), node('p', `${product.plugin_id} · v${product.schema_version} · ${product.definition.metrics.length} 个采样属性`, 'hint'),
          buttons([['查看属性', () => {
            openEditor('查看属性 · ' + product.name, null);
            hint('来自受审产品插件，属性只读；不会从浏览器任意建表。');
            byId('editor-fields').append(table(['标识', '类型', '单位', '类别'], [
              ...product.definition.archive_fields.map(field => [field.name, field.type, field.unit || '—', '档案']),
              ...product.definition.metrics.map(field => [field.name, field.type, field.unit || '—', '采样'])
            ]));
          }]]));
        card.append(body); host.append(card);
      }
      if (!items.length) host.append(node('p', '暂无产品，请安装受审产品插件。', 'empty-state'));
      byId('content').append(host);
      return;
    } else if (route === 'devices') {
      headers = ['设备名称', '外部标识', '位置', '操作'];
      rows = items.map(device => [device.name || device.external_id, device.external_id, device.location || '未设置',
        buttons([['详情', () => detail('档案：来源与本地扩展', device)],
          ...(actor.role !== 'user' ? [['编辑扩展', () => editDevice(device)]] : [])])]);
      byId('iot-create').hidden = true;
    } else if (route === 'formulas') {
      headers = ['公式名称', '版本', '表达式', '输出单位', '操作'];
      rows = items.map(formula => [formula.name, formula.version, formula.expression, formula.unit,
        buttons([['查看参数', () => detail('不可变公式版本', formula)],
          ...(actor.role !== 'user' ? [['新建版本', () => formulaEditor(formula)]] : [])])]);
    } else if (kinds[route] && route !== 'reports') {
      headers = ['任务', '周期', '启用状态', '操作'];
      rows = items.map(task => [task.name, task.interval_minutes + ' 分钟', task.enabled ? '已启用（需 worker）' : '未启用',
        taskButtons(task)]);
    } else if (route === 'reports') {
      headers = ['报表名称', '类型', '生成时间', '操作'];
      rows = items.map(report => [report.name, report.kind, date(report.created_at),
        buttons([['查看证据', () => detail('报表内容', report.content)], ['下载 CSV', () => download(report.id)]])]);
    } else if (route === 'rules') {
      headers = ['规则', '指标/阈值', '等级', '状态', '操作'];
      rows = items.map(rule => [rule.name, rule.operator === 'offline' ? '离线超时 ' + rule.threshold + ' 分钟' : rule.metric + (rule.operator === 'gt' ? ' > ' : ' < ') + rule.threshold,
        rule.level, rule.enabled ? '启用' : '停用', actor.role !== 'user' ? action(rule.enabled ? '停用' : '启用',
          async () => {
            await write('/api/alarm-rules/' + rule.id, {project_id: rule.project_id, name: rule.name,
              device_id: rule.device_id, metric: rule.metric, operator: rule.operator, threshold: Number(rule.threshold),
              level: rule.level, enabled: !rule.enabled}, 'PUT'); await load();
          }) : '只读']);
    } else if (route === 'alarms') {
      headers = ['事件', '来源', '等级', '检测/处理', '操作'];
      rows = items.map(event => [event.name, event.source === 'intelligent_warning' ? '智能预警' : '设备规则', event.level,
        (event.active ? '异常' : '已恢复') + ' · ' + (event.handled ? '已处理' : '待处理'),
        buttons([['证据/通知记录', () => detail('事件与通知记录', event)],
          ...(actor.role !== 'user' ? [['确认处理', () => handleEvent(event)]] : [])])]);
      byId('iot-create').hidden = true;
    } else {
      headers = ['时间', '数字人', '提问', '回答'];
      rows = items.map(item => [date(item.created_at), item.agent, item.prompt,
        action(item.answer.simulated ? '查看模拟回答' : '查看回答', () => detail('智能体结果', item.answer))]);
    }
    byId('content').append(table(headers, rows));
  }
  function taskButtons(task) {
    return buttons([
      ['配置', () => detail('任务配置（绑定固定公式版本）', task)],
      ['执行一次', async () => {
        const run = await write('/api/tasks/' + task.id + '/run');
        notify('已入队 ' + run.id + '，请运行 alinkiot worker；此处不是已执行成功。');
      }],
      ['执行记录', async () => detail('任务执行记录', await api('/api/tasks/' + task.id + '/runs'))],
      ...(actor.role !== 'user' ? [['编辑任务', () => taskEditor(task)]] : []),
      ...(actor.role !== 'user' ? [[task.enabled ? '停用' : '启用', async () => {
        await write('/api/tasks/' + task.id, {project_id: task.project_id, kind: task.kind, name: task.name,
          interval_minutes: task.interval_minutes, enabled: !task.enabled, config: task.config}, 'PUT'); await load();
      }]] : [])
    ]);
  }
  async function download(id) {
    const response = await fetch('/api/reports/' + id + '/download', {headers: {Authorization: 'Bearer ' + token}});
    if (!response.ok) throw new Error((await response.json()).detail);
    const url = URL.createObjectURL(await response.blob());
    const link = node('a'); link.href = url; link.download = 'report.csv'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function inputChoices(name, title, options, selected = []) {
    const container = node('fieldset'); container.append(node('legend', title));
    for (const [value, labelText] of options) {
      const label = node('label', undefined, 'check'); const input = node('input');
      input.type = 'checkbox'; input.name = name; input.value = value; input.checked = selected.includes(value);
      checkLabel(label, input); label.append(node('span', labelText)); container.append(label);
    }
    byId('editor-fields').append(container);
  }
  function chosen(name) {return [...editorForm.querySelectorAll(`[name="${name}"]:checked`)].map(input => input.value);}
  function connectionEditor(source) {
    openEditor(source ? '编辑平台接入（需重新输入 Secret）' : '新增项目平台接入', async () => {
      await write('/api/connections' + (source ? '/' + source.id : ''), {project_id: projectId, kind: values('kind'), name: values('name'),
        url: values('url'), appid: values('appid'), secret: values('secret')}, source ? 'PUT' : 'POST');
    });
    field('name', '名称', source?.name, {required: true, maxLength: 100});
    selectField('kind', '类型', [['source', '设备数据平台'], ['agent', '智能体平台']], source?.kind || 'source').disabled = !!source;
    field('url', 'URL', source?.url || 'http://127.0.0.1:58240', {required: true});
    field('appid', 'AppID', source?.appid || 'demo', {required: true, maxLength: 100});
    field('secret', 'Secret', '', {type: 'password', required: true, maxLength: 1000, autocomplete: 'off'});
    hint('模拟服务命令：alinkiot mock；演示 Secret 为 demo-only，生产凭证只存服务端。URL 必须加入部署白名单。接入成功自动同步列表。');
  }
  function agentSelection(source) {
    openEditor('选择数字人', () => write('/api/connections/' + source.id + '/agent', {agent: values('agent')}, 'PUT'));
    selectField('agent', '数字人', source.catalog.filter(item => item.available !== false).map(item => [item.id, item.name]), source.selected_agent);
  }
  async function bindProduct(source) {
    const products = await api('/api/products');
    openEditor('确认来源产品与受审表映射', () => write('/api/connections/' + source.id + '/products', {
      external_id: values('external_id'), product_id: values('product_id')
    }));
    selectField('external_id', '来源产品', source.catalog.map(p => [p.id, p.name]), source.catalog[0]?.id);
    selectField('product_id', '已安装产品 schema', products.map(p => [p.id, p.name]), products[0]?.id);
    hint('字段结构不一致会拒绝绑定，需先生成和安装受审插件。同步运行时不会自动改 schema。');
  }
  function formulaEditor(formula) {
    openEditor('新建公式版本', () => write('/api/formulas', {project_id: projectId, name: values('name'),
      expression: values('expression'), parameters: JSON.parse(values('parameters')), unit: values('unit'),
      ...(formula ? {family_id: formula.family_id} : {})}));
    field('name', '公式名称', formula?.name, {required: true});
    field('expression', '算术表达式', formula?.expression || 'value / factor', {required: true, maxLength: 300});
    field('parameters', '数值参数 JSON', formula ? JSON.stringify(formula.parameters) : '{"factor":10}', {required: true});
    field('unit', '输出单位', formula?.unit || 'm³/h', {maxLength: 20});
    hint('只允许 + - * / % 与 value/参数，不允许函数调用、属性访问、幂运算或执行代码。重试从原始值计算，不重复套公式。');
  }
  async function taskEditor(task) {
    const kind = task?.kind || kinds[route];
    const [connections, devices, formulas] = await Promise.all([
      api(scope('/api/connections')), api(scope('/api/devices')), api(scope('/api/formulas'))
    ]);
    const sources = connections.filter(c => c.kind === (kind === 'sync' ? 'source' : 'agent'));
    openEditor((task ? '编辑' : '新建') + views[route][0] + '任务', async () => {
      const config = {window_minutes: Number(values('window_minutes')), device_ids: chosen('devices'),
        prompt: editorForm.elements.prompt?.value || '', level: editorForm.elements.level?.value || 'medium'};
      if (kind !== 'report') config.connection_id = values('connection_id');
      if (kind === 'sync') {
        config.products = chosen('products');
        config.formulas = [...editorForm.querySelectorAll('[data-formula]')].filter(input => input.value).map(input => ({
          product: input.dataset.product, metric: input.dataset.metric, formula_id: input.value
        }));
      }
      await write('/api/tasks' + (task ? '/' + task.id : ''), {project_id: projectId, kind, name: values('name'),
        interval_minutes: Number(values('interval_minutes')), enabled: task?.enabled || false, config}, task ? 'PUT' : 'POST');
    });
    field('name', '任务名称', task?.name, {required: true, maxLength: 100});
    field('interval_minutes', '周期（分钟）', task?.interval_minutes || '60', {type: 'number', required: true, min: 1, max: 1440});
    field('window_minutes', '数据窗口（分钟）', task?.config.window_minutes || '1440', {type: 'number', required: true, min: 1, max: 10080});
    if (kind !== 'report') {
      const selector = selectField('connection_id', '平台接入', sources.map(c => [c.id, c.name]), task?.config.connection_id || sources[0]?.id);
      selector.required = true;
      if (kind === 'sync') {
        const productHost = node('div'); byId('editor-fields').append(productHost);
        const render = () => {
          productHost.replaceChildren();
          const source = sources.find(s => s.id === selector.value);
          for (const product of source?.catalog || []) {
            const card = node('div', undefined, 'grant-card');
            const selected = node('input'); selected.type = 'checkbox'; selected.name = 'products'; selected.value = product.id;
            selected.checked = !!task?.config.products.includes(product.id);
            const label = node('label', undefined, 'check'); checkLabel(label, selected); label.append(node('b', product.name)); card.append(label);
            for (const metric of product.metrics.filter(f => ['number', 'integer'].includes(f.type))) {
              const group = node('div', undefined, 'form-field');
              const label = node('label', metric.name + ' 的公式版本');
              const select = node('select'); select.dataset.formula = 'true'; select.dataset.product = product.id; select.dataset.metric = metric.name;
              const none = node('option', '不计算（原样入库）'); none.value = ''; select.append(none);
              formulas.forEach(formula => {const option = node('option', formula.name + ' · v' + formula.version); option.value = formula.id; select.append(option);});
              select.value = task?.config.formulas.find(binding => binding.product === product.id && binding.metric === metric.name)?.formula_id || '';
              select.id = `formula-${product.id}-${metric.name}`; label.htmlFor = select.id;
              group.append(label, select); card.append(group);
            }
            productHost.append(card);
          }
        };
        selector.onchange = render; render();
      }
    }
    if (kind !== 'sync') {
      inputChoices('devices', '分析/报表设备', devices.map(d => [d.id, d.name || d.external_id]), task?.config.device_ids);
      if (kind !== 'report') field('prompt', '分析要求/触发说明', task?.config.prompt || '分析采样异常，返回带证据的结论及布尔 warning。', {required: true, maxLength: 4000});
      if (kind === 'ai_warning') selectField('level', '告警等级', [['low', '低'], ['medium', '中'], ['high', '高']], task?.config.level || 'medium');
    }
    hint('保存默认停用。执行一次先入队，需启动独立 alinkiot worker。报表不在浏览器伪造成功。');
  }
  function editDevice(device) {
    openEditor('编辑设备本地扩展', () => write('/api/devices/' + device.id, {name: values('name'),
      location: values('location'), local_values: JSON.parse(values('local_values')),
      latitude: values('latitude') ? Number(values('latitude')) : null,
      longitude: values('longitude') ? Number(values('longitude')) : null}, 'PUT'));
    field('name', '本地显示名称', device.name, {required: true, maxLength: 100});
    field('location', '安装位置', device.location || '', {maxLength: 200});
    field('latitude', '纬度', device.latitude || '', {type: 'number', min: -90, max: 90, step: 'any'});
    field('longitude', '经度', device.longitude || '', {type: 'number', min: -180, max: 180, step: 'any'});
    field('local_values', '本地扩展 JSON', JSON.stringify(device.local_values || {}), {required: true});
  }
  async function ruleEditor() {
    const devices = await api(scope('/api/devices'));
    openEditor('新建告警规则', () => write('/api/alarm-rules', {project_id: projectId, name: values('name'),
      device_id: values('device_id'), metric: values('metric'), operator: values('operator'),
      threshold: Number(values('threshold')), level: values('level'), enabled: true}));
    field('name', '规则名称', '', {required: true});
    selectField('device_id', '设备', devices.map(d => [d.id, d.name || d.external_id]), devices[0]?.id);
    field('metric', '数值属性标识', 'flow_m3h', {required: true});
    selectField('operator', '条件', [['gt', '大于'], ['lt', '小于'], ['offline', '离线检测（阈值单位：分钟）']], 'gt');
    field('threshold', '阈值（计算后数值）', '10', {type: 'number', step: 'any', required: true});
    selectField('level', '等级', [['low', '低'], ['medium', '中'], ['high', '高']], 'medium');
    hint('离线规则使用“最后采样时间”判断，阈值为 1–10080 分钟，属性标识在离线规则中不参与判断。检测需要 worker。');
  }
  function handleEvent(event) {
    openEditor('确认处理 · ' + event.name, () => write('/api/alarm-events/' + event.id + '/actions', {note: values('note')}));
    field('note', '处理说明', '', {required: true, maxLength: 1000});
    hint('处理不等于数据恢复。检测状态随后续采样或智能预警结果更新。');
  }
  async function panelEditor(panel) {
    const devices = await api(scope('/api/devices'));
    const products = await api('/api/products');
    const choices = [];
    devices.forEach(device => {
      const product = products.find(p => p.id === device.product_id);
      product?.definition.metrics.filter(f => ['number', 'integer'].includes(f.type)).forEach(metric => {
        choices.push([device.id + ':' + metric.name, (device.name || device.external_id) + ' · ' + metric.name + ' [' + metric.unit + ']']);
      });
    });
    const kind = panelKinds[route];
    openEditor(panel ? '编辑' + panel.name : '新建' + views[route][0], () => write('/api/panels' + (panel ? '/' + panel.id : ''),
      {project_id: projectId, kind, name: values('name'), visibility: values('visibility'),
        config: {device_ids: chosen('devices'), series: chosen('series').map(value => {
          const [device_id, metric] = value.split(':'); return {device_id, metric};
        }), html: values('html')}}, panel ? 'PUT' : 'POST'));
    field('name', '名称', panel?.name, {required: true, maxLength: 100});
    selectField('visibility', '可见范围', actor.role === 'user' ? [['private', '个人']] : [['shared', '项目共享'], ['private', '个人']],
      panel?.visibility || (actor.role === 'user' ? 'private' : 'shared'));
    if (kind === 'scene') inputChoices('devices', '现场设备', devices.map(d => [d.id, d.name || d.external_id]), panel?.config.device_ids);
    else inputChoices('series', '数据系列', choices, panel?.config.series.map(s => s.device_id + ':' + s.metric));
    const htmlGroup = node('div', undefined, 'form-field');
    const htmlLabel = node('label', '自定义 HTML（可选，单文件）');
    const html = node('textarea'); html.name = 'html'; html.maxLength = 100000; html.rows = 5; html.value = panel?.config.html || '';
    html.id = 'panel-html'; htmlLabel.htmlFor = html.id;
    htmlGroup.append(htmlLabel, html); byId('editor-fields').append(htmlGroup);
    const upload = node('input'); upload.type = 'file'; upload.accept = '.html,text/html';
    upload.setAttribute('aria-label', '上传单文件 HTML 面板');
    upload.onchange = async () => {
      const file = upload.files[0];
      if (!file) return;
      if (file.size > 100000) {byId('editor-error').textContent = 'HTML 文件最多 100 KB'; return;}
      html.value = await file.text();
    };
    byId('editor-fields').append(upload);
    hint('HTML 默认只展示静态内容或 data-alink-device/data-alink-metric 占位。部署人员审查所有面板后设置 ALINK_PANEL_SCRIPTS=1，才允许脚本使用 AlinkPanelSDK.read()/subscribe()。iframe 不获凭证，不允许设备控制。仅支持自包含单文件，暂不支持 ZIP/CDN。');
    hint('本阶段使用原生设备列表/定位示意/曲线图布局。共享配置需要 configure 能力，普通用户只能维护个人曲线。');
  }
  function panelCards(items) {
    const host = node('div', undefined, 'panel-grid');
    items.forEach(panel => {
      const card = node('article', undefined, 'card panel-card');
      const body = node('div', undefined, 'card-body');
      const mark = node('div', undefined, 'panel-card-icon');
      const template = document.createElement('template'); template.innerHTML = icon(panel.kind === 'dashboard' ? 'monitor' : panel.kind === 'scene' ? 'layers' : 'chart');
      mark.append(template.content);
      body.append(mark, node('h3', panel.name), node('p', panel.visibility === 'private' ? '个人面板' : '项目共享面板', 'hint'),
        buttons([['查看', async () => {selectedPanel = panel; await panelDetail(panel);}]]));
      card.append(body);
      host.append(card);
    });
    if (!items.length) host.append(node('p', '暂无面板，请新建。', 'empty-state'));
    byId('content').append(host);
  }
  async function panelDetail(panel) {
    cleanupPanel();
    byId('content').replaceChildren();
    const controls = buttons([['返回列表', async () => {selectedPanel = null; await load();}],
      ...((actor.role !== 'user' || panel.visibility === 'private') ? [['编辑', () => panelEditor(panel)],
        ['删除', async () => {await api('/api/panels/' + panel.id, {method: 'DELETE'}); selectedPanel = null; await load();}, true]] : [])]);
    if (panel.kind === 'dashboard' && panel.visibility === 'shared' && actor.role !== 'user') {
      controls.append(action('分享（1 小时）', async () => {
        const share = await write('/api/panels/' + panel.id + '/share');
        details('限时分享地址', [['地址', location.origin + '/screen#' + share.token], ['说明', '持有地址可查看关联采样；分享者停用/项目权限收回后失效，可随时撤销。']]);
      }), action('撤销分享', async () => {await api('/api/panels/' + panel.id + '/shares', {method: 'DELETE'}); notify('该大屏分享已全部撤销。');}));
    }
    byId('content').append(controls, node('h2', panel.name));
    if (panel.config.html) {
      const frame = node('iframe'); frame.src = '/sandbox'; frame.title = panel.name; frame.setAttribute('sandbox', 'allow-scripts'); frame.className = 'custom-panel custom-panel-frame';
      const ids = [...new Set(panel.config.device_ids.concat(panel.config.series.map(s => s.device_id)))];
      let refreshTimer = null;
      let disposed = false;
      let readySeen = false;
      const channel = new MessageChannel();
      const refresh = async () => {
        try {
          if (disposed || !actor || !frame.isConnected) return;
          const data = await api('/api/telemetry?project_id=' + panel.project_id + '&latest=true&device_ids=' + ids.join(','));
          if (disposed || !actor || !frame.isConnected) return;
          const samples = data.items.map(row => {
            const fields = panel.kind === 'scene' ? Object.keys(row.values) : panel.config.series.filter(s => s.device_id === row.device_id).map(s => s.metric);
            return {device_id: row.device_id, external_id: row.external_id, time: row.time, quality: row.quality,
              values: Object.fromEntries(fields.map(key => [key, row.values[key]])),
              units: Object.fromEntries(fields.map(key => [key, row.units[key]]))};
          });
          channel.port1.postMessage({type: 'alink-panel-data', html: panel.config.html, data: {samples}});
          refreshTimer = setTimeout(refresh, 10000);
        } catch (error) {
          frame.remove(); notify(error.message);
        }
      };
      const ready = event => {
        if (!readySeen && event.source === frame.contentWindow && event.data?.type === 'alink-panel-ready') {
          readySeen = true;
          frame.contentWindow.postMessage({type: 'alink-panel-connect'}, '*', [channel.port2]);
          refresh();
        }
      };
      window.addEventListener('message', ready);
      panelCleanup = () => {
        disposed = true; clearTimeout(refreshTimer); channel.port1.close(); channel.port2.close();
        window.removeEventListener('message', ready); frame.remove();
      };
      byId('content').append(frame);
      return;
    }
    if (panel.kind === 'scene') {
      const devices = (await api(scope('/api/devices'))).filter(d => panel.config.device_ids.includes(d.id));
      byId('content').append(table(['设备', '位置', '纬度/经度'], devices.map(d => [d.name || d.external_id, d.location,
        d.latitude && d.longitude ? `${d.latitude}, ${d.longitude}` : '未定位'])));
      const map = node('div', undefined, 'scene-map');
      map.append(node('p', '现场设备定位 · 离线经纬度示意（非真实地图）'));
      const located = devices.filter(d => d.latitude !== null && d.longitude !== null);
      located.forEach(device => {
        const point = node('div', device.name || device.external_id, 'map-point');
        point.style.left = (5 + (Number(device.longitude) + 180) / 360 * 85) + '%';
        point.style.top = (18 + (90 - Number(device.latitude)) / 180 * 65) + '%';
        map.append(point);
      });
      if (!located.length) map.append(node('p', '设备暂无定位，请在设备档案设置经纬度。'));
      byId('content').append(map);
    } else {
      const data = await api(scope('/api/telemetry') + '&device_ids=' + [...new Set(panel.config.series.map(s => s.device_id))].join(','));
      const host = node('div', undefined, 'panel-grid');
      for (const series of panel.config.series) {
        const rows = data.items.filter(row => row.device_id === series.device_id && typeof row.values[series.metric] === 'number');
        const card = node('section', undefined, 'chart-card');
        card.append(node('h3', (rows[0]?.external_id || '设备') + ' · ' + series.metric));
        const units = [...new Set(rows.map(row => row.units[series.metric]))];
        card.append(node('p', units.length === 1 ? '单位：' + units[0] : '单位不一致，禁止混画'));
        if (units.length !== 1 || !rows.length) card.append(node('p', '无可绘制同单位采样'));
        else card.append(node('div', undefined, 'chart'), node('p', `最新 ${rows.at(-1).values[series.metric]} · ${rows.length} 个点`, 'hint'));
        host.append(card);
        card._rows = rows; card._metric = series.metric; card._drawable = units.length === 1 && rows.length;
      }
      byId('content').append(host);
      for (const card of host.children) {
        if (!card._drawable) continue;
        const chart = card.querySelector('.chart');
        chartHosts.add(chart);
        Charts.line(chart, {height:240, labels:card._rows.map(row => new Date(row.time).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})),
          series:[{name:card._metric, data:card._rows.map(row => row.values[card._metric])}]});
      }
    }
  }

  async function chat(prompt = '') {
    if (!actor) return;
    await projectOptions();
    if (!projectId) throw new Error('请先分配项目');
    const connections = (await api(scope('/api/connections'))).filter(c => c.kind === 'agent' && c.selected_agent);
    const selector = byId('chat-connection'); selector.replaceChildren();
    connections.forEach(source => {const option = node('option', source.name + ' · ' + source.selected_agent); option.value = source.id; selector.append(option);});
    byId('chat-window').hidden = false; byId('chat-prompt').value = prompt;
    byId('chat-messages').replaceChildren(node('p', connections.length ? '数据范围：当前获授权项目最新采样。' : '尚未接入智能体或选择数字人，请先到平台接入配置。'));
  }
  byId('chat-toggle').onclick = () => chat().catch(error => notify(error.message));
  byId('chat-close').onclick = () => {byId('chat-window').hidden = true;};
  byId('chat-form').onsubmit = async event => {
    event.preventDefault();
    const button = byId('chat-form').querySelector('button'); button.disabled = true;
    try {
      const prompt = byId('chat-prompt').value;
      const answer = await write('/api/agent/ask', {project_id: projectId, connection_id: byId('chat-connection').value, prompt});
      const message = (text, own) => {
        const row = node('div', undefined, own ? 'msg me' : 'msg');
        row.append(node('span', own ? '我' : 'AI', 'm-ava'), node('div', text, 'bubble'));
        return row;
      };
      byId('chat-messages').append(message(prompt, true), message(answer.answer, false));
      byId('chat-prompt').value = '';
    } catch (error) {byId('chat-messages').append(node('p', error.message));}
    finally {button.disabled = false;}
  };
  byId('iot-project').onchange = () => {
    projectId = byId('iot-project').value; selectedPanel = null; byId('chat-window').hidden = true; load();
  };
  byId('iot-refresh').onclick = () => load();
  byId('iot-create').onclick = async () => {
    try {
      if (route === 'connections') connectionEditor();
      else if (route === 'formulas') formulaEditor();
      else if (kinds[route]) await taskEditor();
      else if (panelKinds[route]) await panelEditor();
      else if (route === 'rules') await ruleEditor();
      else if (['diagnosis', 'analysis'].includes(route)) await chat('请分析当前项目设备状态、采样异常和数据质量，给出证据与不确定性。');
    } catch (error) {notify(error.message);}
  };
  window.addEventListener('hashchange', () => {selectedPanel = null; stopTimer(); cleanupPanel();});
  window.IoT = {routes: Object.keys(specifications), load: loadIoT, stop, project};
})();
