const form = document.getElementById('install-form');
const result = document.getElementById('result');
const panels = Array.from(form.querySelectorAll('[data-step]'));
const indicators = Array.from(document.querySelectorAll('[data-step-indicator]'));
const previous = document.getElementById('previous-step');
const next = document.getElementById('next-step');
const start = document.getElementById('start-install');
const test = document.getElementById('test-database');
const connectionResult = document.getElementById('connection-result');
const databaseFields = ['host', 'port', 'database', 'username', 'password', 'tls'];
let step = 0;
let busy = false;
let connectionTested = false;
let demoAccounts = null;
document.getElementById('download-demo-accounts').onclick = () => {
  if (!demoAccounts) return;
  const url = URL.createObjectURL(new Blob([JSON.stringify(demoAccounts, null, 2)], {type: 'application/json'}));
  const link = document.createElement('a');
  link.href = url; link.download = 'alinkiot-demo-accounts.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
window.addEventListener('pagehide', () => {demoAccounts = null;});

function databaseInput() {
  const value = name => form.elements[name].value;
  return {host: value('host'), port: Number(value('port')), database: value('database'),
    username: value('username'), password: value('password'), tls: form.elements.tls.checked};
}

function render(focus = true) {
  panels.forEach((panel, index) => {
    panel.hidden = index !== step;
    panel.querySelectorAll('input').forEach(input => input.disabled = index !== step || busy);
  });
  indicators.forEach((indicator, index) => {
    indicator.classList.toggle('completed', index < step);
    if (index === step) indicator.setAttribute('aria-current', 'step');
    else indicator.removeAttribute('aria-current');
  });
  previous.hidden = step === 0 || step === 4;
  next.hidden = step >= 3;
  start.hidden = step !== 3;
  form.querySelectorAll('button').forEach(button => button.disabled = busy);
  next.disabled = busy || (step === 1 && !connectionTested);
  document.getElementById('wizard-actions').hidden = step === 4;
  document.getElementById('step-count').textContent = `第 ${step + 1} 步，共 5 步`;
  form.setAttribute('aria-busy', String(busy));
  if (focus) panels[step].querySelector('h2').focus();
}

function validateStep() {
  if (step === 2) {
    const confirm = form.elements.admin_password_confirm;
    confirm.setCustomValidity(confirm.value === form.elements.admin_password.value ? '' : '两次输入的密码不一致');
  }
  return form.reportValidity();
}

function summary() {
  const database = databaseInput();
  const values = {
    host: `${database.host}:${database.port}`, database: database.database,
    username: database.username, tls: database.tls ? '开启' : '关闭（仅建议本机测试）',
    admin: form.elements.admin_username.value
  };
  Object.entries(values).forEach(([name, value]) => {
    document.getElementById('summary-' + name).textContent = value;
  });
}

function invalidateConnection() {
  connectionTested = false;
  form.elements.acknowledge.checked = false;
  connectionResult.textContent = '配置已修改，请重新测试连接。';
  render(false);
}

databaseFields.concat('token').forEach(name => {
  form.elements[name].addEventListener('input', invalidateConnection);
  form.elements[name].addEventListener('change', invalidateConnection);
});
['admin_password', 'admin_password_confirm'].forEach(name => {
  form.elements[name].addEventListener('input', () => form.elements.admin_password_confirm.setCustomValidity(''));
});

previous.onclick = () => {
  if (busy || step === 0 || step === 4) return;
  step--;
  result.textContent = '';
  render();
};
next.onclick = () => {
  if (busy || step >= 3 || !validateStep() || (step === 1 && !connectionTested)) return;
  step++;
  result.textContent = '';
  if (step === 3) {
    form.elements.acknowledge.checked = false;
    summary();
  }
  render();
};

async function request(testOnly) {
  if (busy || step !== (testOnly ? 1 : 3) || !validateStep()) return;
  if (!testOnly && !connectionTested) {
    step = 1;
    result.textContent = '请先测试数据库连接。';
    render();
    return;
  }
  const database = databaseInput();
  const payload = testOnly ? database : {database,
    admin_username: form.elements.admin_username.value,
    admin_password: form.elements.admin_password.value,
    seed_demo: form.elements.seed_demo.checked};
  const token = form.elements.token.value;
  busy = true;
  if (testOnly) connectionTested = false;
  result.textContent = testOnly ? '' : '正在按需创建数据库并初始化基础表与产品表，请勿关闭页面…';
  if (testOnly) connectionResult.textContent = '正在测试连接…';
  render(false);
  try {
    const response = await fetch(testOnly ? '/api/install/test' : '/api/install', {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-Install-Token': token},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || '请求失败');
    if (testOnly) {
      connectionTested = true;
      connectionResult.textContent = data.database_exists === false
        ? 'MySQL 连接成功；目标库不存在，正式安装时将自动创建，账户需具备建库权限。'
        : '连接成功，将使用已有数据库，可以继续设置超管账号。';
      result.textContent = '';
    } else {
      document.getElementById('installed-plugins').textContent = '已登记插件：' + data.plugins.join('、');
      if (data.demo?.created) {
        demoAccounts = data.demo.accounts;
        const notice = document.getElementById('installed-demo');
        notice.textContent = `已创建【演示】智慧泵房、${data.demo.devices} 台设备、${data.demo.samples} 条历史采样及面板/报表/告警。离开前下载随机账号密码，丢失后由超管重置。`;
        notice.hidden = false;
        document.getElementById('download-demo-accounts').hidden = false;
      }
      form.reset();
      step = 4;
      result.textContent = '';
    }
  } catch (error) {
    result.textContent = testOnly ? '' : error.message;
    if (testOnly) connectionResult.textContent = error.message;
  } finally {
    busy = false;
    render(!testOnly && step === 4);
  }
}
test.onclick = () => request(true);
form.onsubmit = event => {
  event.preventDefault();
  if (step === 3) request(false);
  else if (step < 3) next.onclick();
};
render(false);
