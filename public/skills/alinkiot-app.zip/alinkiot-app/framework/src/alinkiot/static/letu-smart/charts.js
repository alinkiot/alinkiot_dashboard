/* ═══════════════════════════════════════════
   乐图智慧 · 轻量 SVG 图表引擎（无依赖）
   ═══════════════════════════════════════════ */
const Charts = (() => {
  const NS = 'http://www.w3.org/2000/svg';
  const registry = [];
  const tipEl = () => document.getElementById('chartTip');

  function el(tag, attrs = {}) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  function css(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }
  function palette() {
    return {
      accent: css('--accent'), accent2: css('--accent-2'), accent3: css('--accent-3'),
      grid: css('--chart-grid'), label: css('--chart-label'),
      text: css('--text'), text3: css('--text-3'),
      ok: css('--ok'), warn: css('--warn'), danger: css('--danger'), info: css('--info'),
      panel: css('--panel-solid'), line: css('--line')
    };
  }

  function uid() { return 'c' + Math.random().toString(36).slice(2, 9); }

  function smooth(pts) {
    if (!pts.length) return '';
    let d = `M${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const t = 0.16;
      const c1x = p1[0] + (p2[0] - p0[0]) * t, c1y = p1[1] + (p2[1] - p0[1]) * t;
      const c2x = p2[0] - (p3[0] - p1[0]) * t, c2y = p2[1] - (p3[1] - p1[1]) * t;
      d += ` C${c1x.toFixed(2)},${c1y.toFixed(2)} ${c2x.toFixed(2)},${c2y.toFixed(2)} ${p2[0].toFixed(2)},${p2[1].toFixed(2)}`;
    }
    return d;
  }

  function niceTicks(min, max, count) {
    if (min === max) { min -= 1; max += 1; }
    const raw = (max - min) / count;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const norm = raw / mag;
    const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10) * mag;
    const lo = Math.floor(min / step) * step;
    const hi = Math.ceil(max / step) * step;
    const out = [];
    for (let v = lo; v <= hi + step * 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  }

  function fmt(v, d) {
    if (Math.abs(v) >= 10000) return (v / 1000).toFixed(0) + 'k';
    return d != null ? v.toFixed(d) : (Math.abs(v) >= 100 ? Math.round(v) : +v.toFixed(1));
  }

  /* ── 折线 / 面积图 ── */
  function line(host, cfg) {
    const state = { el: host, type: 'line', cfg };
    registry.push(state);
    drawLine(state);
    return state;
  }

  function drawLine(state) {
    const host = state.el, cfg = state.cfg;
    const W = Math.max(host.clientWidth || 400, 200);
    const H = cfg.height || 240;
    const P = palette();
    const pad = { l: cfg.padLeft ?? 44, r: 16, t: 16, b: cfg.hideX ? 8 : 26 };
    const labels = cfg.labels || [];
    const series = cfg.series || [];
    const n = labels.length || (series[0] ? series[0].data.length : 0);
    if (!n) return;

    let mn = Infinity, mx = -Infinity;
    series.forEach(s => s.data.forEach(v => { if (v != null) { mn = Math.min(mn, v); mx = Math.max(mx, v); } }));
    if (cfg.min != null) mn = cfg.min;
    if (cfg.max != null) mx = cfg.max;
    const ticks = cfg.ticks ?? niceTicks(mn, mx, cfg.yTicks || 4);
    mn = Math.min(mn, ticks[0]); mx = Math.max(mx, ticks[ticks.length - 1]);
    if (mx === mn) mx = mn + 1;

    const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
    const X = i => pad.l + (n === 1 ? iw / 2 : i * iw / (n - 1));
    const Y = v => pad.t + ih - ((v - mn) / (mx - mn)) * ih;

    host.innerHTML = '';
    const svg = el('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, style: 'width:100%;height:auto' });
    const defs = el('defs');
    svg.appendChild(defs);

    /* 网格 */
    const gGrid = el('g');
    ticks.forEach(t => {
      const y = Y(t);
      gGrid.appendChild(el('line', { x1: pad.l, y1: y, x2: W - pad.r, y2: y, stroke: P.grid, 'stroke-width': 1, 'stroke-dasharray': '3 4' }));
      const tx = el('text', { x: pad.l - 9, y: y + 3.5, 'text-anchor': 'end', fill: P.label, 'font-size': 10, 'font-family': 'inherit' });
      tx.textContent = fmt(t, cfg.yDec);
      gGrid.appendChild(tx);
    });
    svg.appendChild(gGrid);

    /* X 轴标签 */
    if (!cfg.hideX) {
      const step = Math.max(1, Math.ceil(n / (cfg.xLabels || 7)));
      labels.forEach((lb, i) => {
        if (i % step !== 0 && i !== n - 1) return;
        const t = el('text', { x: X(i), y: H - 7, 'text-anchor': 'middle', fill: P.label, 'font-size': 10, 'font-family': 'inherit' });
        t.textContent = lb;
        svg.appendChild(t);
      });
    }

    /* 序列 */
    series.forEach((s, si) => {
      const color = s.color || [P.accent, P.accent2, P.accent3, P.warn, P.ok][si % 5];
      const pts = s.data.map((v, i) => [X(i), Y(v == null ? mn : v)]);
      const gid = uid();
      const grad = el('linearGradient', { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 });
      grad.appendChild(el('stop', { offset: '0%', 'stop-color': color, 'stop-opacity': cfg.areaOpacity ?? 0.26 }));
      grad.appendChild(el('stop', { offset: '100%', 'stop-color': color, 'stop-opacity': 0 }));
      defs.appendChild(grad);

      if (cfg.area !== false && s.area !== false) {
        const d = smooth(pts) + ` L${X(n - 1)},${pad.t + ih} L${X(0)},${pad.t + ih} Z`;
        svg.appendChild(el('path', { d, fill: `url(#${gid})` }));
      }
      const path = el('path', {
        d: smooth(pts), fill: 'none', stroke: color,
        'stroke-width': s.width || 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round'
      });
      if (cfg.animate !== false) {
        path.style.strokeDasharray = '2400';
        path.style.strokeDashoffset = '2400';
        path.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(.22,.61,.36,1)';
        requestAnimationFrame(() => { path.style.strokeDashoffset = '0'; });
      }
      svg.appendChild(path);

      if (cfg.dots && n <= 40) {
        pts.forEach(p => svg.appendChild(el('circle', { cx: p[0], cy: p[1], r: 2.2, fill: P.panel, stroke: color, 'stroke-width': 1.6 })));
      }
      if (cfg.lastDot) {
        const lp = pts[pts.length - 1];
        svg.appendChild(el('circle', { cx: lp[0], cy: lp[1], r: 4, fill: color, opacity: .18 }));
        svg.appendChild(el('circle', { cx: lp[0], cy: lp[1], r: 2.4, fill: color }));
      }
    });

    /* 悬浮交互 */
    if (cfg.tooltip !== false) {
      const hover = el('g', { opacity: 0 });
      const vline = el('line', { y1: pad.t, y2: pad.t + ih, stroke: P.label, 'stroke-width': 1, 'stroke-dasharray': '3 3', opacity: .7 });
      hover.appendChild(vline);
      const dots = series.map((s, i) => {
        const c = el('circle', { r: 3.6, fill: s.color || [P.accent, P.accent2, P.accent3][i % 3], stroke: P.panel, 'stroke-width': 1.6 });
        hover.appendChild(c); return c;
      });
      svg.appendChild(hover);

      const hit = el('rect', { x: pad.l, y: pad.t, width: iw, height: ih, fill: 'transparent' });
      svg.appendChild(hit);

      const tip = tipEl();
      const move = e => {
        const r = svg.getBoundingClientRect();
        const scale = W / r.width;
        const px = (e.clientX - r.left) * scale;
        let idx = Math.round((px - pad.l) / (iw / Math.max(n - 1, 1)));
        idx = Math.max(0, Math.min(n - 1, idx));
        const x = X(idx);
        hover.setAttribute('opacity', 1);
        vline.setAttribute('x1', x); vline.setAttribute('x2', x);
        series.forEach((s, i) => {
          const v = s.data[idx];
          dots[i].setAttribute('cx', x);
          dots[i].setAttribute('cy', Y(v == null ? mn : v));
        });
        if (tip) {
          tip.innerHTML = `<b>${labels[idx] || ''}</b>` + series.map((s, i) => {
            const c = s.color || [P.accent, P.accent2, P.accent3][i % 3];
            const v = s.data[idx];
            return `<div class="ct-row"><span class="ct-dot" style="background:${c}"></span><span class="ct-name">${s.name || ''}</span><span class="ct-val">${v == null ? '—' : (cfg.tipFormat ? cfg.tipFormat(v, s) : fmt(v, cfg.yDec))}${cfg.unit || ''}</span></div>`;
          }).join('');
          tip.classList.add('on');
          tip.style.left = (r.left + x / scale) + 'px';
          tip.style.top = (r.top + (e.clientY - r.top) * 0.55) + 'px';
        }
      };
      hit.addEventListener('mousemove', move);
      hit.addEventListener('mouseleave', () => {
        hover.setAttribute('opacity', 0);
        if (tip) tip.classList.remove('on');
      });
    }

    host.appendChild(svg);
    state.W = W; state.H = H;
  }

  /* ── 迷你走势 ── */
  function spark(host, data, color, opts = {}) {
    const W = host.clientWidth || 104, H = opts.height || 44;
    const mn = Math.min(...data), mx = Math.max(...data);
    const pad = 3;
    const X = i => i * W / (data.length - 1);
    const Y = v => H - pad - ((v - mn) / (mx - mn || 1)) * (H - pad * 2);
    const pts = data.map((v, i) => [X(i), Y(v)]);
    const gid = uid();
    host.innerHTML = '';
    const svg = el('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, style: 'width:100%;height:100%' });
    const defs = el('defs');
    const grad = el('linearGradient', { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 });
    grad.appendChild(el('stop', { offset: '0%', 'stop-color': color, 'stop-opacity': .35 }));
    grad.appendChild(el('stop', { offset: '100%', 'stop-color': color, 'stop-opacity': 0 }));
    defs.appendChild(grad); svg.appendChild(defs);
    svg.appendChild(el('path', { d: smooth(pts) + ` L${W},${H} L0,${H} Z`, fill: `url(#${gid})` }));
    svg.appendChild(el('path', { d: smooth(pts), fill: 'none', stroke: color, 'stroke-width': 1.6, 'stroke-linecap': 'round' }));
    host.appendChild(svg);
  }

  /* ── 环形图 ── */
  function donut(host, cfg) {
    const state = { el: host, type: 'donut', cfg };
    registry.push(state);
    drawDonut(state);
    return state;
  }
  function drawDonut(state) {
    const host = state.el, cfg = state.cfg, P = palette();
    const W = Math.max(host.clientWidth || 240, 160), H = cfg.height || 220;
    const cx = W / 2, cy = H / 2, R = Math.min(W, H) / 2 - 12, r = R * (cfg.inner ?? 0.68);
    const data = cfg.data || [];
    const total = data.reduce((a, b) => a + b.value, 0) || 1;
    host.innerHTML = '';
    const svg = el('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, style: 'width:100%;height:auto' });
    const g = el('g', { transform: `rotate(-90 ${cx} ${cy})` });
    let acc = 0;
    const gap = cfg.gap ?? 0.014;
    data.forEach((d, i) => {
      const frac = d.value / total;
      const a0 = (acc + gap / 2) * Math.PI * 2;
      const a1 = (acc + frac - gap / 2) * Math.PI * 2;
      acc += frac;
      const color = d.color || [P.accent, P.accent2, P.accent3, P.warn, P.ok, P.info][i % 6];
      const path = el('path', {
        d: arcPath(cx, cy, R, r, a0, a1), fill: color, opacity: .92
      });
      path.style.transition = 'opacity .2s';
      path.addEventListener('mouseenter', () => path.setAttribute('opacity', 1));
      path.addEventListener('mouseleave', () => path.setAttribute('opacity', .92));
      g.appendChild(path);
    });
    svg.appendChild(g);

    const cLabel = el('text', { x: cx, y: cy - 4, 'text-anchor': 'middle', fill: P.text3, 'font-size': 10.5, 'font-family': 'inherit' });
    cLabel.textContent = cfg.centerLabel || '';
    svg.appendChild(cLabel);
    const cVal = el('text', { x: cx, y: cy + 19, 'text-anchor': 'middle', fill: P.text, 'font-size': 21, 'font-weight': 700, 'font-family': 'inherit' });
    cVal.textContent = cfg.centerValue || '';
    svg.appendChild(cVal);
    host.appendChild(svg);
  }
  function arcPath(cx, cy, R, r, a0, a1) {
    const large = a1 - a0 > Math.PI ? 1 : 0;
    const x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0);
    const x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    const x2 = cx + r * Math.cos(a1), y2 = cy + r * Math.sin(a1);
    const x3 = cx + r * Math.cos(a0), y3 = cy + r * Math.sin(a0);
    return `M${x0},${y0} A${R},${R} 0 ${large} 1 ${x1},${y1} L${x2},${y2} A${r},${r} 0 ${large} 0 ${x3},${y3} Z`;
  }

  /* ── 柱状图 ── */
  function bars(host, cfg) {
    const state = { el: host, type: 'bars', cfg };
    registry.push(state);
    drawBars(state);
    return state;
  }
  function drawBars(state) {
    const host = state.el, cfg = state.cfg, P = palette();
    const W = Math.max(host.clientWidth || 320, 160), H = cfg.height || 200;
    const pad = { l: cfg.padLeft ?? 40, r: 10, t: 14, b: 26 };
    const data = cfg.data || [], labels = cfg.labels || [];
    const rawMax = cfg.max ?? Math.max(...data);
    const ticks = cfg.max != null ? [0, .25, .5, .75, 1].map(f => cfg.max * f) : niceTicks(0, rawMax, 4);
    const mx = ticks[ticks.length - 1] || 1;
    const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
    const bw = Math.min(cfg.barWidth || 26, iw / data.length * 0.55);
    host.innerHTML = '';
    const svg = el('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, style: 'width:100%;height:auto' });
    const defs = el('defs');
    const gid = uid();
    const grad = el('linearGradient', { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 });
    grad.appendChild(el('stop', { offset: '0%', 'stop-color': cfg.color || P.accent, 'stop-opacity': .95 }));
    grad.appendChild(el('stop', { offset: '100%', 'stop-color': cfg.color2 || P.accent2, 'stop-opacity': .55 }));
    defs.appendChild(grad); svg.appendChild(defs);

    ticks.forEach(t => {
      const y = pad.t + ih - (t / mx) * ih;
      svg.appendChild(el('line', { x1: pad.l, y1: y, x2: W - pad.r, y2: y, stroke: P.grid, 'stroke-dasharray': '3 4' }));
      const tx = el('text', { x: pad.l - 8, y: y + 3.5, 'text-anchor': 'end', fill: P.label, 'font-size': 10, 'font-family': 'inherit' });
      tx.textContent = fmt(t, cfg.yDec);
      svg.appendChild(tx);
    });

    const step = iw / data.length;
    data.forEach((v, i) => {
      const x = pad.l + step * i + step / 2 - bw / 2;
      const h = Math.max(2, (v / mx) * ih);
      const rect = el('rect', {
        x, y: pad.t + ih - h, width: bw, height: h, rx: Math.min(6, bw / 2),
        fill: `url(#${gid})`
      });
      rect.style.transformOrigin = `${x + bw / 2}px ${pad.t + ih}px`;
      rect.style.transform = 'scaleY(0)';
      rect.style.transition = `transform .7s cubic-bezier(.16,1,.3,1) ${i * 0.05}s`;
      requestAnimationFrame(() => { rect.style.transform = 'scaleY(1)'; });
      svg.appendChild(rect);
      const lt = el('text', { x: pad.l + step * i + step / 2, y: H - 8, 'text-anchor': 'middle', fill: P.label, 'font-size': 10, 'font-family': 'inherit' });
      lt.textContent = labels[i] || '';
      svg.appendChild(lt);
    });
    host.appendChild(svg);
  }

  /* ── 仪表盘 ── */
  function gauge(host, cfg) {
    const state = { el: host, type: 'gauge', cfg };
    registry.push(state);
    drawGauge(state);
    return state;
  }
  function drawGauge(state) {
    const host = state.el, cfg = state.cfg, P = palette();
    const W = Math.max(host.clientWidth || 180, 120), H = cfg.height || 130;
    const cx = W / 2, cy = H * 0.82, R = Math.min(W / 2, H * 0.82) - 12;
    const pct = Math.max(0, Math.min(1, cfg.value / (cfg.max || 100)));
    const start = Math.PI * 0.82, end = Math.PI * 2.18;
    host.innerHTML = '';
    const svg = el('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, style: 'width:100%;height:auto' });
    const track = el('path', { d: arcStroke(cx, cy, R, start, end), fill: 'none', stroke: P.grid, 'stroke-width': cfg.width || 9, 'stroke-linecap': 'round' });
    svg.appendChild(track);
    const val = el('path', { d: arcStroke(cx, cy, R, start, start + (end - start) * pct), fill: 'none', stroke: cfg.color || P.accent, 'stroke-width': cfg.width || 9, 'stroke-linecap': 'round' });
    svg.appendChild(val);
    const t1 = el('text', { x: cx, y: cy - 6, 'text-anchor': 'middle', fill: P.text, 'font-size': 22, 'font-weight': 700, 'font-family': 'inherit' });
    t1.textContent = cfg.text || cfg.value;
    svg.appendChild(t1);
    const t2 = el('text', { x: cx, y: cy + 12, 'text-anchor': 'middle', fill: P.text3, 'font-size': 10.5, 'font-family': 'inherit' });
    t2.textContent = cfg.label || '';
    svg.appendChild(t2);
    host.appendChild(svg);
  }
  function arcStroke(cx, cy, R, a0, a1) {
    const x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0);
    const x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    const large = a1 - a0 > Math.PI ? 1 : 0;
    return `M${x0},${y0} A${R},${R} 0 ${large} 1 ${x1},${y1}`;
  }

  /* ── 横向进度条组 ── */
  function hbars(host, cfg) {
    const P = palette();
    const data = cfg.data || [];
    const mx = Math.max(...data.map(d => d.value)) || 1;
    host.innerHTML = data.map((d, i) => {
      const c = d.color || [P.accent, P.accent2, P.accent3, P.warn, P.ok][i % 5];
      return `<div style="margin-bottom:${i === data.length - 1 ? 0 : 12}px">
        <div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:5px">
          <span style="color:var(--text-2)">${d.name}</span>
          <span class="num" style="color:var(--text);font-weight:600">${d.label ?? d.value}</span>
        </div>
        <div class="progress" style="height:5px"><i style="width:${(d.value / mx * 100).toFixed(1)}%;background:${c}"></i></div>
      </div>`;
    }).join('');
  }

  function redrawAll() {
    registry.forEach(s => {
      if (!s.el.isConnected) return;
      if (s.type === 'line') drawLine(s);
      else if (s.type === 'donut') drawDonut(s);
      else if (s.type === 'bars') drawBars(s);
      else if (s.type === 'gauge') drawGauge(s);
      else if (s.type === 'spark') spark(s.el, s.cfg.data, s.cfg.color, s.cfg.opts);
    });
  }
  function remove(host) {
    for (let i = registry.length - 1; i >= 0; i--) {
      if (registry[i].el === host) registry.splice(i, 1);
    }
    tipEl()?.classList.remove('on');
  }
  function sparkReg(host, data, color, opts) {
    registry.push({ el: host, type: 'spark', cfg: { data, color, opts } });
    spark(host, data, color, opts);
  }

  let rt;
  window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(redrawAll, 180); });

  return { line, spark: sparkReg, donut, bars, gauge, hbars, redrawAll, palette, remove };
})();
