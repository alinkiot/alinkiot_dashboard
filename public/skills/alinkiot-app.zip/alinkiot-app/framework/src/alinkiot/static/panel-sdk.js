(() => {
  let data = {samples: []};
  let mounted = false;
  const listeners = new Set();
  window.AlinkPanelSDK = Object.freeze({
    read: () => structuredClone(data),
    subscribe: listener => {listeners.add(listener); return () => listeners.delete(listener);},
    control: () => Promise.reject(new Error('真实设备控制未开放'))
  });
  let connected = false;
  function update(event) {
    if (event.data?.type !== 'alink-panel-data') return;
    data = structuredClone(event.data.data);
    if (!mounted) {
      mounted = true;
      const parsed = new DOMParser().parseFromString(event.data.html, 'text/html');
      parsed.querySelectorAll('base,meta,iframe,object,embed,link').forEach(element => element.remove());
      const scripts = [...parsed.querySelectorAll('script')].filter(script => !script.src).map(script => script.textContent);
      parsed.querySelectorAll('script').forEach(script => script.remove());
      document.body.replaceChildren(...parsed.head.childNodes, ...parsed.body.childNodes);
      scripts.forEach(source => {const script = document.createElement('script'); script.textContent = source; document.body.append(script);});
    }
    document.querySelectorAll('[data-alink-device][data-alink-metric]').forEach(element => {
      const sample = data.samples.find(row => row.device_id === element.dataset.alinkDevice);
      const metric = element.dataset.alinkMetric;
      element.textContent = sample ? `${sample.values[metric] ?? '—'} ${sample.units[metric] || ''}` : '—';
    });
    listeners.forEach(listener => listener(structuredClone(data)));
  }
  window.addEventListener('message', event => {
    if (connected || event.source !== parent || event.origin !== location.origin ||
        event.data?.type !== 'alink-panel-connect' || !event.ports[0]) return;
    connected = true;
    const port = event.ports[0];
    port.onmessage = update;
    port.start();
  });
  parent.postMessage({type: 'alink-panel-ready'}, location.origin);
})();
