import json
import os
from urllib.parse import urlsplit

import httpx
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator


class ConnectionInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    project_id: str = Field(min_length=1, max_length=36)
    kind: str = Field(pattern=r"^(source|agent)$")
    name: str = Field(min_length=1, max_length=100)
    url: str = Field(max_length=500)
    appid: str = Field(min_length=1, max_length=100)
    secret: SecretStr = Field(min_length=1, max_length=1000)

    @field_validator("url")
    @classmethod
    def valid_url(cls, value):
        origin(value)
        return value.rstrip("/")


def origin(value):
    parsed = urlsplit(value)
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username
            or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("Only approved HTTP base URLs without credentials/query are supported")
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    return f"{parsed.scheme}://{parsed.hostname.lower()}:{port}"


def request(connection, state, path, payload=None):
    allowed = os.environ.get("ALINK_HTTP_ALLOWLIST", "http://127.0.0.1:58240").split(",")
    if origin(connection["url"]) not in {origin(item.strip()) for item in allowed if item.strip()}:
        raise ValueError("平台地址未加入服务器 ALINK_HTTP_ALLOWLIST")
    secret = state.cipher(create=False).decrypt(connection["encrypted_secret"].encode()).decode()
    headers = {"X-App-ID": connection["appid"], "X-App-Secret": secret}
    try:
        with httpx.Client(timeout=15, follow_redirects=False, trust_env=False) as client:
            with client.stream("POST" if payload is not None else "GET",
                               connection["url"] + path, headers=headers, json=payload) as response:
                response.raise_for_status()
                chunks = bytearray()
                for chunk in response.iter_bytes():
                    chunks.extend(chunk)
                    if len(chunks) > 2_000_000:
                        raise ValueError("平台响应超过 2 MB 上限")
                return json.loads(chunks)
    except (httpx.HTTPError, json.JSONDecodeError) as error:
        raise ValueError("HTTP 平台请求失败或响应格式无效") from error
