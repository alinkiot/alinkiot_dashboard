import csv
import io
import math
import secrets
from datetime import timedelta
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from fastapi.responses import Response
from pydantic import Field, field_validator
from sqlalchemy import delete, insert, select, update

from . import models
from .core import Input, mutation, record
from .data_service import connection_for, product_tables, product_visible, project_scope, query_samples, timestamp
from .formula import parse
from .http_adapter import ConnectionInput, request
from .plugins import ProductSpec
from .security import digest


class FormulaInput(Input):
    project_id: str = Field(max_length=36)
    name: str = Field(min_length=1, max_length=100)
    expression: str = Field(min_length=1, max_length=300)
    parameters: dict[str, float] = Field(default_factory=dict)
    unit: str = Field(default="", max_length=20)
    family_id: str | None = Field(default=None, max_length=36)


class ProductBinding(Input):
    external_id: str = Field(max_length=24)
    product_id: str = Field(max_length=36)


class AgentSelection(Input):
    agent: str = Field(min_length=1, max_length=100)


class FormulaBinding(Input):
    product: str = Field(max_length=24)
    metric: str = Field(max_length=24)
    formula_id: str = Field(max_length=36)


class TaskConfig(Input):
    connection_id: str | None = Field(default=None, max_length=36)
    products: list[str] = Field(default_factory=list, max_length=40)
    formulas: list[FormulaBinding] = Field(default_factory=list, max_length=200)
    device_ids: list[str] = Field(default_factory=list, max_length=100)
    window_minutes: int = Field(default=1440, ge=1, le=10080)
    prompt: str = Field(default="", max_length=4000)
    level: Literal["low", "medium", "high"] = "medium"


class TaskInput(Input):
    project_id: str = Field(max_length=36)
    kind: Literal["sync", "report", "ai_report", "ai_warning"]
    name: str = Field(min_length=1, max_length=100)
    interval_minutes: int = Field(default=60, ge=1, le=1440)
    enabled: bool = False
    config: TaskConfig


class Series(Input):
    device_id: str = Field(max_length=36)
    metric: str = Field(max_length=24)


class PanelConfig(Input):
    device_ids: list[str] = Field(default_factory=list, max_length=100)
    series: list[Series] = Field(default_factory=list, max_length=40)
    html: str = Field(default="", max_length=100000)


class PanelInput(Input):
    project_id: str = Field(max_length=36)
    kind: Literal["scene", "curve", "dashboard"]
    name: str = Field(min_length=1, max_length=100)
    visibility: Literal["private", "shared"] = "shared"
    config: PanelConfig


class DeviceInput(Input):
    name: str = Field(min_length=1, max_length=100)
    location: str = Field(default="", max_length=200)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    local_values: dict = Field(default_factory=dict)

    @field_validator("local_values")
    @classmethod
    def small(cls, value):
        import json
        if len(json.dumps(value, allow_nan=False)) > 10000:
            raise ValueError("Extension data too large")
        return value


class RuleInput(Input):
    project_id: str = Field(max_length=36)
    name: str = Field(min_length=1, max_length=100)
    device_id: str = Field(max_length=36)
    metric: str = Field(max_length=24)
    operator: Literal["gt", "lt", "offline"]
    threshold: float
    level: Literal["low", "medium", "high"] = "medium"
    enabled: bool = True

    @field_validator("threshold")
    @classmethod
    def finite(cls, value):
        if not math.isfinite(value):
            raise ValueError("Finite threshold required")
        return value


class NoteInput(Input):
    note: str = Field(min_length=1, max_length=1000)


class ChatInput(Input):
    project_id: str = Field(max_length=36)
    connection_id: str = Field(max_length=36)
    agent: str | None = Field(default=None, max_length=100)
    prompt: str = Field(min_length=1, max_length=4000)
    device_ids: list[str] = Field(default_factory=list, max_length=20)


TASK_CAP = {"sync": "sync", "report": "report", "ai_report": "report", "ai_warning": "configure"}


def available_agent(source, requested=None):
    agent = requested or source["selected_agent"]
    if not agent or not any(item["id"] == agent and item.get("available", True) for item in source["catalog"]):
        raise ValueError("选择的数字人不存在或已下架")
    return agent


def ai_answer(source, state, agent, prompt, context):
    result = request(source, state, "/ask", {"agent": agent, "prompt": prompt, "context": context})
    if (not isinstance(result, dict) or not isinstance(result.get("answer"), str)
            or len(result["answer"]) > 20000 or result.get("agent") != agent):
        raise ValueError("智能体响应不符合标准协议")
    # Persist only recognized fields; arbitrary model/platform objects are not executable.
    return {"agent": agent, "answer": result["answer"], "simulated": result.get("simulated") is True,
            "warning": result.get("warning") if type(result.get("warning")) is bool else None,
            "evidence_count": len(context["samples"])}


def task_validate(connection, actor, data):
    project_scope(connection, actor, data.project_id, TASK_CAP[data.kind])
    if data.kind == "sync":
        source = connection_for(connection, data.config.connection_id, actor, "source")
        if source["project_id"] != data.project_id or not data.config.products:
            raise ValueError("同步任务需选择同项目平台和产品")
        links = {row["external_id"]: row["product_id"] for row in connection.execute(select(
            models.product_links).where(models.product_links.c.connection_id == source["id"])).mappings()}
        if not set(data.config.products) <= links.keys() or len(set(data.config.products)) != len(data.config.products):
            raise ValueError("产品未绑定受审 schema 或选择重复")
        bound = set()
        for binding in data.config.formulas:
            key = (binding.product, binding.metric)
            if binding.product not in data.config.products or key in bound:
                raise ValueError("公式绑定产品错误或属性重复")
            bound.add(key)
            product, _ = product_tables(connection, links[binding.product])
            field = next((f for f in product["definition"]["metrics"] if f["name"] == binding.metric), None)
            formula = connection.execute(select(models.formulas.c.id).where(
                models.formulas.c.id == binding.formula_id, models.formulas.c.project_id == data.project_id)).first()
            if not formula or not field or field["type"] not in {"number", "integer"}:
                raise ValueError("只能给数值采样字段绑定本项目公式版本")
    else:
        if not data.config.device_ids or len(set(data.config.device_ids)) != len(data.config.device_ids):
            raise ValueError("报表/预警需选择不重复设备")
        query_samples(connection, actor, data.project_id, data.config.device_ids, latest=True)
        if data.kind != "report":
            source = connection_for(connection, data.config.connection_id, actor, "agent")
            if source["project_id"] != data.project_id or not data.config.prompt:
                raise ValueError("智能任务需同项目平台及分析要求")
            available_agent(source)


def rows_in_scope(connection, table, actor, project_id=None, private_owner=False):
    query = select(table)
    if project_id:
        project_scope(connection, actor, project_id)
        query = query.where(table.c.project_id == project_id)
    if actor["role"] != "superadmin":
        query = query.where(table.c.project_id.in_(select(models.projects.c.id).join(models.grants,
            models.projects.c.id == models.grants.c.project_id).where(
            models.grants.c.user_id == actor["id"], models.projects.c.customer_id == actor["customer_id"])))
        if private_owner:
            query = query.where(table.c.owner_id == actor["id"])
    return connection.execute(query.order_by(table.c.created_at.desc()).limit(200)).mappings().all()


def router(engine_dependency, actor_dependency, state):
    routes = APIRouter(prefix="/api")

    @routes.get("/connections")
    def connections(project_id: str | None = None, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [{k: row[k] for k in row if k != "encrypted_secret"} for row in rows_in_scope(
                connection, models.connections, user, project_id)]

    @routes.post("/connections", status_code=201)
    def create_connection(data: ConnectionInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            project_scope(connection, user, data.project_id, "configure")
            encrypted = state.cipher(create=False).encrypt(data.secret.get_secret_value().encode()).decode()
            values = data.model_dump(exclude={"secret"})
            values["encrypted_secret"] = encrypted
            temporary = {**values, "catalog": [], "selected_agent": None}
            path = "/avatars" if data.kind == "agent" else "/products"
            payload = request(temporary, state, path)
            items = validate_catalog(payload, data.kind)
            resource_id = connection.execute(insert(models.connections).values(**values,
                catalog=items, synced_at=models.now())).inserted_primary_key[0]
            if data.kind == "source":
                connection.execute(insert(models.sources).values(id=resource_id, kind="http", endpoint=data.url,
                                                               secret_ref=resource_id))
            record(connection, user, "connection.create", resource_id, kind=data.kind)
        return {"id": resource_id, "catalog": items}

    def validate_catalog(payload, kind):
        if not isinstance(payload, dict) or payload.get("next") or not isinstance(payload.get("items"), list) or len(payload["items"]) > 100:
            raise ValueError("数字人/产品列表分页或格式需适配")
        items = []
        for item in payload["items"]:
            if kind == "source":
                item = ProductSpec.model_validate(item).model_dump()
            else:
                if (not isinstance(item, dict) or not isinstance(item.get("id"), str) or
                        not 1 <= len(item["id"]) <= 100 or not isinstance(item.get("name"), str) or len(item["name"]) > 100):
                    raise ValueError("Invalid avatar")
                item = {"id": item["id"], "name": item["name"], "available": True}
            items.append(item)
        if len({item["id"] for item in items}) != len(items):
            raise ValueError("Duplicate external identifiers")
        return items

    @routes.post("/connections/{connection_id}/refresh")
    def refresh_connection(connection_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            source = connection_for(connection, connection_id, user, capability="configure")
            payload = request(source, state, "/avatars" if source["kind"] == "agent" else "/products")
            items = validate_catalog(payload, source["kind"])
            if source["kind"] == "agent":
                current_ids = {item["id"] for item in items}
                items += [{**item, "available": False} for item in source["catalog"] if item["id"] not in current_ids]
            connection.execute(update(models.connections).where(models.connections.c.id == connection_id).values(
                catalog=items, synced_at=models.now()))
            record(connection, user, "connection.refresh", connection_id)
        return {"items": items}

    @routes.put("/connections/{connection_id}")
    def edit_connection(connection_id: str, data: ConnectionInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            source = connection_for(connection, connection_id, user, capability="configure")
            if source["project_id"] != data.project_id or source["kind"] != data.kind:
                raise HTTPException(403, "接入不能改变项目或类型")
            if source["kind"] == "source" and (source["url"] != data.url or source["appid"] != data.appid):
                if connection.execute(select(models.product_links.c.id).where(
                    models.product_links.c.connection_id == connection_id)).first():
                    raise HTTPException(409, "已绑定设备来源不能原地换平台，请创建新的接入")
            values = data.model_dump(exclude={"secret"})
            values["encrypted_secret"] = state.cipher(create=False).encrypt(data.secret.get_secret_value().encode()).decode()
            catalog = validate_catalog(request(values, state, "/avatars" if data.kind == "agent" else "/products"), data.kind)
            connection.execute(update(models.connections).where(models.connections.c.id == connection_id).values(
                **values, catalog=catalog, synced_at=models.now(), selected_agent=None))
            record(connection, user, "connection.update", connection_id)
        return {"ok": True}

    @routes.delete("/connections/{connection_id}")
    def delete_connection(connection_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            source = connection_for(connection, connection_id, user, capability="configure")
            referenced = any(row["config"].get("connection_id") == connection_id for row in connection.execute(
                select(models.tasks).where(models.tasks.c.project_id == source["project_id"])).mappings())
            if referenced or connection.execute(select(models.conversations.c.id).where(
                models.conversations.c.connection_id == connection_id).limit(1)).first():
                raise HTTPException(409, "接入已被任务或会话引用，不允许删除历史")
            if connection.execute(select(models.devices.c.id).where(models.devices.c.source_id == connection_id).limit(1)).first():
                raise HTTPException(409, "接入已有设备，不能删除")
            connection.execute(delete(models.product_links).where(models.product_links.c.connection_id == connection_id))
            connection.execute(delete(models.connections).where(models.connections.c.id == connection_id))
            if source["kind"] == "source":
                connection.execute(delete(models.sources).where(models.sources.c.id == connection_id))
            record(connection, user, "connection.delete", connection_id)
        return {"ok": True}

    @routes.put("/connections/{connection_id}/agent")
    def select_agent(connection_id: str, data: AgentSelection, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            source = connection_for(connection, connection_id, user, "agent", "configure")
            available_agent(source, data.agent)
            connection.execute(update(models.connections).where(models.connections.c.id == connection_id).values(selected_agent=data.agent))
            record(connection, user, "connection.agent", connection_id, agent=data.agent)
        return {"ok": True}

    @routes.post("/connections/{connection_id}/products")
    def bind_product(connection_id: str, data: ProductBinding, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        if user["role"] != "superadmin":
            raise HTTPException(403, "只有超管可确认受审产品 schema 映射")
        with mutation(engine, user) as connection:
            source = connection_for(connection, connection_id, user, "source")
            declared = next((p for p in source["catalog"] if p["id"] == data.external_id), None)
            product, _ = product_tables(connection, data.product_id)
            if not declared:
                raise ValueError("来源产品未发现")
            for group in ("archive_fields", "metrics"):
                if declared[group] != product["definition"][group]:
                    raise ValueError("来源字段与已安装 schema 不一致，请生成并部署受审插件")
            where = (models.product_links.c.connection_id == connection_id) & (models.product_links.c.external_id == data.external_id)
            old = connection.execute(select(models.product_links).where(where)).mappings().first()
            if old and old["product_id"] != data.product_id:
                raise ValueError("已有产品映射不允许原地替换")
            if not old:
                connection.execute(insert(models.product_links).values(connection_id=connection_id, **data.model_dump()))
            record(connection, user, "product.bind", data.product_id)
        return {"ok": True}

    @routes.get("/products")
    def products(user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            rows = connection.execute(select(models.products).limit(200)).mappings()
            result = []
            for row in rows:
                try:
                    product_visible(connection, user, row["id"])
                    result.append(dict(row))
                except HTTPException:
                    continue
            return result

    @routes.get("/devices")
    def devices(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            project_scope(connection, user, project_id)
            rows = connection.execute(select(models.devices, models.device_details.c.name,
                models.device_details.c.location, models.device_details.c.latitude, models.device_details.c.longitude,
                models.device_details.c.source_values, models.device_details.c.local_values).outerjoin(
                models.device_details, models.devices.c.id == models.device_details.c.device_id).where(
                models.devices.c.project_id == project_id).limit(200)).mappings()
            return [dict(row) for row in rows]

    @routes.put("/devices/{device_id}")
    def update_device(device_id: str, data: DeviceInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            device = connection.execute(select(models.devices).where(models.devices.c.id == device_id)).mappings().one_or_none()
            if not device:
                raise HTTPException(404, "设备不存在")
            project_scope(connection, user, device["project_id"], "configure")
            connection.execute(update(models.device_details).where(models.device_details.c.device_id == device_id).values(
                **{**data.model_dump(), "latitude": str(data.latitude) if data.latitude is not None else None,
                   "longitude": str(data.longitude) if data.longitude is not None else None}))
            record(connection, user, "device.extension", device_id)
        return {"ok": True}

    @routes.get("/telemetry")
    def telemetry(project_id: str, device_ids: str = "", start: str | None = None, end: str | None = None,
                  latest: bool = False, limit: int = Query(default=500, ge=1, le=5000),
                  user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        ids = device_ids.split(",") if device_ids else None
        if ids and len(ids) > 100:
            raise ValueError("Too many devices")
        with engine.connect() as connection:
            return query_samples(connection, user, project_id, ids,
                timestamp(start) if start else None, timestamp(end) if end else None, latest, limit)

    @routes.post("/formulas", status_code=201)
    def create_formula(data: FormulaInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        parse(data.expression, data.parameters)
        with mutation(engine, user) as connection:
            project_scope(connection, user, data.project_id, "configure")
            family_id = data.family_id or secrets.token_hex(16)
            previous = connection.execute(select(models.formulas).where(
                models.formulas.c.family_id == family_id).order_by(models.formulas.c.version.desc())).mappings().first()
            if previous and previous["project_id"] != data.project_id:
                raise HTTPException(403, "公式系列不属于当前项目")
            resource_id = connection.execute(insert(models.formulas).values(**data.model_dump(exclude={"family_id"}),
                family_id=family_id, version=previous["version"] + 1 if previous else 1)).inserted_primary_key[0]
            record(connection, user, "formula.version", resource_id)
        return {"id": resource_id, "family_id": family_id}

    @routes.get("/formulas")
    def formulas(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.formulas, user, project_id)]

    @routes.post("/tasks", status_code=201)
    def create_task(data: TaskInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            task_validate(connection, user, data)
            if user["role"] == "user" and data.enabled:
                raise HTTPException(403, "普通用户不能启用共享定时任务")
            resource_id = connection.execute(insert(models.tasks).values(**data.model_dump(exclude={"config"}),
                owner_id=user["id"], config=data.config.model_dump())).inserted_primary_key[0]
            record(connection, user, "task.create", resource_id, kind=data.kind)
        return {"id": resource_id}

    @routes.put("/tasks/{task_id}")
    def edit_task(task_id: str, data: TaskInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.tasks).where(models.tasks.c.id == task_id)).mappings().first()
            if not old:
                raise HTTPException(404, "任务不存在")
            project_scope(connection, user, old["project_id"], TASK_CAP[old["kind"]])
            if user["role"] == "user" or old["project_id"] != data.project_id or old["kind"] != data.kind:
                raise HTTPException(403, "不能改变任务归属、种类或以普通用户编辑共享任务")
            task_validate(connection, user, data)
            connection.execute(update(models.tasks).where(models.tasks.c.id == task_id).values(
                **data.model_dump(exclude={"config"}), config=data.config.model_dump(), version=old["version"] + 1,
                next_run_at=models.now()))
            record(connection, user, "task.update", task_id)
        return {"ok": True}

    @routes.get("/tasks")
    def tasks(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.tasks, user, project_id,
                                                      private_owner=user["role"] == "user")]

    @routes.post("/tasks/{task_id}/run")
    def enqueue(task_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            task = connection.execute(select(models.tasks).where(models.tasks.c.id == task_id)).mappings().first()
            if not task:
                raise HTTPException(404, "任务不存在")
            project_scope(connection, user, task["project_id"], TASK_CAP[task["kind"]])
            if user["role"] == "user" and task["owner_id"] != user["id"]:
                raise HTTPException(403, "只能执行自己的报表任务")
            existing = connection.execute(select(models.runs.c.id).where(
                models.runs.c.task_id == task_id, models.runs.c.status.in_(["queued", "running"]))).first()
            if existing:
                raise HTTPException(409, "任务已排队或执行中")
            resource_id = connection.execute(insert(models.runs).values(task_id=task_id, task_version=task["version"],
                slot="manual:" + secrets.token_hex(16), status="queued")).inserted_primary_key[0]
            record(connection, user, "task.enqueue", task_id, run_id=resource_id)
        return {"id": resource_id, "status": "queued"}

    @routes.get("/tasks/{task_id}/runs")
    def task_runs(task_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            task = connection.execute(select(models.tasks).where(models.tasks.c.id == task_id)).mappings().first()
            if not task:
                raise HTTPException(404, "任务不存在")
            project_scope(connection, user, task["project_id"])
            if user["role"] == "user" and task["owner_id"] != user["id"]:
                raise HTTPException(403, "无权查看此任务")
            return [dict(row) for row in connection.execute(select(models.runs).where(
                models.runs.c.task_id == task_id).order_by(models.runs.c.created_at.desc()).limit(100)).mappings()]

    @routes.get("/panels")
    def panels(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.panels, user, project_id)
                    if row["visibility"] == "shared" or row["owner_id"] == user["id"] or user["role"] == "superadmin"]

    def validate_panel(connection, user, data):
        personal = data.kind == "curve" and data.visibility == "private"
        project_scope(connection, user, data.project_id, None if personal else "configure")
        if data.kind == "scene" and not data.config.device_ids:
            raise ValueError("场景需关联设备")
        if data.kind != "scene" and not data.config.series:
            raise ValueError("曲线/大屏需配置设备属性系列")
        ids = list(set(data.config.device_ids + [s.device_id for s in data.config.series]))
        query_samples(connection, user, data.project_id, ids, latest=True)
        for series in data.config.series:
            device = connection.execute(select(models.devices).where(models.devices.c.id == series.device_id)).mappings().one()
            product, _ = product_tables(connection, device["product_id"])
            if not any(f["name"] == series.metric and f["type"] in {"number", "integer"} for f in product["definition"]["metrics"]):
                raise ValueError("曲线系列需数值测点")

    @routes.post("/panels", status_code=201)
    def create_panel(data: PanelInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            validate_panel(connection, user, data)
            resource_id = connection.execute(insert(models.panels).values(**data.model_dump(exclude={"config"}),
                config=data.config.model_dump(), owner_id=user["id"])).inserted_primary_key[0]
            record(connection, user, "panel.create", resource_id)
        return {"id": resource_id}

    @routes.put("/panels/{panel_id}")
    def update_panel(panel_id: str, data: PanelInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.panels).where(models.panels.c.id == panel_id)).mappings().one_or_none()
            if not old or old["project_id"] != data.project_id:
                raise HTTPException(404, "面板不存在或不可转移项目")
            if old["visibility"] == "private" and old["owner_id"] != user["id"] and user["role"] != "superadmin":
                raise HTTPException(403, "无权修改他人个人面板")
            project_scope(connection, user, old["project_id"], None if old["visibility"] == "private" and old["kind"] == "curve" else "configure")
            validate_panel(connection, user, data)
            connection.execute(update(models.panels).where(models.panels.c.id == panel_id).values(
                **data.model_dump(exclude={"config"}), config=data.config.model_dump(), version=old["version"] + 1))
            record(connection, user, "panel.update", panel_id)
        return {"ok": True}

    @routes.delete("/panels/{panel_id}")
    def delete_panel(panel_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            old = connection.execute(select(models.panels).where(models.panels.c.id == panel_id)).mappings().one_or_none()
            if not old:
                raise HTTPException(404, "面板不存在")
            personal = old["kind"] == "curve" and old["visibility"] == "private" and old["owner_id"] == user["id"]
            project_scope(connection, user, old["project_id"], None if personal else "configure")
            if old["visibility"] == "private" and not personal and user["role"] != "superadmin":
                raise HTTPException(403, "不能删除他人个人面板")
            connection.execute(delete(models.shares).where(models.shares.c.panel_id == panel_id))
            connection.execute(delete(models.panels).where(models.panels.c.id == panel_id))
            record(connection, user, "panel.delete", panel_id)
        return {"ok": True}

    @routes.post("/panels/{panel_id}/share")
    def share_panel(panel_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            panel = connection.execute(select(models.panels).where(models.panels.c.id == panel_id)).mappings().one_or_none()
            if not panel or panel["kind"] != "dashboard" or panel["visibility"] != "shared":
                raise HTTPException(400, "仅项目共享大屏支持限时分享")
            project_scope(connection, user, panel["project_id"], "configure")
            token = secrets.token_urlsafe(32)
            connection.execute(insert(models.shares).values(token_hash=digest(token), panel_id=panel_id,
                issuer_id=user["id"], expires_at=models.now() + timedelta(hours=1)))
            record(connection, user, "panel.share", panel_id)
        return {"token": token, "expires_in": 3600}

    @routes.delete("/panels/{panel_id}/shares")
    def revoke_shares(panel_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            panel = connection.execute(select(models.panels).where(models.panels.c.id == panel_id)).mappings().one_or_none()
            if not panel:
                raise HTTPException(404, "面板不存在")
            project_scope(connection, user, panel["project_id"], "configure")
            connection.execute(update(models.shares).where(models.shares.c.panel_id == panel_id).values(revoked=True))
            record(connection, user, "panel.share_revoke", panel_id)
        return {"ok": True}

    @routes.get("/shared-panel")
    def shared_panel(x_panel_share: str = Header(default=""), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            share = connection.execute(select(models.shares).where(models.shares.c.token_hash == digest(x_panel_share),
                models.shares.c.expires_at > models.now(), models.shares.c.revoked.is_(False))).mappings().one_or_none()
            if not share:
                raise HTTPException(403, "分享已失效")
            issuer = connection.execute(select(models.users).where(models.users.c.id == share["issuer_id"])).mappings().one()
            panel = connection.execute(select(models.panels).where(models.panels.c.id == share["panel_id"])).mappings().one()
            if not issuer["enabled"]:
                raise HTTPException(403, "分享者账号已停用")
            project_scope(connection, issuer, panel["project_id"], "configure")
            if panel["kind"] != "dashboard" or panel["visibility"] != "shared":
                raise HTTPException(403, "面板不再允许分享")
            ids = list(set(panel["config"]["device_ids"] + [s["device_id"] for s in panel["config"]["series"]]))
            latest = query_samples(connection, issuer, panel["project_id"], ids, latest=True)
            return {"name": panel["name"], "config": panel["config"], "samples": latest["items"]}

    @routes.post("/alarm-rules", status_code=201)
    def create_rule(data: RuleInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            project_scope(connection, user, data.project_id, "alarm")
            query_samples(connection, user, data.project_id, [data.device_id], latest=True)
            device = connection.execute(select(models.devices).where(models.devices.c.id == data.device_id)).mappings().one()
            product, _ = product_tables(connection, device["product_id"])
            if data.operator == "offline" and not 1 <= data.threshold <= 10080:
                raise ValueError("离线超时需要 1–10080 分钟")
            if data.operator != "offline" and not any(f["name"] == data.metric and f["type"] in {"number", "integer"} for f in product["definition"]["metrics"]):
                raise ValueError("告警规则仅支持数值采样属性")
            resource_id = connection.execute(insert(models.alarm_rules).values(
                **{**data.model_dump(), "threshold": str(data.threshold)})).inserted_primary_key[0]
            record(connection, user, "alarm.rule", resource_id)
        return {"id": resource_id}

    @routes.get("/alarm-rules")
    def rules(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.alarm_rules, user, project_id)]

    @routes.put("/alarm-rules/{rule_id}")
    def update_rule(rule_id: str, data: RuleInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            rule = connection.execute(select(models.alarm_rules).where(models.alarm_rules.c.id == rule_id)).mappings().one_or_none()
            if not rule or rule["project_id"] != data.project_id or rule["device_id"] != data.device_id or rule["metric"] != data.metric:
                raise HTTPException(400, "规则归属、设备和属性不能原地改变，请停用后新建")
            project_scope(connection, user, data.project_id, "alarm")
            if data.operator == "offline" and not 1 <= data.threshold <= 10080:
                raise ValueError("离线超时需要 1–10080 分钟")
            connection.execute(update(models.alarm_rules).where(models.alarm_rules.c.id == rule_id).values(
                **{**data.model_dump(), "threshold": str(data.threshold)}))
            record(connection, user, "alarm.rule_update", rule_id)
        return {"ok": True}

    @routes.get("/alarm-events")
    def events(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            rows = rows_in_scope(connection, models.alarm_events, user, project_id)
            result = []
            for row in rows:
                notifications = connection.execute(select(models.notifications).where(
                    models.notifications.c.event_id == row["id"])).mappings()
                actions = connection.execute(select(models.alarm_actions).where(
                    models.alarm_actions.c.event_id == row["id"])).mappings()
                result.append({**dict(row), "notifications": [dict(r) for r in notifications], "actions": [dict(r) for r in actions]})
            return result

    @routes.post("/alarm-events/{event_id}/actions")
    def handle_alarm(event_id: str, data: NoteInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with mutation(engine, user) as connection:
            event = connection.execute(select(models.alarm_events).where(models.alarm_events.c.id == event_id)).mappings().one_or_none()
            if not event:
                raise HTTPException(404, "告警不存在")
            project_scope(connection, user, event["project_id"], "alarm")
            connection.execute(insert(models.alarm_actions).values(event_id=event_id, actor_id=user["id"], note=data.note))
            connection.execute(update(models.alarm_events).where(models.alarm_events.c.id == event_id).values(handled=True))
            record(connection, user, "alarm.handle", event_id)
        return {"ok": True}

    @routes.get("/reports")
    def reports(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.reports, user, project_id,
                private_owner=user["role"] == "user")]

    @routes.get("/reports/{report_id}/download")
    def download_report(report_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            report = connection.execute(select(models.reports).where(models.reports.c.id == report_id)).mappings().one_or_none()
            if not report:
                raise HTTPException(404, "报表不存在")
            project_scope(connection, user, report["project_id"], "report")
            if user["role"] == "user" and report["owner_id"] != user["id"]:
                raise HTTPException(403, "不能下载他人报表")
            buffer = io.StringIO()
            writer = csv.writer(buffer)
            writer.writerow(["device", "time", "metric", "value", "unit", "quality"])
            for row in report["content"]["samples"]:
                for metric, value in row["values"].items():
                    cells = [row["external_id"], row["time"], metric, value, row["units"][metric], row["quality"]]
                    writer.writerow(["'" + str(cell) if isinstance(cell, str) and cell.lstrip().startswith(("=", "+", "-", "@")) else cell for cell in cells])
            if report["content"].get("analysis"):
                writer.writerow(["analysis", "'" + report["content"]["analysis"]["answer"]])
            return Response("\ufeff" + buffer.getvalue(), media_type="text/csv",
                            headers={"Content-Disposition": 'attachment; filename="report.csv"'})

    @routes.post("/agent/ask")
    def ask_agent(data: ChatInput, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            project_scope(connection, user, data.project_id)
            source = connection_for(connection, data.connection_id, user, "agent")
            if source["project_id"] != data.project_id:
                raise HTTPException(403, "智能体接入不属于当前项目")
            agent = available_agent(source, data.agent)
            context = query_samples(connection, user, data.project_id, data.device_ids or None, latest=True)
            source = dict(source)
        result = ai_answer(source, state, agent, data.prompt, {"samples": context["items"], "project_id": data.project_id})
        with mutation(engine, user) as connection:
            project_scope(connection, user, data.project_id)
            resource_id = connection.execute(insert(models.conversations).values(project_id=data.project_id,
                owner_id=user["id"], connection_id=source["id"], agent=agent, prompt=data.prompt,
                answer=result)).inserted_primary_key[0]
            record(connection, user, "agent.ask", resource_id)
        return {"id": resource_id, **result}

    @routes.get("/agent/conversations")
    def conversations(project_id: str, user=Depends(actor_dependency), engine=Depends(engine_dependency)):
        with engine.connect() as connection:
            return [dict(row) for row in rows_in_scope(connection, models.conversations, user, project_id, private_owner=True)]

    return routes
