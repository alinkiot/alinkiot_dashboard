import ast
import math
import operator

OPERATIONS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
              ast.Div: operator.truediv, ast.Mod: operator.mod}


def parse(expression, parameters):
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as error:
        raise ValueError("Invalid arithmetic expression") from error
    nodes = list(ast.walk(tree))
    if len(nodes) > 80:
        raise ValueError("Formula is too complex")
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.UAdd, ast.USub, ast.Name,
               ast.Load, ast.Constant, *OPERATIONS)
    if any(not isinstance(node, allowed) for node in nodes):
        raise ValueError("Only arithmetic with value and numeric parameters is supported")
    for node in nodes:
        if isinstance(node, ast.Name) and node.id not in {"value", *parameters}:
            raise ValueError("Unknown formula variable")
        if isinstance(node, ast.Constant) and (type(node.value) not in (int, float) or abs(node.value) > 1e18 or not math.isfinite(node.value)):
            raise ValueError("Invalid numeric constant")
    if "value" in parameters or len(parameters) > 10:
        raise ValueError("Invalid parameters")
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in parameters.values()):
        raise ValueError("Parameters must be finite numbers")
    return tree


def compute(expression, parameters, value):
    tree = parse(expression, parameters)
    variables = {"value": value, **parameters}

    def evaluate(node):
        if isinstance(node, ast.Expression):
            return evaluate(node.body)
        if isinstance(node, ast.Name):
            return variables[node.id]
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.UnaryOp):
            return (-1 if isinstance(node.op, ast.USub) else 1) * evaluate(node.operand)
        return OPERATIONS[type(node.op)](evaluate(node.left), evaluate(node.right))

    result = evaluate(tree)
    if type(result) not in (int, float) or not math.isfinite(result) or abs(result) > 1e18:
        raise ValueError("Formula result out of range")
    return result
