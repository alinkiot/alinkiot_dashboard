import os
import secrets
from datetime import timedelta
from uuid import uuid4

from sqlalchemy import insert, select, update

from . import models
from .data_service import apply_alarm, persist_sync, query_samples
from .mock_platform import AVATARS, devices, products
from .security import hash_password


def create_demo(connection, state, owner_id):
    prior = connection.execute(select(models.audit.c.detail).where(
        models.audit.c.action == "demo.seed")).scalar_one_or_none()
    if prior:
        return {"created": False, "project_id": prior["project_id"], "accounts": []}
    product = connection.execute(select(models.products).where(
        models.products.c.plugin_id == "demo_meter", models.products.c.code == "water_meter")).mappings().first()
    if not product:
        raise ValueError("演示种子需要已安装 demo_meter 水表插件")
    customer = connection.execute(insert(models.customers).values(name="【演示】乐图智慧客户")).inserted_primary_key[0]
    project = connection.execute(insert(models.projects).values(
        name="【演示】智慧泵房", customer_id=customer)).inserted_primary_key[0]
    accounts = []
    for role, capabilities in (("admin", ["export", "report", "configure", "sync", "alarm"]),
                               ("user", ["export", "report"])):
        username = "demo_" + role + "_" + secrets.token_hex(4)
        password = secrets.token_urlsafe(18)
        user = connection.execute(insert(models.users).values(username=username,
            password_hash=hash_password(password), role=role, customer_id=customer)).inserted_primary_key[0]
        connection.execute(insert(models.grants).values(user_id=user, project_id=project,
            capabilities=capabilities))
        accounts.append({"username": username, "password": password, "role": role})
    cipher = state.cipher()
    secret = cipher.encrypt(os.environ.get("ALINK_MOCK_SECRET", "demo-only").encode()).decode()
    source_id = agent_id = None
    for kind, catalog in (("source", products()["items"]), ("agent", AVATARS)):
        identity = str(uuid4())
        connection.execute(insert(models.connections).values(id=identity, project_id=project,
            kind=kind, name="【演示】" + ("本地设备平台" if kind == "source" else "本地智能体平台"),
            url="http://127.0.0.1:58240", appid=os.environ.get("ALINK_MOCK_APPID", "demo"),
            encrypted_secret=secret, catalog=catalog,
            selected_agent="analyst" if kind == "agent" else None))
        if kind == "source":
            source_id = identity
            connection.execute(insert(models.sources).values(id=identity, kind="http",
                endpoint="http://127.0.0.1:58240", secret_ref=identity))
            connection.execute(insert(models.product_links).values(connection_id=identity,
                external_id="water_meter", product_id=product["id"]))
        else:
            agent_id = identity
    formula = connection.execute(insert(models.formulas).values(family_id=str(uuid4()),
        version=1, project_id=project, name="【演示】流量除十", expression="value / factor",
        parameters={"factor": 10}, unit="m³/h")).inserted_primary_key[0]
    sync_config = {"connection_id": source_id, "products": ["water_meter"],
                   "formulas": [{"product": "water_meter", "metric": "flow_m3h", "formula_id": formula}]}
    sync = connection.execute(insert(models.tasks).values(project_id=project, owner_id=owner_id,
        kind="sync", name="【演示】水表同步（默认关闭）", interval_minutes=5,
        enabled=False, config=sync_config)).inserted_primary_key[0]
    now = models.now().replace(microsecond=0)
    points = []
    for step in range(24):
        stamp = (now - timedelta(minutes=(23 - step) * 5)).isoformat() + "Z"
        for index in range(2):
            external = f"water-00{index + 1}"
            points.append({"device": external, "key": f"seed:{external}:{step}", "time": stamp,
                "values": {"flow_m3h": (120 if index == 0 else 80) + ((step % 6) - 3) * 2,
                           "total_m3": (3600 if index == 0 else 4800) + step * 5, "running": True}})
    source = connection.execute(select(models.connections).where(
        models.connections.c.id == source_id)).mappings().one()
    task = connection.execute(select(models.tasks).where(models.tasks.c.id == sync)).mappings().one()
    result = persist_sync(connection, task, source, devices()["items"],
        {"items": points, "cursor": "", "simulated": True})
    connection.execute(insert(models.runs).values(task_id=sync, task_version=1,
        slot="seed", status="success", finished_at=now, result={**result, "seeded": True}))
    device_rows = connection.execute(select(models.devices).where(
        models.devices.c.project_id == project).order_by(models.devices.c.external_id)).mappings().all()
    ids = [row["id"] for row in device_rows]
    for index, device_id in enumerate(ids):
        connection.execute(update(models.device_details).where(
            models.device_details.c.device_id == device_id).values(location="【演示】泵房",
                latitude=str(30.27 + index * .001), longitude=str(120.15 + index * .001),
                local_values={"simulated": True, "seeded": True}))
    series = [{"device_id": identity, "metric": "flow_m3h"} for identity in ids]
    for kind, name in (("scene", "泵房场景"), ("curve", "水表流量曲线"), ("dashboard", "泵房项目大屏")):
        connection.execute(insert(models.panels).values(project_id=project, owner_id=owner_id,
            kind=kind, name="【演示】" + name, visibility="shared",
            config={"device_ids": ids, "series": series, "html": ""}))
    actor = connection.execute(select(models.users).where(models.users.c.id == owner_id)).mappings().one()
    context = query_samples(connection, actor, project, ids)
    for kind, title in (("report", "统计报表"), ("ai_report", "智能报表"), ("ai_warning", "智能预警")):
        task_id = connection.execute(insert(models.tasks).values(project_id=project, owner_id=owner_id,
            kind=kind, name="【演示】" + title, interval_minutes=60, enabled=False,
            config={"device_ids": ids, "window_minutes": 180,
                    "connection_id": None if kind == "report" else agent_id,
                    "prompt": "分析流量与运行状态", "level": "high"})).inserted_primary_key[0]
        if kind == "report":
            run = connection.execute(insert(models.runs).values(task_id=task_id, task_version=1,
                slot="seed", status="success", finished_at=now, result={"seeded": True})).inserted_primary_key[0]
            report = connection.execute(insert(models.reports).values(project_id=project, owner_id=owner_id,
                run_id=run, name="【演示】泵房流量报表", kind="report",
                content={"samples": context["items"], "analysis": None, "simulated": True,
                         "seeded": True, "window_minutes": 180, "task_version": 1})).inserted_primary_key[0]
            connection.execute(update(models.runs).where(models.runs.c.id == run).values(
                result={"report_id": report, "samples": len(points), "seeded": True, "simulated": True}))
    connection.execute(insert(models.alarm_rules).values(project_id=project,
        name="【演示】一号水表高流量", device_id=ids[0], metric="flow_m3h",
        operator="gt", threshold="10", level="high", enabled=False))
    rule_id = connection.execute(select(models.alarm_rules.c.id).where(
        models.alarm_rules.c.project_id == project)).scalar_one()
    latest = next(row for row in query_samples(connection, actor, project, latest=True)["items"]
                  if row["device_id"] == ids[0])
    apply_alarm(connection, project, rule_id, "device_rule", "【演示】一号水表高流量", "high", True,
        {"device_id": ids[0], "metric": "flow_m3h", "value": latest["values"]["flow_m3h"],
         "time": latest["time"], "simulated": True, "seeded": True})
    connection.execute(insert(models.audit).values(actor_id=owner_id, action="demo.seed",
        detail={"customer_id": customer, "project_id": project, "simulated": True,
                "devices": 2, "samples": len(points)}))
    return {"created": True, "project_id": project, "devices": 2, "samples": len(points),
            "accounts": accounts}


def seed_existing(engine, state):
    from .installer import database_lock
    with engine.connect() as connection, database_lock(connection):
        installation = connection.execute(select(models.installation)).mappings().first()
        if not installation or installation["core_version"] < 2:
            raise ValueError("请先安装或执行 alinkiot upgrade")
        connection.commit()
        with connection.begin():
            connection.execute(select(models.installation.c.id).where(
                models.installation.c.id == 1).with_for_update()).first()
            owner = connection.execute(select(models.users.c.id).where(
                models.users.c.role == "superadmin", models.users.c.enabled.is_(True))).scalar()
            if not owner:
                raise ValueError("没有启用的超管账号")
            return create_demo(connection, state, owner)
