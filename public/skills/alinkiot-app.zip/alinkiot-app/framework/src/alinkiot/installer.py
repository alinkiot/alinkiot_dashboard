from contextlib import contextmanager
from hashlib import sha256

from sqlalchemy import inspect, insert, select, text
from sqlalchemy.exc import OperationalError

from . import models
from .plugins import apply
from .security import hash_password


class DatabaseSetupError(ValueError):
    pass


def check_mysql(connection):
    version = connection.execute(text("SELECT VERSION()")).scalar()
    if "mariadb" in version.lower() or int(version.split(".")[0]) < 8:
        raise DatabaseSetupError("需要 MySQL 8 或更高版本，不支持 MariaDB")


def prepare_database(settings, *, create=False):
    """Test without writes; create only when MySQL reports an unknown database."""
    engine = settings.engine()
    try:
        with engine.connect() as connection:
            check_mysql(connection)
        return True
    except OperationalError as error:
        if error.orig.args[0] != 1049:
            raise
    finally:
        engine.dispose()
    server = settings.engine(server_only=True)
    try:
        with server.connect() as connection:
            check_mysql(connection)
            if create:
                name = connection.dialect.identifier_preparer.quote_identifier(settings.database)
                try:
                    connection.execute(text(f"CREATE DATABASE IF NOT EXISTS {name} CHARACTER SET utf8mb4"))
                    connection.commit()
                except OperationalError as error:
                    if error.orig.args[0] in (1044, 1045, 1142):
                        raise DatabaseSetupError("自动建库失败：数据库账户没有建库权限，请授权或手动创建目标库后重试") from error
                    raise
        return False
    finally:
        server.dispose()


def installed(engine) -> bool:
    with engine.connect() as connection:
        return inspect(connection).has_table(models.installation.name) and bool(
            connection.execute(select(models.installation.c.id).where(models.installation.c.id == 1)).first()
        )


@contextmanager
def database_lock(connection):
    if connection.dialect.name != "mysql":
        yield
        return
    name = "alinkiot:" + sha256(connection.engine.url.database.encode()).hexdigest()[:48]
    if connection.execute(text("SELECT GET_LOCK(:name, 5)"), {"name": name}).scalar() != 1:
        raise ValueError("Installation is already running")
    connection.commit()
    try:
        yield
    finally:
        connection.rollback()
        connection.execute(text("SELECT RELEASE_LOCK(:name)"), {"name": name})
        connection.commit()


def install(engine, manifests, username, password, *, seed_demo=False, state=None):
    if seed_demo and state is None:
        raise ValueError("Demo seed requires encrypted local state")
    with engine.connect() as connection, database_lock(connection):
        if inspect(connection).has_table(models.installation.name):
            if connection.execute(select(models.installation.c.id)).first():
                raise ValueError("Database is already installed")
        if inspect(connection).has_table(models.users.name):
            if connection.execute(select(models.users.c.id)).first():
                raise ValueError("Existing accounts require manual recovery")
        connection.commit()
        models.metadata.create_all(connection)
        connection.commit()
        apply(connection, manifests)
        with connection.begin():
            owner_id = connection.execute(insert(models.users).values(
                username=username, password_hash=hash_password(password),
                role="superadmin", enabled=True)).inserted_primary_key[0]
            demo = None
            if seed_demo:
                from .seed import create_demo
                demo = create_demo(connection, state, owner_id)
            connection.execute(insert(models.audit).values(
                action="core.install", detail={"plugins": [m.id for m in manifests]}))
            connection.execute(insert(models.installation).values(id=1, core_version=2))
        return demo


def upgrade(engine):
    with engine.connect() as connection, database_lock(connection):
        if not connection.execute(select(models.installation.c.id)).first():
            raise ValueError("请先安装")
        connection.commit()
        models.metadata.create_all(connection)
        connection.commit()
        with connection.begin():
            connection.execute(models.installation.update().where(models.installation.c.id == 1).values(core_version=2))
            connection.execute(insert(models.audit).values(action="core.upgrade", detail={"version": 2}))


def install_plugins(engine, manifests, actor_id):
    with engine.connect() as connection, database_lock(connection):
        apply(connection, manifests)
        with connection.begin():
            connection.execute(insert(models.audit).values(
                actor_id=actor_id, action="plugins.install",
                detail={"plugins": [m.id for m in manifests]}))
