"""AlinkIoT core and installation framework."""
