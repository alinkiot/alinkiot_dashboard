import os
from datetime import datetime, timezone

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="AlinkIoT explicitly simulated HTTP platform")
AVATARS = [{"id": "diagnostician", "name": "模拟诊断员"}, {"id": "analyst", "name": "模拟分析员"},
           {"id": "reporter", "name": "模拟报表员"}]


def auth(x_app_id: str = Header(default=""), x_app_secret: str = Header(default="")):
    if x_app_id != os.environ.get("ALINK_MOCK_APPID", "demo") or x_app_secret != os.environ.get("ALINK_MOCK_SECRET", "demo-only"):
        raise HTTPException(401, "模拟平台鉴权失败")


@app.get("/products", dependencies=[Depends(auth)])
def products():
    return {"simulated": True, "items": [{"id": "water_meter", "name": "模拟水表",
        "archive_fields": [{"name": "serial_number", "type": "text", "length": 100},
                           {"name": "diameter_mm", "type": "integer", "unit": "mm"}],
        "metrics": [{"name": "flow_m3h", "type": "number", "unit": "m³/h"},
                    {"name": "total_m3", "type": "number", "unit": "m³"},
                    {"name": "running", "type": "boolean"}]}], "next": None}


@app.get("/devices", dependencies=[Depends(auth)])
def devices():
    return {"simulated": True, "items": [{"id": "water-001", "product": "water_meter", "name": "模拟一号水表",
        "archive": {"serial_number": "DEMO001", "diameter_mm": 50}},
        {"id": "water-002", "product": "water_meter", "name": "模拟二号水表",
         "archive": {"serial_number": "DEMO002", "diameter_mm": 80}}], "next": None}


@app.get("/samples", dependencies=[Depends(auth)])
def samples(cursor: str = ""):
    stamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    return {"simulated": True, "cursor": stamp, "next": None, "items": [
        {"device": "water-001", "key": "water-001:" + stamp, "time": stamp,
         "values": {"flow_m3h": 120.0, "total_m3": 3600.0, "running": True}},
        {"device": "water-002", "key": "water-002:" + stamp, "time": stamp,
         "values": {"flow_m3h": 80.0, "total_m3": 4800.0, "running": True}}]}


@app.get("/avatars", dependencies=[Depends(auth)])
def avatars():
    return {"simulated": True, "items": AVATARS, "next": None}


class Ask(BaseModel):
    agent: str = Field(max_length=100)
    prompt: str = Field(max_length=4000)
    context: dict


@app.post("/ask", dependencies=[Depends(auth)])
def ask(data: Ask):
    if data.agent not in {a["id"] for a in AVATARS}:
        raise HTTPException(404, "数字人不存在")
    count = len(data.context.get("samples", []))
    warning = any(float(row.get("values", {}).get("flow_m3h") or 0) > 10 for row in data.context.get("samples", []))
    return {"simulated": True, "agent": data.agent,
            "answer": f"【模拟 HTTP 智能体，不是真实模型结论】已读取 {count} 条采样；请核对流量与运行状态。",
            "warning": warning, "evidence_count": count}
