from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import (
    JSON, Boolean, Column, DateTime, ForeignKey, Integer, MetaData, String, Table,
    UniqueConstraint,
)

metadata = MetaData()


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def identity():
    return [
        Column("id", String(36), primary_key=True, default=lambda: str(uuid4())),
        Column("created_at", DateTime, nullable=False, default=now),
    ]


customers = Table("customers", metadata, *identity(),
                  Column("name", String(100), nullable=False),
                  Column("enabled", Boolean, nullable=False, default=True))
users = Table("users", metadata, *identity(),
              Column("customer_id", String(36), ForeignKey("customers.id")),
              Column("username", String(80), nullable=False, unique=True),
              Column("password_hash", String(256), nullable=False),
              Column("role", String(24), nullable=False),
              Column("enabled", Boolean, nullable=False, default=True))
projects = Table("projects", metadata, *identity(),
                 Column("customer_id", String(36), ForeignKey("customers.id")),
                 Column("name", String(100), nullable=False),
                 Column("timezone", String(64), nullable=False, default="Asia/Shanghai"))
grants = Table("project_grants", metadata, *identity(),
               Column("user_id", String(36), ForeignKey("users.id"), nullable=False),
               Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
               Column("capabilities", JSON, nullable=False),
               UniqueConstraint("user_id", "project_id"))
sources = Table("data_sources", metadata, *identity(),
                Column("kind", String(32), nullable=False),
                Column("endpoint", String(500), nullable=False),
                Column("secret_ref", String(100)))
products = Table("products", metadata, *identity(),
                 Column("plugin_id", String(24), nullable=False),
                 Column("code", String(24), nullable=False),
                 Column("name", String(100), nullable=False),
                 Column("schema_version", Integer, nullable=False),
                 Column("archive_table", String(64), nullable=False),
                 Column("telemetry_table", String(64), nullable=False),
                 Column("definition", JSON, nullable=False),
                 UniqueConstraint("plugin_id", "code"))
devices = Table("device_registry", metadata, *identity(),
                Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                Column("product_id", String(36), ForeignKey("products.id"), nullable=False),
                Column("source_id", String(36), ForeignKey("data_sources.id")),
                Column("external_id", String(100), nullable=False),
                UniqueConstraint("source_id", "external_id"))
jobs = Table("job_definitions", metadata, *identity(),
             Column("project_id", String(36), ForeignKey("projects.id")),
             Column("kind", String(32), nullable=False),
             Column("version", Integer, nullable=False, default=1),
             Column("enabled", Boolean, nullable=False, default=False),
             Column("config", JSON, nullable=False))
audit = Table("audit_logs", metadata, *identity(),
              Column("actor_id", String(36), ForeignKey("users.id")),
              Column("action", String(80), nullable=False),
              Column("detail", JSON, nullable=False))
sessions = Table("user_sessions", metadata,
                 Column("token_hash", String(64), primary_key=True),
                 Column("user_id", String(36), ForeignKey("users.id"), nullable=False),
                 Column("expires_at", DateTime, nullable=False))
login_limits = Table("login_limits", metadata,
                     Column("key", String(64), primary_key=True),
                     Column("attempts", Integer, nullable=False),
                     Column("window_start", DateTime, nullable=False))
plugins = Table("plugin_registry", metadata,
                Column("id", String(24), primary_key=True),
                Column("version", Integer, nullable=False),
                Column("digest", String(64), nullable=False),
                Column("manifest", JSON, nullable=False),
                Column("installed_at", DateTime, nullable=False, default=now))
installation = Table("installation_state", metadata,
                     Column("id", Integer, primary_key=True),
                     Column("core_version", Integer, nullable=False),
                     Column("installed_at", DateTime, nullable=False, default=now))

connections = Table("platform_connections", metadata, *identity(),
                    Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                    Column("kind", String(16), nullable=False),
                    Column("name", String(100), nullable=False),
                    Column("url", String(500), nullable=False),
                    Column("appid", String(100), nullable=False),
                    Column("encrypted_secret", String(2000), nullable=False),
                    Column("selected_agent", String(100)),
                    Column("catalog", JSON, nullable=False, default=list),
                    Column("synced_at", DateTime))
product_links = Table("source_product_links", metadata, *identity(),
                      Column("connection_id", String(36), ForeignKey("platform_connections.id"), nullable=False),
                      Column("external_id", String(24), nullable=False),
                      Column("product_id", String(36), ForeignKey("products.id"), nullable=False),
                      UniqueConstraint("connection_id", "external_id"))
device_details = Table("device_extensions", metadata,
                       Column("device_id", String(36), ForeignKey("device_registry.id"), primary_key=True),
                       Column("name", String(100), nullable=False),
                       Column("location", String(200), nullable=False, default=""),
                       Column("latitude", String(30)),
                       Column("longitude", String(30)),
                       Column("source_values", JSON, nullable=False, default=dict),
                       Column("local_values", JSON, nullable=False, default=dict))
formulas = Table("formula_versions", metadata, *identity(),
                 Column("family_id", String(36), nullable=False),
                 Column("version", Integer, nullable=False),
                 Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                 Column("name", String(100), nullable=False),
                 Column("expression", String(300), nullable=False),
                 Column("parameters", JSON, nullable=False),
                 Column("unit", String(20), nullable=False),
                 UniqueConstraint("family_id", "version"))
tasks = Table("scheduled_tasks", metadata, *identity(),
              Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
              Column("owner_id", String(36), ForeignKey("users.id"), nullable=False),
              Column("kind", String(24), nullable=False),
              Column("name", String(100), nullable=False),
              Column("enabled", Boolean, nullable=False, default=False),
              Column("version", Integer, nullable=False, default=1),
              Column("interval_minutes", Integer, nullable=False),
              Column("next_run_at", DateTime, nullable=False, default=now),
              Column("config", JSON, nullable=False),
              Column("cursor", String(100), nullable=False, default=""))
runs = Table("task_runs", metadata, *identity(),
             Column("task_id", String(36), ForeignKey("scheduled_tasks.id"), nullable=False),
             Column("task_version", Integer, nullable=False),
             Column("slot", String(100), nullable=False),
             Column("status", String(16), nullable=False),
             Column("finished_at", DateTime),
             Column("result", JSON, nullable=False, default=dict),
             Column("error", String(300)),
             UniqueConstraint("task_id", "slot"))
panels = Table("workspace_panels", metadata, *identity(),
               Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
               Column("owner_id", String(36), ForeignKey("users.id"), nullable=False),
               Column("kind", String(16), nullable=False),
               Column("name", String(100), nullable=False),
               Column("visibility", String(16), nullable=False),
               Column("config", JSON, nullable=False),
               Column("version", Integer, nullable=False, default=1))
alarm_rules = Table("alarm_rules", metadata, *identity(),
                    Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                    Column("name", String(100), nullable=False),
                    Column("device_id", String(36), ForeignKey("device_registry.id"), nullable=False),
                    Column("metric", String(24), nullable=False),
                    Column("operator", String(8), nullable=False),
                    Column("threshold", String(40), nullable=False),
                    Column("level", String(16), nullable=False),
                    Column("enabled", Boolean, nullable=False, default=True))
alarm_events = Table("alarm_events", metadata, *identity(),
                     Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                     Column("identity_key", String(150), nullable=False, unique=True),
                     Column("source", String(24), nullable=False),
                     Column("name", String(100), nullable=False),
                     Column("level", String(16), nullable=False),
                     Column("active", Boolean, nullable=False),
                     Column("last_seen", DateTime, nullable=False, default=now),
                     Column("handled", Boolean, nullable=False, default=False),
                     Column("evidence", JSON, nullable=False))
alarm_actions = Table("alarm_actions", metadata, *identity(),
                      Column("event_id", String(36), ForeignKey("alarm_events.id"), nullable=False),
                      Column("actor_id", String(36), ForeignKey("users.id"), nullable=False),
                      Column("note", String(1000), nullable=False))
notifications = Table("notification_records", metadata, *identity(),
                      Column("event_id", String(36), ForeignKey("alarm_events.id"), nullable=False),
                      Column("channel", String(24), nullable=False),
                      Column("status", String(24), nullable=False),
                      Column("message", String(500), nullable=False))
reports = Table("generated_reports", metadata, *identity(),
                Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                Column("owner_id", String(36), ForeignKey("users.id"), nullable=False),
                Column("run_id", String(36), ForeignKey("task_runs.id"), nullable=False, unique=True),
                Column("name", String(100), nullable=False),
                Column("kind", String(24), nullable=False),
                Column("content", JSON, nullable=False))
conversations = Table("agent_conversations", metadata, *identity(),
                      Column("project_id", String(36), ForeignKey("projects.id"), nullable=False),
                      Column("owner_id", String(36), ForeignKey("users.id"), nullable=False),
                      Column("connection_id", String(36), ForeignKey("platform_connections.id"), nullable=False),
                      Column("agent", String(100), nullable=False),
                      Column("prompt", String(4000), nullable=False),
                      Column("answer", JSON, nullable=False))
shares = Table("panel_shares", metadata,
               Column("token_hash", String(64), primary_key=True),
               Column("panel_id", String(36), ForeignKey("workspace_panels.id"), nullable=False),
               Column("issuer_id", String(36), ForeignKey("users.id"), nullable=False),
               Column("expires_at", DateTime, nullable=False),
               Column("revoked", Boolean, nullable=False, default=False))
