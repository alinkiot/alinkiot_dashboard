import time
from contextlib import contextmanager
from datetime import timedelta

from sqlalchemy import insert, select, text, update
from sqlalchemy.exc import IntegrityError

from . import models
from .business import TASK_CAP, available_agent, ai_answer
from .data_service import connection_for, evaluate_rules, persist_sync, project_scope, query_samples, sync_payload


@contextmanager
def worker_lock(engine):
    with engine.connect() as connection:
        if engine.dialect.name == "mysql":
            name = "alinkiot:worker:" + engine.url.database
            acquired = connection.execute(text("SELECT GET_LOCK(:name, 0)"), {"name": name}).scalar() == 1
            connection.commit()
        else:
            acquired = True
        try:
            yield acquired
        finally:
            if acquired and engine.dialect.name == "mysql":
                connection.execute(text("SELECT RELEASE_LOCK(:name)"), {"name": name})
                connection.commit()


def owner_scope(connection, task):
    owner = connection.execute(select(models.users).where(
        models.users.c.id == task["owner_id"], models.users.c.enabled.is_(True))).mappings().one_or_none()
    if not owner:
        raise ValueError("任务所有者已停用")
    if owner["role"] not in {"superadmin", "admin", "user"}:
        raise ValueError("Invalid task owner")
    project_scope(connection, owner, task["project_id"], TASK_CAP[task["kind"]])
    return owner


def execute(engine, state, run_id):
    with engine.begin() as connection:
        run = connection.execute(select(models.runs).where(models.runs.c.id == run_id)).mappings().one()
        task = connection.execute(select(models.tasks).where(models.tasks.c.id == run["task_id"])).mappings().one()
        connection.execute(update(models.runs).where(models.runs.c.id == run_id).values(status="running"))
        task = dict(task)
    try:
        with engine.connect() as connection:
            actor = dict(owner_scope(connection, task))
            if task["version"] != run["task_version"]:
                raise ValueError("任务配置版本已变更，请重新执行")
            if run["slot"].startswith("scheduled:") and not task["enabled"]:
                raise ValueError("定时任务已停用")
            config = task["config"]
            source = None
            if task["kind"] in {"sync", "ai_report", "ai_warning"}:
                source = dict(connection_for(connection, config["connection_id"], actor,
                    "source" if task["kind"] == "sync" else "agent"))
                if source["project_id"] != task["project_id"]:
                    raise ValueError("Connection project mismatch")
            if task["kind"] != "sync":
                end = models.now()
                context = query_samples(connection, actor, task["project_id"], config["device_ids"],
                    start=end - timedelta(minutes=config["window_minutes"]), end=end, limit=1000)
                if context["truncated"]:
                    raise ValueError("数据范围超限，请缩小窗口或设备范围")
                if not context["items"]:
                    raise ValueError("所选数据窗口没有采样，不生成空报表或无证据预警")
                if task["kind"] == "ai_warning" and (
                    any(row["quality"] != "valid" for row in context["items"]) or
                    {row["device_id"] for row in context["items"]} != set(config["device_ids"])
                ):
                    raise ValueError("预警窗口缺少设备数据或数据质量无效，不能触发/恢复告警")
        if task["kind"] == "sync":
            payload, samples = sync_payload(source, state, task["cursor"])
            analysis = None
        elif task["kind"] in {"ai_report", "ai_warning"}:
            agent = available_agent(source)
            analysis = ai_answer(source, state, agent, config["prompt"],
                {"samples": context["items"], "project_id": task["project_id"]})
            if task["kind"] == "ai_warning" and analysis["warning"] is None:
                raise ValueError("预警响应需包含布尔 warning，不能用任意模型文本触发")
        else:
            analysis = None
        with engine.begin() as connection:
            connection.execute(select(models.installation.c.id).where(models.installation.c.id == 1).with_for_update()).first()
            current = connection.execute(select(models.tasks).where(models.tasks.c.id == task["id"])).mappings().one()
            actor = owner_scope(connection, current)
            if current["version"] != task["version"]:
                raise ValueError("执行期间任务配置已变更")
            if task["kind"] == "sync":
                result = persist_sync(connection, task, source, payload, samples)
                evaluate_rules(connection, actor, task["project_id"])
            elif task["kind"] == "ai_warning":
                from .data_service import apply_alarm
                apply_alarm(connection, task["project_id"], task["id"], "intelligent_warning",
                    task["name"], config["level"], analysis["warning"], {"run_id": run_id, **analysis})
                result = analysis
            else:
                content = {"samples": context["items"], "analysis": analysis,
                           "window_minutes": config["window_minutes"], "task_version": task["version"]}
                report_id = connection.execute(insert(models.reports).values(project_id=task["project_id"],
                    owner_id=task["owner_id"], run_id=run_id, name=task["name"], kind=task["kind"],
                    content=content)).inserted_primary_key[0]
                result = {"report_id": report_id, "samples": len(context["items"]), "analysis": analysis}
            connection.execute(update(models.runs).where(models.runs.c.id == run_id).values(
                status="success", finished_at=models.now(), result=result, error=None))
            connection.execute(insert(models.audit).values(actor_id=actor["id"], action="task.completed",
                detail={"customer_id": actor["customer_id"], "task_id": task["id"], "run_id": run_id, "kind": task["kind"]}))
    except Exception:
        # Never persist external exception strings: they can contain credentials/remote bodies.
        with engine.begin() as connection:
            connection.execute(update(models.runs).where(models.runs.c.id == run_id).values(
                status="failed", finished_at=models.now(),
                error="执行失败：检查授权、任务版本、数据/schema、平台连通性及标准协议；未推进同步游标"))


def tick(engine, state):
    with worker_lock(engine) as acquired:
        if not acquired:
            return 0
        now = models.now()
        with engine.begin() as connection:
            connection.execute(select(models.installation.c.id).where(models.installation.c.id == 1).with_for_update()).first()
            due = connection.execute(select(models.tasks).where(
                models.tasks.c.enabled.is_(True), models.tasks.c.next_run_at <= now).limit(20)).mappings().all()
            for task in due:
                slot = "scheduled:" + task["next_run_at"].isoformat()
                pending = connection.execute(select(models.runs.c.id).where(
                    models.runs.c.task_id == task["id"], models.runs.c.status.in_(["queued", "running"]))).first()
                if pending:
                    continue
                try:
                    with connection.begin_nested():
                        connection.execute(insert(models.runs).values(task_id=task["id"], task_version=task["version"],
                            slot=slot, status="queued"))
                except IntegrityError:
                    pass
                connection.execute(update(models.tasks).where(models.tasks.c.id == task["id"]).values(
                    next_run_at=now + timedelta(minutes=task["interval_minutes"])))
        with engine.connect() as connection:
            queued = connection.execute(select(models.runs.c.id).where(
                models.runs.c.status.in_(["queued", "running"])).order_by(models.runs.c.created_at).limit(20)).scalars().all()
        for run_id in queued:
            execute(engine, state, run_id)
        with engine.begin() as connection:
            connection.execute(select(models.installation.c.id).where(models.installation.c.id == 1).with_for_update()).first()
            detector = connection.execute(select(models.users).where(
                models.users.c.role == "superadmin", models.users.c.enabled.is_(True)).limit(1)).mappings().first()
            if detector:
                projects = connection.execute(select(models.alarm_rules.c.project_id).where(
                    models.alarm_rules.c.enabled.is_(True)).distinct()).scalars().all()
                for project_id in projects:
                    evaluate_rules(connection, detector, project_id)
        return len(queued)


def run(state, once=False):
    config = state.database()
    if config is None:
        raise ValueError("请先安装")
    engine = config.engine()
    try:
        while True:
            tick(engine, state)
            if once:
                return
            time.sleep(5)
    finally:
        engine.dispose()
