import math
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

from fastapi import HTTPException
from sqlalchemy import insert, select, update

from . import models
from .core import customer_active
from .formula import compute
from .http_adapter import request
from .plugins import Manifest, ProductSpec, tables


def project_scope(connection, actor, project_id, capability=None):
    project = connection.execute(select(models.projects).where(models.projects.c.id == project_id)).mappings().first()
    if not project:
        raise HTTPException(404, "项目不存在")
    if actor["role"] == "superadmin":
        return project
    if not actor["enabled"] or project["customer_id"] != actor["customer_id"]:
        raise HTTPException(403, "项目不在当前客户范围")
    customer_active(connection, actor["customer_id"])
    grant = connection.execute(select(models.grants).where(
        models.grants.c.user_id == actor["id"], models.grants.c.project_id == project_id)).mappings().first()
    if not grant or capability and (capability not in grant["capabilities"] or
                                    actor["role"] == "user" and capability not in {"export", "report"}):
        raise HTTPException(403, "项目或操作能力未获授权")
    return project


def connection_for(connection, connection_id, actor, kind=None, capability=None):
    source = connection.execute(select(models.connections).where(
        models.connections.c.id == connection_id)).mappings().first()
    if not source or kind and source["kind"] != kind:
        raise HTTPException(404, "平台接入不存在")
    project_scope(connection, actor, source["project_id"], capability)
    return source


def product_tables(connection, product_id):
    product = connection.execute(select(models.products).where(models.products.c.id == product_id)).mappings().first()
    if not product:
        raise ValueError("Unknown product")
    manifest = Manifest(schema_version=1, id=product["plugin_id"], version=product["schema_version"],
                        name=product["name"], products=[ProductSpec.model_validate(product["definition"])])
    return product, tables(manifest)


def product_visible(connection, actor, product_id):
    if actor["role"] == "superadmin":
        return
    links = connection.execute(select(models.connections.c.project_id).join(models.product_links,
        models.product_links.c.connection_id == models.connections.c.id).where(
        models.product_links.c.product_id == product_id)).scalars()
    for project_id in links:
        try:
            project_scope(connection, actor, project_id)
            return
        except HTTPException:
            continue
    raise HTTPException(403, "产品不在授权项目内")


def timestamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Sample timestamps require timezone")
    return parsed.astimezone(timezone.utc).replace(tzinfo=None)


def typed_value(field, value):
    if value is None:
        return None
    if field["type"] == "boolean":
        if type(value) is not bool:
            raise ValueError("Boolean required")
    elif field["type"] in {"number", "integer"}:
        if type(value) not in (int, float) or not math.isfinite(value) or abs(value) > 1e18:
            raise ValueError("Finite numeric value required")
        if field["type"] == "integer" and (type(value) is not int):
            raise ValueError("Integer required")
    elif not isinstance(value, str) or len(value) > field.get("length", 200):
        raise ValueError("Text length/type mismatch")
    return value


def sync_payload(source, state, cursor):
    devices = request(source, state, "/devices")
    samples = request(source, state, "/samples?cursor=" + quote(cursor, safe=""))
    for payload in (devices, samples):
        if not isinstance(payload, dict) or payload.get("next") or not isinstance(payload.get("items"), list):
            raise ValueError("分页协议未适配，拒绝把不完整页当作完整同步")
        if len(payload["items"]) > 1000:
            raise ValueError("Sync batch limit exceeded")
    if not isinstance(samples.get("cursor"), str) or len(samples["cursor"]) > 100:
        raise ValueError("Invalid cursor")
    return devices["items"], samples


def persist_sync(connection, task, source, payload, sample_payload):
    links = {row["external_id"]: row["product_id"] for row in connection.execute(select(
        models.product_links).where(models.product_links.c.connection_id == source["id"])).mappings()}
    chosen = set(task["config"]["products"])
    if not chosen <= links.keys():
        raise ValueError("Sync product mapping missing")
    products = {key: product_tables(connection, links[key]) for key in chosen}
    imported = {}
    for item in payload:
        if item.get("product") not in chosen:
            continue
        external_id = item.get("id")
        if not isinstance(external_id, str) or not 1 <= len(external_id) <= 100:
            raise ValueError("Invalid device ID")
        product, (archive, _) = products[item["product"]]
        name = item.get("name", external_id)
        if not isinstance(name, str) or len(name) > 100:
            raise ValueError("Invalid device name")
        values = item.get("archive", {})
        fields = {f["name"]: f for f in product["definition"]["archive_fields"]}
        if not isinstance(values, dict) or not values.keys() <= fields.keys():
            raise ValueError("Source schema changed; deploy a reviewed product plugin first")
        values = {name: typed_value(fields[name], value) for name, value in values.items()}
        existing = connection.execute(select(models.devices).where(
            models.devices.c.source_id == source["id"], models.devices.c.external_id == external_id)).mappings().first()
        if existing:
            if existing["project_id"] != task["project_id"] or existing["product_id"] != product["id"]:
                raise ValueError("Device product/project transfer requires reviewed migration")
            device_id = existing["id"]
            connection.execute(update(archive).where(archive.c.device_id == device_id).values(**values))
            connection.execute(update(models.device_details).where(models.device_details.c.device_id == device_id).values(
                source_values={"name": name, **values}))
        else:
            device_id = connection.execute(insert(models.devices).values(project_id=task["project_id"],
                product_id=product["id"], source_id=source["id"], external_id=external_id)).inserted_primary_key[0]
            connection.execute(insert(archive).values(device_id=device_id, **values))
            connection.execute(insert(models.device_details).values(device_id=device_id, name=name,
                source_values={"name": name, **values}, local_values={}))
        imported[external_id] = (device_id, item["product"])
    saved = duplicates = 0
    for item in sample_payload["items"]:
        if item.get("device") not in imported:
            continue
        device_id, product_key = imported[item["device"]]
        product, (_, samples) = products[product_key]
        source_key = item.get("key")
        if not isinstance(source_key, str) or not 1 <= len(source_key) <= 100:
            raise ValueError("Invalid idempotency key")
        if connection.execute(select(samples.c.id).where(
            samples.c.device_id == device_id, samples.c.source_key == source_key)).first():
            duplicates += 1
            continue
        fields = {f["name"]: f for f in product["definition"]["metrics"]}
        raw = item.get("values")
        if not isinstance(raw, dict) or not raw.keys() <= fields.keys():
            raise ValueError("Telemetry schema changed; deploy reviewed plugin")
        values = {key: typed_value(fields[key], value) for key, value in raw.items()}
        versions = {}
        quality = "valid"
        for binding in task["config"].get("formulas", []):
            if binding["product"] != product_key or values.get(binding["metric"]) is None:
                continue
            formula = connection.execute(select(models.formulas).where(
                models.formulas.c.id == binding["formula_id"], models.formulas.c.project_id == task["project_id"])).mappings().one()
            metric = binding["metric"]
            versions[metric] = {"id": formula["id"], "version": formula["version"], "unit": formula["unit"]}
            try:
                values[metric] = typed_value(fields[metric], compute(formula["expression"], formula["parameters"], raw[metric]))
            except (ValueError, ZeroDivisionError, OverflowError):
                values[metric] = None
                quality = "formula_error"
        connection.execute(insert(samples).values(device_id=device_id, event_time=timestamp(item["time"]),
            source_key=source_key, raw_values=raw, formula_versions=versions,
            quality=quality, ingested_at=models.now(), **values))
        saved += 1
    connection.execute(update(models.tasks).where(models.tasks.c.id == task["id"]).values(cursor=sample_payload["cursor"]))
    return {"devices": len(imported), "saved": saved, "duplicates": duplicates,
            "simulated": bool(sample_payload.get("simulated")), "cursor": sample_payload["cursor"]}


def query_samples(connection, actor, project_id, device_ids=None, start=None, end=None, latest=False, limit=1000):
    project_scope(connection, actor, project_id)
    query = select(models.devices).where(models.devices.c.project_id == project_id)
    if device_ids:
        query = query.where(models.devices.c.id.in_(device_ids))
    devices = connection.execute(query.limit(101)).mappings().all()
    if len(devices) > 100:
        raise ValueError("Select at most 100 devices")
    if device_ids and {d["id"] for d in devices} != set(device_ids):
        raise HTTPException(403, "设备不属于当前授权项目")
    end = end or models.now()
    start = start or end - timedelta(hours=24)
    if start > end or end - start > timedelta(days=90):
        raise ValueError("History range must be within 90 days")
    result = []
    truncated = False
    for device in devices:
        product, (_, samples) = product_tables(connection, device["product_id"])
        query = select(samples).where(samples.c.device_id == device["id"])
        if not latest:
            query = query.where(samples.c.event_time >= start, samples.c.event_time <= end)
        count = 1 if latest else min(limit + 1, 5001)
        rows = connection.execute(query.order_by(samples.c.event_time.desc(), samples.c.id.desc()).limit(count)).mappings().all()
        if not latest and len(rows) > limit:
            truncated = True
            rows = rows[:limit]
        for row in rows:
            result.append({"device_id": device["id"], "external_id": device["external_id"],
                "product_id": product["id"], "time": row["event_time"].isoformat() + "Z",
                "values": {f["name"]: row[f["name"]] for f in product["definition"]["metrics"]},
                "units": {f["name"]: row["formula_versions"].get(f["name"], {}).get("unit", f["unit"])
                          for f in product["definition"]["metrics"]},
                "raw_values": row["raw_values"], "formula_versions": row["formula_versions"], "quality": row["quality"]})
        if len(result) >= 5000:
            truncated = True
            result = result[:5000]
            break
    return {"items": sorted(result, key=lambda row: row["time"]), "truncated": truncated}


def apply_alarm(connection, project_id, identity, source, name, level, active, evidence):
    old = connection.execute(select(models.alarm_events).where(
        models.alarm_events.c.identity_key == identity)).mappings().first()
    changed = not old and active or old and old["active"] != active
    if old:
        connection.execute(update(models.alarm_events).where(models.alarm_events.c.id == old["id"]).values(
            active=active, last_seen=models.now(), evidence=evidence,
            **({"handled": False} if active and not old["active"] else {})))
        event_id = old["id"]
    elif active:
        event_id = connection.execute(insert(models.alarm_events).values(project_id=project_id, identity_key=identity,
            source=source, name=name, level=level, active=True, evidence=evidence)).inserted_primary_key[0]
    else:
        return
    if changed:
        connection.execute(insert(models.notifications).values(event_id=event_id, channel="platform",
            status="stored", message=("触发：" if active else "恢复：") + name))


def evaluate_rules(connection, actor, project_id):
    rules = connection.execute(select(models.alarm_rules).where(
        models.alarm_rules.c.project_id == project_id, models.alarm_rules.c.enabled.is_(True))).mappings().all()
    ids = list({rule["device_id"] for rule in rules})
    by_device = {}
    for offset in range(0, len(ids), 100):
        latest = query_samples(connection, actor, project_id, ids[offset:offset + 100], latest=True)
        by_device.update({row["device_id"]: row for row in latest["items"]})
    for rule in rules:
        row = by_device.get(rule["device_id"])
        if rule["operator"] == "offline":
            device = connection.execute(select(models.devices).where(models.devices.c.id == rule["device_id"])).mappings().one()
            last = timestamp(row["time"]) if row else device["created_at"]
            offline = models.now() - last > timedelta(minutes=float(rule["threshold"]))
            apply_alarm(connection, project_id, rule["id"], "device_rule", rule["name"], rule["level"], offline,
                        {"device_id": rule["device_id"], "last_sample": last.isoformat() + "Z",
                         "timeout_minutes": float(rule["threshold"])})
            continue
        value = row and row["values"].get(rule["metric"])
        if row is None or value is None or row["quality"] != "valid":
            continue
        threshold = float(rule["threshold"])
        triggered = value > threshold if rule["operator"] == "gt" else value < threshold
        apply_alarm(connection, project_id, rule["id"], "device_rule", rule["name"], rule["level"], triggered,
                    {"device_id": rule["device_id"], "metric": rule["metric"], "value": value, "time": row["time"]})
