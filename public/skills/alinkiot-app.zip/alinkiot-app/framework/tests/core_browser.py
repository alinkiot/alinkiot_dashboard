"""Exercise real core module UI with an isolated MySQL test server."""
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
from playwright.sync_api import expect, sync_playwright

from alinkiot.installer import install, prepare_database
from alinkiot.plugins import discover
from alinkiot.state import DatabaseInput, State


def main():
    settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
        database="browser_" + secrets.token_hex(8), username="root",
        password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
    prepare_database(settings, create=True)
    root = Path(__file__).parents[1]
    passwords = [secrets.token_urlsafe(20) for _ in range(4)]
    engine = settings.engine()
    try:
        install(engine, discover(root / "plugins"), "browser_root", passwords[0])
    finally:
        engine.dispose()
    with tempfile.TemporaryDirectory(prefix="alinkiot-core-browser-") as directory:
        state = State(Path(directory))
        with state.lock():
            state.save_database(settings)
        environment = os.environ.copy()
        environment["ALINK_STATE_DIR"] = directory
        environment["ALINK_PLUGIN_DIR"] = str(root / "plugins")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "alinkiot.app:app",
            "--host", "127.0.0.1", "--port", str(port)], env=environment,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    if httpx.get(base + "/health/ready", timeout=1).status_code == 200:
                        break
                except httpx.RequestError:
                    pass
                time.sleep(.1)
            else:
                raise RuntimeError("Core browser server did not become ready")
            with sync_playwright() as playwright:
                chrome = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
                browser = playwright.chromium.launch(
                    executable_path=str(chrome) if chrome.exists() else None, headless=True)
                try:
                    page = browser.new_page(viewport={"width": 1366, "height": 768})
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(base)
                    expect(page.locator(".auth-copy h1")).to_contain_text("可被看见")
                    assert page.locator("body").evaluate("element => getComputedStyle(element).getPropertyValue('--bg').trim()") == "#050810"
                    page.locator("#entry [data-theme-toggle]").click()
                    expect(page.locator("html")).to_have_attribute("data-theme", "light")
                    assert page.locator("body").evaluate("element => getComputedStyle(element).getPropertyValue('--bg').trim()") == "#f2f5fa"
                    page.reload()
                    expect(page.locator("html")).to_have_attribute("data-theme", "light")
                    editor = page.locator("#editor")
                    fields = lambda name: editor.locator(f'[name="{name}"]')
                    def check_label(name):
                        checkbox = editor.get_by_label(name, exact=True)
                        checkbox.locator("..").click()
                        expect(checkbox).to_be_checked()

                    def login(username, password):
                        expect(page.locator("#login-form")).to_be_visible()
                        page.locator('#login-form [name="username"]').fill(username)
                        page.locator('#login-form [name="password"]').fill(password)
                        page.locator('#login-submit').click()
                        expect(page.locator("#workspace")).to_be_visible()
                        expect(page.locator("#user")).to_contain_text(username)

                    def navigate(route):
                        if page.viewport_size["width"] <= 860:
                            page.locator("#menu-toggle").click()
                        page.locator(f'[data-route="{route}"]').click()
                        expect(page.locator("#content")).not_to_contain_text("正在加载")

                    def save():
                        editor.locator("#save-editor").click()
                        expect(editor).not_to_be_visible()
                        expect(page.locator("#content")).not_to_contain_text("正在加载")

                    def row(name):
                        return page.get_by_role("row").filter(has=page.get_by_role("cell", name=name, exact=True))

                    login("browser_root", passwords[0])
                    page.locator("#workspace [data-theme-toggle]").click()
                    expect(page.locator("html")).to_have_attribute("data-theme", "dark")
                    expect(page.locator(".kpi")).to_have_count(4)
                    assert page.locator(".sidebar").bounding_box()["width"] == 248
                    assert page.locator(".topbar").bounding_box()["height"] == 64
                    page.locator("#menu-toggle").click()
                    expect(page.locator("#workspace")).to_have_class("app on collapsed")
                    page.locator("#menu-toggle").click()
                    page.locator("#top-search").click()
                    page.locator("#command-query").fill("项目管理")
                    page.locator("#command-results").get_by_role("button").filter(has_text="项目管理").click()
                    expect(page.locator("#command-search")).to_be_hidden()
                    expect(page.locator("#page-title")).to_have_text("项目管理")
                    navigate("customers")
                    for name in ("浏览器客户甲", "浏览器客户乙"):
                        page.locator("#create-resource").click()
                        fields("name").fill(name)
                        save()
                        expect(row(name)).to_be_visible()
                    navigate("projects")
                    page.locator("#create-resource").click()
                    fields("name").fill("浏览器泵房")
                    save()
                    row("浏览器泵房").get_by_role("button", name="分配客户").click()
                    fields("customer_id").select_option(label="浏览器客户甲")
                    save()
                    expect(row("浏览器泵房")).to_contain_text("浏览器客户甲")
                    navigate("users")
                    page.locator("#create-resource").click()
                    fields("username").fill("browser_admin")
                    fields("customer_id").select_option(label="浏览器客户甲")
                    fields("password").fill(passwords[1])
                    save()
                    row("browser_admin").get_by_role("button", name="项目授权", exact=True).click()
                    expect(editor).to_be_visible()
                    check_label("浏览器泵房")
                    check_label("数据导出")
                    save()
                    navigate("logs")
                    expect(page.locator("#content")).to_contain_text("user.grants")
                    page.locator("#logout").click()
                    expect(page.locator("#workspace")).to_be_hidden()
                    login("browser_admin", passwords[1])
                    navigate("customers")
                    expect(row("浏览器客户甲")).to_be_visible()
                    expect(row("浏览器客户乙")).not_to_be_visible()
                    expect(page.locator("#create-resource")).to_be_hidden()
                    expect(page.locator("#plugins-link")).to_be_hidden()
                    navigate("projects")
                    expect(row("浏览器泵房")).to_be_visible()
                    navigate("users")
                    page.locator("#create-resource").click()
                    fields("username").fill("browser_user")
                    fields("password").fill(passwords[2])
                    save()
                    row("browser_user").get_by_role("button", name="项目授权", exact=True).click()
                    check_label("浏览器泵房")
                    check_label("数据导出")
                    expect(editor.get_by_label("共享配置管理", exact=True)).to_have_count(0)
                    save()
                    page.locator("#logout").click()
                    login("browser_user", passwords[2])
                    navigate("projects")
                    expect(row("浏览器泵房")).to_be_visible()
                    expect(page.locator("#create-resource")).to_be_hidden()
                    expect(page.get_by_role("button", name="分配客户")).to_have_count(0)
                    navigate("users")
                    expect(row("browser_user")).to_be_visible()
                    expect(row("browser_admin")).not_to_be_visible()
                    expect(page.get_by_role("button", name="编辑/重置密码")).to_have_count(0)
                    navigate("logs")
                    expect(page.locator("#content")).to_contain_text("auth.login")
                    expect(page.locator("#content")).not_to_contain_text("user.create")
                    page.locator("#change-password").click()
                    fields("current_password").fill(passwords[2])
                    fields("new_password").fill(passwords[3])
                    save()
                    expect(page.locator("#workspace")).to_be_hidden()
                    login("browser_user", passwords[3])
                    navigate("projects")
                    expect(row("浏览器泵房")).to_be_visible()
                    assert page.evaluate("Object.keys(localStorage)") == ["alink-theme"]
                    assert page.evaluate("localStorage.getItem('alink-theme')") == "dark"
                    page.set_viewport_size({"width": 390, "height": 844})
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                    page.locator("#menu-toggle").click()
                    expect(page.locator("#logout")).to_be_visible()
                    page.reload()
                    expect(page.locator("#login-form")).to_be_visible()
                    expect(page.locator("#workspace")).to_be_hidden()
                    assert not errors, errors
                    print("Core module MySQL browser checks passed")
                finally:
                    browser.close()
        finally:
            process.terminate()
            process.wait(timeout=10)


if __name__ == "__main__":
    main()
