import os
import secrets

import pytest
from fastapi.testclient import TestClient
from pydantic import SecretStr
from sqlalchemy import create_engine, inspect, select

from alinkiot import models
from alinkiot.app import create_app
from alinkiot.installer import install, prepare_database
from alinkiot.plugins import discover
from alinkiot.state import DatabaseInput, State
from test_framework import PLUGINS


@pytest.fixture
def core(tmp_path, monkeypatch):
    if os.environ.get("ALINK_TEST_MYSQL_PORT"):
        settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
            database="core_" + secrets.token_hex(8), username="root",
            password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
        prepare_database(settings, create=True)
    else:
        settings = DatabaseInput(host="localhost", database="core_test", username="test",
                                 password=SecretStr(secrets.token_urlsafe(20)), tls=False)
        url = "sqlite:///" + str(tmp_path / "core.db")
        monkeypatch.setattr(DatabaseInput, "engine", lambda self, **kw: create_engine(url))
    engine = settings.engine()
    password = secrets.token_urlsafe(20)
    install(engine, discover(PLUGINS), "root_admin", password)
    state = State(tmp_path / "state")
    with state.lock():
        state.save_database(settings)
    client = TestClient(create_app(state.directory, PLUGINS))
    client.app.state.state = state
    yield client, engine, password
    engine.dispose()


def login(client, username, password):
    response = client.post("/api/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200, response.text
    return {"Authorization": "Bearer " + response.json()["access_token"]}


def post(client, path, auth, payload):
    response = client.post(path, headers=auth, json=payload)
    assert response.status_code == 201, response.text
    return response.json()["id"]


def put(client, path, auth, payload, status=200):
    response = client.put(path, headers=auth, json=payload)
    assert response.status_code == status, response.text
    return response


def setup_hierarchy(client, password):
    root = login(client, "root_admin", password)
    c1 = post(client, "/api/customers", root, {"name": "客户一"})
    c2 = post(client, "/api/customers", root, {"name": "客户二"})
    p1 = post(client, "/api/projects", root, {"name": "泵房一"})
    p2 = post(client, "/api/projects", root, {"name": "泵房二", "timezone": "UTC"})
    other = post(client, "/api/projects", root, {"name": "客户二项目"})
    for project, customer in ((p1, c1), (p2, c1), (other, c2)):
        put(client, f"/api/projects/{project}/assignment", root, {"customer_id": customer})
    credentials = {name: secrets.token_urlsafe(20) for name in ("admin_one", "admin_two", "admin_other", "user_one")}
    a1 = post(client, "/api/users", root, {"username": "admin_one", "password": credentials["admin_one"], "customer_id": c1})
    a2 = post(client, "/api/users", root, {"username": "admin_two", "password": credentials["admin_two"], "customer_id": c1})
    a3 = post(client, "/api/users", root, {"username": "admin_other", "password": credentials["admin_other"], "customer_id": c2})
    for target, project in ((a1, p1), (a2, p2), (a3, other)):
        put(client, f"/api/users/{target}/grants", root, {
            "grants": [{"project_id": project, "capabilities": ["export", "report", "configure"]}]})
    admin = login(client, "admin_one", credentials["admin_one"])
    admin2 = login(client, "admin_two", credentials["admin_two"])
    admin_other = login(client, "admin_other", credentials["admin_other"])
    ordinary_id = post(client, "/api/users", admin, {"username": "user_one", "password": credentials["user_one"]})
    put(client, f"/api/users/{ordinary_id}/grants", admin, {
        "grants": [{"project_id": p1, "capabilities": ["export"]}]})
    ordinary = login(client, "user_one", credentials["user_one"])
    return dict(root=root, admin=admin, admin2=admin2, admin_other=admin_other, ordinary=ordinary,
                c1=c1, c2=c2, p1=p1, p2=p2, other=other, a1=a1, a2=a2, a3=a3,
                ordinary_id=ordinary_id, credentials=credentials)


def test_scope_and_hierarchical_mutations(core):
    client, engine, password = core
    h = setup_hierarchy(client, password)
    assert client.get("/api/customers", headers=h["admin"]).json()["total"] == 1
    assert client.get("/api/projects", headers=h["admin"]).json()["items"][0]["id"] == h["p1"]
    assert client.get("/api/projects", headers=h["ordinary"]).json()["total"] == 1
    assert client.get("/api/users", headers=h["ordinary"]).json()["items"][0]["id"] == h["ordinary_id"]
    assert client.get("/api/users", headers=h["admin"]).json()["total"] == 3
    assert client.get("/api/users", headers=h["admin_other"]).json()["total"] == 1
    assert "password_hash" not in client.get("/api/users", headers=h["root"]).text
    assert client.get("/api/users/" + h["a3"] + "/grants", headers=h["admin"]).status_code == 404
    assert client.get("/api/users/" + h["a1"] + "/grants", headers=h["ordinary"]).status_code == 404
    for auth in (h["admin"], h["ordinary"]):
        assert client.post("/api/customers", headers=auth, json={"name": "illegal"}).status_code == 403
        assert client.post("/api/projects", headers=auth, json={"name": "illegal"}).status_code == 403
    assert client.post("/api/users", headers=h["ordinary"], json={
        "username": "no_user", "password": secrets.token_urlsafe(20)}).status_code == 403
    assert client.post("/api/users", headers=h["admin"], json={
        "username": "no_user", "password": secrets.token_urlsafe(20), "customer_id": h["c2"]}).status_code == 403
    assert client.post("/api/users", headers=h["admin"], json={
        "username": "no_user", "password": secrets.token_urlsafe(20), "role": "superadmin"}).status_code == 422
    put(client, f"/api/users/{h['a1']}", h["admin"], {"enabled": False}, 403)
    put(client, f"/api/users/{h['ordinary_id']}", h["root"], {"enabled": False}, 403)
    put(client, f"/api/users/{h['a3']}", h["admin"], {"enabled": False}, 404)
    for grants in (
        [{"project_id": h["p2"], "capabilities": []}],
        [{"project_id": h["other"], "capabilities": []}],
        [{"project_id": h["p1"], "capabilities": ["configure"]}],
    ):
        put(client, f"/api/users/{h['ordinary_id']}/grants", h["admin"], {"grants": grants}, 403)
    assert client.get("/api/users/" + h["ordinary_id"] + "/grants", headers=h["admin"]).json() == [
        {"project_id": h["p1"], "capabilities": ["export"]}]
    put(client, f"/api/users/{h['a1']}/grants", h["root"], {
        "grants": [{"project_id": h["other"], "capabilities": []}]}, 403)
    assert client.get("/api/plugins", headers=h["ordinary"]).status_code == 403
    assert client.post("/api/plugins/install", headers=h["admin"]).status_code == 403
    assert client.get("/api/projects?page_size=101", headers=h["root"]).status_code == 422
    assert client.post("/api/projects", headers=h["root"], json={"name": "bad", "timezone": "bad/timezone"}).status_code == 422
    assert client.get("/api/users?q=user_one", headers=h["root"]).json()["total"] == 1
    assert client.get("/api/projects?page_size=1&page=2", headers=h["root"]).json()["total"] == 3
    with engine.connect() as connection:
        assert connection.execute(select(models.users.c.role).where(models.users.c.id == h["ordinary_id"])).scalar_one() == "user"


def test_grants_survive_issuer_disable_but_not_customer_transfer(core):
    client, _, password = core
    h = setup_hierarchy(client, password)
    # A second administrator adds their project; the first can edit only their own subset.
    put(client, f"/api/users/{h['ordinary_id']}/grants", h["admin2"], {
        "grants": [{"project_id": h["p2"], "capabilities": ["report"]}]})
    put(client, f"/api/users/{h['ordinary_id']}/grants", h["admin"], {"grants": []})
    assert client.get("/api/projects", headers=h["ordinary"]).json()["items"][0]["id"] == h["p2"]
    put(client, f"/api/users/{h['a2']}/grants", h["root"], {"grants": []})
    assert client.get("/api/projects", headers=h["admin2"]).json()["total"] == 0
    assert client.get("/api/projects", headers=h["ordinary"]).json()["total"] == 1
    put(client, f"/api/users/{h['a2']}", h["root"], {"enabled": False})
    assert client.get("/api/me", headers=h["admin2"]).status_code == 401
    assert client.get("/api/projects", headers=h["ordinary"]).json()["total"] == 1
    put(client, f"/api/projects/{h['p2']}/assignment", h["root"], {"customer_id": h["c2"]})
    assert client.get("/api/projects", headers=h["ordinary"]).json()["total"] == 0
    assert client.get("/api/users/" + h["ordinary_id"] + "/grants", headers=h["admin"]).json() == []
    assert client.get("/api/projects", headers=h["admin_other"]).json()["total"] == 1
    put(client, f"/api/users/{h['a3']}/grants", h["root"], {
        "grants": [{"project_id": h["p2"], "capabilities": []}, {"project_id": h["other"], "capabilities": []}]})
    same = put(client, f"/api/projects/{h['p2']}/assignment", h["root"], {"customer_id": h["c2"]})
    assert same.json()["grants_revoked"] is False
    assert client.get("/api/projects", headers=h["admin_other"]).json()["total"] == 2
    put(client, f"/api/projects/{h['p2']}/assignment", h["root"], {"customer_id": None})
    assert client.get("/api/projects", headers=h["admin_other"]).json()["total"] == 1


def test_password_customer_status_and_safe_audit(core):
    client, _, password = core
    h = setup_hierarchy(client, password)
    logs = client.get("/api/audit-logs?page_size=100", headers=h["root"])
    assert all(value not in logs.text for value in [password, *h["credentials"].values()])
    assert "password_hash" not in logs.text
    tenant_logs = client.get("/api/audit-logs?page_size=100", headers=h["admin"]).json()["items"]
    assert tenant_logs
    assert all(log["detail"]["customer_id"] == h["c1"] for log in tenant_logs)
    own_logs = client.get("/api/audit-logs", headers=h["ordinary"]).json()["items"]
    assert all(log["actor_id"] == h["ordinary_id"] for log in own_logs)
    new_password = secrets.token_urlsafe(20)
    put(client, f"/api/users/{h['ordinary_id']}", h["admin"], {"enabled": True, "password": new_password})
    assert client.get("/api/me", headers=h["ordinary"]).status_code == 401
    ordinary = login(client, "user_one", new_password)
    next_password = secrets.token_urlsafe(20)
    put(client, "/api/me/password", ordinary, {"current_password": "wrong", "new_password": next_password}, 400)
    put(client, "/api/me/password", ordinary, {"current_password": new_password, "new_password": next_password})
    assert client.get("/api/me", headers=ordinary).status_code == 401
    ordinary = login(client, "user_one", next_password)
    put(client, f"/api/customers/{h['c1']}", h["root"], {"name": "客户一", "enabled": False})
    assert client.get("/api/me", headers=ordinary).status_code == 401
    assert client.post("/api/auth/login", json={"username": "user_one", "password": next_password}).status_code == 401
    put(client, f"/api/customers/{h['c1']}", h["root"], {"name": "客户一改名", "enabled": True})
    ordinary = login(client, "user_one", next_password)
    assert client.get("/api/projects", headers=ordinary).json()["total"] == 1
    assert next_password not in client.get("/api/audit-logs?page_size=100", headers=h["root"]).text


def test_deletion_dependency_guard_and_atomic_audit(core):
    client, engine, password = core
    h = setup_hierarchy(client, password)
    assert client.delete(f"/api/customers/{h['c1']}", headers=h["root"]).status_code == 409
    unused = post(client, "/api/customers", h["root"], {"name": "unused"})
    assert client.delete("/api/customers/" + unused, headers=h["root"]).status_code == 200
    assert client.delete("/api/customers/" + unused, headers=h["root"]).status_code == 404
    project = post(client, "/api/projects", h["root"], {"name": "unused project"})
    put(client, "/api/projects/" + project, h["root"], {"name": "edited project", "timezone": "UTC"})
    assert client.delete("/api/projects/" + project, headers=h["root"]).status_code == 200
    with engine.begin() as connection:
        connection.execute(models.jobs.insert().values(project_id=h["p1"], kind="demo", config={}))
    assert client.delete(f"/api/projects/{h['p1']}", headers=h["root"]).status_code == 409
    assert client.get("/api/projects", headers=h["ordinary"]).json()["total"] == 1
    assert client.post("/api/users", headers=h["root"], json={
        "username": "admin_one", "password": secrets.token_urlsafe(20), "customer_id": h["c1"]}).status_code == 409
    with engine.connect() as connection:
        count = connection.execute(select(models.audit.c.id).where(models.audit.c.action == "customer.delete")).all()
        assert len(count) == 1
        assert "customers" in inspect(connection).get_table_names()
