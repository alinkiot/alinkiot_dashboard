"""Real browser flow from HTTP source to formulas, sync, charts and agent= requests."""
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
from playwright.sync_api import expect, sync_playwright

from alinkiot.installer import install, prepare_database
from alinkiot.plugins import discover
from alinkiot.state import DatabaseInput, State
from alinkiot.seed import seed_existing
from alinkiot.worker import tick


def port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def ready(url):
    for _ in range(60):
        try:
            if httpx.get(url, timeout=1).status_code in (200, 401):
                return
        except httpx.RequestError:
            pass
        time.sleep(.1)
    raise RuntimeError("Browser test service not responsive")


def main():
    root = Path(__file__).parents[1]
    mock_port, app_port = port(), port()
    mock_url = f"http://127.0.0.1:{mock_port}"
    app_url = f"http://127.0.0.1:{app_port}"
    settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
        database="iot_browser_" + secrets.token_hex(8), username="root",
        password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
    prepare_database(settings, create=True)
    engine = settings.engine()
    password = secrets.token_urlsafe(20)
    mock_secret = secrets.token_urlsafe(20)
    environment = os.environ.copy()
    environment.update(ALINK_HTTP_ALLOWLIST=mock_url, ALINK_MOCK_APPID="demo", ALINK_MOCK_SECRET=mock_secret,
                       ALINK_PANEL_SCRIPTS="1")
    try:
        install(engine, discover(root / "plugins"), "iot_root", password)
        with tempfile.TemporaryDirectory(prefix="alinkiot-iot-browser-") as directory:
            state = State(Path(directory))
            with state.lock():
                state.save_database(settings)
            environment.update(ALINK_STATE_DIR=directory, ALINK_PLUGIN_DIR=str(root / "plugins"))
            processes = []
            try:
                for module, selected_port in (("alinkiot.mock_platform:app", mock_port), ("alinkiot.app:app", app_port)):
                    processes.append(subprocess.Popen([sys.executable, "-m", "uvicorn", module,
                        "--host", "127.0.0.1", "--port", str(selected_port)], env=environment,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
                ready(mock_url + "/products"); ready(app_url + "/health/ready")
                auth_response = httpx.post(app_url + "/api/auth/login", json={"username": "iot_root", "password": password})
                headers = {"Authorization": "Bearer " + auth_response.json()["access_token"]}
                customer = httpx.post(app_url + "/api/customers", headers=headers, json={"name": "HTTP 测试客户"}).json()["id"]
                project = httpx.post(app_url + "/api/projects", headers=headers, json={"name": "HTTP 泵房"}).json()["id"]
                httpx.put(app_url + f"/api/projects/{project}/assignment", headers=headers, json={"customer_id": customer}).raise_for_status()
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", headless=True)
                    try:
                        page = browser.new_page(viewport={"width": 1440, "height": 900})
                        errors = []
                        page.on("pageerror", lambda error: errors.append(str(error)))
                        page.goto(app_url)
                        page.locator('#login-form [name="username"]').fill("iot_root")
                        page.locator('#login-form [name="password"]').fill(password)
                        page.locator('#login-submit').click()
                        expect(page.locator("#workspace")).to_be_visible()
                        editor = page.locator("#editor")
                        field = lambda name: editor.locator(f'[name="{name}"]')
                        def check_label(name):
                            checkbox = editor.get_by_label(name, exact=True)
                            checkbox.locator("..").click()
                            expect(checkbox).to_be_checked()

                        def navigate(name):
                            page.locator(f'[data-route="{name}"]').click()
                            expect(page.locator("#page-title")).to_have_text({"connections": "平台接入", "formulas": "公式配置",
                                "sync": "同步任务", "realtime": "实时查询", "curves": "曲线管理", "reports": "报表中心",
                                "diagnosis": "智能诊断", "devices": "设备档案", "history": "历史查询",
                                "dashboards": "项目大屏", "alarms": "告警事件"}[name])
                            expect(page.locator("#content")).not_to_contain_text("正在加载")

                        def save():
                            editor.locator("#save-editor").click()
                            expect(editor).not_to_be_visible(timeout=20000)
                            expect(page.locator("#content")).not_to_contain_text("正在加载")

                        navigate("connections")
                        page.locator("#iot-create").click()
                        field("name").fill("模拟设备平台")
                        field("url").fill(mock_url)
                        field("secret").fill(mock_secret)
                        save()
                        expect(page.locator("#content")).to_contain_text("模拟设备平台")
                        page.get_by_role("button", name="绑定产品表").click()
                        save()
                        navigate("formulas")
                        page.locator("#iot-create").click()
                        field("name").fill("流量除十")
                        save()
                        expect(page.locator("#content")).to_contain_text("流量除十")
                        navigate("sync")
                        page.locator("#iot-create").click()
                        field("name").fill("水表 HTTP 同步")
                        check_label("模拟水表")
                        editor.locator('[data-metric="flow_m3h"]').select_option(label="流量除十 · v1")
                        save()
                        page.get_by_role("button", name="执行一次", exact=True).click()
                        expect(page.locator("#notice")).to_contain_text("已入队")
                        old_allowlist = os.environ.get("ALINK_HTTP_ALLOWLIST")
                        os.environ["ALINK_HTTP_ALLOWLIST"] = mock_url
                        try:
                            assert tick(engine, state) == 1
                        finally:
                            if old_allowlist is None:
                                os.environ.pop("ALINK_HTTP_ALLOWLIST")
                            else:
                                os.environ["ALINK_HTTP_ALLOWLIST"] = old_allowlist
                        page.get_by_role("button", name="执行记录").click()
                        expect(editor).to_contain_text('"status": "success"')
                        editor.locator("#close-editor").click()
                        navigate("realtime")
                        expect(page.locator("#content")).to_contain_text("flow_m3h: 12")
                        navigate("devices")
                        expect(page.locator("#content")).to_contain_text("模拟一号水表")
                        navigate("curves")
                        page.locator("#iot-create").click()
                        field("name").fill("两台水表曲线")
                        check_label("模拟一号水表 · flow_m3h [m³/h]")
                        check_label("模拟二号水表 · flow_m3h [m³/h]")
                        save()
                        page.get_by_role("button", name="查看", exact=True).click()
                        expect(page.locator("#content svg")).to_have_count(2)
                        page.get_by_role("button", name="返回列表").click()
                        expect(page.locator("#content")).to_contain_text("两台水表曲线")
                        page.get_by_role("button", name="查看", exact=True).click()
                        page.get_by_role("button", name="编辑", exact=True).click()
                        field("html").fill('<html><body><h1 id="sdk-value">等待</h1><script>const d=AlinkPanelSDK.read();document.getElementById("sdk-value").textContent="SDK:"+d.samples.length+":"+d.samples[0].values.flow_m3h;</script></body></html>')
                        save()
                        expect(page.frame_locator('iframe.custom-panel').locator("#sdk-value")).to_contain_text("SDK:2:", timeout=15000)
                        child = page.frame_locator('iframe.custom-panel')
                        assert child.locator("#sdk-value").evaluate("() => window.origin") == "null"
                        assert child.locator("#sdk-value").evaluate("() => {try{return parent.document.title}catch(error){return 'blocked'}}") == "blocked"
                        page.get_by_role("button", name="返回列表").click()
                        expect(page.locator("iframe.custom-panel")).to_have_count(0)
                        navigate("connections")
                        page.locator("#iot-create").click()
                        field("name").fill("模拟智能平台")
                        field("kind").select_option("agent")
                        field("url").fill(mock_url)
                        field("secret").fill(mock_secret)
                        save()
                        page.get_by_role("button", name="选择数字人").click()
                        field("agent").select_option("analyst")
                        save()
                        navigate("diagnosis")
                        page.locator("#iot-create").click()
                        expect(page.locator("#chat-window")).to_be_visible()
                        page.locator("#chat-form button").click()
                        expect(page.locator("#chat-messages")).to_contain_text("模拟 HTTP 智能体", timeout=20000)
                        assert mock_secret not in page.locator("#chat-messages").inner_text()
                        page.locator("#chat-close").click()
                        seeded = seed_existing(engine, state)
                        navigate("history")
                        page.locator("#iot-project").select_option(seeded["project_id"])
                        expect(page.locator("#list-total")).to_contain_text("48 条采样")
                        navigate("curves")
                        expect(page.locator("#content")).to_contain_text("【演示】水表流量曲线")
                        page.get_by_role("button", name="查看", exact=True).click()
                        expect(page.locator("#content svg")).to_have_count(2)
                        navigate("dashboards")
                        expect(page.locator("#content")).to_contain_text("【演示】泵房项目大屏")
                        panels = httpx.get(app_url + f"/api/panels?project_id={seeded['project_id']}", headers=headers).json()
                        dashboard = next(panel for panel in panels if panel["kind"] == "dashboard")
                        shared = httpx.post(app_url + f"/api/panels/{dashboard['id']}/share", headers=headers).json()
                        screen = browser.new_page(viewport={"width": 1440, "height": 900})
                        try:
                            screen.goto(app_url + "/screen#" + shared["token"])
                            expect(screen.locator("#screen-title")).to_have_text("【演示】泵房项目大屏")
                            expect(screen.locator("#screen-content .panel-card")).to_have_count(2)
                            expect(screen.locator(".standalone-screen")).to_be_visible()
                        finally:
                            screen.close()
                        navigate("reports")
                        expect(page.locator("#content")).to_contain_text("【演示】泵房流量报表")
                        navigate("alarms")
                        expect(page.locator("#content")).to_contain_text("【演示】一号水表高流量")
                        page.locator("#notification-toggle").click()
                        expect(page.locator("#notification-list")).to_contain_text("触发：【演示】一号水表高流量")
                        page.locator("#notification-toggle").click()
                        page.set_viewport_size({"width": 390, "height": 844})
                        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                        assert not errors, errors
                        print("IoT HTTP/formula/sync/chart/agent browser checks passed")
                    finally:
                        browser.close()
            finally:
                for process in processes:
                    process.terminate()
                    process.wait(timeout=10)
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
