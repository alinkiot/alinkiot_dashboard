import csv
import io
import os
import secrets
import socket
import subprocess
import sys
import time
from datetime import timedelta

import httpx
import pytest
from sqlalchemy import select, update

from alinkiot import models
from alinkiot.data_service import sync_payload
from alinkiot.formula import compute
from alinkiot.installer import upgrade
from alinkiot.worker import tick
from test_core import core, login, post, put


def test_seed_existing_creates_scoped_demo_views_without_http(core):
    from alinkiot.seed import seed_existing
    client, engine, password = core
    result = seed_existing(engine, client.app.state.state)
    root = login(client, "root_admin", password)
    project = result["project_id"]
    ordinary = next(account for account in result["accounts"] if account["role"] == "user")
    user = login(client, ordinary["username"], ordinary["password"])
    assert len(client.get(f"/api/devices?project_id={project}", headers=user).json()) == 2
    history = client.get(f"/api/telemetry?project_id={project}", headers=user).json()
    assert len(history["items"]) == 48
    assert all(row["quality"] == "valid" for row in history["items"])
    assert all(row["raw_values"]["flow_m3h"] == row["values"]["flow_m3h"] * 10 for row in history["items"])
    assert len(client.get(f"/api/panels?project_id={project}", headers=user).json()) == 3
    reports = client.get(f"/api/reports?project_id={project}", headers=root).json()
    assert client.get(f"/api/reports/{reports[0]['id']}/download", headers=root).status_code == 200
    assert client.get(f"/api/reports/{reports[0]['id']}/download", headers=user).status_code == 403
    tasks = client.get(f"/api/tasks?project_id={project}", headers=root).json()
    assert len(tasks) == 4 and all(not task["enabled"] for task in tasks)
    assert tick(engine, client.app.state.state) == 0
    assert seed_existing(engine, client.app.state.state)["created"] is False


@pytest.fixture
def mock_http(monkeypatch):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    url = f"http://127.0.0.1:{port}"
    monkeypatch.setenv("ALINK_HTTP_ALLOWLIST", url)
    appid = "test-app"
    secret = secrets.token_urlsafe(20)
    environment = os.environ.copy()
    environment["ALINK_MOCK_APPID"] = appid
    environment["ALINK_MOCK_SECRET"] = secret
    process = subprocess.Popen([sys.executable, "-m", "uvicorn", "alinkiot.mock_platform:app",
        "--host", "127.0.0.1", "--port", str(port)], env=environment,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                if httpx.get(url + "/products").status_code == 401:
                    break
            except httpx.RequestError:
                pass
            time.sleep(.1)
        else:
            pytest.fail("Mock HTTP platform not responsive")
        yield {"url": url, "appid": appid, "secret": secret}
    finally:
        process.terminate()
        process.wait(timeout=10)


def project_setup(client, root):
    customer = post(client, "/api/customers", root, {"name": "业务测试客户"})
    project = post(client, "/api/projects", root, {"name": "业务项目"})
    put(client, f"/api/projects/{project}/assignment", root, {"customer_id": customer})
    return customer, project


def connection_setup(client, root, project, mock, kind):
    return post(client, "/api/connections", root, {**mock, "project_id": project,
                                                 "kind": kind, "name": "模拟 " + kind})


def sync_setup(client, engine, root, project, source, formula=True):
    product = client.get("/api/products", headers=root).json()[0]
    response = client.post(f"/api/connections/{source}/products", headers=root,
                           json={"external_id": "water_meter", "product_id": product["id"]})
    assert response.status_code == 200, response.text
    config = {"connection_id": source, "products": ["water_meter"]}
    if formula:
        formula_id = post(client, "/api/formulas", root, {"project_id": project, "name": "流量缩放",
            "expression": "value / divisor", "parameters": {"divisor": 10}, "unit": "m³/h"})
        config["formulas"] = [{"product": "water_meter", "metric": "flow_m3h", "formula_id": formula_id}]
    task = post(client, "/api/tasks", root, {"project_id": project, "kind": "sync", "name": "同步水表",
                                          "interval_minutes": 1, "config": config})
    return task, config


def execute_task(client, root, task, engine, state):
    response = client.post(f"/api/tasks/{task}/run", headers=root)
    assert response.status_code == 200, response.text
    run_id = response.json()["id"]
    tick(engine, state)
    runs = client.get(f"/api/tasks/{task}/runs", headers=root).json()
    run = next(run for run in runs if run["id"] == run_id)
    assert run["status"] == "success", run
    return run


def test_http_sync_formulas_retry_extensions_and_history(core, mock_http, monkeypatch):
    client, engine, password = core
    root = login(client, "root_admin", password)
    _, project = project_setup(client, root)
    source = connection_setup(client, root, project, mock_http, "source")
    task, config = sync_setup(client, engine, root, project, source)
    state = client.app.state.state
    with engine.connect() as connection:
        source_row = dict(connection.execute(select(models.connections).where(models.connections.c.id == source)).mappings().one())
    payload = sync_payload(source_row, state, "")
    monkeypatch.setattr("alinkiot.worker.sync_payload", lambda *args: payload)
    result = execute_task(client, root, task, engine, state)
    assert result["result"]["saved"] == 2
    devices = client.get(f"/api/devices?project_id={project}", headers=root).json()
    assert len(devices) == 2
    assert client.get(f"/api/telemetry?project_id={project}&latest=true", headers=root).json()["items"][0]["values"]["flow_m3h"] in (8, 12)
    first = devices[0]
    put(client, f"/api/devices/{first['id']}", root, {"name": "本地名称", "location": "泵房",
        "latitude": 30, "longitude": 120, "local_values": {"memo": "不能被重同步覆盖"}})
    second = execute_task(client, root, task, engine, state)
    assert second["result"]["duplicates"] == 2
    assert second["result"]["saved"] == 0
    refreshed = client.get(f"/api/devices?project_id={project}", headers=root).json()
    assert next(d for d in refreshed if d["id"] == first["id"])["local_values"]["memo"] == "不能被重同步覆盖"
    sample = client.get(f"/api/telemetry?project_id={project}", headers=root).json()["items"][0]
    assert sample["raw_values"]["flow_m3h"] == sample["values"]["flow_m3h"] * 10
    assert sample["formula_versions"]["flow_m3h"]["version"] == 1
    assert sample["quality"] == "valid"
    assert mock_http["secret"] not in client.get(f"/api/connections?project_id={project}", headers=root).text
    # Failed responses preserve the last catalog and do not advance the cursor.
    before = client.get(f"/api/connections?project_id={project}", headers=root).json()[0]
    monkeypatch.setattr("alinkiot.business.request", lambda *args: {"items": [], "next": "another-page"})
    assert client.post(f"/api/connections/{source}/refresh", headers=root).status_code == 400
    after = client.get(f"/api/connections?project_id={project}", headers=root).json()[0]
    assert before["catalog"] == after["catalog"]


def test_agent_parameter_reports_alarm_worker_and_permissions(core, mock_http):
    client, engine, password = core
    root = login(client, "root_admin", password)
    customer, project = project_setup(client, root)
    state = client.app.state.state
    source = connection_setup(client, root, project, mock_http, "source")
    sync, config = sync_setup(client, engine, root, project, source)
    execute_task(client, root, sync, engine, state)
    devices = client.get(f"/api/devices?project_id={project}", headers=root).json()
    ids = [d["id"] for d in devices]
    agent = connection_setup(client, root, project, mock_http, "agent")
    put(client, f"/api/connections/{agent}/agent", root, {"agent": "analyst"})
    response = client.post("/api/agent/ask", headers=root, json={"project_id": project,
        "connection_id": agent, "prompt": "分析流量", "device_ids": ids})
    assert response.status_code == 200, response.text
    assert response.json()["agent"] == "analyst"
    assert response.json()["simulated"] is True
    assert response.json()["evidence_count"] == 2
    assert "模拟" in response.json()["answer"]
    for kind in ("report", "ai_report", "ai_warning"):
        task = post(client, "/api/tasks", root, {"project_id": project, "kind": kind,
            "name": kind, "interval_minutes": 1, "config": {"device_ids": ids, "window_minutes": 60,
                "connection_id": agent if kind != "report" else None, "prompt": "判断流量异常", "level": "high"}})
        run = execute_task(client, root, task, engine, state)
        if kind != "ai_warning":
            report_id = run["result"]["report_id"]
            download = client.get(f"/api/reports/{report_id}/download", headers=root)
            assert download.status_code == 200 and "flow_m3h" in download.text
            if kind == "report":
                with engine.begin() as connection:
                    content = connection.execute(select(models.reports.c.content).where(
                        models.reports.c.id == report_id)).scalar_one()
                    content["samples"][0]["external_id"] = "\t=1+1"
                    connection.execute(update(models.reports).where(
                        models.reports.c.id == report_id).values(content=content))
                exported = client.get(f"/api/reports/{report_id}/download", headers=root)
                rows = list(csv.reader(io.StringIO(exported.text.lstrip("\ufeff"))))
                assert rows[1][0] == "'\t=1+1"
    rule = post(client, "/api/alarm-rules", root, {"project_id": project, "name": "高流量",
        "device_id": ids[0], "metric": "flow_m3h", "operator": "gt", "threshold": 1, "level": "high"})
    execute_task(client, root, sync, engine, state)
    alarms = client.get(f"/api/alarm-events?project_id={project}", headers=root).json()
    assert {a["source"] for a in alarms} == {"device_rule", "intelligent_warning"}
    event = alarms[0]
    assert event["notifications"][0]["channel"] == "platform"
    assert client.post(f"/api/alarm-events/{event['id']}/actions", headers=root, json={"note": "已检查"}).status_code == 200
    admin_password = secrets.token_urlsafe(20)
    admin = post(client, "/api/users", root, {"username": "biz_admin", "password": admin_password, "customer_id": customer})
    put(client, f"/api/users/{admin}/grants", root, {"grants": [{"project_id": project, "capabilities": ["report", "export"]}]})
    auth = login(client, "biz_admin", admin_password)
    assert client.post("/api/formulas", headers=auth, json={"project_id": project, "name": "illegal", "expression": "value"}).status_code == 403
    assert client.post(f"/api/tasks/{sync}/run", headers=auth).status_code == 403
    personal_password = secrets.token_urlsafe(20)
    ordinary = post(client, "/api/users", auth, {"username": "biz_user", "password": personal_password})
    put(client, f"/api/users/{ordinary}/grants", auth, {"grants": [{"project_id": project, "capabilities": ["report"]}]})
    user = login(client, "biz_user", personal_password)
    panel = post(client, "/api/panels", user, {"project_id": project, "kind": "curve", "name": "个人曲线",
        "visibility": "private", "config": {"series": [{"device_id": ids[0], "metric": "flow_m3h"}]}})
    assert client.post("/api/panels", headers=user, json={"project_id": project, "kind": "dashboard", "name": "illegal",
        "visibility": "shared", "config": {"series": [{"device_id": ids[0], "metric": "flow_m3h"}]}}).status_code == 403
    assert client.post(f"/api/alarm-events/{event['id']}/actions", headers=user, json={"note": "illegal"}).status_code == 403
    assert client.delete(f"/api/panels/{panel}", headers=user).status_code == 200
    dashboard = post(client, "/api/panels", root, {"project_id": project, "kind": "dashboard", "name": "限时大屏",
        "visibility": "shared", "config": {"series": [{"device_id": ids[0], "metric": "flow_m3h"}]}})
    share = client.post(f"/api/panels/{dashboard}/share", headers=root)
    assert share.status_code == 200, share.text
    shared_headers = {"X-Panel-Share": share.json()["token"]}
    assert client.get("/api/shared-panel", headers=shared_headers).json()["name"] == "限时大屏"
    assert client.post(f"/api/panels/{dashboard}/share", headers=user).status_code == 403
    assert client.delete(f"/api/panels/{dashboard}/shares", headers=root).status_code == 200
    assert client.get("/api/shared-panel", headers=shared_headers).status_code == 403
    assert client.delete(f"/api/projects/{project}", headers=root).status_code == 409
    # A due enabled task is scheduled once, and ordinary users cannot enable it.
    with engine.begin() as connection:
        connection.execute(update(models.tasks).where(models.tasks.c.id == sync).values(enabled=True, next_run_at=models.now() - timedelta(minutes=1)))
    assert tick(engine, state) == 1
    assert tick(engine, state) == 0
    # Losing owner permissions causes queued runs to fail with no data write.
    before_cursor = client.get(f"/api/tasks?project_id={project}", headers=root).json()
    queued = client.post(f"/api/tasks/{sync}/run", headers=root).json()
    with engine.begin() as connection:
        connection.execute(update(models.users).where(models.users.c.username == "root_admin").values(enabled=False))
    tick(engine, state)
    with engine.connect() as connection:
        run = connection.execute(select(models.runs).where(models.runs.c.id == queued["id"])).mappings().one()
        assert run["status"] == "failed"
        assert connection.execute(select(models.tasks.c.cursor).where(models.tasks.c.id == sync)).scalar_one() == next(t["cursor"] for t in before_cursor if t["id"] == sync)


def test_formula_safety_and_upgrade(core):
    for expression in ("__import__('os')", "value.real", "value ** 100000", "[value]", "sum(value)"):
        with pytest.raises((ValueError, SyntaxError)):
            compute(expression, {}, 10)
    assert compute("value / factor + offset", {"factor": 10, "offset": 2}, 100) == 12
    with pytest.raises(ZeroDivisionError):
        compute("value / zero", {"zero": 0}, 10)
    client, engine, _ = core
    assert "'unsafe-inline'" not in client.get("/sandbox").headers["Content-Security-Policy"].split("style-src")[0]
    with engine.begin() as connection:
        connection.execute(update(models.installation).values(core_version=1))
    upgrade(engine)
    upgrade(engine)
    with engine.connect() as connection:
        assert connection.execute(select(models.installation.c.core_version)).scalar_one() == 2


def test_offline_alarm_recovers_and_formula_failure_is_not_valid(core, mock_http, monkeypatch):
    client, engine, password = core
    root = login(client, "root_admin", password)
    _, project = project_setup(client, root)
    source = connection_setup(client, root, project, mock_http, "source")
    task, config = sync_setup(client, engine, root, project, source, formula=False)
    state = client.app.state.state
    execute_task(client, root, task, engine, state)
    device = client.get(f"/api/devices?project_id={project}", headers=root).json()[0]
    post(client, "/api/alarm-rules", root, {"project_id": project, "name": "离线检测", "device_id": device["id"],
        "metric": "offline", "operator": "offline", "threshold": 1})
    with engine.connect() as connection:
        product = connection.execute(select(models.products).where(models.products.c.id == device["product_id"])).mappings().one()
    from alinkiot.data_service import product_tables
    with engine.connect() as connection:
        _, (_, samples) = product_tables(connection, product["id"])
    with engine.begin() as connection:
        connection.execute(update(samples).where(samples.c.device_id == device["id"]).values(
            event_time=models.now() - timedelta(minutes=2)))
    tick(engine, state)
    events = client.get(f"/api/alarm-events?project_id={project}", headers=root).json()
    assert events[0]["active"] is True
    with engine.begin() as connection:
        connection.execute(update(samples).where(samples.c.device_id == device["id"]).values(event_time=models.now()))
    tick(engine, state)
    event = client.get(f"/api/alarm-events?project_id={project}", headers=root).json()[0]
    assert event["active"] is False and len(event["notifications"]) == 2
    bad_formula = post(client, "/api/formulas", root, {"project_id": project, "name": "零除测试",
        "expression": "value / divisor", "parameters": {"divisor": 0}})
    config["formulas"] = [{"product": "water_meter", "metric": "flow_m3h", "formula_id": bad_formula}]
    put(client, f"/api/tasks/{task}", root, {"project_id": project, "kind": "sync", "name": "公式错误测试",
        "interval_minutes": 1, "config": config})
    with engine.begin() as connection:
        connection.execute(samples.delete())
    execute_task(client, root, task, engine, state)
    newest = client.get(f"/api/telemetry?project_id={project}&latest=true", headers=root).json()["items"][0]
    assert newest["quality"] == "formula_error"
    assert newest["values"]["flow_m3h"] is None
    assert newest["raw_values"]["flow_m3h"] > 0
    devices = client.get(f"/api/devices?project_id={project}", headers=root).json()
    ids = [row["id"] for row in devices]
    agent = connection_setup(client, root, project, mock_http, "agent")
    put(client, f"/api/connections/{agent}/agent", root, {"agent": "analyst"})
    warning = post(client, "/api/tasks", root, {"project_id": project, "kind": "ai_warning",
        "name": "完整证据预警", "interval_minutes": 1, "config": {
            "connection_id": agent, "device_ids": ids, "window_minutes": 60,
            "prompt": "判断流量", "level": "high"}})
    calls = []
    monkeypatch.setattr("alinkiot.worker.ai_answer", lambda *args: calls.append(args) or {
        "agent": "analyst", "answer": "正常", "warning": False})
    for missing_device in (False, True):
        if missing_device:
            with engine.begin() as connection:
                connection.execute(update(samples).values(quality="valid"))
                connection.execute(samples.delete().where(samples.c.device_id == ids[0]))
        queued = client.post(f"/api/tasks/{warning}/run", headers=root)
        assert queued.status_code == 200, queued.text
        tick(engine, state)
        runs = client.get(f"/api/tasks/{warning}/runs", headers=root).json()
        assert next(row for row in runs if row["id"] == queued.json()["id"])["status"] == "failed"
    assert not calls
