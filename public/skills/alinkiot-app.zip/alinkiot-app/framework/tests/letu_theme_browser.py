"""Compare runtime components against the unmodified Letu source in Chrome."""
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
from playwright.sync_api import expect, sync_playwright


def main():
    theme = Path(__file__).resolve().parents[2] / "themes" / "letu-smart"
    static = Path(__file__).resolve().parents[1] / "src" / "alinkiot" / "static" / "letu-smart"
    for source in ("styles.css", "alarms.css", "panels.css", "js/ui.js", "js/charts.js"):
        assert (theme / source).read_bytes() == (static / Path(source).name).read_bytes()
    with tempfile.TemporaryDirectory(prefix="alinkiot-theme-") as directory:
        environment = os.environ.copy()
        environment["ALINK_STATE_DIR"] = directory
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "alinkiot.app:app",
            "--host", "127.0.0.1", "--port", str(port)], env=environment,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    if httpx.get(base + "/health/live", timeout=1).status_code == 200:
                        break
                except httpx.RequestError:
                    pass
                time.sleep(.1)
            else:
                raise RuntimeError("Theme comparison server did not start")
            with sync_playwright() as playwright:
                chrome = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
                browser = playwright.chromium.launch(executable_path=str(chrome) if chrome.exists() else None, headless=True)
                try:
                    actual = browser.new_page(viewport={"width": 1440, "height": 900})
                    reference = browser.new_page(viewport={"width": 1440, "height": 900})
                    actual.route("**/api/install/status", lambda route: route.fulfill(json={"installed": True}))
                    actual.route("**/api/auth/login", lambda route: route.fulfill(json={"access_token": "visual-test-only"}))
                    actual.route("**/api/me", lambda route: route.fulfill(json={"username": "visual_user", "role": "superadmin"}))
                    def list_response(route):
                        route.fulfill(json={"items": [], "total": 0})
                    for resource in ("projects", "customers", "users", "audit-logs"):
                        actual.route(f"**/api/{resource}?*", list_response)
                    reference_html = re.sub(r"<script\b[^>]*>.*?</script>", "", (theme / "index.html").read_text(), flags=re.S)
                    for asset in ("styles.css", "alarms.css", "panels.css"):
                        reference_html = reference_html.replace(f'href="{asset}"', f'href="{base}/theme/letu-smart/{asset}"')
                    reference_html = reference_html.replace("</body>", f'<script src="{base}/static/letu-smart/ui.js"></script></body>')
                    reference.route("**/reference", lambda route: route.fulfill(content_type="text/html", body=reference_html))
                    reference.goto(base + "/reference")
                    actual.goto(base)
                    properties = ["display", "position", "fontFamily", "fontSize", "fontWeight", "lineHeight",
                        "color", "backgroundColor", "backgroundImage", "borderRadius", "borderLeftWidth",
                        "borderBottomWidth", "borderColor", "paddingTop", "paddingRight", "paddingBottom",
                        "paddingLeft", "gap", "boxShadow", "backdropFilter"]
                    def style(page, selector):
                        return page.locator(selector).first.evaluate(
                            "(element, keys) => Object.fromEntries(keys.map(key => [key,getComputedStyle(element)[key]]))", properties)
                    for theme_name in ("dark", "light"):
                        for page in (actual, reference):
                            page.evaluate("(theme) => document.documentElement.dataset.theme=theme", theme_name)
                        actual.wait_for_timeout(600)
                        for selector, source in [(".auth", ".auth"), (".auth-wrap", ".auth-wrap"),
                            (".login-card", ".login-card"), (".input-wrap input", ".input-wrap input"),
                            ("#login-submit", "#loginBtn"), (".theme-pill", ".theme-pill")]:
                            assert style(actual, selector) == style(reference, source), (theme_name, selector,
                                style(actual, selector), style(reference, source))
                    actual.locator('#login-form [name="username"]').fill("visual_user")
                    actual.locator('#login-form [name="password"]').fill("visual-test-only")
                    actual.locator("#login-submit").click()
                    expect(actual.locator("#workspace")).to_be_visible()
                    source_js = (theme / "js" / "app.js").read_text()
                    navigation = source_js[source_js.index("const NAV ="):source_js.index("let CURRENT")]
                    build_nav = source_js[source_js.index("function buildNav()"):source_js.index("function markNav(")]
                    reference.evaluate("() => {" + navigation + build_nav +
                        "function go(){} function syncMenuButtons(){} buildNav();"
                        "document.getElementById('auth').remove();document.getElementById('app').classList.add('on');"
                        "document.querySelector('[data-nav=\"dashboard\"]').classList.add('on');"
                        "document.body.classList.add('logged-in');}")
                    for theme_name in ("dark", "light"):
                        for page in (actual, reference):
                            page.evaluate("(theme) => document.documentElement.dataset.theme=theme", theme_name)
                        actual.wait_for_timeout(600)
                        for selector in (".sidebar", ".sb-head", ".sb-nav", ".nav-item", ".sb-foot",
                            ".sb-user", ".topbar", ".tb-search", ".tb-icon", ".theme-switch", ".view"):
                            assert style(actual, selector) == style(reference, selector), (theme_name, selector)
                        for width, height in ((1440, 900), (1280, 720), (390, 844)):
                            for page in (actual, reference):
                                page.set_viewport_size({"width": width, "height": height})
                            actual.wait_for_timeout(400)
                            for selector in (".topbar", ".view"):
                                assert actual.locator(selector).bounding_box() == reference.locator(selector).bounding_box(), (
                                    theme_name, width, selector, actual.locator(selector).bounding_box(), reference.locator(selector).bounding_box())
                    for page in (actual, reference):
                        page.set_viewport_size({"width": 1440, "height": 900})
                    actual.locator('[data-route="customers"]').click()
                    actual.locator("#create-resource").click()
                    reference.evaluate("""() => {
                        document.getElementById('view').innerHTML = '<div class="view-in"><div class="page-head"><div>' +
                          '<h1 class="page-title">客户管理</h1><p class="page-desc">客户档案</p></div>' +
                          '<div class="page-actions"><button class="btn btn-primary">新增客户</button></div></div>' +
                          '<div class="card"><div class="table-wrap"><table class="tbl"><thead><tr><th>名称</th></tr></thead></table></div>' +
                          '<div class="pager"><span class="pinfo">共 0 条</span></div></div></div>';
                        openModal('新增客户', '<div class="form-field"><label>客户名称</label><input class="inp"></div>' +
                          '<div class="form-field"><label>状态</label><select class="sel"><option>正常</option></select></div>',
                          '<button class="btn btn-primary">保存</button>');
                    }""")
                    for theme_name in ("dark", "light"):
                        for page in (actual, reference):
                            page.evaluate("(theme) => document.documentElement.dataset.theme=theme", theme_name)
                        actual.wait_for_timeout(600)
                        for selector in (".page-title", ".page-desc", ".page-actions .btn", ".card", ".tbl",
                            ".tbl thead th", ".pager", ".modal", ".modal-head", ".modal-body", ".modal-foot",
                            ".form-field label", ".modal .inp", ".modal .sel"):
                            assert style(actual, selector) == style(reference, selector), (theme_name, selector,
                                style(actual, selector), style(reference, selector))
                    print("Letu source assets, login components, shell styles and responsive geometry match")
                finally:
                    browser.close()
        finally:
            process.terminate()
            process.wait(timeout=10)


if __name__ == "__main__":
    main()
