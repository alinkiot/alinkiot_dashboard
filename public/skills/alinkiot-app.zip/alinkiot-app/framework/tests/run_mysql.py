"""Run the framework suite against an isolated, disposable MySQL container."""
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path

import pymysql


def main():
    environment = os.environ.copy()
    environment["MYSQL_ROOT_PASSWORD"] = secrets.token_urlsafe(24)
    image = environment.get("ALINK_TEST_MYSQL_IMAGE", "mysql:8.0")
    container = subprocess.check_output([
        "docker", "run", "--detach", "--name", "alinkiot-test-" + secrets.token_hex(6),
        "--env", "MYSQL_ROOT_PASSWORD", "--env", "MYSQL_ROOT_HOST=%",
        "--publish", "127.0.0.1::3306", image,
    ], env=environment, text=True).strip()
    try:
        port = int(subprocess.check_output(["docker", "port", container, "3306/tcp"], text=True).strip().rsplit(":", 1)[1])
        for _ in range(90):
            try:
                connection = pymysql.connect(host="127.0.0.1", port=port, user="root",
                    password=environment["MYSQL_ROOT_PASSWORD"], connect_timeout=2)
                connection.close()
                break
            except pymysql.Error:
                time.sleep(1)
        else:
            raise RuntimeError("Isolated MySQL did not become ready")
        environment["ALINK_TEST_MYSQL_PORT"] = str(port)
        environment["ALINK_TEST_MYSQL_PASSWORD"] = environment["MYSQL_ROOT_PASSWORD"]
        result = subprocess.call([sys.executable, "-m", "pytest", "-q"], env=environment,
                                 cwd=Path(__file__).parents[1])
        if result == 0 and environment.get("ALINK_TEST_BROWSER") == "1":
            result = subprocess.call([sys.executable, "tests/core_browser.py"], env=environment,
                                     cwd=Path(__file__).parents[1])
        if result == 0 and environment.get("ALINK_TEST_BROWSER") == "1":
            result = subprocess.call([sys.executable, "tests/iot_browser.py"], env=environment,
                                     cwd=Path(__file__).parents[1])
        return result
    finally:
        subprocess.run(["docker", "rm", "--force", "--volumes", container],
                       stdout=subprocess.DEVNULL, check=True)


if __name__ == "__main__":
    sys.exit(main())
