"""Exercise the install wizard in Chrome without writing to a database."""
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
from playwright.sync_api import expect, sync_playwright


def main():
    with tempfile.TemporaryDirectory(prefix="alinkiot-wizard-") as directory:
        environment = os.environ.copy()
        environment["ALINK_STATE_DIR"] = directory
        environment["ALINK_PANEL_SCRIPTS"] = "0"
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "alinkiot.app:app",
                                    "--host", "127.0.0.1", "--port", str(port)],
                                   env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    if httpx.get(base + "/health/live", timeout=1).status_code == 200:
                        break
                except httpx.RequestError:
                    pass
                time.sleep(.1)
            else:
                raise RuntimeError("Wizard test server did not become ready")
            with sync_playwright() as playwright:
                chrome = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
                browser = playwright.chromium.launch(
                    executable_path=str(chrome) if chrome.exists() else None, headless=True)
                try:
                    page = browser.new_page(viewport={"width": 1366, "height": 768})
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    requests = []
                    test_ok = False
                    install_ok = False

                    def test_route(route):
                        requests.append(("test", route.request.post_data_json))
                        route.fulfill(status=200 if test_ok else 400, json=(
                            {"ok": True, "database_exists": False} if test_ok else {"detail": "连接失败：请检查配置"}))

                    def install_route(route):
                        requests.append(("install", route.request.post_data_json))
                        route.fulfill(status=200 if install_ok else 400, json=(
                            {"installed": True, "plugins": ["demo_meter"], "demo": {
                                "created": True, "devices": 2, "samples": 48,
                                "accounts": [{"username": "demo_user", "password": "random-test-only", "role": "user"}]}} if install_ok
                            else {"detail": "安装失败；检查数据库权限后重试"}))

                    page.route("**/api/install/test", test_route)
                    page.route("**/api/install", install_route)
                    page.goto(base + "/install")
                    active = lambda index: page.locator(f'[data-step="{index}"]')
                    field = lambda name: page.locator(f'input[name="{name}"]')
                    next_button = page.locator("#next-step")
                    previous = page.locator("#previous-step")
                    shell_bounds = {}
                    def fits_screen():
                        for width, height in ((1366, 768), (1280, 720)):
                            page.set_viewport_size({"width": width, "height": height})
                            bounds = page.locator(".install-shell").bounding_box()
                            viewport = (width, height)
                            if viewport not in shell_bounds:
                                shell_bounds[viewport] = bounds
                            assert bounds == shell_bounds[viewport], "Install frame moved or resized between steps"
                            assert page.locator(".install-panel:not([hidden])").evaluate(
                                "panel => panel.scrollHeight <= panel.clientHeight"), str(page.locator(
                                    ".install-panel:not([hidden])").evaluate(
                                        "panel => ({content:panel.scrollHeight,available:panel.clientHeight})"))
                            assert page.evaluate("document.documentElement.scrollHeight <= innerHeight"), (
                                f"Step has vertical overflow at {width}x{height}: " + str(page.evaluate(
                                    "Object.fromEntries(['.install-shell','.install-header','.install-steps',"
                                    "'.install-panel:not([hidden])','.install-actions','#result'].map(selector => "
                                    "[selector,document.querySelector(selector).getBoundingClientRect().height]))")))
                            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                        page.set_viewport_size({"width": 1366, "height": 768})

                    expect(active(0)).to_be_visible()
                    fits_screen()
                    next_button.click()
                    expect(active(0)).to_be_visible()
                    field("token").fill("local-test-token")
                    next_button.click()
                    expect(active(1)).to_be_visible()
                    fits_screen()
                    expect(field("database")).to_have_value("alinkiot_app")
                    expect(next_button).to_be_disabled()
                    field("username").fill("test-user")
                    field("password").fill(secrets.token_urlsafe(20))
                    field("tls").uncheck()
                    # Connection testing must not require credentials from the admin step.
                    page.locator("#test-database").click()
                    expect(page.locator("#connection-result")).to_contain_text("连接失败")
                    fits_screen()
                    expect(next_button).to_be_disabled()
                    test_ok = True
                    page.locator("#test-database").click()
                    expect(next_button).to_be_enabled()
                    expect(page.locator("#connection-result")).to_contain_text("正式安装时将自动创建")
                    fits_screen()
                    field("host").fill("localhost")
                    expect(next_button).to_be_disabled()
                    page.locator("#test-database").click()
                    expect(next_button).to_be_enabled()
                    next_button.click()
                    expect(active(2)).to_be_visible()
                    fits_screen()
                    password = secrets.token_urlsafe(20)
                    field("admin_password").fill(password)
                    field("admin_password_confirm").fill(password + "different")
                    next_button.click()
                    expect(active(2)).to_be_visible()
                    field("admin_password_confirm").fill(password)
                    next_button.click()
                    expect(active(3)).to_be_visible()
                    fits_screen()
                    expect(page.locator("#summary-database")).to_have_text("alinkiot_app")
                    assert password not in active(3).inner_text()
                    assert "local-test-token" not in active(3).inner_text()
                    # Back navigation preserves inputs but returning requires confirmation again.
                    previous.click()
                    expect(field("admin_password")).to_have_value(password)
                    next_button.click()
                    page.locator("#start-install").click()
                    assert not any(kind == "install" for kind, _ in requests)
                    field("acknowledge").check()
                    page.locator("#start-install").click()
                    expect(page.locator("#result")).to_contain_text("安装失败")
                    fits_screen()
                    expect(active(3)).to_be_visible()
                    expect(page.locator("#start-install")).to_be_enabled()
                    install_ok = True
                    page.locator("#start-install").click()
                    expect(active(4)).to_be_visible()
                    fits_screen()
                    expect(page.locator("#installed-plugins")).to_contain_text("demo_meter")
                    expect(page.locator("#installed-demo")).to_contain_text("48 条历史采样")
                    with page.expect_download() as downloaded:
                        page.locator("#download-demo-accounts").click()
                    assert downloaded.value.suggested_filename == "alinkiot-demo-accounts.json"
                    expect(page.locator("#wizard-actions")).to_be_hidden()
                    expect(field("admin_password")).to_have_value("")
                    expect(field("password")).to_have_value("")
                    expect(field("token")).to_have_value("")
                    sent = [data for kind, data in requests if kind == "install"]
                    assert len(sent) == 2
                    assert sent[-1]["admin_password"] == password
                    assert "admin_password_confirm" not in sent[-1]
                    assert sent[-1]["database"]["database"] == "alinkiot_app"
                    assert sent[-1]["seed_demo"] is True
                    assert not errors, errors
                    # Small screens retain the guide and navigation without page overflow.
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.goto(base + "/install")
                    expect(active(0)).to_be_visible()
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                    field("token").fill("local-test-token")
                    next_button.click()
                    expect(active(1)).to_be_visible()
                    expect(active(1).locator(".step-guide")).to_be_visible()
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
                    page.evaluate("""() => {
                        const frame = document.createElement('iframe');
                        frame.id = 'sandbox-test'; frame.hidden = true;
                        frame.sandbox = 'allow-scripts'; frame.src = '/sandbox';
                        const channel = new MessageChannel();
                        window.testPanelChannel = channel.port1;
                        window.testPanelData = {type:'alink-panel-data', html:
                            '<span id="default-value" data-alink-device="meter" data-alink-metric="flow"></span>' +
                            '<script>window.uploadedScriptRan=true</script>',
                            data:{samples:[{device_id:'meter',values:{flow:12},units:{flow:'m³/h'}}]}};
                        function ready(event) {
                            if (event.source !== frame.contentWindow || event.data?.type !== 'alink-panel-ready') return;
                            window.removeEventListener('message', ready);
                            frame.contentWindow.postMessage({type:'alink-panel-connect'}, '*', [channel.port2]);
                            channel.port1.postMessage(window.testPanelData);
                        }
                        window.addEventListener('message', ready);
                        document.body.append(frame);
                    }""")
                    child = page.frame_locator("#sandbox-test")
                    expect(child.locator("#default-value")).to_have_text("12 m³/h")
                    assert child.locator("body").evaluate("() => window.uploadedScriptRan === undefined")
                    with page.expect_event("framenavigated", predicate=lambda frame: frame.url.endswith("/sandbox?new=1")) as navigation:
                        child.locator("body").evaluate("() => {location.href='/sandbox?new=1'}")
                    navigation.value.wait_for_load_state()
                    page.evaluate("""async () => {
                        window.testPanelChannel.postMessage(window.testPanelData);
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }""")
                    assert navigation.value.evaluate("() => AlinkPanelSDK.read().samples.length") == 0
                    page.evaluate("() => {window.testPanelChannel.close();document.getElementById('sandbox-test').remove()}")
                    assert not errors, errors
                    print("Install wizard browser checks passed")
                finally:
                    browser.close()
        finally:
            process.terminate()
            process.wait(timeout=10)


if __name__ == "__main__":
    main()
