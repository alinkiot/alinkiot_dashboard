import os
import secrets
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient
from pydantic import SecretStr, ValidationError
from sqlalchemy import create_engine, insert, inspect, select, text

from alinkiot import models
from alinkiot.app import create_app
from alinkiot.installer import install, installed, install_plugins, prepare_database
from alinkiot.plugins import Manifest, discover, ensure_table, tables
from alinkiot.state import DatabaseInput, State

PLUGINS = Path(__file__).parents[1] / "plugins"


@pytest.fixture
def engine():
    engine = create_engine("sqlite://")
    yield engine
    engine.dispose()


def example():
    return discover(PLUGINS)[0]


def changed_manifest(version=2, field=None):
    data = example().model_dump()
    data["version"] = version
    data["products"][0]["metrics"].append(field or {"name": "pressure", "type": "number"})
    return Manifest.model_validate(data)


def test_install_idempotency_and_additive_plugin(engine):
    install(engine, [example()], "admin", "very-strong-password")
    assert installed(engine)
    with pytest.raises(ValueError, match="already installed"):
        install(engine, [example()], "other", "another-strong-password")
    install_plugins(engine, [example()], None)
    install_plugins(engine, [changed_manifest()], None)
    with engine.connect() as connection:
        assert connection.execute(select(models.users.c.username)).scalars().all() == ["admin"]
        assert connection.execute(select(models.plugins.c.version)).scalar_one() == 2
        assert "pressure" in {c["name"] for c in inspect(connection).get_columns(tables(example())[1].name)}
    with pytest.raises(ValueError, match="increasing"):
        install_plugins(engine, [example()], None)
    data = changed_manifest().model_dump()
    data["version"] = 3
    data["products"][0]["metrics"][0]["type"] = "text"
    with pytest.raises(ValueError, match="additive"):
        install_plugins(engine, [Manifest.model_validate(data)], None)
    with engine.connect() as connection:
        assert connection.execute(select(models.plugins.c.version)).scalar_one() == 2


def test_install_demo_seed_is_transactional_and_idempotent(engine, tmp_path, monkeypatch):
    from sqlalchemy import func
    from alinkiot.seed import seed_existing
    from alinkiot.security import verify_password
    state = State(tmp_path / "seed-state")
    import alinkiot.seed as seed
    with monkeypatch.context() as patch:
        patch.setattr(seed, "persist_sync", lambda *args: (_ for _ in ()).throw(ValueError("seed failure")))
        with pytest.raises(ValueError, match="seed failure"):
            install(engine, [example()], "seed_root", "very-strong-password", seed_demo=True, state=state)
    assert not installed(engine)
    with engine.connect() as connection:
        assert connection.execute(select(func.count()).select_from(models.users)).scalar_one() == 0
        assert connection.execute(select(func.count()).select_from(models.projects)).scalar_one() == 0
    result = install(engine, [example()], "seed_root", "very-strong-password", seed_demo=True, state=state)
    assert result["created"] and result["samples"] == 48
    assert len(result["accounts"]) == 2
    with engine.connect() as connection:
        assert connection.execute(select(func.count()).select_from(models.devices)).scalar_one() == 2
        assert connection.execute(select(func.count()).select_from(tables(example())[1])).scalar_one() == 48
        assert connection.execute(select(func.count()).select_from(models.reports)).scalar_one() == 1
        assert connection.execute(select(models.alarm_events.c.active)).scalar_one() is True
        assert not any(connection.execute(select(models.tasks.c.enabled)).scalars())
        assert not any(connection.execute(select(models.alarm_rules.c.enabled)).scalars())
        for account in result["accounts"]:
            user = connection.execute(select(models.users).where(
                models.users.c.username == account["username"])).mappings().one()
            assert verify_password(account["password"], user["password_hash"])
            assert account["password"] != "very-strong-password"
            assert account["password"] not in str(connection.execute(select(models.audit)).mappings().all())
    assert seed_existing(engine, state)["created"] is False
    assert seed_existing(engine, state)["accounts"] == []


def test_partial_ddl_recovery_and_unique_data(engine):
    install(engine, [example()], "admin", "very-strong-password")
    new = changed_manifest()
    with engine.connect() as connection:
        ensure_table(connection, tables(new)[1])
        connection.commit()
    install_plugins(engine, [new], None)
    with engine.begin() as connection:
        project = connection.execute(insert(models.projects).values(name="demo").returning(models.projects.c.id)).scalar_one()
        product = connection.execute(select(models.products.c.id)).scalar_one()
        device = connection.execute(insert(models.devices).values(project_id=project, product_id=product, external_id="demo").returning(models.devices.c.id)).scalar_one()
        samples = tables(new)[1]
        connection.execute(insert(samples).values(device_id=device, source_key="sample-1", event_time=models.now(),
            raw_values={"flow_m3h": 10}, formula_versions={}, quality="valid", ingested_at=models.now(),
            flow_m3h=10, running=True, pressure=2))
        assert connection.execute(select(samples.c.flow_m3h)).scalar_one() == 10


def test_manifest_rejects_sql_and_same_version_changes(engine):
    data = example().model_dump()
    data["products"][0]["metrics"][0]["name"] = "x);drop_table"
    with pytest.raises(ValidationError):
        Manifest.model_validate(data)
    data = example().model_dump()
    data["sql"] = "DROP TABLE users"
    with pytest.raises(ValidationError):
        Manifest.model_validate(data)
    install(engine, [example()], "admin", "very-strong-password")
    with pytest.raises(ValueError, match="increasing"):
        install_plugins(engine, [changed_manifest(version=1)], None)


def test_schema_drift_not_silently_accepted(engine):
    install(engine, [example()], "admin", "very-strong-password")
    name = tables(example())[1].name
    with engine.begin() as connection:
        connection.execute(text("DROP INDEX ix_demo_meter_water_meter_time"))
    with pytest.raises(ValueError, match="index differs"):
        install_plugins(engine, [example()], None)
    assert inspect(engine).has_table(name)


def test_product_name_collisions_rejected_before_ddl(engine):
    data = example().model_dump()
    data["id"] = "a_b"
    data["products"][0]["id"] = "c"
    first = Manifest.model_validate(data)
    data["id"] = "a"
    data["products"][0]["id"] = "b_c"
    second = Manifest.model_validate(data)
    with pytest.raises(ValueError, match="collide"):
        install(engine, [first, second], "admin", "very-strong-password")
    assert not inspect(engine).has_table("p_a_b_c_samples")


def test_cli_server_readiness_and_static_files(tmp_path):
    environment = os.environ.copy()
    environment["ALINK_STATE_DIR"] = str(tmp_path / "server-state")
    environment["ALINK_PLUGIN_DIR"] = str(PLUGINS)
    command = [sys.executable, "-c", "from alinkiot.cli import main; main()"]
    token = subprocess.check_output(command + ["install-token"], text=True, env=environment).strip()
    assert State(tmp_path / "server-state").check_token(token)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    process = subprocess.Popen(command + ["serve", "--port", str(port)], env=environment,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(50):
            try:
                response = httpx.get(base + "/health/live", timeout=1)
                if response.status_code == 200:
                    break
            except httpx.RequestError:
                pass
            if process.poll() is not None:
                pytest.fail("Framework CLI server exited before readiness")
            time.sleep(.1)
        else:
            pytest.fail("Framework CLI server did not become responsive")
        assert httpx.get(base + "/health/ready").status_code == 503
        assert httpx.get(base + "/install").status_code == 200
        assert httpx.get(base + "/static/install.js").status_code == 200
        assert httpx.get(base + "/static/style.css").status_code == 200
    finally:
        process.terminate()
        process.wait(timeout=10)


def test_encrypted_state_and_secret_free_http_errors(tmp_path):
    state = State(tmp_path / "state")
    token = state.token()
    assert state.check_token(token) and not state.check_token("wrong")
    settings = DatabaseInput(host="localhost", database="testdb", username="admin", password="a-secret-password", tls=False)
    with state.lock():
        state.save_database(settings)
    assert "a-secret-password" not in (state.directory / "database.json").read_text()
    assert state.database().password.get_secret_value() == "a-secret-password"
    assert (state.directory / "database.json").stat().st_mode & 0o777 == 0o600
    (state.directory / "master.key").unlink()
    with pytest.raises(ValueError, match="missing"):
        state.database()
    assert not (state.directory / "master.key").exists()
    client = TestClient(create_app(tmp_path / "http-state", PLUGINS))
    assert client.get("/install").status_code == 200
    assert client.post("/api/install/test", json={"password": "a-secret-password"}).status_code == 403
    http_state = State(tmp_path / "http-state")
    response = client.post("/api/install/test", headers={"X-Install-Token": http_state.token()},
        json={"password": "a-secret-password"})
    assert response.status_code == 422
    assert "a-secret-password" not in response.text
    assert client.get("/health/live").status_code == 200


@pytest.mark.skipif(not os.environ.get("ALINK_TEST_MYSQL_PORT"), reason="Isolated MySQL integration server not configured")
def test_mysql_web_install_with_demo_seed(tmp_path):
    settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
        database="seed_" + secrets.token_hex(8), username="root",
        password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
    state = State(tmp_path / "state")
    client = TestClient(create_app(state.directory, PLUGINS))
    database = settings.model_dump(mode="json")
    database["password"] = settings.password.get_secret_value()
    payload = {"database": database, "admin_username": "seed_root",
               "admin_password": secrets.token_urlsafe(20), "seed_demo": True}
    headers = {"X-Install-Token": state.token()}
    response = client.post("/api/install", json=payload, headers=headers)
    assert response.status_code == 200, response.text
    demo = response.json()["demo"]
    assert demo["created"] and demo["samples"] == 48
    account = next(row for row in demo["accounts"] if row["role"] == "user")
    logged_in = client.post("/api/auth/login", json={
        "username": account["username"], "password": account["password"]})
    auth = {"Authorization": "Bearer " + logged_in.json()["access_token"]}
    projects = client.get("/api/projects", headers=auth).json()["items"]
    assert len(projects) == 1 and projects[0]["id"] == demo["project_id"]
    assert len(client.get(f"/api/telemetry?project_id={demo['project_id']}", headers=auth).json()["items"]) == 48
    assert account["password"] not in client.get("/api/audit-logs", headers=auth).text
    assert client.post("/api/install", json=payload, headers=headers).status_code == 409


@pytest.mark.skipif(not os.environ.get("ALINK_TEST_MYSQL_PORT"), reason="Isolated MySQL integration server not configured")
def test_mysql_install_auth_and_plugin_lifecycle(tmp_path):
    settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
        database="alinkiot_test", username="root", password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
    plugin_root = tmp_path / "plugins"
    (plugin_root / "demo_meter").mkdir(parents=True)
    manifest_path = plugin_root / "demo_meter" / "plugin.json"
    manifest_path.write_text(example().model_dump_json())
    state_dir = tmp_path / "state"
    state = State(state_dir)
    headers = {"X-Install-Token": state.token()}
    client = TestClient(create_app(state_dir, plugin_root))
    password = secrets.token_urlsafe(20)
    database = settings.model_dump(mode="json")
    database["password"] = settings.password.get_secret_value()
    payload = {"database": database, "admin_username": "admin", "admin_password": password}
    response = client.post("/api/install/test", json=database, headers=headers)
    assert response.status_code == 200, response.text
    assert response.json()["database_exists"] is False
    server = settings.engine(server_only=True)
    try:
        with server.connect() as connection:
            assert connection.execute(text(
                "SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=:name"),
                {"name": settings.database}).first() is None
    finally:
        server.dispose()
    assert not (state_dir / "database.json").exists()
    response = client.post("/api/install", json=payload, headers=headers)
    assert response.status_code == 200, response.text
    assert prepare_database(settings, create=True) is True
    assert not (state_dir / "install.token").exists()
    assert client.get("/health/ready").status_code == 200
    assert client.post("/api/install", json=payload, headers=headers).status_code == 409
    assert client.get("/install").status_code == 409
    assert client.get("/api/plugins").status_code == 401
    response = client.post("/api/auth/login", json={"username": "admin", "password": password})
    assert response.status_code == 200, response.text
    auth = {"Authorization": "Bearer " + response.json()["access_token"]}
    assert client.get("/api/me", headers=auth).json()["role"] == "superadmin"
    assert client.post("/api/plugins/install", headers=auth).status_code == 200
    manifest_path.write_text(changed_manifest().model_dump_json())
    response = client.post("/api/plugins/install", headers=auth)
    assert response.status_code == 200, response.text
    assert client.get("/api/plugins", headers=auth).json()[0]["version"] == 2
    manifest_path.write_text(example().model_dump_json())
    assert client.post("/api/plugins/install", headers=auth).status_code == 400
    bad = changed_manifest().model_dump()
    bad["version"] = 3
    bad["products"][0]["metrics"][0]["type"] = "text"
    manifest_path.write_text(Manifest.model_validate(bad).model_dump_json())
    assert client.post("/api/plugins/install", headers=auth).status_code == 400
    assert client.get("/api/plugins", headers=auth).json()[0]["version"] == 2
    manifest_path.write_text(changed_manifest().model_dump_json())
    engine = settings.engine()
    try:
        with engine.begin() as connection:
            project = connection.execute(insert(models.projects).values(name="demo")).inserted_primary_key[0]
            product = connection.execute(select(models.products.c.id)).scalar_one()
            device = connection.execute(insert(models.devices).values(
                project_id=project, product_id=product, external_id="demo")).inserted_primary_key[0]
            samples = tables(changed_manifest())[1]
            connection.execute(insert(samples).values(device_id=device, source_key="sample-1",
                event_time=models.now(), raw_values={"flow_m3h": 10}, formula_versions={},
                quality="valid", ingested_at=models.now(), flow_m3h=10, running=True, pressure=2))
            assert connection.execute(select(samples.c.flow_m3h)).scalar_one() == 10
            connection.execute(models.users.update().values(role="user"))
        assert client.post("/api/plugins/install", headers=auth).status_code == 403
        with engine.begin() as connection:
            connection.execute(models.users.update().values(role="superadmin"))
    finally:
        engine.dispose()
    assert client.post("/api/auth/logout", headers=auth).status_code == 200
    assert client.get("/api/me", headers=auth).status_code == 401
    for _ in range(5):
        assert client.post("/api/auth/login", json={"username": "admin", "password": "wrong"}).status_code == 401
    assert client.post("/api/auth/login", json={"username": "ADMIN", "password": password}).status_code == 429
    assert settings.password.get_secret_value() not in (state_dir / "database.json").read_text()
    assert password not in (state_dir / "database.json").read_text()


@pytest.mark.skipif(not os.environ.get("ALINK_TEST_MYSQL_PORT"), reason="Isolated MySQL integration server not configured")
def test_mysql_create_permission_and_existing_database(tmp_path):
    settings = DatabaseInput(host="127.0.0.1", port=int(os.environ["ALINK_TEST_MYSQL_PORT"]),
        database="alinkiot_existing", username="root", password=os.environ["ALINK_TEST_MYSQL_PASSWORD"], tls=False)
    assert prepare_database(settings, create=True) is False
    engine = settings.engine()
    limited_password = secrets.token_urlsafe(24)
    try:
        with engine.begin() as connection:
            connection.execute(text("CREATE TABLE preserved_data (value INTEGER NOT NULL)"))
            connection.execute(text("INSERT INTO preserved_data VALUES (42)"))
            connection.execute(text("CREATE USER 'install_limited'@'%' IDENTIFIED BY :password"),
                               {"password": limited_password})
            connection.execute(text("GRANT SELECT ON alinkiot_denied.* TO 'install_limited'@'%'"))
        assert prepare_database(settings, create=True) is True
        with engine.connect() as connection:
            assert connection.execute(text("SELECT value FROM preserved_data")).scalar_one() == 42
            charset = connection.execute(text(
                "SELECT DEFAULT_CHARACTER_SET_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=:name"),
                {"name": settings.database}).scalar_one()
            assert charset == "utf8mb4"
    finally:
        engine.dispose()
    limited = settings.model_copy(update={"database": "alinkiot_denied", "username": "install_limited",
        "password": SecretStr(limited_password)})
    state = State(tmp_path / "limited-state")
    client = TestClient(create_app(state.directory, PLUGINS))
    headers = {"X-Install-Token": state.token()}
    database = limited.model_dump(mode="json")
    database["password"] = limited_password
    response = client.post("/api/install/test", headers=headers, json=database)
    assert response.status_code == 200, response.text
    assert response.json()["database_exists"] is False
    response = client.post("/api/install", headers=headers, json={"database": database,
        "admin_username": "admin", "admin_password": secrets.token_urlsafe(24)})
    assert response.status_code == 400
    assert "没有建库权限" in response.json()["detail"]
    assert limited_password not in response.text
    assert not (state.directory / "database.json").exists()
    assert (state.directory / "install.token").exists()
    assert client.get("/api/install/status").json() == {"installed": False}
