# AlinkIoT 固定核心 + 产品插件框架

当前实现：**FastAPI + MySQL 8，Web 安装、客户/项目/三级权限/日志、HTTP 平台接入、产品 schema 绑定、设备档案扩展、原始/公式计算采样入库、查询、独立定时 worker、报表、告警、数字人问答/智能报表/预警，以及原生场景/曲线/大屏与隔离单文件 HTML 面板**。后台复制 Letu 原版登录/应用外壳和组件结构，原样使用 `themes/letu-smart/styles.css`、`alarms.css`、`panels.css`，复用原版 `js/ui.js` 的图标和 `js/charts.js` 图表；侧栏/顶栏、卡片/表格、表单/弹窗/抽屉、助手、科技蓝/明亮白配色与移动菜单均使用原组件。`console.css` 仅处理原主题没有的运行时语义（hidden、原生 dialog 等）及业务扩展，不再另画一套主题。安装向导保留已确认的固定尺寸五步布局。

工作台统计、菜单搜索、通知与业务页面使用真实授权数据，独立分享大屏同样使用 Letu 组件；不加载离线主题的样本数据、模拟登录或控制逻辑。各业务页的数据字段和当前尚缺的生产功能不因复制主题而伪造。部署包包含 `static/letu-smart/` 原文件副本，更新主题时同步对应 CSS、`ui.js`、`charts.js`。HTTP 模拟服务有明确标识，不代表真实设备平台或真实 AI 模型已接通。

## 启动与安装

需要 Python 3.11+、`uv` 和可连接的 MySQL 8 服务。不支持 MariaDB；本阶段仅支持 macOS/Linux。填写专用库名，目标库不存在时正式安装会自动创建（`utf8mb4`），已存在则沿用、不清空数据。新库需要账户具备针对目标库的建库权限；安装及后续插件升级还需该库的 SELECT/INSERT/UPDATE/DELETE、CREATE/ALTER/INDEX/REFERENCES 权限。没有建库权限时明确提示授权或手工预建库，不保存失败连接配置。不要接生产库或已有其他应用的库。

```bash
cd framework
uv sync --locked
uv run alinkiot install-token
uv run alinkiot serve
```

打开 `http://127.0.0.1:58239/install`，按“安装准备 → 数据库连接 → 超管设置 → 确认安装 → 安装完成”逐步操作，每步有独立说明，可以返回修改。桌面采用紧凑双栏布局，常见屏幕尽量一屏显示；小屏保持必要滚动，不裁切操作。数据库名称默认 `alinkiot_app`；连接测试成功后才能继续，修改连接信息/令牌后需重测。测试连接只读验证：目标库不存在时测试 MySQL 服务并提示安装将建库，不执行建库或建表。确认页不显示密码，勾选备份确认后才自动建库建表。密码至少 12 字符，两次输入须一致；账号以字母开头，只能使用字母、数字、点、下划线、连字符。安装成功后 `/install` 与安装 API 被数据库标记锁定，令牌文件删除，页面清空密码。到 `/` 登录后可查看产品插件与安装部署目录里的新插件。

安装命令与服务**必须使用同一个工作目录/状态目录**。默认 `var/` 和 `plugins/` 相对运行目录；部署时建议显式设置绝对路径：

```bash
export ALINK_STATE_DIR=/srv/alinkiot/state
export ALINK_PLUGIN_DIR=/srv/alinkiot/plugins
uv run alinkiot serve --host 127.0.0.1 --port 58239
```

`.env.example` 仅说明环境变量，不自动加载。生产由进程管理器加载环境变量、管理服务，反向代理提供 HTTPS；默认只监听本机，不应把安装向导直接暴露公网。MySQL TLS 默认开启，使用系统 CA 并验证主机名；证书应覆盖填写的数据库主机。本机无 TLS 的测试库可取消勾选，不应在生产关闭。

## 固定核心与插件边界

### 安装演示种子

安装确认页默认勾选“创建完整演示种子”，生产安装可取消。无需启动 mock 或连接外部平台即可初始化：一个【演示】客户和智慧泵房项目、客户管理员/普通用户及项目授权、两个本地模拟平台接入、水表映射、公式、两台水表与 48 条近两小时历史采样、场景/曲线/大屏、统计报表、告警事件与平台内通知、同步/报表/智能任务。数据名称和证据标记演示；没有伪造 AI 回答。所有任务和演示告警规则默认关闭，启动 worker 不会自动调用模拟平台。

演示账号各有独立随机密码，仅保存哈希；安装完成后点击“下载演示账号”，凭证不写入日志或浏览器持久存储，离开完成页后不能再次获取，丢失需超管重置。账号下载文件含密码，应妥善保存，生产中停用演示账号。默认模拟平台为 `127.0.0.1:58240`，需启动 `alinkiot mock` 才能手动同步/问答。

已有安装不必重装，备份后在同一状态目录运行 `uv run alinkiot seed`，终端仅本次输出随机演示凭证（注意终端录屏/日志）；旧库先执行 `alinkiot upgrade`。种子与业务记录在同一事务写入，失败不留下半套业务数据；再次运行根据初始化日志跳过，不覆盖已有数据，不重新生成账号密码。需要保留 `demo_meter` 示例插件；修改了该产品字段时应先核对演示数据兼容性。

固定表：`customers`、`users`、`projects`、`project_grants`、`data_sources`、`products`、`device_registry`、`job_definitions`、`audit_logs`、`user_sessions`、`login_limits`、`plugin_registry`、`installation_state`。

客户/项目/用户/授权和操作日志提供真实 API 与后台。设备注册表保存公共定位，插件为每个产品各建档案表和采样表，不将不同产品字段合并成一张宽表。设备同步、公式、任务、报表、告警及智能体问答通过下述标准 HTTP 协议运行；未经适配的实际平台不能直接替换 URL 即宣称兼容。

## 基础模块与操作流程

安装后使用初始超管登录 `/`：

1. **客户管理**：新建、修改名称、启停客户；无账号/项目关联的客户可删除。停用立即撤销该客户所有会话，保留项目及授权，重新启用后需重新登录。
2. **项目管理**：超管新建项目并设置 IANA 时区，随后“分配客户”。新建未分配项目仅超管可见；转移客户或收回项目在同一事务清除全部项目授权，相同客户不清除。有关联设备/任务的项目不能删除，无关联项目删除会清理授权。
3. **角色权限**：超管仅开通/维护客户管理员，为管理员选择本客户项目与可选能力。客户管理员登录后仅维护本客户普通用户，且只分配自己已获授权的项目/能力。普通用户只有自己的账号信息和获授权项目，不允许创建账号、客户、项目或修改共享配置。
4. **账号生命周期**：账号角色、登录名及客户归属不可在编辑时改变；管理员可启停下级账号、重置密码，立即撤销其会话；本人可验证旧密码修改自己的密码，之后重新登录。账号保留而非硬删除，避免破坏授权归属与审计。
5. **操作日志**：保存创建/修改/删除、归属调整、授权、登录/退出、密码修改和插件动作。超管查看全局；客户管理员仅看本客户记录；普通用户仅看自己的操作。密码只记录“是否重置”，不记录原文或哈希。失败的业务变更不提交数据或成功日志。

管理员停用、重置密码或个人项目授权收回不级联影响其他用户已有授权；管理员在授权页只能修改自己可管理的项目，其范围外的已有授权保留。超管不参与普通用户的日常管理。可选项目能力为 `export/report/configure/sync/alarm`，普通用户上限为 `export/report`；相关业务接口分别校验这些能力，不因主题菜单显示而放行。

列表支持服务端分页和搜索（每页最多 100 条），后台每页 20 条。授权编辑最多 200 个项目；页面明确拒绝超大批次，不静默截断。核心写操作使用安装状态行锁串行化，保证归属转移与授权更新一致；后续扩大吞吐时再细化资源锁。每次请求验证会话、角色、账号及客户状态，并从数据库计算项目范围；不能以菜单是否显示作为授权依据。

客户/权限模块沿用既有表结构。新增数据应用表需执行下述 `alinkiot upgrade`，**不重新安装或重建库**。后台是 Letu 风格的真实业务页，不是将原离线主题全部脚本换成 API。后续 SKILL 生成应用时先让用户选择 `themes/` 中的主题，再基于选定主题生成后台；业务 API、权限与数据模型不绑定主题。

## 数据与智能能力：升级并跑通模拟 HTTP 闭环

旧安装环境先停止旧 Web 进程，备份数据库及 `var/`，在同一目录/状态目录执行：

```bash
cd framework
uv sync --locked
uv run alinkiot upgrade
uv run alinkiot serve     # Web: http://127.0.0.1:58239
```

新安装直接创建全部业务表，无需另行升级。升级是固定代码新增表，不修改现有产品字段或删除数据；数据库 `core_version` 更新为 2。MySQL DDL 非整体事务，失败可重试，不能宣称自动回滚。

另开两个终端（同一环境/状态目录），各自运行：

```bash
uv run alinkiot mock      # 明确标记的本地模拟 HTTP 平台：127.0.0.1:58240
uv run alinkiot worker    # 独立持久化任务调度/执行与告警检测，5 秒轮询
# 执行一轮后退出，用于检查或外部调度
uv run alinkiot worker --once
```

Web 不自动启动定时器，避免多个 Web worker 重复调度；未启动 worker 的任务保持入队，不虚报已执行。多个 MySQL worker 通过数据库级互斥锁保证只有一个执行者；排队/执行中记录持久化，进程中断后可恢复未完成任务。失败记录保存安全摘要，不保存远端异常原文；同步事务失败不推进游标。HTTP AI 失败/进程中断后的人工重试可能再次请求远端，真实平台应支持请求幂等键适配；本版不承诺跨平台 exactly-once。

操作顺序：

1. 超管在“项目管理”创建/分配项目；平台接入选择该项目，新建设备平台，URL `http://127.0.0.1:58240`、AppID `demo`、Secret `demo-only`。点击接入后实际 HTTP 获取模拟产品目录并保存。
2. “绑定产品表”选择模拟水表 → 已安装示例水表 schema。字段、类型、长度、单位必须吻合；否则生成/安装受审插件后再绑定，采样运行不任意建表。
3. “公式配置”新建 `value / factor`、参数 `{"factor":10}`、输出单位 `m³/h`。公式是不可变版本；“新建版本”保留旧版本，任务固定引用具体版本 ID。
4. “同步任务”新建任务、选择设备平台/水表，为 `flow_m3h` 选择公式版本。点击“执行一次”，由 worker 实际 HTTP 获取设备与采样，保存公共设备索引、产品档案、原始值及计算值；按设备/来源键幂等去重。实时/历史页从数据库查询，原始值 120 对应计算值 12，不二次计算。公式失败该属性存空值并标 `formula_error`，不伪造有效零值。
5. “设备档案”维护本地显示名称、位置、经纬度及 JSON 扩展，重同步只更新来源档案，不覆盖本地扩展。“场景管理”关联现场设备、列表和离线定位示意；“曲线/项目大屏”选择多设备属性，卡片→详情/返回，按单系列单位绘图。
6. “报表中心”配置统计报表任务与设备/窗口，可执行一次或由管理员启用周期执行。报表在独立 worker 生成并保存，CSV 下载重新校验项目和报表能力；普通用户只能生成/查看自己的报表任务与结果，不能启用共享定时任务。
7. 平台接入新建“智能体平台”（同模拟 URL/AppID/Secret），自动 HTTP 获取数字人，选择 `analyst` 等目标；更新列表保留新增/变更、下架状态，失败保留旧目录。修改接入需重新输入 Secret 并重新选择数字人；已绑定设备来源不能原地换平台。
8. “智能诊断/智能分析”、右下角助手或历史页“智能分析”发送实际 `POST /ask`，请求包含 `agent`、`prompt` 和受控设备采样。回答/证据数量持久化，模拟回答明确提示非真实模型结论。
9. “智能报表”新建任务，对指定设备窗口执行 HTTP 问答后保存新报表，结果在报表中心查看/下载。“智能预警”以同样方式分析，要求响应有布尔 `warning`；任意文本不直接触发告警。结果写告警事件，来源 `intelligent_warning`，触发/恢复均记录通知。
10. “告警规则”配置数值阈值或离线超时，worker 检测触发/恢复；告警事件保存证据、处理说明和平台内通知记录。处理不等于数据已恢复，不发送假短信/邮件。

新增表：`platform_connections/source_product_links/device_extensions/formula_versions/scheduled_tasks/task_runs/workspace_panels/panel_shares/alarm_rules/alarm_events/alarm_actions/notification_records/generated_reports/agent_conversations`，与原基础表/产品插件表融合在同一 MySQL 库。业务 GET/POST/PUT API 使用 `/api/connections`、`/products`、`/devices`、`/telemetry`、`/formulas`、`/tasks`、`/panels`、`/alarm-rules`、`/alarm-events`、`/reports`、`/agent/ask` 等路径；可从后台操作。读取数据与写配置逐次校验项目/角色/能力，任务执行前与落库前重查所有者权限，授权撤销后不会继续提交业务结果。

## HTTP 适配协议（当前 v1）

服务器环境变量 `ALINK_HTTP_ALLOWLIST` 是逗号分隔的精确 HTTP origin 白名单，默认仅 `http://127.0.0.1:58240`；拒绝未批准地址、不跟随重定向、不使用环境 HTTP 代理。真实平台由部署人员显式批准地址，生产仍需网络层出站限制与正确 TLS；不把任意浏览器 URL 变成代理。

每个请求带 `X-App-ID` / `X-App-Secret`，仅在服务端解密使用。实际平台鉴权签名不同就修改适配器，不将真实密钥放前端存储、URL或日志。

| 方法/路径 | 响应/请求 |
|---|---|
| `GET /products` | `{"items":[{"id":"water_meter","name":"…","archive_fields":[…],"metrics":[…]}],"next":null}`，字段声明同产品插件 |
| `GET /devices` | `{"items":[{"id":"water-001","product":"water_meter","name":"…","archive":{"serial_number":"…"}}],"next":null}` |
| `GET /samples?cursor=…` | `{"items":[{"device":"water-001","key":"稳定来源采样键","time":"带时区 ISO 时间","values":{"flow_m3h":120}}],"cursor":"成功后推进值","next":null}` |
| `GET /avatars` | `{"items":[{"id":"analyst","name":"分析员"}],"next":null}` |
| `POST /ask` | 请求 `{"agent":"analyst","prompt":"分析要求","context":{"project_id":"…","samples":[…]}}` |
| `/ask` 响应 | `{"agent":"analyst","answer":"回答","warning":true,"simulated":true}`；`warning` 为智能预警所需布尔值，真实服务不应标 `simulated:true` |

模拟服务 AppID/Secret 可由 `ALINK_MOCK_APPID/ALINK_MOCK_SECRET` 设置，默认值只用于本地演示。模拟采样随 HTTP 请求时间产生稳定批次来源键，不是浏览器硬编码成功。v1 每批最多 1000 条设备/采样，目录最多 100 项，响应最多 2 MB；收到 `next` 分页标记会拒绝整个批次，不错误推进游标。完整分页、签名鉴权和更大流量需要真实平台适配扩展。

## 面板与分享

原生场景/曲线/大屏持久化选定设备/属性与可见范围，个人曲线与共享配置有独立权限。面板支持自包含单文件 HTML（100 KB 文件/100000 字符配置）；默认不允许上传脚本执行，可使用 `<span data-alink-device="设备ID" data-alink-metric="flow_m3h"></span>` 展示值。部署人员审查所有面板后设置 `ALINK_PANEL_SCRIPTS=1`，才允许脚本通过 `AlinkPanelSDK.read()` 或 `subscribe(listener)` 读取授权关联采样。

HTML 在不含 `allow-same-origin` 的 sandbox 中展示，CSP 禁止外部脚本、fetch/资源连接和表单；iframe 不获得 Bearer/Secret，读不到后台 DOM，不允许顶层导航/弹窗。数据通过绑定初始文档的 MessageChannel 发送，iframe 自身导航不会使新文档继承数据通道。**iframe 不是恶意脚本的绝对隔离**：自身导航等仍可能被脚本用于外发已读内容，不能把允许脚本当作防泄漏承诺；未受审内容保持脚本关闭，生产另行限制网络与资源。SDK `control()` 明确拒绝，真实指令服务未开放。离开详情关闭数据通道并移除 iframe/监听/轮询。

共享项目大屏可生成 1 小时分享地址，令牌仅放 URL fragment，由页面放入 `X-Panel-Share` 请求头，不进查询串。分享可全部撤销；每次拉取校验分享者启用状态、当前项目授权和共享可见性，失效时清除大屏数据。独立 `/screen` 不含后台导航，当前展示原生实时状态卡，不渲染自定义上传 HTML。

## 当前仍未完成的范围

这是一套能运行标准 HTTP **模拟闭环**的基础实现，不是全部生产需求已交付。以下仍需继续实现/适配，不能从菜单存在推导已完成：

- 真实设备/智能体平台协议、完整分页、签名/密钥轮换、项目外部绑定及统一跨项目同步任务。
- TDengine 时序适配、大规模流式导出、正式时区/降采样策略；当前仅 MySQL，查询最多 100 设备、90 天、5000 点（超限明确标识/拒绝），报表窗口最多 7 天，列表最多展示 200 条。
- ZIP 多资源上传、产品级单设备操作面板和真实控制回执、场景内多命名上传标签与完整现场布局；当前有原生列表/定位/曲线和每面板单文件 HTML，SDK 不含指令通道。
- 告警持续/恢复次数策略、追加事件周期的独立历史模型与真实通知渠道/重试；当前有基本阈值/离线检测、活动状态、处理及平台内通知留存。
- 更完整的报表模板/图文排版、预警 JSON 证据规则、严格供应商幂等/多 worker 分片、任务版本升级迁移与告警规则历史版本。

这些边界不妨碍已经验证的端到端基础链路，但不应将它描述为“全部生产功能完成”。

插件放在 `<ALINK_PLUGIN_DIR>/<目录>/plugin.json`，参考 [`plugins/demo_meter/plugin.json`](plugins/demo_meter/plugin.json)：

- `schema_version: 1`，`id` 是插件稳定标识，`version` 为正整数递增版本。
- `products` 描述产品 `id/name/archive_fields/metrics`，字段类型仅 `number/integer/text/boolean`，可选 `length/unit`。产品及字段标识只允许小写字母开头、数字/下划线，最长 24 字符；禁止覆盖系统保留字段，禁止额外执行字段。
- 每产品建 `p_<plugin_id>_<product_id>_devices` 与 `_samples`。档案以公共 `device_id` 为主键；采样包含设备、时间、来源幂等键、原始 JSON、公式版本 JSON、质量和入库时间，`(device_id, source_key)` 唯一。
- 初始化扫描并校验所有清单后建表、保存插件与产品定义。初始安装要求至少一个插件，示例产品不是已接通的设备来源。
- 后续部署插件后，以超管登录点击“安装/更新部署目录中的插件”（`POST /api/plugins/install`）。只扫描固定部署目录，不接受浏览器上传、文件路径或 SQL。重复安装校验结构并幂等更新注册记录。
- 更新必须递增 `version`；允许新增产品及**可空字段**。字段删除、改类型/长度/单位、产品删除、版本回退、同版本内容修改都拒绝。已安装但未在目录出现的插件/表保留，不自动删表。
- 比对现有列、主键、唯一约束、外键与时间索引，发现结构偏差报错，不静默覆盖。核心版本 2 提供固定新增表升级；人工破坏性迁移、插件卸载及任意历史版本迁移器尚未实现。

AI 应在开发阶段根据接口样例生成清单，人工审查后部署；**本版不执行 AI 生成的 Python 或 SQL，不在采样请求内任意建表**。标准 HTTP 适配器已实现来源字段/本地扩展分离、游标和公式执行；任意 AI Python 执行插件 ABI 尚未开放，真实协议通过受审代码适配。

## 安装一致性与密钥

本地文件锁与 MySQL 数据库级 `GET_LOCK` 串行化表初始化；插件更新共用数据库锁。建库仅在目标库返回不存在错误时执行 `CREATE DATABASE IF NOT EXISTS`，库名受格式校验并引用，不删除或重建已有库。MySQL DDL 自动提交，**失败不保证回滚库和表结构**：可能保留空库、部分空表/可空新增列，插件注册信息仅在该批结构处理完成后提交；兼容清单可重试恢复，禁止通过删除库、表或清空用户来“修复”。初始超管与安装完成标记在同一事务提交；已有账号但没有完成标记时需人工恢复，安装器不覆盖账户。

连接验证后先持久化加密连接配置，再写安装完成标记，避免数据库已安装而配置丢失。已配置库不可连接或密钥不可读取时返回不可用，**不自动重新开放安装**。数据库完成标记是最终依据，不能仅靠删除令牌/本地文件重新安装同一库。

状态目录 `0700`，配置、安装令牌和密钥文件 `0600`；数据库密码使用 Fernet 加密。默认生成本地 `master.key`，与配置同机只属于基础保护；生产建议独立密钥管理渠道设置 `ALINK_MASTER_KEY`，备份数据库、配置及密钥，**不可安装后直接换密钥或丢失密钥**，当前无轮换工具。不要提交 `var/`、`.env`、令牌或真实凭证。

超管密码 scrypt 哈希；Bearer 会话服务端仅存令牌摘要，一小时过期，退出撤销，页面仅内存持有，刷新重新登录。登录按客户端地址与规范化账号五分钟最多五次失败尝试；反向代理地址策略、全局限流、账号生命周期及过期会话清理需要后续生产加固。不要记录请求正文或凭证；校验/连接失败响应不回显密码和 DSN。

## 校验

```bash
uv sync --locked --extra test
uv run --extra test python -m pytest -q
# 真实 MySQL；创建专用临时容器，结束后只删除自己的容器及匿名卷
uv run --extra test python tests/run_mysql.py
# 指定另一已存在或允许拉取的 MySQL 8 镜像
ALINK_TEST_MYSQL_IMAGE=mysql:8.4 uv run --extra test python tests/run_mysql.py
# 安装向导浏览器交互回归（macOS 使用已有 Chrome，其他环境需 Playwright Chromium）
uv run --extra test --with playwright python tests/wizard_browser.py
# 与 Letu 原文件对照登录/外壳/表格/表单样式及响应式尺寸
uv run --extra test --with playwright python tests/letu_theme_browser.py
# MySQL 基础模块 + 真实浏览器三级账号操作链路
ALINK_TEST_BROWSER=1 uv run --extra test --with playwright python tests/run_mysql.py
```

普通测试使用 SQLite 验证声明校验、授权和迁移约束，不替代 MySQL 验收。真实 MySQL 流程涵盖 Web 自动建库安装、超管登录/退出、安装锁定、产品表写入查询、重复安装/增量升级、登录限流，以及客户/项目/用户变更、负向三级权限、密码/客户停用撤销会话、保留范围外授权、项目转移收回授权和日志隔离。浏览器回归包含三种账号的真实后台操作与移动布局。没有现成镜像时 Docker 需要联网获取；只在隔离测试库运行，集成测试创建数据，不用于生产库。

接口：`GET /health/live`、`GET /health/ready`、`GET /api/install/status`、`POST /api/install/test`、`POST /api/install`、`POST /api/auth/login`、`POST /api/auth/logout`、`GET /api/me`、`GET /api/plugins`、`POST /api/plugins/install`。安装 API 使用 `X-Install-Token`；安装后 API 使用 `Authorization: Bearer <token>`。

基础接口：`GET/POST /api/customers`、`PUT/DELETE /api/customers/{id}`、`GET/POST /api/projects`、`PUT/DELETE /api/projects/{id}`、`PUT /api/projects/{id}/assignment`、`GET/POST /api/users`、`PUT /api/users/{id}`、`GET/PUT /api/users/{id}/grants`、`PUT /api/me/password`、`GET /api/capabilities`、`GET /api/audit-logs`。更新授权请求为 `{"grants":[{"project_id":"...","capabilities":["export"]}]}`；仅替换操作者可管理范围内的授权。当前沿用 `/api` 与 `{detail}` 错误响应，尚未统一迁移到规范中的 `/api/v1` 和结构化错误码。
