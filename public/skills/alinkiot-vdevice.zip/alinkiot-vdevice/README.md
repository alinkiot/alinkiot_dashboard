# skill-alinkiot-vdevice

ALinkIOT 平台的虚拟设备 SKILL：选定平台上的一台设备，按它的产品协议和物模型模拟接入、上报数据、应答轮询、接收控制。

本仓库同时是一个 SKILL 目录和一个标准 OTP 应用：

| 路径 | 用途 |
|---|---|
| `SKILL.md` | SKILL 入口，智能体按它工作 |
| `scripts/vdevice.py` | 虚拟设备脚本（Python 标准库） |
| `scripts/drivers/` | 每个协议一个 driver，内置 Modbus-RTU、mqtt-json、tcp-json |
| `references/protocols/` | 每个协议一份说明，依据平台后端协议模块整理 |
| `env.ini.example` | 平台地址和应用凭证模板 |
| `rebar.config`、`src/` | Erlang 应用部分，作为 ALinkIOT 后端的依赖引入 |

平台前端「智能体应用 → 虚拟设备」页面打包下载的 SKILL 只包含 SKILL 部分，不含 Erlang 应用部分。

## 快速使用

平台「智能体应用 → 虚拟设备」页面按产品选设备、选通讯方式后生成提示词，提示词里带一段设备描述：

```bash
python3 scripts/vdevice.py init --from-json devices/ASAIR03.desc.json
python3 scripts/vdevice.py run ASAIR03 --count 4
```

也可以用应用凭证从平台拉取（需要 env.ini）：

```bash
cp env.ini.example env.ini          # 填 host、appId、Secret
python3 scripts/vdevice.py init --device-id 1534
python3 scripts/vdevice.py check ASAIR03
```

## 新增协议

1. 在 `references/protocols/` 下按 `README.md` 里的模板写 `<协议标识>.md`。
2. 需要内置时，在 `scripts/drivers/` 下实现 `<模块名>.py`，用 `run` + `check` 在平台上验证。
