# 设备面板

`run` 启动时会在本机起一个监控服务（默认 `http://127.0.0.1:8765/`，端口被占用时往后找），并自动打开浏览器：

- `devices/<addr>.panel/index.html` 存在时，首页显示这个**设备面板**；
- 不存在时显示**内置监控页**（数据点卡片、曲线、收发报文、修改取值）；内置页面始终可以从 `/builtin` 打开。

设备面板用 [industrial-screen](https://github.com/alinkiot/skill-industrial-screen) 技能生成：按这台设备的物模型做一张工业风格的实时面板，数据来自监控服务的接口。

## 生成步骤

1. **准备技能**：智能体没有 industrial-screen 技能时，`git clone https://github.com/alinkiot/skill-industrial-screen.git` 放进 skills 目录，先读它的 `SKILL.md`。
2. **选模式**（用户没有指定时）：
   | 情况 | industrial-screen 模式 |
   |---|---|
   | 数据点全部只读（传感器、仪表），默认 | `dashboard`，布局 `asset-health`：每个数据点一块仪表盘 + 趋势，配设备铭牌、通信状态、数据质量、收发事件流、模拟取值 |
   | 有可写数据点（`access` 为 `rw` / `write`，如变频器、阀门、继电器） | `local-panel`（单机就地控制屏） |
   | 用户要工艺流程图、组态效果 | `dashboard`，布局 `process-overview` |
3. **按设备设计内容**：数据点取自 `devices/<addr>.json` 的 `points`（`name`、`title`、`unit`、`min`、`max`、`access`），设备名、产品、协议取自同一文件。只展示这台设备真实有的数据点，不要编造点位。
4. **输出位置**（覆盖 industrial-screen 默认的 `out/` 目录约定）：
   - 页面写到 `devices/<addr>.panel/index.html`；
   - 把用到的本地库从 industrial-screen 的 `assets/vendor/`（`vue.global.prod.js`、`echarts.min.js` 等）复制到 `devices/<addr>.panel/vendor/`，页面里用 `./vendor/<文件>` 引用；用到的图元、图片同样复制到面板目录下用相对路径引用。不使用 CDN。
5. **接数据**：去掉 industrial-screen 的演示工况脚本，改为每秒请求一次 `GET /api/tags`（同源，直接写相对路径），见下文接口。状态栏写「虚拟设备 · 模拟数据」而不是「演示数据」。
6. **验证**：`python3 scripts/vdevice.py run <addr>`，在浏览器打开监控页，确认：数值每次轮询或上报后更新；停止虚拟设备后通信状态变为离线、点位质量变为 `BAD`；控制台没有错误。再按 industrial-screen 的要求运行对应模式的校验脚本、检查 1920×1080 截图。

## 接口

### GET /api/tags

按 industrial-screen 的 `references/data-contract.md` 整理：

```json
{
  "device": {
    "deviceId": "ASAIR03", "name": "ASAIR-03", "product": "奥松温湿度传感器", "protocol": "Modbus-RTU",
    "state": "RUNNING", "mode": "REMOTE", "health": 100, "alarmLevel": "NONE",
    "lastSeen": "2026-11-28T01:40:51+08:00",
    "communication": {"connected": true, "error": "", "endpoint": "127.0.0.1:6500"},
    "simulated": true
  },
  "tags": [
    {
      "tagId": "ASAIR03.temperature", "name": "温度", "value": 36, "raw": 360, "unit": "°C",
      "min": 0, "max": 100, "quality": "GOOD", "timestamp": "2026-11-28T01:40:46+08:00",
      "alarmState": "NORMAL", "writable": false, "simMode": "fixed",
      "history": [[1795801246.4, 36], [1795801256.4, 36]]
    }
  ],
  "events": [{"seq": 12, "ts": 1795801251.4, "kind": "up", "text": "应答 01 03 02 01 72 39 F1  humidity=370"}]
}
```

| 字段 | 说明 |
|---|---|
| `device.state` | 连着平台为 `RUNNING`，断开为 `OFFLINE` |
| `tags[].value` | 平台上显示的工程值；`raw` 是设备实际发送的原始值（工程值 = 原始值 × rate + offset） |
| `tags[].quality` | `GOOD` 正常；`UNCERTAIN` 还没上报或还没被轮询；`STALE` 超过 3 个上报周期没有更新；`BAD` 与平台断开 |
| `tags[].history` | 最近 120 次取值 `[秒级时间戳, 值]`，用于趋势图 |
| `tags[].simMode` | 模拟取值方式：`walk` 游走、`random` 随机、`sine` 正弦、`fixed` 固定 |
| `events` | 最近 50 条收发记录，`kind`：`up` 上行、`down` 下行、`ctrl` 平台控制、`error`、`info` |

### POST /api/points/<name>

修改**虚拟设备输出的模拟值**（不是向平台下发控制）：

```json
{"mode": "fixed", "value": 36}
{"mode": "sine", "min": 20, "max": 30, "period": 300}
```

面板上可以提供「模拟取值」操作（例如把某个点设为固定值来测试告警），按钮文案要写明是模拟，不要做成设备启停、急停这类控制。

### POST /api/report

推送型协议立即上报一次；轮询型协议（如 Modbus-RTU）返回 400。

### GET /api/state

内置页面用的完整状态，含设备信息、计数和增量事件（`?since=<seq>`），一般不需要。

## 约束

- 面板只访问本机监控服务的接口，不调用平台接口，页面里不出现任何设备密钥或应用凭证。
- 监控服务只监听 127.0.0.1；需要给别人看时，让用户自己决定是否做端口转发。
