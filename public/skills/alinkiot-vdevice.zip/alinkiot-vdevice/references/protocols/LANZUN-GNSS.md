# LANZUN-GNSS

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/alinkcore_lanzun_watcher.erl`（扫描设备）、`apps/alinkiot_core/src/protocol/lanzun_gnss_client.erl`（每台设备一个拉取进程）、`apps/alinkiot_core/src/alinkcore_lanzun_gnss.erl`（调第三方接口）。`alinkcore_sup.erl` 启动 watcher |
| 接入 | **平台主动拉取（非设备接入）**。没有 `-protocol` 属性的模块，设备走 TCP 6500 或 MQTT 登录会被拒绝 |
| 上报方式 | 平台轮询第三方云平台（蓝尊 GNSS 云），设备本身不与平台通讯 |
| 登录与心跳 | 不适用 |
| 适用设备 | 蓝尊 GNSS 位移监测仪，库中产品「蓝尊GNSS」（id 51） |
| 虚拟设备 | **不能模拟**，没有 driver |

## 数据从哪里来

```
蓝尊 GNSS 设备 ──▶ 蓝尊云平台（第三方）◀── 平台每 10 分钟拉一次
```

1. `alinkcore_lanzun_watcher` 每 5 分钟查一次库：`sys_device` 与 `sys_product` 联表，`protocol = 'LANZUN-GNSS'` 的所有设备。（启动时要等 `alinkiot alinkdata alinkcore alinkalarm alinkiot_tdengine` 都起来才开始，每 10 秒检查一次。）
2. 对没有会话的设备，读设备配置里的 `device_id`（第三方平台上的设备 ID），启动一个 `lanzun_gnss_client`。该进程把设备写入会话缓存，所以平台显示该设备「在线」。
3. 每 10 分钟拉一次数据，起点是 TDengine 表 `device_{addr}` 里最后一条数据的时间（没有则 0），终点是现在。
4. 拉到的数据按时间戳合并，经 `alinkcore_data:handle` 入库。连续失败 5 次后该进程退出，会话随之删除。

第三方接口（主机名写死在 `alinkcore_lanzun_gnss.erl` 里，不可配置）：

| 步骤 | 请求 |
|---|---|
| 登录取 token | `POST /api/auth/login`，JSON `{"username": "<用户名>", "password": "<密码>"}`，应答里取 `token` |
| 取遥测 | `GET /api/plugins/telemetry/DEVICE/{device_id}/values/timeseries?keys=X,XI,Y,YI,H,HI&startTs={毫秒}&endTs={毫秒}`，请求头 `Authorization: Bearer <token>`；应答 401 时重新登录再请求一次 |

用户名、密码来自产品的 `config`（名为 `username`、`password` 的两项），在平台产品配置里填写，文档中不记录具体值。

遥测应答的结构（由代码的解析方式推出）：

```json
{
  "X":  [{"ts": 1700000000000, "value": "1.234"}],
  "XI": [{"ts": 1700000000000, "value": "0.01"}],
  "Y":  [], "YI": [], "H": [], "HI": []
}
```

- 每个键对应一个数组，`ts` 是毫秒，`value` 是**字符串**；不含 `.` 按整数转，含 `.` 按浮点数转。
- 键名映射到平台物模型：`X→x`、`XI→xi`、`Y→y`、`YI→yi`、`H→h`、`HI→hi`；代码里还会映射 `status→stat`、`satNum→satnum`，但请求的 `keys` 里没有它们，物模型里也没有。
- 同一 `ts` 的各键合并成一条记录，`ts` 取整除 1000 的秒数。

## 平台里的物模型和设备

| name | 含义 | 单位 |
|---|---|---|
| `x` `xi` | 北向量，北向量高程瞬时变化 | m |
| `y` `yi` | 东向量，东向量高程瞬时变化 | m |
| `h` `hi` | 高程，高程瞬时变化 | m |

全部为 `float`、`access` 为 `read`，没有 `rate`、`offset`、`precision`。设备的 `config` 是 `[{"name":"device_id","type":"string","value":"<第三方设备 ID>"}]`。`watcher` 读取设备配置里 `device_id` 时 `alinkcore_cache` 如何把它转成 map，代码中未确定。

## 为什么不能模拟

- 数据来自第三方云平台，不是设备主动连平台，设备侧没有可模拟的协议。
- 第三方域名写死在代码里，没有配置项可以改成别的地址。

## 要测试时可以怎么做

| 做法 | 说明 |
|---|---|
| 模拟第三方接口（需要改部署环境） | 起一个本地 HTTPS 服务，实现上面两个接口，用 hosts 或 DNS 把第三方域名指到它。是否校验证书取决于 `alinkiot_utils_http`（代码里只设了 `depth`），能否通过自签证书，代码中未确定 |
| 用别的协议代替，看前端效果 | 建一个物模型与上表相同（`x xi y yi h hi`）的 `mqtt-json` 或 `tcp-json` 产品，用虚拟设备上报同名数据，看到的图表、告警与真实 GNSS 一致。注意它测不到拉取、登录和会话逻辑 |
| 直接写时序库 | 不推荐，绕过平台的换算和告警 |

## 写 driver 要点

不适用，不要为该协议写 driver。需要时在平台里用上面的「用别的协议代替」。
