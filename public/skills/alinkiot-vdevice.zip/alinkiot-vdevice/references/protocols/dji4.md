# dji4

| 项 | 内容 |
|---|---|
| 后端模块 | **代码中未找到处理模块** |
| 接入 | 代码中未确定。没有对应的协议模块，设备用 TCP 6500 登录会收到 `02`（协议未找到），用 MQTT 连接会被拒绝 |
| 上报方式 | 代码中未确定 |
| 登录与心跳 | 不适用 |
| 适用设备 | 库中产品「大疆机场4」（id 143），无人机机场和飞行状态数据 |
| 虚拟设备 | 未内置，**无法依据代码写出接入方式** |

## 查证过程

- 在 `apps/`、配置文件、文档中搜索 `dji4`、`dji`（不区分大小写），**没有任何匹配**（`_build/` 里也没有）。
- `apps/alinkiot_core/src/protocol/` 下没有声明该协议的 `-protocol(...)` 属性，`alinkcore_protocol:get_mod/1` 返回 `undefined`。
- 数据库字典里有两处：`iot_protocol_id` 类型下标签「大疆机场4」、值 `dji4`；`iot_product_mgr` 类型下标签「大疆机场4」，值不是类型名，而是一个 JSON：`{"type":"html","value":"<上传目录下的 html 路径>","path":"<另一个 html 路径>"}`，说明产品管理页面是前端按上传的 HTML 文件渲染的，不是后端协议。这些 HTML 不在后端代码仓库里，内容代码中未确定。
- 产品 `config` 里有一项 `supportImport`（数据导入，开关 0/1，缺省 0）。后端只有 `hnlg-vdg-protocol` 注册了导入钩子（`alinkiot_import/src/alinkiot_vdg_import.erl`），`dji4` 没有，所以导入处理代码中未确定。
- 该项目 `git log` 里没有包含该名字的提交。

## 库里的物模型

全部 `read`，`rate` 为 1，没有 `modbus` 字段：

| name | type | 说明 |
|---|---|---|
| `altitude` | integer | 飞行高度 |
| `horizontal_speed` | integer | 水平速度 |
| `vertical_speed` | integer | 垂直速度 |
| `battery_percent` | integer | 电池电量 |
| `satellite_count` | integer | 卫星数量 |
| `heading` | integer | 航向角 |
| `signal` | integer | 链路信号 |
| `longitude` | integer | 经度 |
| `latitude` | integer | 纬度 |

经纬度在物模型里是 `integer`，是否按放大倍数存储，代码中未确定。

## 要测试时可以怎么做

- 与后端同事确认数据由谁写入（外部服务、前端页面、还是已被删除的后端模块）。
- 临时验证平台功能：建一个物模型相同的 `mqtt-json` 产品，用现有的 `mqtt-json` driver 上报这些字段。

## 写 driver 要点

无依据，不要写 driver。
