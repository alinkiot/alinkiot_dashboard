# Modbus-RTU

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/modbus_server.erl` |
| 接入 | TCP 6500，DTU / 网关透传 |
| 上报方式 | 平台轮询：平台是 Modbus 主站，设备是从机，只应答 |
| 登录与心跳 | 通用规则（`reg` 登录、`ping\r\n` 心跳） |
| 适用设备 | 绝大多数工业传感器、变频器、电表、继电器 |
| 虚拟设备 | 已内置 `scripts/drivers/modbus_rtu.py`，本地平台实测通过 |

## 通讯流程

1. 设备登录后，平台读取产品物模型，把每个带 `modbus` 配置、`access` 不是 `write` 的数据点按 `freq`（秒，缺省 30）分组，建立定时任务。
2. 每到周期，平台对组里的数据点逐个发送读请求，每个请求等待最长 10 秒应答（等待期间收到的 `ping\r\n` 会被跳过）。
3. 一个周期内所有点读完后，平台把结果一起入库。应答超时的点本轮记为忽略，CRC 错误或从机号不符的点跳过。
4. 平台下发写指令时，发送写请求并等待设备回显。

## 上报报文格式

平台发出的请求固定 8 字节，CRC 为 Modbus CRC16，**低字节在前**：

| 字节 | 内容 |
|---|---|
| 0 | 从机号：物模型 `modbus.slaveId`（十六进制字符串，缺省 `01`）；网关子设备用子设备地址 |
| 1 | 功能码：读用 `modbus.rFunCode`，写用 `modbus.wFunCode`（十六进制字符串） |
| 2-3 | 起始地址：`modbus.start`（十六进制字符串），大端 |
| 4-5 | 读：寄存器数量 `modbus.quantity`；写：写入值。大端 |
| 6-7 | CRC16 |

设备应答：

| 功能码 | 应答 |
|---|---|
| 03 / 04 读寄存器 | `从机号 功能码 字节数(=数量×2) 数据 CRC` |
| 01 / 02 读线圈 | `从机号 功能码 字节数(=⌈数量/8⌉) 数据 CRC` |
| 05 / 06 写单个 | 原样回显请求帧 |

平台只校验应答的 CRC 和从机号，然后取「字节数」之后的数据区，不校验功能码。

## 物模型配置

数据区按以下规则解码（`alinkiot_utils:format_value/2`），解码后的原始值再乘 `rate` 加 `offset`：

| 字段 | 位置 | 作用 |
|---|---|---|
| `type` | thing | `integer` 或 `float`；`string` 时原样返回数据区的 hex |
| `modbus.quantity` | modbus | 寄存器数量，决定数据区长度：1 → 16 位，2 → 32 位，4 → 64 位 |
| `modbus.signed` | modbus | `signed`（缺省）/ `unsigned` |
| `modbus.endianness` | modbus | `big`、`little`（**缺省 little**）、`big2`、`little2`。带 2 的表示每个寄存器内高低字节互换（CDAB 这类字序） |
| `rate` / `offset` / `precision` | thing | 显示值 = 原始值 × rate + offset，再保留 precision 位小数 |
| `freq` | thing | 轮询周期（秒），缺省 30 |
| `access` | thing | `write` 的点不轮询；`rw` / `write` 的点可以下发 |

`float` 配 `quantity` 2 是 32 位 IEEE754，配 4 是 64 位；配 1 是 16 位半精度，依赖 OTP 版本，尽量不用。数据区解出 `FFFF` 时平台丢弃该点。

## 平台下发

写指令来自界面或接口 `POST /iotapi/system/control/device`（`name`、`value`）。平台找到 `access` 为 `rw` / `write` 的同名数据点，按 `wFunCode` 组帧：`从机号 wFunCode start value CRC`。浮点值四舍五入成整数；字符串值按十进制解析，前端带 `format: hex` 时按十六进制解析。设备应原样回显。

## 报文示例

产品「奥松温湿度传感器」，湿度点：`slaveId 01`、`rFunCode 03`、`start 0201`、`quantity 1`、`type integer`、`rate 0.1`、`signed`、`endianness big`。

```
平台请求  01 03 02 01 00 01 D4 72      读从机 01 的保持寄存器 0x0201，1 个
设备应答  01 03 02 02 08 B8 E2         数据区 02 08 = 520
平台入库  humidity = 520 × 0.1 = 52.0
```

## 写 driver 要点

已内置，要点记录在这里便于排查：

- `MODE = "poll"`，不实现 `report`；`on_receive` 按 8 字节滑动找 CRC 正确的请求帧，CRC 不对就丢一个字节重新对齐。
- 匹配数据点用 从机号 + 功能码 + 起始地址 + 数量；物模型里没有的寄存器应答全 0，避免平台等 10 秒超时。
- 编码时先把显示值反算成原始值 `(值 - offset) / rate`，再按 type / quantity / signed / endianness 编码；`endianness` 缺省按 `little`，和平台一致。
- 网关子设备用子设备地址作从机号，内置 driver 目前只模拟设备自身。
