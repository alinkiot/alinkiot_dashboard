# protocol_t

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/t_protocol_server.erl`，监听入口 `apps/alinkiot_bridge/src/alinkiot_t_protocol_listen.erl` |
| 接入 | TCP，**独立端口**，缺省 `10881`（应用 `alinkcore` 的环境变量 `t_protocol_port`），不是通用的 6500。部署是否改过端口，代码中未确定 |
| 上报方式 | 设备推送二进制帧；平台每收到一帧就应答一帧（时间同步帧） |
| 登录与心跳 | **不走通用 reg 登录，没有 ping**。连接后直接发数据帧，设备地址取自帧内的 12 字节地址字段，平台不校验 dk/ds 或 pk/ps |
| 适用设备 | T 系列主动上报设备，典型产品「拉线位移计」（位移 + 温度，带报警阈值） |
| 虚拟设备 | 未内置，按本文「写 driver 要点」实现 `drivers/protocol_t.py` |

## 通讯流程

```
设备 ──TCP 连 10881──▶ 平台
设备 ──上报帧(A5 5A 00 …)──▶ 平台 ：解码、CRC 校验、入库
平台 ──应答帧(A5 5A FF …)──▶ 设备 ：带平台当前时间戳
```

- 平台按产品协议 `protocol_t` 查产品（`QUERY_product`，取返回的**第一条**）。库里没有该协议的产品时连接直接失败。多个产品用同一协议标识时选哪个，代码中未确定，虚拟设备应使用该协议下排在最前的产品。
- 平台用「一次 TCP 收到的数据」作为一帧，**没有缓冲和拆包**。设备必须一次 `send` 一整帧，并且不能把两帧合并发送。
- 每收到一帧，处理顺序：解码 → `alinkcore_data:handle` 入库 → 回应答帧 → 第一帧时踢掉同地址旧连接并检查自动注册。
- 设备在平台里不存在时，第一帧数据**会被丢弃**（入库发生在注册检查之前）。只有产品开启自动注册（`autoRegister` 为 `"1"`）才会在第一帧之后创建设备，从第二帧起数据才入库。设备名等于地址，归属取产品的 owner。
- 解码失败（帧头、长度、CRC、帧尾任一不符）会使连接进程崩溃，TCP 被断开，没有错误应答。
- 模块里没有超时和重发逻辑，设备按自己的间隔（`record_interval`）上报。空闲超时由底层 esockd 决定，代码中未确定。

## 上报报文格式

设备 → 平台，所有多字节整数**大端、有符号**。总长度 = 45 + 4 × `CacheDataLen`。

| 偏移 | 长度 | 字段 | 说明 |
|---|---|---|---|
| 0 | 2 | 帧头 | 固定 `A5 5A` |
| 2 | 1 | 类型 | 固定 `00` |
| 3 | 2 | `Len` | 整帧总字节数（含帧头和帧尾），必须等于实际长度 |
| 5 | 12 | `Addr` | 设备地址，12 字节原样作为平台设备地址（ASCII 字符串，不补零不转换）。长度不足 12 时帧无法解码 |
| 17 | 1 | 电量状态 | 见下方换算，对应 `dianliang_status` |
| 18 | 1 | 信号强度 | `xinhao_status` |
| 19 | 2 | 记录间隔 | `record_interval`，单位 s |
| 21 | 2 | `CacheDataLen` | 每个缓存区的字节数，可为 0 |
| 23 | 1 | 设备类型 | `device_type` |
| 24 | 1 | 报警状态 | `alert_status` |
| 25 | 2 | 位移报警下限 | `weiyi_alert_min` |
| 27 | 2 | 位移报警上限 | `weiyi_alert_max` |
| 29 | 2 | 温度报警下限 | `wendu_alert_min` |
| 31 | 2 | 温度报警上限 | `wendu_alert_max` |
| 33 | 2 | 位移当前值 | `weiyi` |
| 35 | 2 | 温度当前值 | `wendu` |
| 37 | 4 | 时间戳 | 设备时间，Unix 秒，作为这批数据的 `ts` |
| 41 | 4×`CacheDataLen` | 缓存数据 1~4 | 4 个缓存区依次排列，每个 `CacheDataLen` 字节，**平台不解析** |
| 41+4L | 2 | CRC | 对前面所有字节（帧头到缓存区末尾）做 CRC-16/Modbus，**高字节在前** |
| 43+4L | 2 | 帧尾 | 固定 `55 AA` |

### 电量状态换算

平台计算 `dianliang_status = ((b div 16) rem 2 × 16 + (b rem 16)) × 5`，`b` 是有符号字节。等价于取低 5 位再乘 5（`b` 在 0~127 范围内时）。例：`0x12` → `(16 + 2) × 5 = 90`；`0x0A` → 50。负数字节（≥ 0x80）的结果与低 5 位算法不同，虚拟设备只发 0~127。

### CRC 字节序

CRC-16/Modbus（初值 `FFFF`，多项式 `A001`）。平台函数 `alinkiot_utils:crc16/1` 返回**低字节在前**，上报帧校验时把帧里的两字节反过来比较，所以：

| 帧 | CRC 字节顺序 |
|---|---|
| 设备上报帧 | 高字节在前（`crc >> 8`，`crc & 0xFF`） |
| 平台应答帧 | 低字节在前（与 Modbus-RTU 相同） |

## 物模型配置

解码结果的字段名固定，物模型的 `name` 必须与下表一致才会入库，其它字段忽略。字段是否出现在物模型里决定数据是否展示。

| 物模型 name | 帧字段 | 参与换算的 thing 字段 |
|---|---|---|
| `dianliang_status` | 电量状态 | 无（平台已先做电量换算） |
| `xinhao_status` / `record_interval` / `device_type` / `alert_status` | 对应字段 | 无 |
| `weiyi` / `weiyi_alert_min` / `weiyi_alert_max` | 位移，原始整数 | `rate`（现有产品 0.1）、`precision`（2） |
| `wendu` / `wendu_alert_min` / `wendu_alert_max` | 温度，原始整数 | `rate`（0.1）、`precision`（2） |

换算：显示值 = 原始值 × `rate` + `offset`，再按 `precision` 四舍五入（`alinkcore_data:create_format`）。设备发送的是原始整数，所以位移 123.4 mm 要发 1234。数值字段类型为 `float` 或 `integer` 时，原始值是整数，不会再做字符串转换。

参考产品「拉线位移计」（`id=85`）物模型要点，全部 `access: read`：

| name | type | rate | precision | unit |
|---|---|---|---|---|
| `weiyi`、`weiyi_alert_min`、`weiyi_alert_max` | float | 0.1 | 2 | mm |
| `wendu`、`wendu_alert_min`、`wendu_alert_max` | float | 0.1 | 2 | °C |
| `dianliang_status`、`xinhao_status`（dB）、`record_interval`（s）、`device_type`、`alert_status` | integer | 无 | 无 | |

产品还有字符串配置项 `road_name`（高速名称）、`stake`（桩号），属于设备配置，不在上报帧里。

## 平台下发

平台没有任何写指令下发逻辑，物模型全部只读。唯一的平台 → 设备数据是每次上报后的**应答帧**，设备必须能容忍收到它（不需要再回复）。

应答帧，固定 27 字节，平台 → 设备：

| 偏移 | 长度 | 字段 | 说明 |
|---|---|---|---|
| 0 | 2 | 帧头 | `A5 5A` |
| 2 | 1 | 类型 | `FF` |
| 3 | 2 | `Len` | 固定 `00 1B`（27） |
| 5 | 12 | `Addr` | 回显设备地址 |
| 17 | 4 | 时间 | 平台当前 Unix 秒，大端有符号 |
| 21 | 2 | 保留 | `00 00` |
| 23 | 2 | CRC | CRC-16/Modbus，**低字节在前** |
| 25 | 2 | 帧尾 | `55 AA` |

设备收到后用于校时。设备收到应答后的具体行为，代码中未确定。

## 报文示例

设备 `T00000000001`，使用产品「拉线位移计」物模型。原始帧（45 字节，`CacheDataLen = 0`）：

```
A5 5A 00 00 2D 54 30 30 30 30 30 30 30 30 30 30 31 12 19 00 3C 00 00 01 00 00 00 07 D0 FF 38 03 20 04 D2 01 00 69 55 B9 00 75 D1 55 AA
```

逐字段解析（已用平台同样的 Erlang 解码模式验证，CRC 通过）：

| 字段 | 原始值 | 平台入库值 |
|---|---|---|
| 地址 | `T00000000001` | 设备地址 |
| `dianliang_status` | `0x12` | 90 |
| `xinhao_status` | 25 | 25 |
| `record_interval` | 60 | 60 |
| `device_type` | 1 | 1 |
| `alert_status` | 0 | 0 |
| `weiyi_alert_min` | 0 | 0.0 |
| `weiyi_alert_max` | 2000 | 200.0 |
| `wendu_alert_min` | -200 | -20.0 |
| `wendu_alert_max` | 800 | 80.0 |
| `weiyi` | 1234 | 123.4 |
| `wendu` | 256 | 25.6 |
| `ts` | 1767225600 | 1767225600 |

平台应答（`now = 1767225601`）：

```
A5 5A FF 00 1B 54 30 30 30 30 30 30 30 30 30 30 31 69 55 B9 01 00 00 E9 64 55 AA
```

Python 生成上报帧：

```python
import struct

def crc16(data):
    c = 0xFFFF
    for b in data:
        c ^= b
        for _ in range(8):
            c = (c >> 1) ^ 0xA001 if c & 1 else c >> 1
    return c

def build_report(addr12, power, signal, interval, dtype, alert,
                 w_min, w_max, t_min, t_max, weiyi, wendu, ts, cache_len=0):
    total = 45 + 4 * cache_len
    body = (b"\xA5\x5A\x00" + struct.pack(">H", total) + addr12
            + struct.pack(">bbhhbb", power, signal, interval, cache_len, dtype, alert)
            + struct.pack(">hhhhhh", w_min, w_max, t_min, t_max, weiyi, wendu)
            + struct.pack(">i", ts) + b"\x00" * (4 * cache_len))
    c = crc16(body)
    return body + bytes([c >> 8, c & 0xFF]) + b"\x55\xAA"   # 上报帧 CRC 高字节在前
```

## 写 driver 要点

| 项 | 内容 |
|---|---|
| `PROTOCOL` | `"protocol_t"`，模块文件 `protocol_t.py` |
| `TRANSPORT` | `"tcp"`，但**端口是 10881**，且不发 reg |
| `MODE` | `"push"` |

- 覆盖 `login()` 返回 `None`（或空），不发 `reg`。覆盖 `heartbeat()` 返回 `None`，不要发 `ping\r\n`，平台会当成非法帧。是否支持这两项覆盖取决于 `vdevice.py`，需要先确认它对 `None` 的处理，并允许 profile 指定端口 10881。
- `report()`：返回一整帧 bytes，一次发完。设备地址取 profile 里的 `addr`，**必须正好 12 个 ASCII 字符**，不足时校验设备地址配置，不要自动补零（平台会把补零后的字符串当地址，找不到设备）。
- 物值 → 原始整数：`raw = round((显示值 - offset) / rate)`，`rate` 缺省按 1。物模型里没有的字段发 0。`dianliang_status` 显示值（5 的倍数，0~155）发 `显示值 / 5`，且只用低 5 位。
- 所有整数有符号 16 位或 8 位，超范围要截断（位移/温度 ±32767，电量/信号/类型/报警 ±127）。
- `ts` 使用设备当前 Unix 秒。
- `on_receive()`：收到应答帧可以只打日志，返回 `([], 剩余字节)`。应答长度固定 27 字节，从帧头 `A5 5A FF` 对齐，TCP 可能粘包。
- 设备在平台里不存在时，第一帧不入库。自动注册开启时，第二帧起才入库，所以首次连接后应尽快再发一帧。
- 容易出错的地方：
  - 上报帧 CRC 高字节在前，应答帧低字节在前，不要共用同一个打包函数。
  - `Len` 是整帧长度，不是载荷长度。
  - 帧不合法会让平台直接断开连接，出现「刚连上就被断开」时先检查 Len、CRC、地址长度。
  - 缓存区平台不解析，`CacheDataLen` 填 0 最简单。填非 0 时 4 个缓存区都要补满。
