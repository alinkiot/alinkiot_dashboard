# hnlg-vdg-protocol

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/hnlg_vdg_server.erl`（MQTT 入口 `alinkcore_mqtt.erl`） |
| 接入 | MQTT（不走 TCP 6500，没有 reg 登录） |
| 上报方式 | 设备推送，JSON，发布到 `d/out/{addr}` |
| 登录与心跳 | 与通用 MQTT 规则相同（clientId `uzy_1_{addr}` 或 `uzy_2_{addr}`），心跳用 MQTT 自带 PINGREQ，无差异 |
| 适用设备 | VDG 系列多通道采集仪（腐蚀电位、电流、温度，如产品「采集仪VDG」`node_type=gateway`）。每个通道登记成网关下的一个子设备 |
| 虚拟设备 | 未内置，按本文「写 driver 要点」实现 `drivers/hnlg_vdg_protocol.py` |

本协议是 `hnlg-protocol` 的变体，JSON 外壳相同，区别在于 cmd 2 的含义（数组按通道分配给子设备）、连接时所有子设备自动上线、没有 cmd 5/6/20。先读 [hnlg-protocol.md](hnlg-protocol.md) 了解 cmd 1、cmd 3 的字段，本文只写差异和完整规则。

## 通讯流程

```
设备                                   平台
 │（连接成功：平台把网关下全部启用的子设备置为在线）
 │── d/out/{addr} {cmd:1,...} ───────▶│  上报采集间隔，平台回 ack（cmd:1）
 │◀── d/in/{addr}  {cmd:1,state:1} ────│
 │── d/out/{addr} {cmd:2,...} ───────▶│  全部通道的数组，平台分发给各子设备，ack 里的 cmd 是 3
 │◀── d/in/{addr}  {cmd:3,state:1} ────│
 │── d/out/{addr} {cmd:3,...} ───────▶│  单个子设备的 hex 字节串，ack（cmd:3）
 │◀── d/in/{addr}  {cmd:4,deviceSet} ──│  用户修改 interval_time 时下发
 │── d/out/{addr} {cmd:4,state:1} ───▶│  设备应答，平台忽略
```

- 连接建立时（`init/1`）平台查询网关的子设备（`sys_sub_device`，仅启用状态），为每个子设备建立在线会话，`sub_addr` 必须是 2 位 hex（1 字节）。不满足会让登录失败，原因代码中未确定。
- 设备掉线时平台删除这些子设备的会话。
- 其它 topic 的消息被忽略。上报字段缺失或组合不在下表时，平台没有兜底分支，会抛异常，不回复也不入库。

## 上报报文格式

所有消息为 UTF-8 JSON，字段名区分大小写（`timesTamp`、`offline_flag`、`IntervalTime` 是代码中的原拼写）。

### cmd 1：上报采集间隔

```json
{"id": 1, "cmd": 1, "address": 0, "IntervalTime": 10}
```

平台把值发布到 `p/thing/{产品ID}/{addr}`：`{"ts":秒,"interval_time":{"value":10,"ts":秒}}`。与 `hnlg-protocol` 不同，本协议**不发布到 `p/out/{addr}`**。不经过 rate/precision 换算，也不入库。

应答：`{"id":<原id>,"address":0,"state":1,"cmd":1}`

### cmd 2：全部通道数据（数组分发给子设备）

```json
{"id": 2, "cmd": 2, "address": 0, "timesTamp": 1735689600, "dataArray": [1.001, 1.002, 1.003, 1.004]}
```

| 字段 | 要求 |
|---|---|
| `timesTamp` | 秒级 Unix 时间戳，原样作为这批数据的时间；不是整数时平台用自己的当前时间 |
| `dataArray` | 数值数组，元素是**原始值**。第 1 个元素的序号是 1 |

对网关下**每个当前在线的子设备**（连接时全部在线，被 cmd 3 `offline_flag=1` 置为离线的除外），平台做：

1. 通道号 `S = (sub_addr 数值 + 1) div 2`。`sub_addr` 取 `sys_sub_device.sub_addr` 的 hex 数值，所以 `01` 和 `02` 都是 1，`03` 和 `04` 都是 2，`3F`（63）是 32，`79`（121）是 61。
2. 查子设备所属产品的物模型，对其中每个点：
   - 取 `modbus.rFunCode`，没有 `modbus` 或没有该键时按 `"100"`。**只有等于 `"100"` 的点才参与**，其它值（如 `"03"`）的点被跳过。
   - 取 `modbus.start`（hex 字符串，没有时按 `"00"`），解码成 1 字节整数 `K`。
   - 点的值 = `dataArray` 第 `S + K` 个元素（从 1 数起）。`S + K` 大于数组长度则该点没有值。
3. 有值的点按子设备产品的 `rate`/`offset`/`precision` 换算后入库到**子设备**。一个子设备所有点都没值则不入库。

网关本体不入库任何点。`modbus.start` 非法（不是 2 位 hex）的点被跳过并记录错误日志。

应答（注意 `cmd` 是 3，不是 2）：`{"id":<原id>,"address":0,"state":1,"cmd":3}`

### cmd 3：单个子设备数据

```json
{"id": 3, "cmd": 3, "address": 3, "timesTamp": 1735689600, "offline_flag": 0, "dataArray": "000125800001"}
```

与 `hnlg-protocol` 的 cmd 3 规则相同：

| 字段 | 要求 |
|---|---|
| `address` | 子设备从机地址整数（0–255），与 `sub_addr` 的数值比对 |
| `offline_flag` | 必须带。1 表示该子设备离线：平台删除它的会话，之后 cmd 2 不再给它分发数据，直到下次 cmd 3 `offline_flag=0` 把它重新上线 |
| `dataArray` | hex 字符串，偶数个字符 |
| `timesTamp` | 秒 |

解码：用**子设备产品**物模型中 `access` 为 `read`/`rw`、且 `modbus` 里同时有 `start`、`quantity`、`signed`、`endianness` 的点。取 `dataArray` 解码字节串的 `[start, start+quantity)`（`start` 是 hex 字节偏移，`quantity` 是字节数），按下表解码。缺任何一个键的点被跳过。

| 字节数 | 结果 |
|---|---|
| 1 | 8 位整数（按 `signed`） |
| 2、4、8 | 按 `endianness`（`big`、`little`、`big2`、`little2`）和 `signed`、`type`（`integer`/`float`）解码 |
| 其它长度，或 `type` 为 `string` | 整段字节的大写 hex 字符串 |

`big2`/`little2`：先把每 2 字节对调（A B C D → B A D C），再分别按大端/小端读。与 `hnlg-protocol` 完全相同，细节见 [hnlg-protocol.md](hnlg-protocol.md)。`start+quantity` 超出数据长度时整条消息解析失败，没有 ack。

找不到 `address` 对应的子设备时丢弃数据，但仍回 ack。

应答：`{"id":<原id>,"address":<原address>,"state":1,"cmd":3}`

### 分帧与校验

MQTT 一条消息一帧，无 CRC。代码中未确定：`id` 的取值规则（平台只回显）。

## 物模型配置

两个层级：

| 产品 | 哪些字段起作用 |
|---|---|
| 网关产品（如「采集仪VDG」） | 只有 `interval_time`（`access: rw`）用于下发。其余物模型点在 cmd 2 里不使用 |
| 子设备产品（如「腐蚀传感器」「电流传感器」） | 决定 cmd 2 解码（`modbus.rFunCode`、`modbus.start`，以及 `rate`/`offset`/`precision`）和 cmd 3 解码（`modbus.start/quantity/signed/endianness`、`type`） |

DB 里的真实例子：

| 产品 | 物模型 | 子设备 cmd 2 行为 |
|---|---|---|
| 腐蚀传感器 | 一个点 `d`，`type: float`，`rate: 1`，`precision: 3`，无 `modbus` | 用 `rFunCode="100"`、`start="00"`，取 `dataArray[S]` |
| 电流传感器 | 一个点 `d`，`type: float`，`precision: 3`，无 `modbus` | 同上 |
| 温度传感器 | 一个点 `d`，带 `modbus.rFunCode: "03"`、`start: "01"` | `rFunCode` 不是 `"100"`，**cmd 2 被跳过**，这类子设备只能走 cmd 3 |

「采集仪VDG」网关（DB 中地址 860059059631916）下 61 个子设备的 `sub_addr`，间隔均为 2：腐蚀传感器 `01`…`3B`（30 个，S 为 1–30），电流传感器 `3F`…`5D`（16 个，S 为 32–47），温度传感器 `5F`…`79`（14 个，S 为 48–61），另有一个腐蚀类产品的子设备 `7B`（S=62）。通道 S=31 没有子设备。温度传感器产品带 `rFunCode: "03"`，cmd 2 不会给它们写数据。`7B` 的 S 为 62，数组要有 62 个元素才取得到。

## 平台下发

用户写 `interval_time` 时，平台把 `{"type":"write","name":"interval_time","value":10}` 改写成发布到 `d/in/{addr}` 的：

```json
{"id": 1, "cmd": 4, "address": 0, "deviceSet": [10]}
```

`id` 是平台为该连接生成的递增序号，从 1 开始。`deviceSet` 里是用户给的 `value`。

设备应答：

```json
{"id": 1, "cmd": 4, "address": 0, "state": 1}
```

- 本协议平台收到 `address=0, state=1` 的应答后**直接忽略**：不会像 `hnlg-protocol` 那样发布 `interval_time` 到 `p/out`。页面上的 `interval_time` 要靠设备下次发 cmd 1 更新。
- 应答 `{"id":n,"address":0,"state":0}`（失败）：平台按 `id` 在最近 3 条下发中找原报文，找到就重发到 `d/in/{addr}`。
- 其它 `name` 的写指令，平台不改写，设备收到 `{"type":"write","name":...,"value":...}`，本协议代码没有定义设备应答，代码中未确定。
- 没有 cmd 5、6、20，这三个在 `hnlg-protocol` 里才有。

## 报文示例

场景：网关「VDG61-1916」下登记了三个腐蚀传感器子设备，`sub_addr` 为 `01`、`03`、`05`（产品「腐蚀传感器」：点 `d`，无 `modbus`，`rate 1`，`precision 3`）。

设备发布到 `d/out/860059059631916`：

```json
{"id":2,"cmd":2,"address":0,"timesTamp":1735689600,"dataArray":[1.001,1.002,1.003,1.004]}
```

平台解析：

| 子设备 sub_addr | S = (n+1) div 2 | 取值 | 入库 `d` |
|---|---|---|---|
| `01` | 1 | `dataArray[1]` | 1.001 |
| `03` | 2 | `dataArray[2]` | 1.002 |
| `05` | 3 | `dataArray[3]` | 1.003 |

数组第 4 个元素 1.004 没有对应子设备，被忽略。时间戳 `1735689600`。平台回复到 `d/in/860059059631916`：

```json
{"id":2,"address":0,"state":1,"cmd":3}
```

## 写 driver 要点

| 项 | 内容 |
|---|---|
| `PROTOCOL` | `"hnlg-vdg-protocol"` |
| `TRANSPORT` | `"mqtt"` |
| `MODE` | `"push"` |
| 文件名 | `drivers/hnlg_vdg_protocol.py` |
| `UP_TOPIC` | 默认 `d/out/{addr}` |

要覆盖的方法：

- `report()`：返回一条 JSON 的 bytes。一次只能返回一帧。第一次调用返回 cmd 1（`IntervalTime` 取本地间隔），之后每次返回 cmd 2。cmd 1 不是必须的，但没有它用户页面上就没有 `interval_time` 的最新值。
- `on_receive(data, topic)`：`json.loads(data)`。
  - `cmd: 4`：取 `deviceSet[0]` 更新本地间隔，返回 `[{"id":原id,"cmd":4,"address":0,"state":1}]` 的 JSON bytes。
  - 带 `state` 的 ack（cmd 1、cmd 3）：不回复。
  - `{"type":"write",...}`：未定义，记日志。

容易出错的地方：

| 问题 | 说明 |
|---|---|
| 通道序号 | cmd 2 数组的下标由子设备的 `sub_addr` 推出：`S = (int(sub_addr,16)+1)//2`，并加上物模型 `modbus.start` 的偏移。数组长度必须覆盖所有在线子设备的 `S+K`，否则缺的点没有值 |
| 子设备列表 | 虚拟设备需要知道网关下每个子设备的 `sub_addr` 和产品物模型（`profile` 里是否提供子设备信息，代码中未确定，需按 SKILL 脚本能给的数据确定），否则无法算出各通道含义 |
| 原始值 | 设备发的是原始值。显示值 V 对应原始值 = (V − offset) / rate。腐蚀传感器 `rate 1`，直接发 1.001 即可 |
| ack 的 cmd | 平台对 cmd 2 的 ack 里 `cmd` 是 3。driver 解析 ack 时不要用 `cmd` 对应请求 |
| cmd 2 对 `rFunCode` 的限制 | 子设备物模型的 `modbus.rFunCode` 必须缺省或等于 `"100"`，否则该点不会从 cmd 2 取值，需要改用 cmd 3 |
| cmd 3 的 `address` | 整数，对应 `sub_addr` 的数值（`"0B"` 对应 11） |
| 离线 | cmd 3 带 `offline_flag: 1` 后，该子设备不再收到 cmd 2 的数据，直到再发 cmd 3 `offline_flag: 0` |
| 平台没有兜底分支 | 报文字段缺失会让平台抛异常，只是不回复。driver 发出的 JSON 必须按上文字段写全 |
