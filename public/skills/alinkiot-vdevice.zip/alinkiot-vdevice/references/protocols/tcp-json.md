# tcp-json

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/tcp_json_server.erl`，转换 `alinkiot_utils/src/alinkiot_json_parser.erl` |
| 接入 | TCP 6500 |
| 上报方式 | 设备推送：发送 JSON |
| 登录与心跳 | 通用规则（`reg` 登录、`ping\r\n` 心跳） |
| 适用设备 | 经 TCP 透传、自定义 JSON 报文的设备或网关 |
| 虚拟设备 | 已内置 `scripts/drivers/tcp_json.py`，本地平台实测通过 |

## 通讯流程

1. 设备 `reg` 登录时，平台读取产品的协议转换（`protocolConfig`）。没有配置时登录失败并断开。
2. 设备在同一连接上发送 JSON 报文，平台按协议转换转成物模型字段并入库。
3. 转换结果带 `$sub_addr` 时，数据交给该子设备（网关场景，子设备需在线）。

## 上报报文格式

- 每条报文是一个 JSON 对象，多条之间用**回车换行字节 `0D 0A`** 分隔。注意这和登录、心跳用的 4 字符文本 `\r\n` 不同。
- 平台按 `0D 0A` 切分收到的数据，每段单独解码；一段不是合法 JSON 时丢弃该段。
- 平台对 TCP 数据不做跨包拼接：一条报文要在一次发送里完整发出。
- JSON 结构和取值规则与 mqtt-json 相同，见 [mqtt-json.md](mqtt-json.md) 的「上报报文格式」。

## 物模型配置

同 mqtt-json：`name` 对应协议转换的 key，`type`、`rate`、`offset`、`precision` 决定换算。

## 平台下发

平台当前不向 tcp-json 设备下发写指令：`tcp_json_server` 收到写消息后不发送任何数据。

## 报文示例

协议转换同 mqtt-json 的示例：

```
设备发送  {"data": {"flow": 8.51, "valve": 1}}<0D 0A>
平台解析  SteamFlow = 8.51，Valve = 1
```

## 写 driver 要点

已内置：

- `MODE = "push"`，`report` 复用 `drivers/jsonmap.py` 生成报文，结尾加 `\r\n`（0D 0A 字节）。
- 登录和心跳走通用规则；`on_receive` 只打印收到的数据。
