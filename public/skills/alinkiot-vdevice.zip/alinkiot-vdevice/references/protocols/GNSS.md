# GNSS

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/gnss_server.erl`（设备上报解析）、`gnss_sub_device.erl`（子设备，平台自己去外部数据库取数）；`$dp` 入口见 `apps/alinkiot_core/src/alinkcore_mqtt.erl` 的 `on_message_publish`（topic `$dp`） |
| 接入 | **MQTT**（clientId `uzy_1_{addr}` / `uzy_2_{addr}`）。设备数据发到 topic **`$dp`**，不是 `d/out/{addr}`。不走 TCP reg |
| 上报方式 | 设备推送（`$dp`）；子设备数据由平台轮询外部 MySQL，设备不参与 |
| 登录与心跳 | 通用 MQTT 登录，心跳用 MQTT 自带 PINGREQ，无差异 |
| 适用设备 | 司南 A300 等 GNSS 基站/监测站。示例产品：「GNSS-基点」(node_type=device)、「GNSS-A300」「司南A300」(node_type=gateway)；「GNSS-测点」「司南子设备」(node_type=children) |
| 虚拟设备 | 未内置，需新写 `scripts/drivers/gnss.py`；**现有 driver 接口不足，需要扩展**（见「写 driver 要点」） |

## 通讯流程

1. 设备用 MQTT 登录（通用规则）。登录时平台调用 `gnss_server:init`：若设备有子设备，会为每个子设备启动一个 `gnss_sub_device` 进程（见下面「子设备」）。设备没有子设备时什么都不做，仍然登录成功。
2. 设备向 topic `$dp` 发布一条消息：**前 3 个字节是任意内容的头，平台直接丢弃，之后是 JSON**。
3. 平台解析 JSON，按 key 把值转成物模型字段，入库。
4. 平台不回应答。

`d/out/{addr}` 在本协议下**被忽略**：`gnss_server:handle_in` 对 `d/out` 消息走兜底分支直接返回 `ok`，数据不入库。

## 上报报文格式

### 外层

```
<3 字节头><JSON>
```

| 项 | 说明 |
|---|---|
| 头 | 3 字节，平台 `<<_:3/binary, Payload/binary>>` 直接丢弃。真实设备里这 3 字节的含义代码中未确定；虚拟设备用任意 3 字节（如 `00 00 00`）即可 |
| JSON | 顶层对象，**key 必须等于 MQTT clientId**，如 `uzy_1_A31016765`（一型一密则是 `uzy_2_<addr>`）。key 不匹配时整条消息被静默忽略，不报错 |
| 校验 | 无 |

```json
{ "<clientId>": { "<类型>_<代码>_<序号>": <值>, ... } }
```

内层每个 key 必须是 `类型_代码_任意` 三段（按 `_` 切成**恰好 3 段**，如 `L1_QJ_1`）。段数不是 3，或值的格式不符合下表，**整条消息作废**（只记日志，一个字段都不入库）。第 3 段平台不使用，随便填。

### key 与值的对应表

平台只认下表。值里"逗号串"是**字符串**，例如 `"1.2,3.4"`，不是 JSON 数组。凡标"浮点"的，值可以是 JSON 数字（整数或小数都行）；若是字符串，则**必须带小数点**（`"3.0"` 可以，`"3"` 不行）。

| key（类型_代码） | 值 | 产生的物模型标识（左到右对应） |
|---|---|---|
| `S1_ZT` | JSON 对象，只保留下面 12 个字段，其余字段丢弃 | `ext_power_volt` `solar_volt` `battery_dump_energy` `temp` `humidity` `lon` `lat` `on_4g` `signal_4g` `signal_NB` `signal_bd` `sw_version`（子键名即标识，值原样） |
| `L1_LF` | 浮点 | `l1_lf` |
| `L1_GP` | `"a,b,c,d"`（恰好 4 个） | `l1_gpsinitial` `l1_gpstotalx` `l1_gpstotaly` `l1_gpstotalz` |
| `L1_SW` | `"a,b"`（恰好 2 个） | `l1_dispsx` `l1_dispsy` |
| `L1_JS` | `"a,b,c"`（恰好 3 个） | `l1_gx` `l1_gy` `l1_gz` |
| `L1_QJ` | `"a,b,c,d,e"`（5 个） | `l1_x` `l1_y` `l1_z` `l1_angle` `l1_azi` |
| `L1_QJ` | `"a,b,c,d,e,f,g,h"`（8 个） | `l1_plx` `l1_ply` `l1_plz` `l1_plvalue` `l1_sjx` `l1_sjy` `l1_sjz` `l1_sjvalue`；个数既不是 5 也不是 8 则整条消息作废 |
| `L2_YL` | 浮点 | `l2_yl` |
| `L2_TY` | 字符串（原样） | `l2_ty` |
| `L2_CS` | `"a,b,c"` | `l2_cs_osp` `l2_cs_vsp` `l2_cs_freq` |
| `L2_DS` | `"a,b,c"` | `l2_ds_osp` `l2_ds_vsp` `l2_ds_freq` |
| `L3_YL` | `"a,b"` | `l3_yl` `l3_yl_total` |
| `L3_QW` | 字符串（原样） | `l3_qw` |
| `L3_TW` `L3_HS` `L3_ST` `L3_LS` `L3_CJ` | 浮点 | `l3_tw` `l3_hs` `l3_st` `l3_ls` `l3_cj` |
| `L3_QY` | 浮点 | **`l3_qj`**（注意标识是 `qj`，不是 `qy`） |
| `L3_DB` `L3_DX` `L3_SY` | `"温度,值"` | `l3_db_temp` `l3_db_value`；`l3_dx_temp` `l3_dx_value`；`l3_sy_temp` `l3_sy_value` |
| `L4_SP` | 字符串（原样） | `l4_sp` |
| `L4_NW` | 字符串（原样） | **`l4_ty`**（不是 `l4_nw`） |
| `L4_LD` | `"x,y,z,speed"`（4 个） | `l4_ld_x` `l4_ld_y` `l4_ld_z` `l4_ld_speed` |
| `L4_LB` | 原样 | **`yl`**（不是 `l4_lb`） |
| 其它类型/代码 | 任意 | 忽略，不报错 |

另外，`ts` 取平台收到时刻（秒），报文里不带时间。

逗号串里个数不对，会因 `[A, B] = split(...)` 匹配失败而整条作废；逗号串值若不是字符串（如 JSON 数组）同样失败。

## 物模型配置

平台只会保存**物模型里存在**的标识。示例产品里：

- 「GNSS-基点」「GNSS-A300」「司南A300」的物模型只定义了 `S1_ZT` 的 12 个字段，所以实际有效的只有 `S1_ZT`；`L1_*` 等标识需要在产品物模型里补上才会保存。
- 「GNSS-测点」「司南子设备」(children) 的物模型是 `b l h x y sx sy sh ax ay ah`（以及 `h_diff x_diff y_diff`），这些是子设备由平台轮询外部数据库得到的，不是设备通过 `$dp` 上报的（见「子设备」）。

影响解码的物模型字段（`alinkcore_data` 通用换算）：

| 字段 | 作用 |
|---|---|
| `name` | 必须等于上表标识，否则丢弃 |
| `type` | `string` 不换算；`float` / `int` / `integer` 做换算。若值是字符串，`float` 用 `binary_to_float`（必须带小数点），`int`/`integer` 用 `binary_to_integer` |
| `rate` / `offset` / `precision` | 平台值 = 原始值 × rate + offset，按 precision 取小数位 |
| `formula` | 公式字段（如测点的 `diff_x0`）在入库前处理，本协议代码未涉及 |

示例产品中 `lon` `lat` 是 `string` 类型，原样保存；`on_4g` 是 `integer`；其余是 `float`。

### MQTT topic 白名单（必须配置）

`$dp` 不是内置 topic。`alinkcore_mqtt.erl` 的 `check_device_acl` 对设备（`uzy_1_` / `uzy_2_`）的非内置 topic 做**严格白名单**校验：产品的「topic」配置（JSON 数组）里必须有一条 `{"topic":"$dp","action":"publish"}`，否则发布被拒绝。本地库里示例产品 GNSS-基点(98)、GNSS-A300(94)、司南A300(48) 的 `topic` 都是 `NULL`，即未配置。虚拟设备要先确认产品已配置，未配置的话发布不会成功。拒绝后的客户端表现取决于 broker，代码中未确定。

## 平台下发

本协议没有下发功能。`handle_out` 原样返回消息；示例产品物模型全部为 `access: read`。设备不需要处理控制指令，也不需要应答。

## 子设备（`gnss_sub_device`）

挂在 GNSS 设备下的子设备（如「GNSS-测点」）**不通过设备上报**。平台在 `gnss_server:init` 里为每个子设备启动一个进程，进程用子设备配置项 `gnss`（解算服务器名称，示例 `ALINKIOT-GNSS`）去查一份外部 MySQL 连接配置，然后：

- 每 60 秒（可由配置 `retry` 改）查询 `data_gnss_current` 与 `data_mqtt_YYYYMM` 表，按 `station_name = 子设备 addr` 取最新一行；`time` 比上次新才入库。
- 入库字段：`b l h x y sx sy sh ax ay ah x_diff y_diff h_diff station_name`，`ts` 为数据库行的 `time`。

虚拟设备无法模拟这部分，也不需要：虚拟设备只模拟「GNSS-基点」这类直接连 MQTT 的设备。外部数据库的连接信息在平台配置里，**不要抄进文档或 driver**。

## 报文示例

clientId `uzy_1_A31016765`，设备 topic `$dp`，产品物模型含 `S1_ZT` 的 12 个字段，另外补充了 `l1_x l1_y l1_z l1_angle l1_azi`。

发布内容（`00 00 00` 为 3 字节头，后接 JSON）：

```
topic:   $dp
payload: 00 00 00 + {"uzy_1_A31016765":{"S1_ZT_1":{"ext_power_volt":12.61,"solar_volt":13.08,"battery_dump_energy":88.5,"temp":23.4,"humidity":56.0,"lon":"113.123456","lat":"23.123456","on_4g":1,"signal_4g":-85.0,"signal_NB":0.0,"signal_bd":42.0,"sw_version":"1.0.3","extra":1},"L1_QJ_1":"0.01,0.02,0.98,1.2,35.5"}}
```

平台解析出的物模型值（`extra` 不在 12 个字段内，丢弃）：

| 标识 | 值 |
|---|---|
| `ext_power_volt` | 12.61 |
| `solar_volt` | 13.08 |
| `battery_dump_energy` | 88.5 |
| `temp` | 23.4 |
| `humidity` | 56.0 |
| `lon` / `lat` | `113.123456` / `23.123456`（字符串） |
| `on_4g` | 1 |
| `signal_4g` | -85.0 |
| `signal_NB` | 0.0 |
| `signal_bd` | 42.0 |
| `sw_version` | `1.0.3` |
| `l1_x` `l1_y` `l1_z` `l1_angle` `l1_azi` | 0.01 0.02 0.98 1.2 35.5（物模型有这些标识时才保存） |

## 写 driver 要点

| 项 | 取值 |
|---|---|
| `PROTOCOL` | `"GNSS"`（模块文件名 `gnss.py`） |
| `TRANSPORT` | `"mqtt"` |
| `MODE` | `"push"` |

覆盖与扩展：

- `UP_TOPIC = "$dp"`：基类默认 `d/out/{addr}`，必须改。`vdevice.py` 取 `Driver.UP_TOPIC` 原样作为发布 topic，所以只设这个类属性就够，接口不需要扩展。
- `report()`：返回 `b"\x00\x00\x00" + json.dumps(...).encode()`。**不是纯 JSON**：前 3 字节不能省。
- JSON 顶层 key 要用 clientId：`"uzy_%d_%s" % (profile["auth"]["mode"], profile["addr"])`。driver 里要能读到这两个值（`BaseDriver.login()` 已经用了 `self.profile["auth"]["mode"]` 和 `self.profile["addr"]`，可参考）。
- `on_receive()`：本协议没有下发，不需要特殊处理，用基类默认即可。
- `heartbeat()`：MQTT 用默认（返回 `None`，走协议自带 PINGREQ）。

实现时的注意点：

1. 内层 key 的 `_` 必须恰好两个，如 `S1_ZT_1`、`L1_QJ_1`。不要写成 `S1_ZT` 或 `S1_ZT_1_a`，会整条作废。
2. 逗号串（`L1_QJ`、`L1_GP` 等）必须是**字符串**，且个数固定。浮点数转字符串时一定带小数点（`"%.4f"`），不要出现 `"3"`。
3. `L1_QJ` 的值有 5 个或 8 个两种含义，按物模型有哪些标识（`l1_x...` 还是 `l1_plx...`）选。
4. 标识与代码有几处不一致：`L3_QY → l3_qj`、`L4_NW → l4_ty`、`L4_LB → yl`。driver 里按产品物模型的标识反推 key。
5. 只发物模型里存在的字段；`S1_ZT` 中多余的字段被丢弃但不报错。
6. 设备原始值要做逆换算：`原始值 = (显示值 - offset) / rate`。`S1_ZT` 的子字段也走同样的 rate/offset。
7. 产品 topic 白名单没有 `$dp` 的 publish 时，发布会被拒绝，这是产品配置问题，不是 driver 的问题。driver 启动时最好提示用户检查。
8. 只模拟设备自身。有 `gnss` 配置的子设备由平台后台取数，driver 不需要处理。
