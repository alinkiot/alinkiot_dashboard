# ezviz

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/alinkcore_yinshi.erl`（萤石云摄像头，萤石开放平台标识 `ys`，模块名为 `yinshi`）。库里的协议标识 `ezviz` 在代码里没有被引用，模块与协议标识的对应靠产品约定 |
| 接入 | **第三方系统推送到平台的 HTTP 回调**，不是设备接入。摄像头不连平台的 TCP 6500，也不走 MQTT。没有 `-protocol` 模块，TCP/MQTT 登录会被拒绝 |
| 上报方式 | 萤石云在摄像头触发告警时回调平台；另外平台会主动调用萤石云的取流等接口（见下） |
| 登录与心跳 | 不适用 |
| 适用设备 | 萤石摄像头，库中产品「萤石摄像头」（id 45）。字典 `iot_product_mgr` 里还有一个 `ezviz` 项，是前端产品管理页面的类型 |
| 虚拟设备 | **不能用虚拟设备模拟**，没有 driver。但可以用一个 HTTP 客户端模拟萤石云的告警回调（见下） |

## 数据从哪里来

```
摄像头 ──▶ 萤石云 ──HTTP POST 告警回调──▶ 平台 POST /camera?type=yinshi
```

### 告警回调（入库路径）

平台路由 `/camera`（`alinkcore_yinshi:route/2`），查询参数 `type=yinshi`，方法 POST，没有鉴权。请求体 JSON，满足下面结构且 `header.type` 为 `ys.alarm` 时才处理：

```json
{
  "header": {"messageId": "<消息ID>", "type": "ys.alarm"},
  "body": {
    "devSerial": "<摄像头序列号>",
    "alarmTime": "2024-01-01T12:00:00",
    "alarmType": "<告警类型>",
    "pictureList": [{"url": "http://example.invalid/a.jpg"}]
  }
}
```

处理过程：

1. 用 `devSerial` 查设备：`select addr, product from sys_device where config like '%{devSerial}%'`，也就是设备的 `config` 里要包含这个序列号。库里设备配置的形式是 `[{"name":"device_serial","type":"string","value":"<序列号>"}]`。查到恰好一台设备时才继续，查到 0 台或多台都直接忽略。
2. 组数据 `{ts, alarmType:{value}, pictureList:{value: 图片 URL 的 JSON 数组字符串}}`。`ts` 是 `alarmTime` 前 19 位当东八区时间转成的 Unix 秒；格式不符时用当前时间。
3. 调用钩子 `data.publish`，参数是产品 ID、设备地址、数据。该处只用 `run`（不是 `run_fold`），是否会落库、触发告警，取决于挂在该钩子上的其它模块，代码中未确定。
4. 无论是否查到设备，都返回 HTTP 200，内容 `{"messageId": "<原样回传>"}`。结构不匹配时（没有 `header.messageId`）会因函数子句不匹配而出错，返回值代码中未确定。

没有设置设备会话，所以这种设备在平台上**不会显示在线**，代码中未发现在线状态的维护逻辑。

### 平台主动调用萤石云的部分

模块里还有 `get_token`、`get_live_address`、`device_info`、`device_list` 等函数，用产品的 `pk`、`ps`（在产品里填的萤石应用 key 和 secret）换取 `accessToken`，调用萤石开放平台的取直播地址、设备信息、设备列表接口。这些由前端页面触发，用于看实时画面，不产生物模型数据。密钥只在平台产品里配置，文档不记录。

## 物模型

| name | type | 说明 |
|---|---|---|
| `alarmType` | string | 告警类型，取回调里的 `alarmType` |
| `pictureList` | array | 图片，入库时是图片 URL 数组的 JSON 字符串 |

## 为什么不能用虚拟设备模拟

- 摄像头并不连接平台，平台收到的是萤石云发来的 HTTP 回调。
- 取流、设备信息等需要真实萤石账号和第三方接口，不能模拟。

## 要测试时可以怎么做

| 做法 | 说明 |
|---|---|
| 模拟告警回调 | 平台里建一个 `ezviz` 产品下的设备，设备 `config` 填 `[{"name":"device_serial","type":"string","value":"TESTSERIAL001"}]`；然后向 `POST http://<平台HTTP地址>/camera?type=yinshi` 发上面的 JSON，`devSerial` 填同一个序列号。平台 HTTP 的端口和路径前缀，代码中未确定 |
| 注意 | 设备 `config` 用 `like` 匹配，序列号要足够唯一，避免多台设备匹配导致被忽略 |
| 用别的协议代替 | 建一个物模型相同（`alarmType`、`pictureList`）的 `mqtt-json` 产品，用虚拟设备上报，测前端展示 |

## 写 driver 要点

不适用。如果要做「模拟回调」脚本，它是一个 HTTP 客户端，不属于 `drivers/`。
