# mqtt-json

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/mqtt_server.erl`，转换 `alinkiot_utils/src/alinkiot_json_parser.erl` |
| 接入 | MQTT 1883 |
| 上报方式 | 设备推送：发布 JSON 到 `d/out/{addr}` |
| 登录与心跳 | 通用规则（clientId `uzy_1_` / `uzy_2_`，MQTT keepalive） |
| 适用设备 | 原生支持 MQTT、自定义 JSON 报文的设备 |
| 虚拟设备 | 已内置 `scripts/drivers/mqtt_json.py`，本地平台实测通过（上报和下发） |

## 通讯流程

1. 设备连接认证时，平台检查产品扩展配置里的**协议转换**（`protocolConfig`）。没有配置或解析失败，认证直接失败（CONNACK 返回码 4）。
2. 设备向 `d/out/{addr}` 发布原始 JSON。平台按协议转换把它转成标准 JSON（物模型字段），再换算入库。
3. 转换结果里有 `$sub_addr` 时，数据记到该子设备上（网关场景）。

## 上报报文格式

报文是任意结构的 JSON，由协议转换决定怎么取值。`protocolConfig` 是 base64 编码的 JSON 对象，key 是物模型字段名，value 是取值定义：

| 定义写法 | 含义 |
|---|---|
| `"#a/b"` | 取原始报文的 `a.b`；路径用 `/` 分级 |
| `"#list/items/2/v"` | `items/N` 表示数组第 N 个元素（从 1 开始） |
| `{"value": "#a", "ts": {"ref": "${CURRENT_TIME}"}}` | 值取 `a`，时间戳取平台当前时间 |
| `{"ref": "#a", "format": ...}` | 取值后按 format 转换 |
| `{"ref": "#a", "re": "...", "keys": [...]}` | 对取到的字符串做正则拆分（无法自动反推，需手写报文模板） |
| 其它常量 | 原样作为值 |

转换后每个字段可以是值，也可以是 `{"value": 值, "ts": 秒}`。平台再按物模型做 `值 × rate + offset`。

## 物模型配置

| 字段 | 作用 |
|---|---|
| `name` | 与协议转换的 key 对应 |
| `type` | `integer` / `float` / `string`；字符串形式的数字会按 type 转换 |
| `rate` / `offset` / `precision` | 显示值换算 |
| `access` | `rw` / `write` 的字段可以下发 |

## 平台下发

平台把写指令以 JSON 推送到 `p/in/{addr}`（设备不用订阅，平台直接投递给该连接）：

```json
{"type": "write", "name": "Valve", "value": 1}
```

前端下发时可能带 `format` 字段。平台不要求应答，设备按需上报新状态即可。

## 报文示例

协议转换（解码后）：

```json
{"SteamFlow": {"value": "#data/flow", "ts": {"ref": "${CURRENT_TIME}"}}, "Valve": "#data/valve"}
```

```
设备上报  d/out/VDEVTEST01  {"data": {"flow": 10.18, "valve": 0}}
平台解析  SteamFlow = 10.18（rate 1），Valve = 0
平台下发  p/in/VDEVTEST01   {"value":1,"type":"write","name":"Valve"}
```

## 写 driver 要点

已内置：

- `MODE = "push"`，`report` 调用 `drivers/jsonmap.py`，按协议转换反推原始报文：取每个物模型字段的 `#路径`，把当前原始值写到该位置。
- 带正则的定义无法反推，在虚拟设备配置里写 `payloadTemplate`（任意 JSON，值写 `"{{字段名}}"`）代替。
- 收到 `type: write` 后把该点改为固定输出写入的值，并立即上报一次。
