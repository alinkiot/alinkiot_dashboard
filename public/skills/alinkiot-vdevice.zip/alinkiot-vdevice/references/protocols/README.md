# 协议说明

每个产品协议一份说明，文件名就是协议标识（产品的 `protocol` 字段），例如 `Modbus-RTU.md`。
说明依据平台后端的协议模块（`alinkiot/apps/alinkiot_core/src/protocol/`）整理，描述**真实设备**应该怎么和平台通讯；虚拟设备按同样的方式模拟。

## 所有协议共用的部分

由 `scripts/vdevice.py` 统一处理，各协议说明里不再重复：

| 项 | 内容 |
|---|---|
| MQTT 登录 | 端口 1883（TLS 8883）。clientId `uzy_1_{addr}`、用户名 dk、密码 ds（一机一证）；或 clientId `uzy_2_{addr}`、用户名 pk、密码 ps（一型一密，产品开启自动注册时设备不存在会自动创建） |
| MQTT topic | 设备上报发布到 `d/out/{addr}`；平台下发的写指令推送到 `p/in/{addr}`（无需订阅）；设备可订阅 `d/in/{addr}` |
| TCP 登录 | 端口 6500。连接后先发 `reg,1,{addr},{dk},{ds}\r\n` 或 `reg,2,{addr},{pk},{ps}\r\n`，分隔符可用 `,` `\|` `/`。结尾的 `\r\n` 是 **4 个 ASCII 字符**（`5C 72 5C 6E`），不是回车换行。成功无应答；失败返回 `01` 认证失败、`02` 协议未找到、`99` 其它，然后断开 |
| TCP 心跳 | `ping\r\n`（同样是 4 个字符的 `\r\n`），建议 30 秒一次 |
| 数值换算 | 平台显示值 = 原始值 × `rate` + `offset`，再按 `precision` 取小数位。设备发送的是原始值 |
| 数据归属 | 网关类产品可在报文里带子设备地址，平台把数据记到子设备上；虚拟设备目前只模拟设备自身 |

## 协议一览

| 协议标识 | 接入 | 上报方式 | 虚拟设备 | 说明 |
|---|---|---|---|---|
| `Modbus-RTU` | TCP | 平台轮询 | 内置 `drivers/modbus_rtu.py` | [Modbus-RTU.md](Modbus-RTU.md) |
| `mqtt-json` | MQTT | 设备推送 | 内置 `drivers/mqtt_json.py` | [mqtt-json.md](mqtt-json.md) |
| `tcp-json` | TCP | 设备推送 | 内置 `drivers/tcp_json.py` | [tcp-json.md](tcp-json.md) |
| `Modbus-JY-R100` | TCP | 平台轮询 | 未内置 | [Modbus-JY-R100.md](Modbus-JY-R100.md) |
| `rouxingcexie-huasi` | TCP | 平台轮询 | 未内置 | [rouxingcexie-huasi.md](rouxingcexie-huasi.md) |
| `protocol_t` | TCP 10881（不走 reg） | 设备推送 | 未内置 | [protocol_t.md](protocol_t.md) |
| `GNSS` | MQTT（topic `$dp`） | 设备推送 | 未内置 | [GNSS.md](GNSS.md) |
| `RION-HM705` | MQTT | 设备推送 | 未内置 | [RION-HM705.md](RION-HM705.md) |
| `hnlg-protocol` | MQTT | 设备推送 | 未内置 | [hnlg-protocol.md](hnlg-protocol.md) |
| `hnlg-vdg-protocol` | MQTT | 设备推送 | 未内置 | [hnlg-vdg-protocol.md](hnlg-vdg-protocol.md) |
| `LANZUN-GNSS` | 平台拉取第三方云 | — | 不可模拟 | [LANZUN-GNSS.md](LANZUN-GNSS.md) |
| `CEHOUSHEBEI` | 平台拉取第三方数据库 | — | 不可模拟 | [CEHOUSHEBEI.md](CEHOUSHEBEI.md) |
| `ezviz` | 萤石云回调平台 | — | 不可模拟 | [ezviz.md](ezviz.md) |
| `JIANYUWENSHIDU` | 代码中未找到处理模块 | — | 不可模拟 | [JIANYUWENSHIDU.md](JIANYUWENSHIDU.md) |
| `dji4` | 代码中未找到处理模块 | — | 不可模拟 | [dji4.md](dji4.md) |

除三个内置协议外，说明由后端代码整理，报文示例按代码计算，尚未在平台上实测；写 driver 后务必用 `run` + `check` 验证。没有内置 driver 的协议，按说明里「写 driver 要点」一节实现 `scripts/drivers/<模块名>.py`（接口见 `scripts/drivers/__init__.py`）。

## 说明模板

新增协议时按这个结构写：

```markdown
# <协议标识>

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/.../xxx.erl` |
| 接入 | MQTT / TCP 6500 / 平台主动拉取（非设备接入） |
| 上报方式 | 设备推送 / 平台轮询 |
| 登录与心跳 | 与通用规则相同，或写明差异 |
| 适用设备 | 哪类设备、典型产品 |
| 虚拟设备 | 已内置 `drivers/xxx.py` / 未内置 |

## 通讯流程
## 上报报文格式      字节布局或 JSON 结构、分帧方式、校验
## 物模型配置        哪些 thing 字段影响编解码
## 平台下发          写指令的格式和设备应答
## 报文示例          一帧原始报文 → 平台解析出的物模型值
## 写 driver 要点    MODE、分帧、要覆盖的方法、容易出错的地方
```
