# CEHOUSHEBEI

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/alinkcore_cehou_watcher.erl`（`alinkcore_sup.erl` 启动）；分析接口 `apps/alinkiot_data/src/service/alinkdata_cehou_service.erl`（只做查询，不接入） |
| 接入 | **平台主动拉取（非设备接入）**，平台直接连接第三方的 MySQL 数据库读表。没有 `-protocol` 模块，TCP 6500 或 MQTT 登录会被拒绝 |
| 上报方式 | 平台每 5 分钟轮询一次 |
| 登录与心跳 | 不适用 |
| 适用设备 | 测厚设备（厚度、温度、设备状态、电量状态），库中产品「测厚设备」（id 61） |
| 虚拟设备 | **不能直接模拟设备**；可以模拟第三方数据库（见下），没有 driver |

## 数据从哪里来

```
测厚设备 ──▶ 第三方系统写入 MySQL 表 ◀── 平台每 5 分钟 SELECT 一次
```

1. 平台启动后（需 `alinkiot alinkdata alinkcore alinkalarm alinkiot_tdengine` 都起来，每 10 秒检查）立即执行一次，之后每 5 分钟执行一次。
2. 查库：`sys_device` 联表 `sys_product`，`protocol = 'CEHOUSHEBEI'` 的设备，同时取出产品的 `config`。**只取结果里第一条的产品 `config` 连库**，所有设备共用这一份连接配置。
3. 用产品 `config` 里这四项连第三方 MySQL（没配时的缺省值：地址 `127.0.0.1`、端口 3306，用户名和密码有缺省值，不在这里写）：

| 产品 config 的 name | 类型 | 说明 |
|---|---|---|
| `database_host` | string | 第三方 MySQL 地址 |
| `database_port` | integer | 端口 |
| `database_user` | string | 用户名 |
| `database_password` | string | 密码，只在平台产品配置里填，不写进文档或脚本 |

4. 查询的表是固定的 `changchuan.yw_jiedianjk`（库名 `changchuan`），只取比上次入库时间晚的行：

```sql
SELECT jiedian, jiedianbm, shebei_status, dianliang_status, wendu, houdu, shangchuansj
FROM changchuan.yw_jiedianjk
WHERE shangchuansj > '<本产品 TDengine 表中最后一条数据的时间，格式 YYYY-MM-DD HH:MM:SS，东八区>'
ORDER BY shangchuansj
```

   「最后一条数据的时间」取自 TDengine 表 `alinkiot_{产品ID}`，没有数据时从 0 开始（即全量）。

5. 每一行按列处理：

| 列 | 去向 |
|---|---|
| `jiedian` | **平台设备地址 `addr`**。只有 `jiedian` 等于库里某个该协议设备的 `addr` 时这一行才入库，否则丢弃 |
| `shebei_status` | `<<"1">>`（字符串 `1`）时写入会话缓存，设备显示在线；其它值删除会话，显示离线。同时作为物模型 `shebei_status` 入库 |
| `dianliang_status` | 物模型 `dianliang_status` |
| `wendu` | 物模型 `wendu` |
| `houdu` | 物模型 `houdu` |
| `shangchuansj` | 数据时间。MySQL 的 datetime 被当作东八区时间，减 8 小时转成 Unix 秒 |
| `jiedianbm` | 查询了但没有使用 |

   这些行经 `alinkcore_data:handle` 入库，因此物模型的 `precision`（`wendu`、`houdu` 为 4 位）会生效。列的 SQL 类型（`wendu`、`houdu` 是 decimal 还是 double、`shebei_status` 是不是字符串类型）代码中未确定。

## 物模型

| name | type | 说明 |
|---|---|---|
| `wendu` | float，precision 4 | 温度 |
| `houdu` | float，precision 4，unit m | 厚度 |
| `shebei_status` | string | 设备状态，`1` 表示在线 |
| `dianliang_status` | string | 电量状态 |

## 为什么不能模拟

数据由第三方系统写进它自己的 MySQL，平台只是读表。不存在设备到平台的连接，也没有帧协议。

## 要测试时可以怎么做

连接地址来自产品配置，**不需要改代码**，所以可以自己搭一个第三方库：

| 步骤 | 做法 |
|---|---|
| 1 | 起一个测试用 MySQL（本机或容器），建库 `changchuan` 和表 `yw_jiedianjk`，包含上面 7 列。列类型自选，例如 `jiedian` varchar、`shangchuansj` datetime、`wendu`/`houdu` decimal，`shebei_status`/`dianliang_status` varchar |
| 2 | 在平台里把产品的 `database_host`、`database_port`、`database_user`、`database_password` 改成这个测试库（平台的 Erlang 进程必须能访问到该地址） |
| 3 | 平台里建一个该产品下的设备，`addr` 与表里 `jiedian` 的值一致 |
| 4 | 向表里持续插入行，`shangchuansj` 要大于已入库的最后时间；`shebei_status` 填 `1` 表示在线。最长等 5 分钟看到数据 |

「虚拟设备」脚本在这里的角色是「往测试库插行的小程序」，不是 `drivers/` 下的 driver。要在不搭库的情况下看效果，可用物模型相同的 `mqtt-json` 产品上报 `wendu houdu shebei_status dianliang_status`。

## 已知限制（来自代码）

- 多个产品使用该协议时，只有结果集里第一条设备所属的产品配置被使用，其它产品的设备按这套连接配置读数据，并按第一条设备的产品 ID 入库。
- 连接第三方库失败时，代码没有返回有效结果，后续处理的行为代码中未确定。

## 写 driver 要点

不适用，不要写 `drivers/` 下的 driver。
