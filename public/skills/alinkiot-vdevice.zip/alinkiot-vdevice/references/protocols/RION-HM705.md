# RION-HM705

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/rion_hm705_server.erl`，MQTT 钩子在 `apps/alinkiot_core/src/alinkcore_mqtt.erl` |
| 接入 | MQTT（端口 1883 / TLS 8883） |
| 上报方式 | 设备推送 JSON，平台不轮询 |
| 登录与心跳 | 与通用 MQTT 规则相同，无差异。协议模块的 `init/1` 直接返回 ok，不做额外校验 |
| 适用设备 | RION HM705 4G 高精度倾角振动传感器（角度、加速度、温度、电量、定位、告警） |
| 虚拟设备 | 未内置，按本文「写 driver 要点」实现 `drivers/rion_hm705.py` |

## 通讯流程

```
设备 ─MQTT 登录(uzy_1_{addr} 或 uzy_2_{addr})─▶ 平台
设备 ─发布 d/out/{addr}  {"params":{...}}─▶ 平台 ：过滤字段、转小写、换算、入库
平台 ─推送 p/in/{addr}   {"params":{"ANG":30}}─▶ 设备 ：用户在平台改可写属性时
```

- 平台只处理发布到 `d/out/{addr}` 的消息。`{addr}` 必须是登录用的设备地址。
- 每条上报消息到达时，平台先检查该设备有没有未下发的缓存指令（设备离线时用户下发的写指令会缓存）。有则 500 ms 后重新发给设备，见「平台下发」。
- 平台不对上报做应答。设备没有需要回复的上行确认。
- 上报间隔、休眠周期由设备自己决定，协议模块里没有定时逻辑。

## 上报报文格式

MQTT 消息，payload 为 UTF-8 JSON，topic `d/out/{addr}`：

```json
{"params": {"XANG": 12.4, "YANG": -3.2, "TEMP": 25, "CSQ": 20}}
```

处理规则（`build_data/1`）：

| 规则 | 说明 |
|---|---|
| 外层必须是对象且含 `params` | 没有 `params` 的消息被忽略，不报错 |
| key 必须**大写**且在白名单内 | 不在白名单的 key 被丢弃。白名单是全大写字符串，小写 key 不会命中 |
| key 转小写作为物模型 `name` | `XANG` → `xang` |
| 时间戳 | 平台取收到消息的时间，**不使用设备时间**。报文里不用带时间 |
| 值 | 原样传给换算，不检查类型 |
| 地址 | 取自 MQTT 登录的设备地址，报文里没有地址字段 |
| 分帧 | 一条 MQTT 消息一次上报，没有拆包问题 |
| 校验 | 无 |

白名单（共 24 个，对应小写物模型字段）：

`INDEX` `IMEI` `PID` `XANG` `YANG` `ZANG` `XACC` `YACC` `ZACC` `ALARM_FLG` `ALARM_TYPE` `ANG` `ACC` `CLR_FLG` `FIX` `FREQ` `RFAA` `ACTC` `CSQ` `EQC` `TEMP` `LNGTD` `LATTD` `SOFTVERSION`

各字段含义以参考产品物模型为准（见下节）；`INDEX`、`IMEI`、`SOFTVERSION` 不在参考物模型中，含义和类型代码中未确定。

## 物模型配置

数值换算（`alinkcore_data:create_format`）：显示值 = 值 × `rate` + `offset`，再按 `precision` 四舍五入。`rate` 缺省 1，`offset` 缺省 0。

| thing 字段 | 对编解码的影响 |
|---|---|
| `name` | 必须等于白名单 key 的小写形式，否则该字段不入库 |
| `type` | `string` 不换算，原样入库；其它类型做数值换算。**JSON 里发字符串数字给 float/integer 字段时**，平台用 `binary_to_float` / `binary_to_integer`，`"25"` 给 float 字段会报错，所以 driver 一律发 JSON 数字 |
| `precision` | 整数时对结果四舍五入到该小数位。参考产品里角度字段 `precision: 0`（版本 `id=23`）会把 `12.4` 变成 `12.0`；`id=93` 的版本是 2 位小数 |
| `rate` / `offset` | 参考产品未配置，值按原样入库；若产品配置了，设备要发送反算后的原始值：`raw = (显示值 - offset) / rate` |
| `access` | `read` / `write` / `rw`，决定平台下发写指令时是否放行，见下节 |
| `min` / `max` | 代码中未确定是否参与校验，上报不会被拦截 |

参考产品「4G高精度倾角振动传感器」（`protocol = RION-HM705`，库里有 `id=23`、`id=93` 两个版本，字段相同，仅角度精度不同）：

| name | 含义 | type | 范围 | access |
|---|---|---|---|---|
| `xang` `yang` `zang` | 各轴与水平面夹角，° | float | -90~90 | read |
| `xacc` `yacc` `zacc` | 各轴加速度，g | float | -2~2 | read |
| `ang` | 角度阈值，° | float | 0~90 | **rw** |
| `acc` | 加速度阈值，g | float | 0~1 | **rw** |
| `fix` | 安装方向 | integer | 0~5 | read |
| `eqc` | 电量百分比，% | integer | | read |
| `temp` | 温度，°C | float | -128~127 | read |
| `rfaa` | 告警周期，s | integer | 600~259200 | **rw** |
| `pid` | 产品 id | integer | | read |
| `alarm_flg` / `alarm_type` | 告警标志 / 类型 | integer | | read |
| `clr_flg` | 清零标志 | integer | | **rw** |
| `lngtd` / `lattd` | 经度 / 纬度，° | float，precision 2 | | read |
| `csq` | 信号强度 | integer | | read |
| `actc` | 告警确认，min | integer | 0~127 | **rw** |
| `freq` | 休眠周期，s | integer | 600~259200 | **rw** |

## 平台下发

### 用户改可写属性

平台收到前端指令（`msgType=control_device`），发布到 `p/in/{addr}`。该消息在投递给设备前经过 `handle_out`：

| 步骤 | 内容 |
|---|---|
| 入参 | `{"type": ..., "name": "ang", "value": 30}`，可能还有 `format`，该协议不使用 `type` 和 `format` |
| 检查 | `name` 与产品物模型某个 thing 的 `name` **完全相同**（小写），且该 thing 的 `access` 是 `rw` 或 `write` |
| 通过 | 设备收到：`{"params": {"ANG": 30}}`（`name` 转大写，`value` 原样） |
| 不通过 | 设备收到空指令：`{"params": {}}` |
| 缺少 `name` 或 `value` | 原消息原样投递 |

设备在 `p/in/{addr}` 收到后按 `params` 里的 key 修改本地参数。**设备不需要回复**，协议模块里没有应答处理。平台也不会自动把写入值更新到物模型，设备应在后续上报里带上新值（如 `ANG`）。前端是否在下发前对 `value` 做 `rate` 反算，代码中未确定。

### 设备离线时的缓存指令

用户下发指令时设备不在线，指令（含 `name`、`value`）缓存在平台。设备下次上报任意 `d/out/{addr}` 消息时，平台 500 ms 后把它发布到 **`d/in/{addr}`**（QoS 2），内容同样是 `{"params": {"ANG": 30}}`。此路径**不检查 `access`**。设备需订阅 `d/in/{addr}` 才能收到。

该路径调用 `alinkiot:mqtt_publish/4` 时参数顺序与函数声明（`From, Topic, Qos, Payload`）不一致（代码传的是 `From, 2, Topic, Payload`），实际能否送达，代码中未确定。

## 报文示例

上报，设备 `HM705000001`，topic `d/out/HM705000001`，使用参考产品 `id=93`：

```json
{"params": {"PID": 705, "XANG": 12.456, "YANG": -3.2, "ZANG": 85.731, "XACC": 0.012, "YACC": -0.003, "ZACC": 0.998,
            "ANG": 30, "ACC": 0.5, "FIX": 1, "EQC": 90, "TEMP": 25, "RFAA": 3600, "ALARM_FLG": 0, "ALARM_TYPE": 0,
            "CLR_FLG": 0, "LNGTD": 113.27, "LATTD": 23.12, "CSQ": 20, "ACTC": 0, "FREQ": 3600, "FOO": 1}}
```

平台解析出的物模型值（`FOO` 不在白名单被丢弃；`ts` 为平台收到时间）：

| name | 入库值 | 说明 |
|---|---|---|
| `xang` | 12.46 | precision 2 |
| `yang` | -3.2 | |
| `zang` | 85.73 | precision 2 |
| `xacc` / `yacc` / `zacc` | 0.012 / -0.003 / 0.998 | 未配置 precision，原样 |
| `ang` / `acc` | 30 / 0.5 | |
| `fix` / `eqc` / `temp` / `csq` | 1 / 90 / 25 / 20 | |
| `rfaa` / `freq` | 3600 / 3600 | |
| `lngtd` / `lattd` | 113.27 / 23.12 | precision 2 |
| `pid` `alarm_flg` `alarm_type` `clr_flg` `actc` | 705 0 0 0 0 | |

下发：用户把 `ang` 改成 35，设备在 `p/in/HM705000001` 收到：

```json
{"params": {"ANG": 35}}
```

用户对只读字段（如 `xang`）下发，设备收到：

```json
{"params": {}}
```

## 写 driver 要点

| 项 | 内容 |
|---|---|
| `PROTOCOL` | `"RION-HM705"`，模块文件 `rion_hm705.py` |
| `TRANSPORT` | `"mqtt"`，上报 topic 缺省 `d/out/{addr}`，不用改 `UP_TOPIC` |
| `MODE` | `"push"` |

- `report()`：返回 `json.dumps({"params": {...}}).encode()`。key 用**大写**，只放白名单里的字段；值用 JSON 数字（字符串只给 `type: string` 的字段，如 `IMEI`、`SOFTVERSION` 在产品里被配置成字符串时）。
- 取值：按物模型 `name` 大写后作为 key。物模型里没有的白名单字段可以不发。有 `rate` 时发 `raw = (显示值 - offset) / rate`。
- `on_receive(data, topic)`：解析 `p/in/{addr}`（和可选的 `d/in/{addr}`）里的 JSON。对 `params` 中每个 key 转小写，若物模型里存在该字段，更新本地值，并返回 `[self.report()]` 立即上报一次，让平台看到新值。`params` 为空时不处理。
- 可写字段只有 `ang`、`acc`、`rfaa`、`clr_flg`、`actc`、`freq`（以实际产品物模型的 `access` 为准）。写入的值要保持，之后的上报一直带新值。`clr_flg` 的含义（写入后是否自动复位）代码中未确定。
- 想收到离线缓存指令需订阅 `d/in/{addr}`。是否需要订阅 `p/in/{addr}` 见通用规则，平台直推，无需订阅。
- 容易出错的地方：
  - key 写成小写会被整个丢弃，平台不报错，数据看起来「没上报」。
  - 不要发 `type: float` 或 `integer` 字段的字符串值。平台对字符串走 `binary_to_float` / `binary_to_integer`，`"25"` 这类写法会转换失败，这条数据不会入库。
  - 值保持在物模型 `min` / `max` 范围内（如角度 -90~90）。平台代码里没有看到范围检查，范围的其它用途代码中未确定。
  - 不要在报文里带 `addr` 或时间字段，平台忽略它们。
  - 登录必须用 MQTT（`uzy_1_` / `uzy_2_`），该协议没有 TCP 接入。
