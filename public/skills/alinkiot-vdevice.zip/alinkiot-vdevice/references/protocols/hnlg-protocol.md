# hnlg-protocol

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/hnlg_server.erl`（MQTT 入口 `alinkcore_mqtt.erl`） |
| 接入 | MQTT（不走 TCP 6500，没有 reg 登录） |
| 上报方式 | 设备推送，JSON，发布到 `d/out/{addr}` |
| 登录与心跳 | 与通用 MQTT 规则相同（clientId `uzy_1_{addr}` 或 `uzy_2_{addr}`），心跳用 MQTT 自带 PINGREQ，无差异 |
| 适用设备 | 河南理工大学项目的 4G 采集仪/网关（骏业科技采集仪、有智云采集仪、QD-potential 电位采集仪等）。网关本体上报数组，RS485 子设备上报 hex 字节串 |
| 虚拟设备 | 未内置，按本文「写 driver 要点」实现 `drivers/hnlg_protocol.py` |

登录成功时平台按产品的 `protocol` 字段找到本模块并调用 `init/1`。之后设备发布到 `d/out/{addr}` 的每条消息都交给 `handle_in/3`。发到其它 topic 的消息被忽略。

## 通讯流程

```
设备                                   平台
 │── d/out/{addr} {cmd:1,...} ───────▶│  上报采集间隔，平台回 ack
 │◀── d/in/{addr}  {cmd:1,state:1} ────│
 │── d/out/{addr} {cmd:2,...} ───────▶│  网关自身数据（数组），平台回 ack
 │◀── d/in/{addr}  {cmd:2,state:1} ────│
 │── d/out/{addr} {cmd:3,...} ───────▶│  子设备数据（hex 字节串），平台回 ack
 │◀── d/in/{addr}  {cmd:3,state:1} ────│
 │◀── d/in/{addr}  {cmd:4,deviceSet} ──│  用户修改 interval_time 时下发
 │── d/out/{addr} {cmd:4,state:1} ───▶│  设备应答
```

- 三种上报（cmd 1、2、3）互相独立，平台不要求先发 cmd 1。
- 平台的 ack 和下发都发布在 `d/in/{addr}`，设备订阅这个 topic 即可。
- 上报消息必须带全下表中的字段。字段缺失或多余的组合在平台没有兜底分支（函数子句不匹配会抛异常），平台不会回复，该消息也不入库。

## 上报报文格式

所有消息都是 UTF-8 JSON 对象，字段名区分大小写（`timesTamp` 是代码中的原拼写，`offline_flag` 带下划线，`IntervalTime` 首字母大写）。

### cmd 1：上报采集间隔

```json
{"id": 1, "cmd": 1, "address": 0, "IntervalTime": 10}
```

| 字段 | 要求 |
|---|---|
| `id` | 整数，平台原样放进 ack |
| `cmd` | 固定 1 |
| `address` | 固定 0（匹配条件，其它值不被识别） |
| `IntervalTime` | 采集间隔，物模型 `interval_time` 的原始值 |

平台动作：把 `IntervalTime` 记入该连接的内存配置，并发布 `{"ts":秒,"interval_time":{"value":IntervalTime,"ts":秒}}` 到 `p/out/{addr}` 和 `p/thing/{产品ID}/{addr}`。**不走 `alinkcore_data`，不经过 rate/precision 换算，也不入库**。之后每次 cmd 2 上报都会附带这个 `interval_time` 值入库（连接断开后清除）。

平台应答（发到 `d/in/{addr}`）：`{"id":<原id>,"address":0,"state":1,"cmd":1}`

### cmd 2：网关自身数据

```json
{"id": 2, "cmd": 2, "address": 0, "timesTamp": 1735689600, "dataArray": [12345, 12000, 215]}
```

| 字段 | 要求 |
|---|---|
| `timesTamp` | 秒级 Unix 时间戳整数。不是整数时平台用自己的当前时间 |
| `dataArray` | 数值数组，元素是**原始值**（未乘 rate） |

平台把数组第 N 个元素（从 1 数起）记为物模型点 `dN`，即 `dataArray[0]` → `d1`，`dataArray[1]` → `d2`。点名固定是 `d` 加序号，与物模型里的 `modbus` 配置无关。数组里的点必须在物模型中有同名 `name`，否则被丢弃。再附带 cmd 1 记下的 `interval_time`。

平台应答：`{"id":<原id>,"address":0,"state":1,"cmd":2}`

### cmd 3：子设备数据

```json
{"id": 3, "cmd": 3, "address": 1, "timesTamp": 1735689600, "offline_flag": 0, "dataArray": "000125800001000203E8"}
```

| 字段 | 要求 |
|---|---|
| `address` | 子设备从机地址，整数 0 到 255。平台把它转成 1 字节，与子设备在 `sys_sub_device.sub_addr`（2 位 hex，如 `01`、`0B`）中登记的值比对 |
| `offline_flag` | 0 表示在线并带数据；1 表示该子设备离线，平台删除它的在线会话，不解析 `dataArray`（字段仍要给出，`dataArray` 可为任意值） |
| `dataArray` | **hex 字符串**，一串字节的十六进制文本（大小写均可，必须偶数个字符）。注意与 cmd 2 的数组不同 |
| `timesTamp` | 同 cmd 2 |

平台动作：
1. 用网关地址查它的子设备列表（仅启用状态的设备），按 `address` 找到子设备。找不到则丢弃，**但仍回 ack**。
2. 子设备首次上报时平台为它建立在线会话；`offline_flag=1` 时删除会话。
3. 按子设备产品的物模型解析 `dataArray`，见下一节。

平台应答（不论是否找到子设备都回）：`{"id":<原id>,"address":<原address>,"state":1,"cmd":3}`

### 分帧与校验

MQTT 一条消息就是一帧，没有分帧问题。JSON 之外没有校验字段，不使用 CRC。代码中未确定：设备 `id` 的取值规则（平台只回显）。

## 物模型配置

### cmd 2（网关产品）

只用到 `name`（必须是 `d1`…`dN`）以及换算字段：

| thing 字段 | 作用 |
|---|---|
| `name` | 必须是 `d` + 数组序号 |
| `type` | `integer`/`float` 等，做数值换算；`string` 不换算 |
| `rate` | 平台显示值 = 原始值 × rate + offset，缺省 rate=1 |
| `offset` | 缺省 0 |
| `precision` | 整数时四舍五入保留该位小数；非整数（如产品 97 里的 `0.1`）或缺省时不取整 |
| `access` | 不参与 cmd 2 解析 |

### cmd 3（子设备产品）

平台用**子设备产品**的物模型，只处理同时满足下面条件的点：`access` 为 `read` 或 `rw`，且 `modbus` 对象里同时有 `start`、`quantity`、`signed`、`endianness`，另外有 `name`、`type`。缺任何一个键该点被跳过（不报错）。

| thing 字段 | 作用 |
|---|---|
| `modbus.start` | **hex 字符串**，是 `dataArray` 解码后的**字节偏移**，不是寄存器号。`"0002"` 表示从第 2 个字节开始 |
| `modbus.quantity` | 取的**字节数**，不是寄存器数。一个 16 位寄存器是 2 |
| `modbus.signed` | `signed` 或 `unsigned` |
| `modbus.endianness` | `big`、`little`、`big2`、`little2`（见下表） |
| `type` | `integer`、`float`，`string` 特殊处理 |
| `rate`、`offset`、`precision` | 解码后再做 原始值 × rate + offset 和取整 |
| `modbus.rFunCode`、`slaveId` | 本协议不使用（DB 里的子设备产品会带 `rFunCode: "03"`，对解析没有影响） |

解码规则（`hnlg_server:format_type/4` 加 `alinkiot_utils:format_value/2`）：取 `dataArray` 字节串里 `[start, start+quantity)` 这一段，按段长（字节数）和下表解码。

| 字节数 | 格式 | 结果 |
|---|---|---|
| 1 | `signed`/`unsigned` 整数 | 8 位整数（`endianness` 不起作用） |
| 2、4、8 | `{endianness}-{signed}-{type}` | 整数或浮点。`type` 取物模型的 `type`，`float` 按 IEEE754 解码 |
| 其它长度（3、5、6 等） | 无匹配 | 返回整段字节的**大写 hex 字符串**，再被当成字符串点处理 |
| 任意，`type` 为 `string` | `string` | 同样返回整段字节的**大写 hex 字符串**，不是 UTF-8 文本 |

`endianness` 含义（16/32/64 位通用，按字节排列）：

设 hex 串里的 4 个字节自左向右为 A B C D。下表给出解码出的数值，其字节从高到低的排列：

| 值 | 数值的高→低字节 | 做法 |
|---|---|---|
| `big` | A B C D | 直接按大端读 |
| `little` | D C B A | 直接按小端读 |
| `big2` | B A D C | 先把每 2 字节对调（A B C D → B A D C），再按大端读 |
| `little2` | C D A B | 先把每 2 字节对调，再按小端读 |

2 字节、8 字节同理（8 字节也是每 2 字节对调）。

16 位 `float` 的解码是否可用代码中未确定（依赖 Erlang/OTP 版本），建议浮点用 4 或 8 字节。

`start + quantity` 超出 `dataArray` 实际字节数时，`binary:part` 抛异常。解析在生成 ack 之前执行，所以这条消息**不入库，也收不到 ack**。设备必须保证字节串覆盖物模型里所有点。

## 平台下发

下发由平台 `handle_out/3` 在 p/in 消息送达设备时改写，改写后发布到 `d/in/{addr}`。

### 修改 interval_time（常用）

平台收到用户写入 `interval_time` 的指令（原始指令为 `{"type":"write","name":"interval_time","value":10}`）时，改写成：

```json
{"id": 1, "cmd": 4, "address": 0, "deviceSet": [10]}
```

`id` 是平台为该连接生成的递增序号（从 1 开始）。`deviceSet` 数组里放用户给的 `value`（原样类型）。设备应答：

```json
{"id": 1, "cmd": 4, "address": 0, "state": 1}
```

- `state: 1` 表示成功：平台把 `interval_time` 发布到 `p/out/{addr}`，用户页面上才会更新。
- `state: 0` 表示失败（任意 `cmd`，只要带 `address: 0`）：平台按 `id` 在最近 3 条下发缓存中查找，找到就把**原下发报文**再发一次到 `d/in/{addr}`。没找到则不回复。
- 代码中未确定：cmd 4 的 ack 分支最后调用 `emqx:publish` 并把它的返回值交给 `reply/2` 当报文发布，可能导致平台这一步抛异常。设备照常回 ack 即可，不必关心。

### 其它写指令

`name` 不是 `interval_time` 且报文里没有 `cmd` 字段的写指令，平台不改写，设备收到的是 `{"type":"write","name":"...","value":...}`，topic 仍是 `p/in/{addr}`。本协议代码没有为它们定义设备应答，代码中未确定设备应如何处理。

### 调试用指令（用户界面的写入不会触发）

只有 payload 里带下面 `cmd` 时才会触发，平台普通写指令不带，通常只能通过 `hnlg_server:test_send/2` 之类的内部调用触发：

| 平台 → 设备 | 设备应答 |
|---|---|
| `{"id":n,"cmd":5,"address":0}` 读取 485 配置 | `{"id":n,"cmd":5,"state":1,"dataArray":{"RS485":[{"BaudRate":9600,"address":0,"Feature":0,"startReg":0,"numReg":10}]}}`，平台把这些字段写进 `sys_device.config`（`address` 0 写网关本身，其它值按子地址找子设备） |
| `{"id":n,"cmd":6,"address":0,"dataArray":{"RS485":[]}}` 设置 485 配置 | `{"id":n,"cmd":6,"state":1}`，平台忽略 |
| `{"id":n,"cmd":20,"address":0,"data":1}` 清缓存 | `{"id":n,"cmd":20,"state":1}`，平台忽略 |

设备应答里**不要带 `address: 0`**：平台按顺序匹配，`address` 为 0 且 `state` 为 1 的消息会先被通用的忽略分支吃掉，cmd 5 的数据就不会处理（cmd 4 的应答除外，它有专门分支）。cmd 5 应答里 `BaudRate`、`address`、`Feature`、`startReg`、`numReg` 五个键缺一个就会解析失败。`insert_into_config_map` 只更新 `sys_device.config` 里已存在的同名项。

## 报文示例

### 示例 1：网关数据（产品「骏业科技采集仪」）

物模型：`d1`–`d8` 振弦，`rate 0.1`，`precision 2`，单位 Hz；`d9`–`d16` 温度，`rate 0.1`，`precision 1`，单位 °C。

设备发布到 `d/out/866276058509794`：

```json
{"id":1,"cmd":2,"address":0,"timesTamp":1735689600,"dataArray":[12345,12000,11800,0,0,0,0,0,215,220,0,0,0,0,0,0]}
```

平台解析：

| 点 | 原始值 | 换算 | 入库值 |
|---|---|---|---|
| d1 | 12345 | ×0.1，保留 2 位 | 1234.5 |
| d2 | 12000 | 同上 | 1200.0 |
| d3 | 11800 | 同上 | 1180.0 |
| d9 | 215 | ×0.1，保留 1 位 | 21.5 |
| d10 | 220 | 同上 | 22.0 |

时间戳 `1735689600`。平台回复到 `d/in/866276058509794`：`{"id":1,"address":0,"state":1,"cmd":2}`。

### 示例 2：子设备数据（产品「水位计-子设备」，Modbus-RTU 类产品挂在网关下）

子设备在网关下登记的 `sub_addr` 为 `01`。其物模型 `sd1`–`sd5` 均为 `integer`、`signed: unsigned`、`endianness: big`、`quantity: 2`，`start` 依次为 `0000`、`0002`、`0004`、`0006`、`0008`。

```json
{"id":2,"cmd":3,"address":1,"timesTamp":1735689600,"offline_flag":0,"dataArray":"000125800001000203E8"}
```

字节串 `00 01 | 25 80 | 00 01 | 00 02 | 03 E8` 按 2 字节切分，平台解析：

| 点 | start | 字节 | 值 |
|---|---|---|---|
| sd1 | 0000 | `0001` | 1 |
| sd2 | 0002 | `2580` | 9600 |
| sd3 | 0004 | `0001` | 1 |
| sd4 | 0006 | `0002` | 2 |
| sd5 | 0008 | `03E8` | 1000 |

数据记到子设备（`address=1` 对应的设备）而不是网关。平台回复：`{"id":2,"address":1,"state":1,"cmd":3}`。

### 示例 3：修改间隔

平台 → 设备（`d/in/{addr}`）：`{"id":1,"cmd":4,"address":0,"deviceSet":[10]}`
设备 → 平台（`d/out/{addr}`）：`{"id":1,"cmd":4,"address":0,"state":1}`

## 写 driver 要点

| 项 | 内容 |
|---|---|
| `PROTOCOL` | `"hnlg-protocol"` |
| `TRANSPORT` | `"mqtt"` |
| `MODE` | `"push"` |
| 文件名 | `drivers/hnlg_protocol.py` |
| `UP_TOPIC` | 用默认 `d/out/{addr}` |

要覆盖的方法：

- `report()`：返回一条 JSON（`json.dumps(...).encode()`）。一次只能返回一帧，需要自己轮换。建议第一次调用返回 cmd 1，之后每次返回 cmd 2（网关产品，物模型点名为 `d1…dN`）或 cmd 3（子设备）。平台不要求 cmd 1，不发也能入库，但没有 `interval_time`。
- `on_receive(data, topic)`：`data` 是一条完整消息，`json.loads` 后按 `cmd` 处理：
  - 收到 `cmd: 4`：取 `deviceSet[0]` 更新本地 `interval_time`，返回 `{"id":原id,"cmd":4,"address":0,"state":1}`。
  - 收到平台对 cmd 1/2/3 的 ack（含 `state`）：不用回复。
  - 收到 `{"type":"write",...}`（非 interval_time 的写入）：本协议未定义应答，记日志即可。
  - 收到 cmd 5、6、20：按上文应答（可选）。
  - 不要依赖 `topic`：平台改写后的消息通过 `d/in/{addr}` 到达，没改写的写指令可能仍是 `p/in/{addr}`。

容易出错的地方：

| 问题 | 说明 |
|---|---|
| cmd 2 与 cmd 3 的 `dataArray` 类型不同 | cmd 2 是数字数组，cmd 3 是 hex 字符串 |
| 原始值 | 设备发的是**原始值**，不是显示值。要上报显示值 V，原始值 = (V − offset) / rate，再取整（整型点） |
| 点名与序号 | cmd 2 的点名固定为 `d1…dN`，必须与产品物模型一致 |
| cmd 3 的 `start`、`quantity` | 单位是字节，`start` 是 hex 文本。生成字节串时按 `start+quantity` 的最大值分配，空白处补 0 |
| 字节序 | 按物模型 `endianness` 编码，`big2`/`little2` 要先按 big/little 排好再每 2 字节对调。浮点用 4 或 8 字节 |
| `string` 类型 | 平台把字节段原样转成大写 hex 字符串，不做 UTF-8 解码。若要显示可读文本，需要代码之外的约定，代码中未确定 |
| `address` | cmd 3 的 `address` 必须与 `sys_sub_device.sub_addr` 的数值一致（`"0B"` 对应 11）。不一致时平台丢弃但仍回 ack |
| `offline_flag` | cmd 3 必须带此字段，即使是 0 |
| 重发 | 平台只缓存最近 3 条下发，只在收到 `state: 0` 的应答时重发。平台不会因为设备没应答而重发 |
| `timesTamp` | 用秒。平台没有校验单位，原样作为数据时间 |
