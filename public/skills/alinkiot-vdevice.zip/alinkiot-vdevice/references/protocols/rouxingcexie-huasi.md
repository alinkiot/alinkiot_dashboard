# rouxingcexie-huasi

| 项 | 内容 |
|---|---|
| 后端模块 | `apps/alinkiot_core/src/protocol/flexible_inclinometer_server.erl`（TCP 帧分发见 `apps/alinkiot_bridge/src/alinkiot_dtu_listen.erl`，子设备模块选择见 `apps/alinkiot_core/src/alinkcore_protocol.erl` 的 `get_childeren_mod`） |
| 接入 | TCP 6500，走通用 `reg` 登录 |
| 上报方式 | 平台轮询：平台每 60 秒向设备发一条 `$HUASI,GET,DATA,...` 请求，设备回一帧数据（`DATA_INTERVAL = 60*1000`） |
| 登录与心跳 | 登录同通用规则。心跳除通用的 `ping\r\n`（4 个字符）外，还接受 `$HB...*HB`（见下） |
| 适用设备 | 华思柔性测斜仪（多节点串联，每节点 10 个值）。示例产品：「华思柔性测斜仪」(node_type=children)、「海思全向位移计」(node_type=device) |
| 虚拟设备 | 未内置，需新写 `scripts/drivers/rouxingcexie_huasi.py` |

## 通讯流程

1. 设备 TCP 连 6500，发 `reg,...\r\n`（通用规则，`\r\n` 为 4 个 ASCII 字符）。
2. 登录成功后平台为该连接启动 60 秒定时器。**登录后约 60 秒才会发第一条请求**，之后每 60 秒一次。
3. 定时器触发时平台发请求帧，在 10 秒内等设备回一帧。收到后校验、解析、入库。超时或校验失败只记日志，不断连。
4. 设备空闲时按需发 `ping\r\n` 或 `$HB...*HB` 心跳，平台不应答。

三种接入形态，设备侧报文完全相同，区别在平台怎样选模块和归属数据：

| 形态 | 条件 | 数据记到 | 请求里的 device_id 来自 |
|---|---|---|---|
| 单设备 | 登录设备的产品 `node_type` 不是 gateway，产品协议为 `rouxingcexie-huasi` | 登录设备自己，用它自己产品的物模型 | 该设备配置项 `device_id` |
| 网关 + 子设备 | 登录设备产品 `node_type=gateway`，且它的某个子设备产品协议是 `rouxingcexie-huasi`。此时无论网关产品协议是什么（只要平台能找到该协议），连接都改用本模块 | 每个子设备各自记自己，用子设备产品的物模型 | 每个子设备自己配置里的 `device_id` |
| 网关自身 | 同上，网关本身也有一个 60 秒定时器 | 网关设备自己 | 网关设备配置项 `device_id`，没配置则为空串 |

要点：
- 网关下有 N 个子设备时，每 60 秒会发出 N+1 条请求（每个子设备一条，加网关自己一条），在同一连接上**串行**收发，每条最多等 10 秒。设备必须一问一答，顺序对应。
- 子设备的 `subAddr` 不进报文，请求只靠 `device_id` 区分，不要用 subAddr 区分。
- 网关自身那条请求的 `device_id` 可能为空（`$HUASI,GET,DATA,*XX`）。设备对它回不回帧，代码中未确定；不回只会等 10 秒超时，数据不入库，对其它子设备无影响。

## 上报报文格式

### 平台请求（平台 → 设备）

```
$HUASI,GET,DATA,<device_id>*<CS>\r\n
```

- 末尾 `\r\n` 是**真实的 0D 0A 两个字节**（和 reg/ping 里的 4 字符文本不同）。
- `<CS>` 是 2 位**大写**十六进制校验。
- 没有长度字段，设备按 `\r\n` 切帧。

### 设备应答（设备 → 平台）

```
$HUASI,GET,DATA,<device_id>,<node_num>,<f1>,<f2>,...,<fN>*<CS>\r\n
```

| 部分 | 说明 |
|---|---|
| `<device_id>` | 字符串，原样存入物模型 `device_id`。平台不校验它是否等于请求里的值 |
| `<node_num>` | 整数（`binary_to_integer`），存入物模型 `node_num` |
| `<f1>...` | 按位置依次命名，每节点 10 个值，见下表。个数不做检查，不要求等于 `node_num` × 10 |
| `<CS>` | 2 位大写十六进制，见校验 |
| `\r\n` | 真实 0D 0A，可有可无（平台会把所有 `\r\n` 删掉再解析） |

字段位置与物模型标识（第 `Seq` 个值，从 1 开始；`Seq%10` 决定名称，`节点号 = (Seq-1) div 10`）：

| Seq%10 | 标识前缀 | 类型 | 例（节点 0 / 节点 1） |
|---|---|---|---|
| 1 | `node` | 字符串 | `node0` / `node1`（Seq=1 / 11） |
| 2 | `voltage` | 浮点 | `voltage0` / `voltage1` |
| 3 | `temp` | 浮点 | `temp0` |
| 4 | `accx` | 浮点 | `accx0` |
| 5 | `accy` | 浮点 | `accy0` |
| 6 | `accz` | 浮点 | `accz0` |
| 7 | `locationx` | 浮点 | `locationx0` |
| 8 | `locationy` | 浮点 | `locationy0` |
| 9 | `locationz` | 浮点 | `locationz0` |
| 0 | `rotation_angle` | 浮点 | `rotation_angle0`（Seq=10）/ `rotation_angle1`（Seq=20） |

### 分帧与整帧要求

- 平台用一次 `recv` 取回应答，**整帧要在一次 `send` 里发出**，不要拆包，也不要把多帧合并。
- 平台先删掉所有 `\r\n`，再按 `*` 切分，必须恰好切成两段（`*` 前、`*` 后）。所以帧中除结尾那个 `*` 外不能再有 `*`。
- 浮点值用 Erlang `binary_to_float`，**必须带小数点**：`3.30`、`0.0`、`-1.25` 合法；`3`、`.5`、`5.` 不合法。指数写法 `1.0e-3` 合法，建议不用。任何一个字段不合法，**整帧丢弃**（只记日志，不入库部分字段）。
- 校验失败 / 切分失败 / 解析异常：整帧丢弃，不回错误给设备。

### 校验

对帧中**第一个 `$` 之后、第一个 `*` 之前**的所有字节逐字节异或，结果转 2 位大写十六进制。不含 `$`、`*`，不含 `\r\n`，请求和应答算法相同。

```python
from functools import reduce
def checksum(body: bytes) -> str:      # body = "$" 和 "*" 之间的字节
    return "%02X" % reduce(lambda a, c: a ^ c, body, 0)
```

平台按字符串精确比较，`3c` 与 `3C` 不相等，必须大写。

### 心跳 `$HB...*HB`

平台在**空闲时**（没有在等应答时）收到以 `$HB` 开头的数据，会丢弃从开头到第一个 `*HB` 之间的内容，`*HB` 之后的字节继续当作下一帧处理。

- 帧内必须含 `*HB`，否则平台处理异常。
- `*HB` 之后不要再跟字节（包括 `\r\n`）。剩余不足 3 字节时平台会缓存，并拼在下一次收到的数据前，会破坏下一帧的开头判断。
- `$HB` 与 `*HB` 之间放什么，真实设备的心跳内容代码中未确定。自拟时可用 `$HB,<device_id>*HB`。
- 心跳只在平台空闲时被识别。平台正在等应答的 10 秒内如果收到 `$HB...`，会被当成应答去校验，失败后丢弃，对应那一轮数据丢失。所以心跳应在收到请求之后不要立即发，或在回完应答后再发。

## 物模型配置

示例（华思柔性测斜仪，3 个节点，`node_type=children`）物模型字段：`node0..node2`、`voltage0..2`、`temp0..2`、`accx0..2`、`accy0..2`、`accz0..2`、`locationx0..2`、`locationy0..2`、`locationz0..2`、`rotation_angle0..2`、`node_num`、`device_id`。

| 配置 | 位置 | 作用 |
|---|---|---|
| `device_id`（设备配置项，`[{"name":"device_id","type":"string","value":"817854"}]`） | 设备 `config` | 放进平台请求帧。虚拟设备的应答应使用同一个 device_id |
| 物模型 `name` | 产品 thing | 必须等于上表生成的标识（如 `voltage1`）。物模型里没有的标识，平台解析出来也会丢弃 |
| `type` | 产品 thing | `string` 不换算；`float` / `int` / `integer` 做换算 |
| `rate` / `offset` / `precision` | 产品 thing | 平台值 = 原始值 × rate + offset，再按 precision 取小数位（缺省 1 / 0 / 不取整）。设备发送的是原始值 |

注意：
- 报文里的节点数要和物模型对得上。物模型只定义了 3 个节点，设备发 4 个节点时第 4 个节点的值会被丢掉。
- 物模型 `thing` 为空时（如示例里的「海思全向位移计」产品），入库流程取不到物模型，数据不会正常保存，代码中未确定其行为。使用前确认产品物模型已配置。
- 本协议没有 `modbus` / `protocolConfig` 之类的配置影响编解码。

## 平台下发

本模块没有下发（写）功能。`p/in/{addr}` 收到的消息在网关进程里解析为 JSON 后被丢弃（`handle_message/2` 不做任何事）；子设备进程会转给网关，同样不处理。设备不需要应答任何控制指令。

## 报文示例

设备配置 `device_id=817854`，物模型含 `node0..1` 全套字段，`precision=2`，`rate=1`、`offset=0`。

平台请求（文本 `$HUASI,GET,DATA,817854*2B` 加真实 CRLF）：

```
2448554153492c4745542c444154412c3831373835342a32420d0a
```

设备应答（文本，结尾 `0D 0A` 为真实 CRLF）：

```
$HUASI,GET,DATA,817854,2,N01,3.30,25.50,0.01,0.02,0.98,1.5,2.5,3.5,45.0,N02,3.31,25.60,0.00,0.01,0.99,1.6,2.6,3.6,90.0*3C
```

十六进制（不含结尾 `0D 0A`）：

```
2448554153492c4745542c444154412c3831373835342c322c4e30312c332e33302c32352e35302c302e30312c302e30322c302e39382c312e352c322e352c332e352c34352e302c4e30322c332e33312c32352e36302c302e30302c302e30312c302e39392c312e362c322e362c332e362c39302e302a3343
```

校验：`$` 与 `*` 之间所有字节异或 = `0x3C`。

平台解析出的物模型值（按物模型 precision=2 取整后；没有 precision 的字段保留原值）：

| 标识 | 值 | 标识 | 值 |
|---|---|---|---|
| `device_id` | `817854` | `node_num` | `2` |
| `node0` | `N01` | `node1` | `N02` |
| `voltage0` | 3.30 | `voltage1` | 3.31 |
| `temp0` | 25.50 | `temp1` | 25.60 |
| `accx0` / `accy0` / `accz0` | 0.01 / 0.02 / 0.98 | `accx1` / `accy1` / `accz1` | 0.00 / 0.01 / 0.99 |
| `locationx0` / `locationy0` / `locationz0` | 1.5 / 2.5 / 3.5 | `locationx1` / `locationy1` / `locationz1` | 1.6 / 2.6 / 3.6 |
| `rotation_angle0` | 45.0 | `rotation_angle1` | 90.0 |

心跳示例：`$HB,817854*HB`（内容自拟，格式满足平台的 `$HB` 开头、含 `*HB`、之后无多余字节）。

## 写 driver 要点

| 项 | 取值 |
|---|---|
| `PROTOCOL` | `"rouxingcexie-huasi"`（模块文件名 `rouxingcexie_huasi.py`） |
| `TRANSPORT` | `"tcp"` |
| `MODE` | `"poll"`：设备只应答，不主动上报（`report()` 可不实现） |

需要实现 / 覆盖：

- `on_receive(data, topic=None)`：`data` 是累计缓冲区。按真实 `\r\n`（0D 0A，不是 `TEXT_CRLF` 那个 4 字符文本）切帧；对每一条以 `$HUASI,GET,DATA,` 开头的请求，取出 `*` 前的 device_id，回一帧应答，返回 `([应答bytes...], 剩余bytes)`。请求帧也带校验，建议先校验再应答，校验错就忽略。
- `heartbeat()`：返回 `ping` + `TEXT_CRLF`（默认）或 `$HB,<device_id>*HB` 均可被平台接受。如果用 `$HB`，末尾不要加任何字节。
- `login()`：用默认的即可。
- `UP_TOPIC`：不涉及（TCP）。

应答构造：

1. 从 `profile["points"]` 按标识取值：节点号 n（从 0 开始）对应 `node{n}`、`voltage{n}`、`temp{n}`、`accx{n}`、`accy{n}`、`accz{n}`、`locationx{n}`、`locationy{n}`、`locationz{n}`、`rotation_angle{n}`，顺序固定，每节点 10 个。
2. 浮点值转原始值：`raw = (显示值 - offset) / rate`，用 `"%.2f"` 之类**保证带小数点**的格式输出，不要让 Python 输出 `3`、`1e-05`。
3. `node_num` 取物模型里的节点数（或实际节点数）。`node{n}` 是字符串，不能含 `,` `*` `\r` `\n`。
4. 拼 `"$HUASI,GET,DATA,%s,%d,%s" % (device_id, node_num, ",".join(fields))`，加 `*`、2 位大写 hex 校验、真实 `\r\n`，**一次 send**。
5. device_id 优先用请求里带的值回显；请求的 device_id 为空时，应答是否回帧代码中未确定，建议不回。

容易出错的地方：

- 把应答的结尾写成 4 字符 `\\r\\n`：平台删的是真实 CRLF，4 字符文本会留在帧里，导致 `*` 之后多出内容，校验不通过。
- 校验写成小写，或把 `$`、`*` 也异或进去。
- 浮点值不带小数点，整帧被丢弃。
- 登录后立即等数据：第一条请求要等约 60 秒，不是登录即发。验证时要等够一轮。
- 一条连接上有多条请求时，必须逐条应答，次序与请求一致；不要主动连续发多帧应答。
- 网关场景下 device_id 要用配置里各子设备的值，虚拟设备应能为多个 device_id 应答。现有 `profile` 是否提供子设备列表，需要在 driver 里确认；没有时只能模拟单设备形态。
- 心跳不要在平台等应答的窗口内发。
