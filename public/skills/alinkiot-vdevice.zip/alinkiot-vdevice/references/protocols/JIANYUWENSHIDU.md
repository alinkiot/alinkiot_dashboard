# JIANYUWENSHIDU

| 项 | 内容 |
|---|---|
| 后端模块 | **代码中未找到处理模块** |
| 接入 | 代码中未确定。没有对应的协议模块，设备用 TCP 6500 登录会收到 `02`（协议未找到），用 MQTT 连接会被拒绝 |
| 上报方式 | 代码中未确定 |
| 登录与心跳 | 不适用 |
| 适用设备 | 库中产品「测试温湿度传感器」（id 116），温度、湿度、露点温度 |
| 虚拟设备 | 未内置，**无法依据代码写出接入方式** |

## 查证过程

- 在 `apps/`、配置文件、文档中搜索 `JIANYUWENSHIDU`、`jianyu`（不区分大小写），**没有任何匹配**（`_build/` 里也没有）。
- 在 `apps/alinkiot_core/src/protocol/` 下没有声明该协议的 `-protocol(...)` 属性，`alinkcore_protocol:get_mod/1` 返回 `undefined`。
- 仅在数据库字典 `sys_dict_data` 的 `iot_protocol_id` 类型里存在一项，标签「测试温湿度传感器」，值 `JIANYUWENSHIDU`。
- 产品 `config` 里有一项 `supportImport`（数据导入，开关 0/1，缺省 0）。后端只有 `alinkiot_import/src/alinkiot_vdg_import.erl` 注册了 `http.import.hnlg-vdg-protocol` 一个导入钩子，没有 `JIANYUWENSHIDU` 的导入钩子，所以该开关对应的导入处理，代码中未确定。
- 该项目 `git log` 里没有包含该名字的提交。

## 库里的物模型

| name | type | 说明 |
|---|---|---|
| `wendu` | float，precision 2，rate 1，unit °C，freq 5 | 温度 |
| `shidu` | float，precision 2，rate 1，unit %RH，freq 5 | 湿度 |
| `ludian` | float，precision 2，rate 1，unit °C，freq 5 | 露点温度 |

物模型里没有 `modbus` 字段，也没有帧结构信息，推不出任何报文格式。

## 要测试时可以怎么做

- 与对应后端同事确认该协议是已删除、尚未提交，还是由前端或外部服务写数据。
- 临时验证平台功能：建一个物模型相同的 `mqtt-json` 产品，上报 `wendu`、`shidu`、`ludian`，用现有的 `mqtt-json` driver。

## 写 driver 要点

无依据，不要写 driver。
