"""
协议 driver：每个产品协议一个模块，负责「把数值编码成报文」和「处理平台发来的报文」。
连接、登录、心跳、取值、运行循环由 vdevice.py 统一处理。

模块文件名 = 协议标识转小写、非字母数字换成下划线，例如：
    Modbus-RTU → modbus_rtu.py    mqtt-json → mqtt_json.py    hnlg-protocol → hnlg_protocol.py

模块需要定义：
    PROTOCOL  = "协议标识"          与产品的 protocol 字段一致
    TRANSPORT = "mqtt" 或 "tcp"     mqtt：连 1883，clientId uzy_{1|2}_{addr}；tcp：连 6500，先发 reg 登录
    MODE      = "push" 或 "poll"    push：设备按间隔主动上报；poll：平台轮询，设备只应答

    class Driver(BaseDriver):
        def report(self):            push 模式必需：返回一帧上报报文（bytes），None 表示本次不报
        def on_receive(self, data, topic=None):
            处理平台发来的数据，返回 (要回复的报文列表, 未处理完的剩余字节)。
            TCP 下 data 是累计的缓冲区，按协议自行分帧；MQTT 下 data 是一条完整消息的 payload。

可选：
    PORT = 10881                     TCP 协议使用独立端口时指定，默认 6500；设备描述里写了端口时以描述为准
        def login(self):             TCP 登录帧，默认 reg,{1|2},{addr},{key},{secret}\\r\\n；不需要登录时返回 None
        def heartbeat(self):         心跳帧，默认 TCP 发 ping\\r\\n，MQTT 用协议自带的 PINGREQ；返回 None 表示不发
        UP_TOPIC                     MQTT 上报 topic，默认 d/out/{addr}

各协议的报文格式见 references/protocols/<协议标识>.md。
"""
import importlib
import os
import re
import sys

TEXT_CRLF = b"\\r\\n"  # 4 个 ASCII 字符 \ r \ n，平台的 reg/ping 按文本匹配


def module_name(protocol):
    return re.sub(r"[^0-9a-z]+", "_", protocol.lower()).strip("_")


def load(protocol):
    """按协议标识加载 driver 模块，没有时返回 None"""
    name = module_name(protocol)
    if not os.path.isfile(os.path.join(os.path.dirname(__file__), name + ".py")):
        return None
    module = importlib.import_module("drivers." + name)
    for attr in ("PROTOCOL", "TRANSPORT", "MODE", "Driver"):
        if not hasattr(module, attr):
            sys.exit("错误：driver %s.py 缺少 %s" % (name, attr))
    return module


def available():
    here = os.path.dirname(__file__)
    found = []
    for f in sorted(os.listdir(here)):
        if f.endswith(".py") and not f.startswith("_") and f not in ("jsonmap.py",):
            try:
                found.append(importlib.import_module("drivers." + f[:-3]).PROTOCOL)
            except Exception:  # 写坏的 driver 不影响列出其它协议
                pass
    return found


class BaseDriver:
    UP_TOPIC = None

    def __init__(self, profile, values, log):
        self.profile = profile
        self.values = values
        self.log = log

    def login(self):
        auth = self.profile["auth"]
        return ("reg,%d,%s,%s,%s" % (auth["mode"], self.profile["addr"], auth["user"], auth["pass"])).encode() + TEXT_CRLF

    def heartbeat(self):
        return b"ping" + TEXT_CRLF if self.profile["transport"] == "tcp" else None

    def report(self):
        return None

    def on_receive(self, data, topic=None):
        if data:
            self.log("收到下发 %s" % data.decode("utf-8", "replace"))
        return [], b""
