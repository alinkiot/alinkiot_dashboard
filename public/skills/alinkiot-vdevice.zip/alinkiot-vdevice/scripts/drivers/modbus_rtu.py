"""
Modbus-RTU：TCP 透传接入，平台作为主站按物模型轮询，设备作为从机应答。说明见 references/protocols/Modbus-RTU.md

请求帧固定 8 字节：从机号 功能码 起始地址(2) 数量或写入值(2) CRC(2，低字节在前)
"""
import struct

from drivers import BaseDriver

PROTOCOL = "Modbus-RTU"
TRANSPORT = "tcp"
MODE = "poll"


def crc16(data):
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return struct.pack("<H", crc)


def hex_int(v, default=0):
    if v in (None, ""):
        return default
    return int(str(v), 16)


def swap_words(data):
    """big2 / little2：每个寄存器内高低字节互换"""
    return b"".join(data[i + 1:i + 2] + data[i:i + 1] for i in range(0, len(data), 2))


def encode(point, raw, nbytes):
    """按物模型的 type、signed、endianness 把原始值编码成寄存器字节，与平台 alinkiot_utils:format_value 互逆"""
    m = point.get("modbus", {})
    signed = m.get("signed", "signed") == "signed"
    endian = m.get("endianness", "little")  # 平台缺省按 little 解码
    order = "big" if endian.startswith("big") else "little"
    if point["type"] == "string":
        data = str(raw).encode("utf-8")[:nbytes].ljust(nbytes, b"\x00")
    elif point["type"] == "float" and nbytes in (2, 4, 8):
        fmt = {2: "e", 4: "f", 8: "d"}[nbytes]
        data = struct.pack((">" if order == "big" else "<") + fmt, float(raw))
    else:
        bits = nbytes * 8
        lo, hi = (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if signed else (0, (1 << bits) - 1)
        data = max(lo, min(hi, int(round(float(raw))))).to_bytes(nbytes, order, signed=signed)
    if endian.endswith("2") and nbytes >= 2:
        data = swap_words(data)
    return data


def decode(point, data):
    m = point.get("modbus", {})
    endian = m.get("endianness", "little")
    if endian.endswith("2") and len(data) >= 2:
        data = swap_words(data)
    order = "big" if endian.startswith("big") else "little"
    return int.from_bytes(data, order, signed=m.get("signed", "signed") == "signed")


class Driver(BaseDriver):
    def __init__(self, profile, values, log):
        super().__init__(profile, values, log)
        self.points = [p for p in profile["points"] if p.get("modbus")]

    def find(self, slave, start, fn, qty=None, write=False):
        for p in self.points:
            m = p["modbus"]
            if hex_int(m.get("slaveId"), 1) != slave or hex_int(m.get("start")) != start:
                continue
            if write:
                if hex_int(m.get("wFunCode"), fn) == fn:
                    return p
            elif hex_int(m.get("rFunCode"), fn) == fn and int(m.get("quantity", qty)) == qty:
                return p
        return None

    def on_receive(self, data, topic=None):
        replies = []
        while len(data) >= 8:
            frame = data[:8]
            if crc16(frame[:6]) != frame[6:8]:
                data = data[1:]  # 不是完整的请求帧，滑动一个字节重新对齐
                continue
            data = data[8:]
            reply, note = self.answer(frame)
            self.log("收到 %s" % frame.hex(" ").upper())
            self.log("应答 %s  %s" % (reply.hex(" ").upper(), note))
            replies.append(reply)
        return replies, data

    def answer(self, frame):
        slave, fn, start, arg = struct.unpack("!BBHH", frame[:6])
        if fn in (3, 4):  # 读保持寄存器 / 输入寄存器
            p = self.find(slave, start, fn, arg)
            nbytes = arg * 2
            if p:
                raw = self.values.raw(p["name"])
                data, note = encode(p, raw, nbytes), "%s=%s" % (p["name"], raw)
            else:
                data, note = b"\x00" * nbytes, "物模型里没有该寄存器，应答 0"
            body = struct.pack("!BBB", slave, fn, nbytes) + data
            return body + crc16(body), note
        if fn in (1, 2):  # 读线圈 / 离散输入
            p = self.find(slave, start, fn, arg)
            nbytes = (arg + 7) // 8
            bit = 1 if p and float(self.values.raw(p["name"])) else 0
            body = struct.pack("!BBB", slave, fn, nbytes) + bytes([bit]) + b"\x00" * (nbytes - 1)
            return body + crc16(body), ("%s=%s" % (p["name"], bit)) if p else "物模型里没有该线圈，应答 0"
        if fn in (5, 6):  # 写单个线圈 / 寄存器：原样回显
            p = self.find(slave, start, fn, write=True)
            if p:
                raw = (1 if arg == 0xFF00 else 0) if fn == 5 else decode(p, frame[4:6])
                note = "写入 %s = %s，之后固定输出该值" % (p["name"], self.values.written(p["name"], raw))
            else:
                note = "物模型里没有该寄存器，只回显"
            return frame, note
        body = struct.pack("!BB", slave, fn | 0x80) + b"\x01"
        return body + crc16(body), "不支持功能码 %02X，返回异常应答" % fn
