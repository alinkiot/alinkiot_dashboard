"""mqtt-json：MQTT 接入，按协议转换配置生成原始 JSON，发布到 d/out/{addr}。说明见 references/protocols/mqtt-json.md"""
import json

from drivers import BaseDriver, jsonmap

PROTOCOL = "mqtt-json"
TRANSPORT = "mqtt"
MODE = "push"


class Driver(BaseDriver):
    def report(self):
        payload = json.dumps(jsonmap.build(self.profile, self.values, self.log), ensure_ascii=False)
        return payload.encode("utf-8")

    def on_receive(self, data, topic=None):
        text = data.decode("utf-8", "replace")
        self.log("收到下发 %s %s" % (topic, text))
        if jsonmap.handle_command(text, self.values, self.log):
            return [self.report()], b""
        return [], b""
