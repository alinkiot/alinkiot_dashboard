"""
JSON 类协议（mqtt-json、tcp-json）共用：按产品「协议转换」（protocolConfig）反推设备的原始报文。

平台收到原始 JSON 后，按转换定义把它转成物模型字段：
    {"temperature": {"value": "#Temperature 1", "ts": {"ref": "${CURRENT_TIME}"}}}
表示物模型字段 temperature 取原始报文里的 "Temperature 1"。路径用 / 分级，items/N 表示数组第 N 个（从 1 开始）。
这里反过来：对每个物模型字段，取到 #路径，把当前值写到原始报文的对应位置。
带正则（re）的定义无法反推，改用虚拟设备配置里的 payloadTemplate 手写报文。
"""
import json


def ref_path(define):
    """取转换定义里的 #路径；正则等无法反推的定义返回 None"""
    if isinstance(define, str):
        return define[1:] if define.startswith("#") else None
    if isinstance(define, dict):
        if "re" in define:
            return None
        for key in ("value", "ref"):
            if key in define:
                found = ref_path(define[key])
                if found:
                    return found
    return None


def set_path(cur, parts, value):
    key = parts[0]
    if key == "items" and len(parts) > 1 and parts[1].isdigit() and isinstance(cur, list):
        idx = int(parts[1]) - 1
        while len(cur) <= idx:
            cur.append({})
        rest = parts[2:]
        if not rest:
            cur[idx] = value
            return
        want_list = rest[0] == "items"
        if not isinstance(cur[idx], list if want_list else dict):
            cur[idx] = [] if want_list else {}
        set_path(cur[idx], rest, value)
        return
    if len(parts) == 1:
        cur[key] = value
        return
    want_list = parts[1] == "items"
    if not isinstance(cur.get(key), list if want_list else dict):
        cur[key] = [] if want_list else {}
    set_path(cur[key], parts[1:], value)


def fill_template(node, values):
    """payloadTemplate：字符串 "{{数据点名}}" 替换为当前原始值"""
    if isinstance(node, dict):
        return {k: fill_template(v, values) for k, v in node.items()}
    if isinstance(node, list):
        return [fill_template(v, values) for v in node]
    if isinstance(node, str) and node.startswith("{{") and node.endswith("}}"):
        name = node[2:-2].strip()
        if name in values.points:
            return values.raw(name)
    return node


def build(profile, values, log):
    template = profile.get("payloadTemplate")
    if template:
        return fill_template(template, values)
    names = {p["name"] for p in profile["points"]}
    raw, skipped = {}, []
    for key, define in (profile.get("transform") or {}).items():
        if key not in names:
            continue
        path = ref_path(define)
        if path:
            set_path(raw, path.split("/"), values.raw(key))
        else:
            skipped.append(key)
    if skipped and not profile.get("_warned"):
        profile["_warned"] = True
        log("提示：这些数据点的协议转换无法自动反推（如带正则），未上报，可改用 payloadTemplate：%s" % "、".join(skipped))
    return raw


def handle_command(payload, values, log):
    """平台下发的物模型写指令 {"type":"write","name":..,"value":..}：之后固定输出写入的值。返回是否需要立即上报"""
    try:
        msg = json.loads(payload)
    except ValueError:
        return False
    if isinstance(msg, dict) and msg.get("type") == "write" and msg.get("name"):
        shown = values.written(msg["name"], msg.get("value"))
        if shown is None:
            log("物模型里没有数据点 %s，忽略" % msg["name"])
            return False
        log("写入 %s = %s，之后固定输出该值" % (msg["name"], shown))
        return True
    return False
