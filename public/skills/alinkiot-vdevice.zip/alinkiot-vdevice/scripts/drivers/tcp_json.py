"""tcp-json：TCP 接入，reg 登录后按协议转换配置发送 JSON，每条以回车换行（0D 0A）结尾。说明见 references/protocols/tcp-json.md"""
import json

from drivers import BaseDriver, jsonmap

PROTOCOL = "tcp-json"
TRANSPORT = "tcp"
MODE = "push"


class Driver(BaseDriver):
    def report(self):
        payload = json.dumps(jsonmap.build(self.profile, self.values, self.log), ensure_ascii=False)
        return payload.encode("utf-8") + b"\r\n"

    def on_receive(self, data, topic=None):
        # 平台当前不向 tcp-json 设备下发写指令（tcp_json_server 收到 write 不发送），这里只打印
        if data:
            self.log("收到下发 %s" % data.decode("utf-8", "replace"))
        return [], b""
