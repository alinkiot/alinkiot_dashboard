#!/usr/bin/env python3
"""
ALinkIOT 虚拟设备：按平台上的产品物模型和设备凭证，模拟一台设备接入平台并上报数据。

只依赖 Python 3.8+ 标准库。连接、登录、心跳、取值、运行循环在本文件；
每个产品协议的报文编码和应答在 drivers/<协议>.py，协议说明在 references/protocols/<协议标识>.md。

子命令：
    init       从平台拉取设备和产品，生成虚拟设备配置 devices/{addr}.json
    show       查看虚拟设备的数据点及取值方式
    set        修改某个数据点的取值方式（固定值 / 随机 / 游走 / 正弦）
    run        连接平台开始模拟，打印收发的每一帧，Ctrl+C 停止
    check      通过平台接口查询设备在线状态和最新数据，验证模拟是否生效
    protocols  列出已有 driver 的协议

平台地址和应用凭证从 skill 目录下的 env.ini 读取（host、appId、Secret），见 env.ini.example。
"""
import argparse
import base64
import json
import math
import os
import random
import select
import socket
import ssl
import struct
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import drivers  # noqa: E402
import monitor as monitor_mod  # noqa: E402

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_INI = os.path.join(SKILL_DIR, "env.ini")
DEVICES_DIR = os.path.join(SKILL_DIR, "devices")
PROTOCOL_DOCS = os.path.join(SKILL_DIR, "references", "protocols")

DEFAULT_PORTS = {"mqtt": 1883, "mqtts": 8883, "tcp": 6500}
MODES = ("walk", "random", "sine", "fixed")
TCP_LOGIN_ERRORS = {b"01": "认证失败（设备或密钥不对）", b"02": "产品协议未找到", b"99": "其他错误"}
MQTT_CONNACK_ERRORS = {
    1: "协议版本不支持", 2: "clientId 不合法", 3: "服务不可用",
    4: "用户名或密码错误（设备或密钥不对，或产品缺少协议转换配置）", 5: "未授权",
}


MONITOR = None  # run 时的本地监控页，日志同时推送到页面


class LoginError(Exception):
    """平台拒绝登录：凭证或产品配置有问题，重连也没用"""


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)
    if MONITOR:
        MONITOR.event(msg)


def die(msg):
    print("错误：" + msg, file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------- env.ini

def load_env(required=True):
    cfg = {}
    if os.path.isfile(ENV_INI):
        with open(ENV_INI, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line[0] in "#;[" or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                cfg[k.strip().lower()] = v.strip().strip('"').strip("'")
    host = cfg.get("host") or os.environ.get("UZYIOT_BASE_URL")
    if not host:
        if required:
            die("这个命令要用应用凭证访问平台接口：在 %s 里写 host、appId、Secret" % ENV_INI)
        host = "https://localhost"
    if not host.startswith(("http://", "https://")):
        host = "https://" + host
    return {
        "base": host.rstrip("/"),
        "appId": cfg.get("appid") or cfg.get("app_id"),
        "secret": cfg.get("secret") or cfg.get("appsecret") or cfg.get("app_secret"),
        "mqttPort": cfg.get("mqttport"),
        "tcpPort": cfg.get("tcpport"),
        "mqttTls": cfg.get("mqtttls", "").lower() in ("1", "true", "yes"),
        "insecure": cfg.get("insecure", "").lower() in ("1", "true", "yes"),
    }


# ---------------------------------------------------------------- 平台接口

class Api:
    def __init__(self, env):
        self.env = env
        self.token = None
        self.ctx = None
        if env["insecure"]:
            self.ctx = ssl._create_unverified_context()

    def request(self, method, path, params=None, body=None, auth=True):
        url = self.env["base"] + path
        if params:
            url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["token"] = self.login()
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20, context=self.ctx) as resp:
                text = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            die("%s %s 返回 HTTP %s：%s" % (method, path, e.code, e.read().decode("utf-8", "replace")[:300]))
        except urllib.error.URLError as e:
            die("连接平台失败 %s：%s" % (url, e.reason))
        resp = json.loads(text)
        if isinstance(resp, dict) and resp.get("code") not in (None, 200):
            die("%s %s 失败：%s" % (method, path, resp.get("msg") or resp))
        return resp

    def login(self):
        if self.token:
            return self.token
        if not self.env["appId"] or not self.env["secret"]:
            die("env.ini 缺少 appId 或 Secret")
        resp = self.request("POST", "/iotapi/system/user/app/login",
                            body={"appId": self.env["appId"], "appSecret": self.env["secret"]}, auth=False)
        self.token = resp.get("token") or (resp.get("data") or {}).get("token")
        if not self.token:
            die("登录没有返回 token：%s" % resp)
        return self.token

    def device(self, device_id=None, addr=None):
        if device_id:
            data = self.request("GET", "/iotapi/system/device/%s" % device_id).get("data")
            if isinstance(data, list):
                data = data[0] if data else None
            if not data:
                die("找不到设备 ID %s（或不在该应用所属项目内）" % device_id)
            return data
        rows = self.request("GET", "/iotapi/system/device/list",
                            params={"addr": addr, "pageNum": 1, "pageSize": 10}).get("rows") or []
        rows = [r for r in rows if r.get("addr") == addr]
        if not rows:
            die("找不到设备地址 %s（或不在该应用所属项目内）" % addr)
        return rows[0]

    def product(self, product_id):
        data = self.request("GET", "/iotapi/system/product/%s" % product_id).get("data")
        if isinstance(data, list):
            data = data[0] if data else None
        if not data:
            die("找不到产品 %s" % product_id)
        return data


# ---------------------------------------------------------------- 虚拟设备配置

def json_field(value, default):
    if value in (None, ""):
        return default
    if isinstance(value, str):
        try:
            return json.loads(value)
        except ValueError:
            return default
    return value


def load_transform(product):
    """产品扩展配置里的 protocolConfig：base64 编码的「报文 → 标准 JSON」转换定义"""
    config = json_field(product.get("config"), [])
    items = config if isinstance(config, list) else [{"name": k, "value": v} for k, v in config.items()]
    for item in items:
        if isinstance(item, dict) and item.get("name") == "protocolConfig" and item.get("value"):
            try:
                return json.loads(base64.b64decode(str(item["value"]).strip()))
            except (ValueError, TypeError):
                die("产品的协议转换配置（protocolConfig）不是合法的 base64 JSON")
    return None


def build_point(thing, mode):
    lo, hi = thing.get("min"), thing.get("max")
    lo = float(lo) if lo not in (None, "") else 0.0
    hi = float(hi) if hi not in (None, "") else 100.0
    if hi < lo:
        lo, hi = hi, lo
    point = {
        "name": thing["name"],
        "title": thing.get("title", thing["name"]),
        "type": thing.get("type", "float"),
        "unit": thing.get("unit", ""),
        "access": thing.get("access", "read"),
        "min": lo,
        "max": hi,
        "rate": thing.get("rate", 1) or 1,
        "offset": thing.get("offset", 0) or 0,
        "precision": thing.get("precision"),
        "mode": "fixed" if thing.get("type") == "string" else mode,
    }
    if thing.get("type") == "string":
        point["value"] = ""
    # 协议相关的配置（如 modbus 寄存器）原样保留，由 driver 使用
    for key, value in thing.items():
        if isinstance(value, dict) and key not in point:
            point[key] = value
    return point


def profile_path(name):
    if os.path.isfile(name):
        return name
    path = os.path.join(DEVICES_DIR, name if name.endswith(".json") else name + ".json")
    if not os.path.isfile(path):
        die("没有虚拟设备配置 %s，先执行 init" % path)
    return path


def load_profile(name):
    path = profile_path(name)
    with open(path, encoding="utf-8") as f:
        return path, json.load(f)


def save_profile(path, profile):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    os.chmod(path, 0o600)  # 含设备密钥


def protocol_doc(protocol):
    path = os.path.join(PROTOCOL_DOCS, protocol + ".md")
    return path if os.path.isfile(path) else None


AUTH_DESC = {1: "一机一证（设备 dk/ds）", 2: "一型一密（产品 pk/ps）"}


def build_profile(device, product, connect, auth, args):
    """按设备、产品、连接方式和登录凭证生成虚拟设备配置"""
    protocol = product.get("protocol") or ""
    driver = drivers.load(protocol)
    if driver is None:
        doc = protocol_doc(protocol)
        log("提示：协议 %s 还没有 driver。%s，按说明写 scripts/drivers/%s.py 后再 run" % (
            protocol, "说明见 " + doc if doc else "references/protocols/ 下也没有它的说明",
            drivers.module_name(protocol)))
    elif driver.TRANSPORT != connect["transport"]:
        log("提示：协议 %s 只支持 %s 接入，已改用 %s" % (protocol, driver.TRANSPORT.upper(), driver.TRANSPORT.upper()))
        connect = dict(connect, transport=driver.TRANSPORT, tls=False)
    if product.get("nodeType") == "gateway":
        log("提示：该产品是网关，虚拟设备只模拟网关自身，不模拟子设备")

    transform = load_transform(product)
    if protocol in ("mqtt-json", "tcp-json") and not transform:
        die("产品「%s」没有配置协议转换（扩展配置 protocolConfig），平台会拒绝该设备接入。"
            "先在产品管理里配置协议转换，再重新 init" % product.get("name"))

    things = [t for t in json_field(product.get("thing"), []) if isinstance(t, dict) and t.get("name")]
    points = [build_point(t, args.mode) for t in things]
    freqs = [int(t.get("freq") or 0) for t in things if t.get("freq")]
    # 端口：设备描述里写了就用它；否则用协议的独立端口（driver.PORT）或默认端口
    ports = {"mqtt": DEFAULT_PORTS["mqtts" if connect.get("tls") else "mqtt"],
             "tcp": getattr(driver, "PORT", None) or DEFAULT_PORTS["tcp"]}
    if connect.get("port"):
        ports[connect["transport"]] = int(connect["port"])
    return {
        "addr": device["addr"],
        "deviceId": device.get("id"),
        "deviceName": device.get("name"),
        "productId": product.get("id"),
        "productName": product.get("name"),
        "protocol": protocol,
        "transport": connect["transport"],
        "host": connect["host"],
        "ports": ports,
        "tls": bool(connect.get("tls")),
        "auth": dict(auth, desc=AUTH_DESC.get(auth["mode"], "")),
        "interval": args.interval or (min(freqs) if freqs else 30),
        "productConfig": json_field(product.get("config"), []),
        "transform": transform,
        "payloadTemplate": None,
        "points": points,
    }


def init_from_json(path):
    """平台「虚拟设备」页面生成的设备描述：设备、产品（含物模型和扩展配置）、连接方式、登录凭证"""
    try:
        with open(path, encoding="utf-8") if path != "-" else sys.stdin as f:
            desc = json.load(f)
    except (OSError, ValueError) as e:
        die("读取设备描述失败：%s" % e)
    for key in ("device", "product", "connect", "auth"):
        if not isinstance(desc.get(key), dict):
            die("设备描述缺少 %s" % key)
    auth = desc["auth"]
    if auth.get("mode") not in (1, 2) or not auth.get("user") or not auth.get("pass"):
        die("设备描述的 auth 需要 mode（1 一机一证 / 2 一型一密）、user、pass")
    if not desc["connect"].get("host") or desc["connect"].get("transport") not in ("mqtt", "tcp"):
        die("设备描述的 connect 需要 transport（mqtt / tcp）和 host")
    return desc["device"], desc["product"], desc["connect"], auth


def init_from_api(args):
    """用 env.ini 的应用凭证从平台拉取设备和产品"""
    env = load_env()
    api = Api(env)
    device = api.device(args.device_id, args.addr)
    product = api.product(device["product"])
    if device.get("dk") and device.get("ds"):
        auth = {"mode": 1, "user": device["dk"], "pass": device["ds"]}
    elif product.get("pk") and product.get("ps"):
        auth = {"mode": 2, "user": product["pk"], "pass": product["ps"]}
    else:
        die("设备没有 dk/ds，产品也没有 pk/ps，无法接入")
    driver = drivers.load(product.get("protocol") or "")
    transport = driver.TRANSPORT if driver else "tcp"
    tls = env["mqttTls"] or env["mqttPort"] == "8883"
    port = env["mqttPort"] if transport == "mqtt" else env["tcpPort"]
    connect = {"transport": transport, "host": urllib.parse.urlparse(env["base"]).hostname,
               "port": port, "tls": tls and transport == "mqtt"}
    return device, product, connect, auth


def cmd_init(args):
    if args.from_json:
        device, product, connect, auth = init_from_json(args.from_json)
    else:
        device, product, connect, auth = init_from_api(args)
    profile = build_profile(device, product, connect, auth, args)
    path = os.path.join(DEVICES_DIR, device["addr"] + ".json")
    save_profile(path, profile)
    log("已生成 %s" % path)
    print_profile(profile)


def print_profile(profile):
    driver = drivers.load(profile["protocol"])
    print("设备：%s（%s），产品：%s，协议：%s" % (
        profile.get("deviceName"), profile["addr"], profile.get("productName"), profile["protocol"]))
    if driver:
        transport = driver.TRANSPORT
        print("接入：%s://%s:%s，%s" % (transport + ("s" if transport == "mqtt" and profile.get("tls") else ""),
                                     profile["host"], profile["ports"][transport], profile["auth"]["desc"]))
        print("上报：%s" % ("平台轮询，虚拟设备应答" if driver.MODE == "poll" else "每 %s 秒主动上报" % profile["interval"]))
    else:
        print("接入：还没有 driver，见 references/protocols/%s.md" % profile["protocol"])
    print("数据点：")
    for p in profile["points"]:
        how = {"fixed": "固定 %s" % p.get("value"), "random": "随机", "walk": "游走", "sine": "正弦"}[p["mode"]]
        extra = ""
        if p.get("modbus"):
            m = p["modbus"]
            extra = "  modbus 从机 %s 功能码 %s 起始 %s 数量 %s" % (
                m.get("slaveId", "01"), m.get("rFunCode"), m.get("start"), m.get("quantity"))
        print("  %-16s %-10s %-8s [%g, %g] %s%s%s" % (
            p["name"], p["title"], p["type"], p["min"], p["max"], p.get("unit") or "", "  " + how, extra))


def cmd_show(args):
    _, profile = load_profile(args.device)
    print_profile(profile)


def cmd_set(args):
    path, profile = load_profile(args.device)
    targets = [p for p in profile["points"] if args.name in (p["name"], "*")]
    if not targets:
        die("没有数据点 %s，可用：%s" % (args.name, "、".join(p["name"] for p in profile["points"])))
    for p in targets:
        if args.value is not None:
            p["mode"] = "fixed"
            p["value"] = args.value if p["type"] == "string" else float(args.value)
        if args.mode:
            p["mode"] = args.mode
            if args.mode == "fixed" and "value" not in p:
                p["value"] = (p["min"] + p["max"]) / 2
        if args.min is not None:
            p["min"] = args.min
        if args.max is not None:
            p["max"] = args.max
        if args.period is not None:
            p["period"] = args.period
    if args.interval:
        profile["interval"] = args.interval
    save_profile(path, profile)
    print_profile(profile)


# ---------------------------------------------------------------- 取值

class Values:
    """按数据点的取值方式生成工程值（平台显示的值）"""

    def __init__(self, points):
        self.points = {p["name"]: p for p in points}
        self.state = {}
        self.start = time.time()

    def next(self, name):
        p = self.points[name]
        lo, hi = p["min"], p["max"]
        mode = p["mode"]
        if mode == "fixed":
            v = p.get("value", lo)
            if p["type"] == "string":
                return v
        elif mode == "random":
            v = random.uniform(lo, hi)
        elif mode == "sine":
            period = p.get("period", 600)
            v = (lo + hi) / 2 + (hi - lo) / 2 * math.sin(2 * math.pi * (time.time() - self.start) / period)
        else:  # walk：在区间内小步游走，曲线比纯随机更像真实数据
            prev = self.state.get(name, (lo + hi) / 2)
            v = min(hi, max(lo, prev + random.gauss(0, (hi - lo) * 0.03 or 1)))
        self.state[name] = v
        if p["type"] in ("integer", "int"):
            return int(round(v))
        if isinstance(p.get("precision"), int):
            return round(v, p["precision"])
        return v

    def raw(self, name, value=None):
        """平台收到值后按 值 × rate + offset 换算，这里反推设备应发送的原始值"""
        p = self.points[name]
        v = self.next(name) if value is None else value
        if p["type"] == "string":
            raw = v
        else:
            raw = (float(v) - float(p["offset"])) / float(p["rate"])
            raw = int(round(raw)) if p["type"] in ("integer", "int") else raw
        if MONITOR:
            MONITOR.record(name, v, raw)
        return raw

    def written(self, name, raw):
        """平台下发写入原始值后，改为固定输出该值"""
        p = self.points.get(name)
        if not p:
            return None
        if p["type"] == "string":
            p["value"] = raw
        else:
            p["value"] = float(raw) * float(p["rate"]) + float(p["offset"])
            if p["type"] in ("integer", "int") and p["value"] == int(p["value"]):
                p["value"] = int(p["value"])
        p["mode"] = "fixed"
        if MONITOR:
            MONITOR.record(name, p["value"], raw)
        return p["value"]


# ---------------------------------------------------------------- MQTT 3.1.1（QoS 0）

def mqtt_str(s):
    b = s.encode("utf-8") if isinstance(s, str) else s
    return struct.pack("!H", len(b)) + b


def mqtt_len(n):
    out = bytearray()
    while True:
        byte, n = n % 128, n // 128
        out.append(byte | (0x80 if n else 0))
        if not n:
            return bytes(out)


class Mqtt:
    def __init__(self, host, port, tls, insecure):
        sock = socket.create_connection((host, port), timeout=15)
        if tls:
            ctx = ssl._create_unverified_context() if insecure else ssl.create_default_context()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        self.sock = sock
        self.buf = b""

    def send(self, header, body):
        self.sock.sendall(bytes([header]) + mqtt_len(len(body)) + body)

    def connect(self, client_id, user, password, keepalive):
        body = mqtt_str("MQTT") + b"\x04\xc2" + struct.pack("!H", keepalive)
        body += mqtt_str(client_id) + mqtt_str(user) + mqtt_str(password)
        self.send(0x10, body)
        packet = self.read(15)
        if not packet:
            raise ConnectionError("平台没有响应 CONNACK 就断开了")
        header, data = packet
        if header >> 4 != 2:
            raise ConnectionError("期望 CONNACK，收到报文类型 %d" % (header >> 4))
        if data[1] != 0:
            raise LoginError("连接被拒绝：%s" % MQTT_CONNACK_ERRORS.get(data[1], data[1]))

    def subscribe(self, topic):
        self.send(0x82, struct.pack("!H", 1) + mqtt_str(topic) + b"\x00")

    def publish(self, topic, payload):
        self.send(0x30, mqtt_str(topic) + payload)

    def ping(self):
        self.send(0xC0, b"")

    def recv(self, timeout):
        self.sock.settimeout(timeout)
        try:
            chunk = self.sock.recv(65536)
        except socket.timeout:
            return False
        if not chunk:
            raise ConnectionError("平台断开了连接")
        self.buf += chunk
        return True

    def take(self):
        """从缓冲区取一个完整报文，不完整返回 None"""
        if len(self.buf) < 2:
            return None
        mult, length, i = 1, 0, 1
        while True:
            if i >= len(self.buf):
                return None
            byte = self.buf[i]
            length += (byte & 0x7F) * mult
            mult *= 128
            i += 1
            if not byte & 0x80:
                break
        if len(self.buf) < i + length:
            return None
        header, data = self.buf[0], self.buf[i:i + length]
        self.buf = self.buf[i + length:]
        return header, data

    def read(self, timeout):
        deadline = time.time() + timeout
        while True:
            packet = self.take()
            if packet:
                return packet
            left = deadline - time.time()
            if left <= 0 or not self.recv(left):
                return None


# ---------------------------------------------------------------- 连接

class MqttLink:
    """MQTT 接入：clientId uzy_{1|2}_{addr}，订阅 d/in/{addr}，上报到 driver.UP_TOPIC 或 d/out/{addr}"""

    def __init__(self, profile, driver_mod, env):
        addr, auth = profile["addr"], profile["auth"]
        port = profile["ports"]["mqtt"]
        client_id = "uzy_%d_%s" % (auth["mode"], addr)
        log("连接 MQTT %s:%s，clientId=%s" % (profile["host"], port, client_id))
        self.conn = Mqtt(profile["host"], port, profile.get("tls"), env["insecure"])
        self.keepalive = 60
        self.conn.connect(client_id, auth["user"], auth["pass"], self.keepalive)
        self.conn.subscribe("d/in/" + addr)
        self.topic = getattr(driver_mod.Driver, "UP_TOPIC", None) or "d/out/" + addr
        self.heartbeat_every = self.keepalive / 2

    def send(self, frame):
        self.conn.publish(self.topic, frame)
        return self.topic

    def heartbeat(self, frame):
        if frame:
            self.conn.publish(self.topic, frame)
        else:
            self.conn.ping()

    def receive(self, timeout, driver):
        """返回 driver 产生的回复报文"""
        replies = []
        packet = self.conn.read(timeout)
        while packet:
            header, data = packet
            if header >> 4 == 3:  # PUBLISH：平台下发
                qos = (header >> 1) & 0x03
                tlen = struct.unpack("!H", data[:2])[0]
                topic = data[2:2 + tlen].decode("utf-8", "replace")
                pos = 2 + tlen
                if qos:
                    self.conn.send(0x40, data[pos:pos + 2])  # PUBACK
                    pos += 2
                out, _ = driver.on_receive(data[pos:], topic)
                replies.extend(out)
            packet = self.conn.take()
        return replies


class TcpLink:
    """TCP 透传接入：连接后先发 driver.login()，登录失败时平台返回错误码并断开"""

    def __init__(self, profile, driver):
        port = profile["ports"]["tcp"]
        log("连接 TCP %s:%s" % (profile["host"], port))
        self.sock = socket.create_connection((profile["host"], port), timeout=15)
        self.buf = b""
        self.heartbeat_every = 30
        login = driver.login()
        if login:
            self.sock.sendall(login)
            secret = profile["auth"]["pass"]
            log("发送登录 %s" % login.decode("utf-8", "replace").replace(secret, "***"))
        ready, _, _ = select.select([self.sock], [], [], 2)
        if ready:
            data = self.sock.recv(64)
            if not data or data[:2] in TCP_LOGIN_ERRORS:
                raise LoginError("登录失败：%s" % TCP_LOGIN_ERRORS.get(data[:2], "连接被平台关闭"))
            self.buf = data

    def send(self, frame):
        self.sock.sendall(frame)
        return "TCP"

    def heartbeat(self, frame):
        if frame:
            self.sock.sendall(frame)

    def receive(self, timeout, driver):
        ready, _, _ = select.select([self.sock], [], [], timeout)
        if ready:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("平台断开了连接")
            self.buf += chunk
        if not self.buf:
            return []
        replies, self.buf = driver.on_receive(self.buf)
        return replies


def show_frame(frame):
    try:
        text = frame.decode("utf-8")
        if text.isprintable() or text.rstrip("\r\n").isprintable():
            return text.rstrip("\r\n")
    except UnicodeDecodeError:
        pass
    return frame.hex(" ").upper()


class Runner:
    """运行一次连接；断线后由 cmd_run 决定是否重连。上报次数、截止时间跨重连保留"""

    def __init__(self, profile, driver_mod, args, env):
        self.profile = profile
        self.driver_mod = driver_mod
        self.args = args
        self.env = env
        self.values = Values(profile["points"])  # 页面上的修改跨重连保留
        self.push = driver_mod.MODE == "push"
        self.deadline = time.time() + args.duration if args.duration else None
        self.count = 0

    def finished(self):
        if self.deadline and time.time() >= self.deadline:
            log("达到运行时长，停止")
            return True
        if self.args.count and self.count >= self.args.count:
            time.sleep(1)  # 等平台处理完再断开
            log("已%s %d 次，停止" % ("上报" if self.push else "应答", self.count))
            return True
        return False

    def counted(self):
        self.count += 1
        if MONITOR:
            MONITOR.count("reports" if self.push else "replies")

    def run_once(self):
        driver = self.driver_mod.Driver(self.profile, self.values, log)
        if self.driver_mod.TRANSPORT == "mqtt":
            link = MqttLink(self.profile, self.driver_mod, self.env)
        else:
            link = TcpLink(self.profile, driver)
        log("已登录，平台应显示设备在线")
        if MONITOR:
            MONITOR.set_status(connected=True, since=time.time(), error="")
        interval = self.args.interval or self.profile["interval"]
        if not self.push:
            log("等待平台轮询（轮询周期由物模型的 freq 决定）")
        next_report = time.time() if self.push else None
        next_beat = time.time() + link.heartbeat_every
        while not self.finished():
            now = time.time()
            if self.push and (now >= next_report or (MONITOR and MONITOR.take_report_request())):
                frame = driver.report()
                if frame:
                    log("上报 %s %s" % (link.send(frame), show_frame(frame)))
                    self.counted()
                next_report = now + interval
            if now >= next_beat:
                link.heartbeat(driver.heartbeat())
                next_beat = now + link.heartbeat_every
            waits = [next_beat - now, 0.5] + ([next_report - now] if self.push else [])
            if self.deadline:
                waits.append(self.deadline - now)
            for reply in link.receive(max(0.05, min(waits)), driver):
                where = link.send(reply)
                if self.push:
                    log("上报 %s %s" % (where, show_frame(reply)))
                self.counted()


# ---------------------------------------------------------------- run / check

def cmd_run(args):
    global MONITOR
    env = load_env(required=False)
    path, profile = load_profile(args.device)
    driver_mod = drivers.load(profile["protocol"])
    if driver_mod is None:
        doc = protocol_doc(profile["protocol"])
        die("协议 %s 还没有 driver：%s，按说明写 scripts/drivers/%s.py" % (
            profile["protocol"], "说明见 " + doc if doc else "references/protocols/ 下没有它的说明",
            drivers.module_name(profile["protocol"])))
    profile.setdefault("transport", driver_mod.TRANSPORT)
    if not args.no_web:
        panel_dir = os.path.join(DEVICES_DIR, profile["addr"] + ".panel")
        MONITOR = monitor_mod.Monitor(profile, path, save_profile, driver_mod.MODE == "push", panel_dir)
        url = MONITOR.start(args.web_port, not args.no_browser)
        if os.path.isfile(os.path.join(panel_dir, "index.html")):
            log("监控页：%s（设备面板 %s；内置页面 %sbuiltin）" % (url, panel_dir, url))
        else:
            log("监控页：%s（实时显示设备数据，可在页面上修改取值）" % url)
    runner = Runner(profile, driver_mod, args, env)
    # 指定了 --count / --duration 时只跑一次；否则断线后每 5 秒重连，监控页保持打开
    keep_alive = not args.count and not args.duration
    while True:
        try:
            runner.run_once()
            return
        except KeyboardInterrupt:
            log("已停止")
            return
        except LoginError as e:
            log("错误：%s" % e)
            die(str(e))
        except (ConnectionError, OSError) as e:
            log("连接断开：%s" % e)
            if MONITOR:
                MONITOR.set_status(connected=False, error=str(e))
            if not keep_alive:
                die(str(e))
        try:
            time.sleep(5)
            log("重新连接…")
        except KeyboardInterrupt:
            log("已停止")
            return


def cmd_check(args):
    env = load_env()
    _, profile = load_profile(args.device)
    api = Api(env)
    addr = profile["addr"]
    online = api.request("GET", "/iotapi/system/device/online", params={"addr": addr})
    last = api.request("GET", "/iotapi/system/device/history/last", params={"addr": addr})
    print(json.dumps({"online": online.get("data", online), "last": last.get("data", last)},
                     ensure_ascii=False, indent=2))


def cmd_protocols(_args):
    for protocol in drivers.available():
        print(protocol)


def main():
    parser = argparse.ArgumentParser(description="ALinkIOT 虚拟设备")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="从平台拉取设备和产品，生成虚拟设备配置")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--from-json", metavar="FILE", help="平台「虚拟设备」页面提示词里的设备描述（JSON 文件，- 表示标准输入）")
    g.add_argument("--device-id", help="设备 ID（需要 env.ini 的应用凭证）")
    g.add_argument("--addr", help="设备地址（需要 env.ini 的应用凭证）")
    p.add_argument("--mode", choices=MODES, default="walk", help="数据点默认取值方式，默认 walk（游走）")
    p.add_argument("--interval", type=int, help="主动上报间隔（秒），默认取物模型最小 freq，没有则 30")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("show", help="查看虚拟设备配置")
    p.add_argument("device", help="设备地址或配置文件路径")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("set", help="修改数据点取值方式")
    p.add_argument("device", help="设备地址或配置文件路径")
    p.add_argument("name", help="数据点名，* 表示全部")
    p.add_argument("--value", help="固定值")
    p.add_argument("--mode", choices=MODES)
    p.add_argument("--min", type=float)
    p.add_argument("--max", type=float)
    p.add_argument("--period", type=float, help="正弦周期（秒），默认 600")
    p.add_argument("--interval", type=int, help="同时修改主动上报间隔（秒）")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("run", help="连接平台开始模拟")
    p.add_argument("device", help="设备地址或配置文件路径")
    p.add_argument("--interval", type=int, help="本次运行的上报间隔（秒）")
    p.add_argument("--count", type=int, help="上报（轮询型协议为应答）多少次后退出")
    p.add_argument("--duration", type=int, help="运行多少秒后退出")
    p.add_argument("--web-port", type=int, default=8765, help="本地监控页端口，默认 8765，被占用时依次往后找")
    p.add_argument("--no-browser", action="store_true", help="不自动打开浏览器，只打印监控页地址")
    p.add_argument("--no-web", action="store_true", help="不启动监控页")
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("check", help="查询设备在线状态和最新数据")
    p.add_argument("device", help="设备地址或配置文件路径")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("protocols", help="列出已有 driver 的协议")
    p.set_defaults(func=cmd_protocols)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
