"""
虚拟设备的本地监控页：run 时在 127.0.0.1 启动一个 HTTP 服务，浏览器实时查看设备状态、数据点和收发报文，
并可在页面上修改数据点的取值方式。只用标准库；只监听本机，接口不返回设备密钥。

    GET  /                    面板：devices/<addr>.panel/index.html（用 industrial-screen 等技能生成），没有时用内置页面
    GET  /builtin             内置监控页（web/index.html）
    GET  /<文件>              面板目录下的静态文件（vendor 脚本、图片等）
    GET  /api/state?since=N   设备信息、连接状态、数据点（含最近取值曲线）、序号大于 N 的事件
    GET  /api/tags            按 industrial-screen 数据契约整理的设备与实时点位（quality、timestamp、writable）
    POST /api/points/<name>   修改数据点：{"mode": "fixed|walk|random|sine", "value", "min", "max", "period"}
    POST /api/report          推送型协议立即上报一次
"""
import collections
import datetime
import json
import mimetypes
import os
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
MODES = ("walk", "random", "sine", "fixed")


def event_kind(text):
    if text.startswith(("上报", "应答")):
        return "up"
    if text.startswith("收到"):
        return "down"
    if text.startswith("写入"):
        return "ctrl"
    if text.startswith(("错误", "连接断开", "登录失败")):
        return "error"
    return "info"


class Monitor:
    def __init__(self, profile, profile_file, save_profile, push, panel_dir=None):
        self.profile = profile
        self.panel_dir = panel_dir
        self.profile_file = profile_file
        self.save_profile = save_profile
        self.push = push
        self.lock = threading.Lock()
        self.events = collections.deque(maxlen=300)
        self.seq = 0
        self.history = {p["name"]: collections.deque(maxlen=120) for p in profile["points"]}
        self.current = {}
        self.status = {"connected": False, "since": None, "error": "", "reports": 0, "replies": 0,
                       "commands": 0, "started": time.time()}
        self.report_now = False
        self.server = None
        self.url = None

    # ---- 由运行循环调用

    def event(self, text):
        with self.lock:
            self.seq += 1
            self.events.append({"seq": self.seq, "ts": time.time(), "kind": event_kind(text), "text": text})
            if text.startswith("写入"):
                self.status["commands"] += 1

    def record(self, name, value, raw):
        with self.lock:
            now = time.time()
            self.current[name] = {"value": value, "raw": raw, "ts": now}
            if name in self.history and isinstance(value, (int, float)):
                self.history[name].append([round(now, 1), value])

    def set_status(self, **kw):
        with self.lock:
            self.status.update(kw)

    def count(self, key):
        with self.lock:
            self.status[key] += 1

    def take_report_request(self):
        with self.lock:
            flag, self.report_now = self.report_now, False
            return flag

    # ---- HTTP 接口

    def state(self, since):
        p = self.profile
        with self.lock:
            points = []
            for point in p["points"]:
                name = point["name"]
                item = {k: point.get(k) for k in ("name", "title", "type", "unit", "access", "mode", "value",
                                                   "min", "max", "period", "rate", "offset")}
                item["current"] = self.current.get(name)
                item["history"] = list(self.history.get(name, []))
                points.append(item)
            return {
                "device": {
                    "name": p.get("deviceName"), "addr": p["addr"], "product": p.get("productName"),
                    "protocol": p["protocol"], "transport": p.get("transport"), "host": p["host"],
                    "port": p["ports"].get(p.get("transport") or "tcp"), "tls": p.get("tls"),
                    "auth": p["auth"].get("desc"), "push": self.push, "interval": p.get("interval"),
                },
                "status": dict(self.status, now=time.time()),
                "points": points,
                "events": [e for e in self.events if e["seq"] > since],
                "seq": self.seq,
            }

    def tags(self):
        """industrial-screen 的数据契约（references/data-contract.md）：设备 + 实时点位"""
        p = self.profile
        now = time.time()
        stale_after = max(3 * float(p.get("interval") or 30), 90)
        iso = lambda ts: datetime.datetime.fromtimestamp(ts).astimezone().isoformat(timespec="seconds") if ts else None
        with self.lock:
            connected = self.status["connected"]
            tags = []
            for point in p["points"]:
                cur = self.current.get(point["name"])
                if not connected:
                    quality = "BAD"
                elif not cur:
                    quality = "UNCERTAIN"
                elif now - cur["ts"] > stale_after:
                    quality = "STALE"
                else:
                    quality = "GOOD"
                tags.append({
                    "tagId": "%s.%s" % (p["addr"], point["name"]),
                    "name": point.get("title") or point["name"],
                    "value": cur["value"] if cur else None,
                    "raw": cur["raw"] if cur else None,
                    "unit": point.get("unit") or "",
                    "min": point.get("min"),
                    "max": point.get("max"),
                    "quality": quality,
                    "timestamp": iso(cur["ts"]) if cur else None,
                    "alarmState": "NORMAL",
                    "writable": point.get("access") in ("rw", "write"),
                    "simMode": point.get("mode"),
                    "history": list(self.history.get(point["name"], [])),
                })
            last = max([c["ts"] for c in self.current.values()] or [0])
            return {
                "device": {
                    "deviceId": p["addr"],
                    "name": p.get("deviceName") or p["addr"],
                    "product": p.get("productName"),
                    "protocol": p["protocol"],
                    "state": "RUNNING" if connected else "OFFLINE",
                    "mode": "REMOTE",
                    "health": 100 if connected else 0,
                    "alarmLevel": "NONE",
                    "lastSeen": iso(last),
                    "communication": {"connected": connected, "error": self.status["error"],
                                      "endpoint": "%s:%s" % (p["host"], p["ports"].get(p.get("transport") or "tcp"))},
                    "simulated": True,
                },
                "tags": tags,
                "events": list(self.events)[-50:],
            }

    def update_point(self, name, body):
        with self.lock:
            point = next((x for x in self.profile["points"] if x["name"] == name), None)
            if point is None:
                return 404, {"error": "没有数据点 %s" % name}
            mode = body.get("mode")
            if mode is not None and mode not in MODES:
                return 400, {"error": "mode 只能是 " + "、".join(MODES)}
            try:
                for key in ("min", "max", "period"):
                    if body.get(key) not in (None, ""):
                        point[key] = float(body[key])
                if body.get("value") not in (None, ""):
                    point["value"] = body["value"] if point["type"] == "string" else float(body["value"])
                    if point["type"] in ("integer", "int"):
                        point["value"] = int(round(point["value"]))
                    mode = mode or "fixed"
            except (TypeError, ValueError):
                return 400, {"error": "数值格式不对"}
            if mode:
                point["mode"] = mode
                if mode == "fixed" and "value" not in point:
                    point["value"] = (point["min"] + point["max"]) / 2
            self.save_profile(self.profile_file, self.profile)
            if self.push:
                self.report_now = True
        self.event("页面修改 %s：%s" % (name, json.dumps(body, ensure_ascii=False)))
        return 200, {"ok": True}

    def start(self, port, open_browser):
        monitor = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # 不刷屏
                pass

            def reply(self, code, body, ctype="application/json; charset=utf-8"):
                data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def send_file(self, path):
                ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
                    ctype += "; charset=utf-8"
                with open(path, "rb") as f:
                    self.reply(200, f.read(), ctype)

            def do_GET(self):
                url = urllib.parse.urlparse(self.path)
                path = urllib.parse.unquote(url.path)
                panel = monitor.panel_dir if monitor.panel_dir and os.path.isfile(
                    os.path.join(monitor.panel_dir, "index.html")) else None
                if path == "/api/state":
                    since = urllib.parse.parse_qs(url.query).get("since", ["0"])[0]
                    self.reply(200, monitor.state(int(since) if since.isdigit() else 0))
                elif path == "/api/tags":
                    self.reply(200, monitor.tags())
                elif path in ("/builtin", "/builtin/") or (path in ("/", "/index.html") and not panel):
                    self.send_file(os.path.join(WEB_DIR, "index.html"))
                elif panel:
                    # 面板目录下的静态文件；禁止跳出目录
                    rel = "index.html" if path in ("/", "") else path.lstrip("/")
                    full = os.path.realpath(os.path.join(panel, rel))
                    if full.startswith(os.path.realpath(panel) + os.sep) and os.path.isfile(full):
                        self.send_file(full)
                    else:
                        self.reply(404, {"error": "not found"})
                else:
                    self.reply(404, {"error": "not found"})

            def do_POST(self):
                url = urllib.parse.urlparse(self.path)
                length = int(self.headers.get("Content-Length") or 0)
                try:
                    body = json.loads(self.rfile.read(length) or b"{}") if length else {}
                except ValueError:
                    return self.reply(400, {"error": "请求体不是 JSON"})
                if url.path.startswith("/api/points/"):
                    name = urllib.parse.unquote(url.path[len("/api/points/"):])
                    code, resp = monitor.update_point(name, body if isinstance(body, dict) else {})
                    self.reply(code, resp)
                elif url.path == "/api/report":
                    if not monitor.push:
                        return self.reply(400, {"error": "该协议由平台轮询，不主动上报"})
                    with monitor.lock:
                        monitor.report_now = True
                    self.reply(200, {"ok": True})
                else:
                    self.reply(404, {"error": "not found"})

        # 端口被占用时依次往后找
        last_error = None
        for candidate in range(port, port + 20) if port else [0]:
            try:
                self.server = ThreadingHTTPServer(("127.0.0.1", candidate), Handler)
                break
            except OSError as e:
                last_error = e
        if self.server is None:
            raise OSError("监控页端口 %s 起都被占用：%s" % (port, last_error))
        self.server.daemon_threads = True
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.url = "http://127.0.0.1:%d/" % self.server.server_address[1]
        if open_browser:
            try:
                import webbrowser
                webbrowser.open(self.url)
            except Exception:  # 没有图形界面时只打印地址
                pass
        return self.url
