---
name: alinkiot-vdevice
description: ALinkIOT 平台虚拟设备。按平台上选定设备的产品物模型和凭证，用 Python 模拟一台真实设备接入平台（MQTT / TCP），按产品协议上报数据、应答平台轮询、接收下发控制；运行时在本机打开实时监控页，可配合 industrial-screen 技能生成设备面板。内置 Modbus-RTU、mqtt-json、tcp-json，其它协议按 references/protocols/ 下的说明编写 driver。用于联调、演示、告警和大屏测试，不需要真实硬件。
---

# ALinkIOT 虚拟设备

用设备在平台上的真实身份接入，走和真实设备完全相同的协议，所以平台上的在线状态、数据入库、告警、场景和控制都能完整测试。

- 脚本：`scripts/vdevice.py`，只依赖 Python 3.8+ 标准库
- 协议 driver：`scripts/drivers/<协议模块名>.py`
- 协议说明：`references/protocols/<协议标识>.md`，总览见 `references/protocols/README.md`
- 设备面板：`references/panel.md`（用 industrial-screen 技能生成，`run` 时由本地监控服务提供）

## 两种用法

**A. 平台「虚拟设备」页面生成的提示词（常用）**：提示词里已经写明设备、产品、连接方式、登录方式和协议文档，并附一段设备描述 JSON（含物模型和协议转换配置）。不需要 env.ini，也不访问平台接口。

**B. 用应用凭证从平台拉取**：在 skill 目录下新建 `env.ini`（模板见 `env.ini.example`，填 `host`、`appId`、`Secret`），`init` 时用 `--device-id` 或 `--addr`。`check` 命令也需要它。

## 工作流程

1. **生成配置**
   - 用法 A：把提示词里的设备描述原样保存为 `devices/<addr>.desc.json`，执行 `python3 scripts/vdevice.py init --from-json devices/<addr>.desc.json`。
   - 用法 B：`python3 scripts/vdevice.py init --device-id <设备ID>`，凭证优先用设备 dk/ds，没有就用产品 pk/ps。
   - 生成的 `devices/<addr>.json` 含接入凭证、数据点和协议转换配置。核对 init 输出的协议、接入地址和登录方式是否与提示词一致；协议只支持另一种接入方式时，脚本会提示并自动改用正确的方式。
2. **确认协议**：
   - `python3 scripts/vdevice.py protocols` 列出已有 driver 的协议。
   - 协议没有 driver 时，读提示词指定的 `references/protocols/<协议标识>.md`，按「写 driver 要点」实现 `scripts/drivers/<模块名>.py`（模块名 = 协议标识转小写、非字母数字换成下划线），接口见 `scripts/drivers/__init__.py`，可参照 `modbus_rtu.py`、`mqtt_json.py`。
   - 说明里写「不可模拟」的协议（平台去第三方拉数据），告诉用户原因和说明里给的替代测试办法，不要硬做。
3. **按用户要求调整取值**：`python3 scripts/vdevice.py set <addr> <数据点|*> ...`
   - `--mode walk`（默认，区间内小步游走）、`random`、`sine`（配 `--period` 秒）、`fixed`（配 `--value`）
   - `--min` / `--max` 改区间；`--interval` 改主动上报间隔（秒）
   - 测试告警时，把某个点设成超过告警阈值的固定值。
4. **生成设备面板**（用户没有说不要时都做）：按 `references/panel.md`，用 industrial-screen 技能为这台设备生成实时面板，放到 `devices/<addr>.panel/`。没有该技能时先 `git clone https://github.com/alinkiot/skill-industrial-screen.git` 到 skills 目录；用户赶时间时可以跳过，run 会用内置监控页。
5. **运行**：`python3 scripts/vdevice.py run <addr>`。
   - 启动后会在本机起监控服务并打开浏览器（默认 `http://127.0.0.1:8765/`，被占用时往后找，以输出的地址为准）：有设备面板时显示面板，内置监控页在 `/builtin`。页面实时显示连接状态、每个数据点的当前值和曲线、收发报文，可以直接修改模拟取值。把地址告诉用户。
   - 终端同时打印收发的每一帧，Ctrl+C 停止。不带 `--count` / `--duration` 时断线会每 5 秒自动重连，监控页保持打开；登录被拒（凭证或产品配置错误）会直接退出。
   - `--count N` 上报（轮询型协议为应答）N 次后退出，`--duration S` 运行 S 秒后退出；`--no-browser` 只打印地址，`--no-web` 不起监控服务，`--web-port` 指定端口。
   - 需要长时间运行时放到后台：`nohup python3 scripts/vdevice.py run <addr> --no-browser > devices/<addr>.log 2>&1 &`，告诉用户监控页地址、进程号和停止方法。
6. **验证**：监控页上点位质量为 `GOOD`、数值在更新；再让用户在平台设备详情里看在线状态和最新数据，有 env.ini 时可用 `python3 scripts/vdevice.py check <addr>`。平台显示值 = 原始值 × rate + offset，应与监控页一致。

用户在平台上下发控制时，run 会打印收到的写指令，并把对应数据点改为固定输出写入的值。

## 判断问题

| 现象 | 原因 |
|---|---|
| MQTT 连接被拒，返回码 4 | 设备或密钥不对；mqtt-json 产品没有配置协议转换 |
| TCP 登录返回 `01` / `02` / `99` | 认证失败 / 产品协议在平台上找不到模块 / 其它错误，平台日志有详细原因 |
| TCP 登录后连接立即被关闭，没有错误码 | 平台处理登录时出错，常见是产品配置数据格式不对，需要查平台日志 |
| Modbus 一直没有收到轮询 | 物模型的数据点没有 `modbus` 配置，或 `freq` 很长；轮询周期按 `freq` 秒 |
| check 没有最新数据 | 先看 run 输出是否真的发出；协议转换的路径与报文是否一致；平台数据库是否为该产品建了数据表 |

## 注意

- 设备描述、`devices/*.json` 和 `env.ini` 含设备密钥或应用 Secret，不要提交、不要转发到其它对话或日志。
- 虚拟设备使用真实设备的身份。真实设备同时在线时会互相挤掉，先和用户确认该设备没有在现场运行。
- 网关类产品目前只模拟网关自身，不模拟子设备。
- 不要对生产环境做高频上报；默认间隔取物模型的 `freq`。
